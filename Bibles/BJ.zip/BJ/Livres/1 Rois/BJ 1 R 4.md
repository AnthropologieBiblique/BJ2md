---
aliases : 
- 1 Rois 4
- 1 Rois 4
- 1 R 4
- 1 Kings 4
tags : 
- Bible/1R/4
- français
cssclass : français
---

# 1 Rois 4

###### 1
Le roi Salomon fut roi sur tout Israël, 
###### 2
et voici quels étaient ses grands officiers :Azaryahu fils de Sadoq, prêtre. 
###### 3
Élihaph et Ahiyya, fils de Shisha, secrétaires. Yehoshaphat fils d'Ahilud, héraut. 
###### 4
Benayahu, fils de Yehoyada, chef de l'armée. Sadoq et Ébyatar, prêtres. 
###### 5
Azaryahu fils de Natân, chef des préfets. Zabud fils de Natân, familier du roi,
###### 6
Ahishar, maître du palais. Éliab fils de Joab, chef de l'armée. Adoram fils d'Abda, chef de la corvée. 
###### 7
Salomon avait douze préfets sur tout Israël, qui approvisionnaient le roi et sa maison ; il revenait à chacun d'y pourvoir un mois par an. 
###### 8
Voici leurs noms :Fils de Hur, dans la montagne d'Éphraïm. 
###### 9
Fils de Déqer, à Mahaç, Shaalbim, Bet-Shémesh, Ayyalôn, Bet-Hanân. 
###### 10
Fils de Hésed, à Arubbot ; il avait Soko et tout le pays de Héphèr. 
###### 11
Fils d'Abinadab : tous les coteaux de Dor. Tabaat, fille de Salomon, fut sa femme. 
###### 12
Baana fils d'Ahilud, à Tanak et Megiddo jusqu'au-delà de Yoqméam, et tout Bet-Sheân au-dessous de Yizréel, depuis Bet-Sheân jusqu'à Abel-Mehola, qui est vers Çartân. 
###### 13
Fils de Géber, à Ramot de Galaad ; il avait les Douars de Yaïr, fils de Manassé, qui sont en Galaad ; il avait le territoire d'Argob qui est en Bashân, soixante villes fortes, emmurées et verrouillées de bronze. 
###### 14
Ahinadab fils d'Iddo, à Mahanayim. 
###### 15
Ahimaaç, en Nephtali ; lui aussi épousa une fille de Salomon, Basmat. 
###### 16
Baana fils de Hushaï, dans Asher et aux falaises. 
###### 17
Yehoshaphat fils de Paruah, en Issachar. 
###### 18
Shiméï fils d'Éla, en Benjamin. 
###### 19
Géber fils d'Uri, au pays de Gad, le pays de Sihôn roi des Amorites et d'Og roi du Bashân. En plus, il y a avait un préfet qui était dans le pays. 
###### 20
Juda et Israël étaient nombreux, aussi nombreux que le sable qui est au bord de la mer; ils mangeaient et buvaient et vivaient heureux.
