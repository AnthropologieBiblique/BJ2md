---
aliases : 
- 1 Rois 8
- 1 Rois 8
- 1 R 8
- 1 Kings 8
tags : 
- Bible/1R/8
- français
cssclass : français
---

# 1 Rois 8

###### 1
Alors Salomon convoqua les anciens d'Israël à Jérusalem pour faire monter de la Cité de David, qui est Sion, l'arche de l'alliance de Yahvé. 
###### 2
Tous les hommes d'Israël se rassemblèrent auprès du roi Salomon, au mois d'Étanim, pendant la fête c'est le septième mois , 
###### 3
et les prêtres portèrent l'arche 
###### 4
et la Tente du Rendez-vous avec tous les objets sacrés qui y étaient. 
###### 5
Le roi Salomon et tout Israël avec lui sacrifièrent devant l'arche moutons et bœufs en quantité innombrable et incalculable. 
###### 6
Les prêtres apportèrent l'arche de l'alliance de Yahvé à sa place, au Debir du Temple, c'est-à-dire au Saint des Saints, sous les ailes des chérubins. 
###### 7
En effet, les chérubins étendaient leurs ailes au-dessus de l'emplacement de l'arche et faisaient un abri au-dessus de l'arche et de ses barres. 
###### 8
Celles-ci étaient assez longues pour qu'on vît leur extrémité depuis le Saint devant le Debir, mais pas en dehors de là. elles y sont restées jusqu'à ce jour. 
###### 9
Il n'y avait rien dans l'arche, sauf les deux tables de pierre que Moïse y déposa à l'Horeb, les tables de l'alliance que Yahvé avait conclue avec les Israélites à leur sortie de la terre d'Égypte ; 
###### 10
Or quand les prêtres sortirent du sanctuaire, la nuée remplit le Temple de Yahvé 
###### 11
et les prêtres ne purent pas continuer leur fonction, à cause de la nuée : la gloire de Yahvé remplissait le Temple de Yahvé ! 
###### 12
Alors Salomon dit :" Yahvé a décidé d'habiter la nuée obscure. 
###### 13
Oui, je t'ai construit une demeure princière, une résidence où tu habites à jamais. "
###### 14
Puis le roi se retourna et bénit toute l'assemblée d'Israël, et toute l'assemblée d'Israël se tenait debout. 
###### 15
Il dit : " Béni soit Yahvé, Dieu d'Israël, qui a accompli de sa main ce qu'il avait promis de sa bouche à mon père David en ces termes : 
###### 16
"Depuis le jour où j'ai fait sortir d'Égypte mon peuple Israël, je n'ai pas choisi de ville, dans toutes les tribus d'Israël, pour qu'on y bâtit une maison où serait mon Nom, mais j'ai choisi David pour qu'il commandât à mon peuple Israël. " 
###### 17
Mon père David eut dans l'esprit de bâtir une maison pour le Nom de Yahvé, Dieu d'Israël, 
###### 18
mais Yahvé dit à mon père David : "Tu as eu dans l'esprit de bâtir une maison pour mon Nom, et tu as bien fait. 
###### 19
Seulement, ce n'est pas toi qui bâtiras cette maison, c'est ton fils, issu de tes reins, qui bâtira la maison pour mon Nom. " 
###### 20
Yahvé a réalisé la parole qu'il avait dite : j'ai succédé à mon père David et je me suis assis sur le trône d'Israël comme avait dit Yahvé, j'ai construit la maison pour le Nom de Yahvé, Dieu d'Israël, 
###### 21
et j'y ai fixé un emplacement pour l'arche, où est l'alliance que Yahvé a conclue avec nos pères lorsqu'il les fit sortir du pays d'Égypte. "
###### 22
Puis Salomon se tint devant l'autel de Yahvé, en présence de toute l'assemblée d'Israël ; il étendit les mains vers le ciel 
###### 23
et dit : " Yahvé, Dieu d'Israël ! il n'y a aucun Dieu pareil à toi là-haut dans les cieux ni ici-bas sur la terre, toi qui es fidèle à l'alliance et gardes la bienveillance à l'égard de tes serviteurs, quand ils marchent de tout leur cœur devant toi. 
###### 24
Tu as tenu à ton serviteur David, mon père, la promesse que tu lui avais faite, et ce que tu avais dit de ta bouche, tu l'as accompli aujourd'hui de ta main. 
###### 25
Et maintenant, Yahvé, Dieu d'Israël, tiens à ton serviteur David, mon père, la promesse que tu lui as faite, quand tu as dit : "Tu ne seras jamais dépourvu d'un descendant qui soit devant moi, assis sur le trône d'Israël, à condition que tes fils veillent à leur conduite et marchent devant moi comme tu as marché toi-même devant moi. " 
###### 26
Maintenant donc, Dieu d'Israël, que se vérifie la parole que tu as dite à ton serviteur David, mon père ! 
###### 27
Mais Dieu habiterait-il vraiment avec les hommes sur la terre ? Voici que les cieux et les cieux des cieux ne le peuvent contenir, moins encore cette maison que j'ai construite ! 
###### 28
Sois attentif à la prière et à la supplication de ton serviteur, Yahvé, mon Dieu, écoute l'appel et la prière que ton serviteur fait aujourd'hui devant toi ! 
###### 29
Que tes yeux soient ouverts jour et nuit sur cette maison, sur ce lieu dont tu as dit : "Mon Nom sera là", écoute la prière que ton serviteur fera en ce lieu. 
###### 30
" Écoute la supplication de ton serviteur et de ton peuple Israël lorsqu'ils prieront en ce lieu. Toi, écoute du lieu où tu résides, au ciel, écoute et pardonne. 
###### 31
Supposé qu'un homme pèche contre son prochain et que celui-ci prononce sur lui un serment imprécatoire et le fasse jurer devant ton autel dans ce Temple, 
###### 32
toi, écoute au ciel et agis ; juge entre tes serviteurs : déclare coupable le méchant en faisant retomber sa conduite sur sa tête, et justifie l'innocent en lui rendant selon sa justice. 
###### 33
Quand ton peuple Israël sera battu devant l'ennemi, parce qu'il aura péché contre toi, s'il revient à toi, loue ton Nom, prie et supplie vers toi dans ce Temple, 
###### 34
toi, écoute au ciel, pardonne le péché de ton peuple Israël et ramène-le dans le pays que tu as donné à ses pères. 
###### 35
Quand le ciel sera fermé qu'il n'y aura pas de pluie parce qu'ils auront péché contre toi, s'ils prient en ce lieu, louent ton Nom et se repentent de leur péché, parce que tu les auras humiliés, 
###### 36
toi, écoute au ciel, pardonne le péché de ton serviteur et de ton peuple Israël - tu leur indiqueras la bonne voie qu'ils doivent suivre - et arrose de pluie ta terre, que tu as donnée en héritage à ton peuple. 
###### 37
Quand le pays subira la famine, la peste, la rouille ou la nielle, quand surviendront les sauterelles ou les criquets, quand l'ennemi de ce peuple assiégera l'une de ses portes, quand il y aura n'importe quel fléau ou épidémie, 
###### 38
quelle que soit la prière ou la supplication de quiconque éprouve le remords de sa propre conscience, s'il étend les mains vers ce Temple, 
###### 39
toi, écoute au ciel, où tu résides, pardonne et agis ; rends à chaque homme selon sa conduite, puisque tu connais son cœur - tu es le seul à connaître le cœur de tous -, 
###### 40
en sorte qu'ils te craignent tous les jours qu'ils vivront sur la terre que tu as donnée à nos pères. 
###### 41
" Même l'étranger qui n'est pas d'Israël ton peuple, s'il vient d'un pays lointain à cause de ton Nom - 
###### 42
car on entendra parler de ton grand Nom, de ta main forte et de ton bras étendu -, s'il vient et prie en ce Temple, 
###### 43
toi, écoute-le au ciel, où tu résides, exauce toutes les demandes de l'étranger afin que tous les peuples de la terre reconnaissent ton Nom et te craignent comme fait ton peuple Israël, et qu'ils sachent que ce Temple que j'ai bâti porte ton nom. 
###### 44
Si ton peuple part en guerre contre ses ennemis par le chemin où tu l'auras envoyé et s'il prie Yahvé, tourné vers la ville que tu as choisie et vers le Temple que j'ai construit pour ton Nom, 
###### 45
écoute au ciel sa prière et sa supplication et fais-lui justice. 
###### 46
Quand ils pécheront contre toi - car il n'y a aucun homme qui ne pèche -, quand tu seras irrité contre eux, que tu les livreras à l'ennemi et que leurs conquérants les emmèneront captifs dans un pays ennemi, lointain ou proche, 
###### 47
s'ils rentrent en eux-mêmes dans le pays où ils auront été déportés, s'ils se repentent et te supplient dans le pays de leurs conquérants en disant : "Nous avons péché, nous avons mal agi, nous nous sommes pervertis", 
###### 48
s'ils reviennent à toi de tout leur cœur et de toute leur âme dans le pays des ennemis qui les auront déportés, et s'ils te prient, tournés vers le pays que tu as donné à leurs pères, vers la ville que tu as choisie et le Temple que j'ai bâti pour ton Nom, 
###### 49
écoute au ciel où tu résides, 
###### 50
pardonne à ton peuple les péchés qu'il a commis envers toi et toutes les rébellions dont ils furent coupables, fais-leur trouver grâce devant leurs conquérants, que ceux-ci aient pitié d'eux ; 
###### 51
car ils sont ton peuple et ton héritage, ceux que tu as fait sortir d'Égypte, cette fournaise pour le fer. 
###### 52
" Que tes yeux soient ouverts sur la supplication de ton serviteur et de ton peuple Israël, pour écouter tous les appels qu'ils lanceront vers toi. 
###### 53
Car c'est toi qui les as mis à part comme ton héritage, parmi tous les peuples de la terre, ainsi que tu l'as déclaré par le ministère de ton serviteur Moïse, quand tu as fait sortir nos pères d'Égypte, Seigneur Yahvé ! "
###### 54
Quand Salomon eut achevé d'adresser à Yahvé toute cette prière et cette supplication, il se releva de l'endroit où il était agenouillé, les mains étendues vers le ciel, devant l'autel de Yahvé, 
###### 55
et se tint debout. Il bénit à haute voix toute l'assemblée d'Israël : 
###### 56
" Béni soit Yahvé, dit-il, qui a accordé le repos à son peuple Israël, selon toutes ses promesses ; de toutes les bonnes paroles qu'il a dites par le ministère de son serviteur Moïse, aucune n'a failli. 
###### 57
Que Yahvé notre Dieu soit avec nous, comme il fut avec nos pères, qu'il ne nous abandonne pas et ne nous rejette pas ! 
###### 58
Qu'il incline nos cœurs vers lui, pour que nous suivions toutes ses voies et gardions les commandements, les lois et les ordonnances qu'il a donnés à nos pères. 
###### 59
Puissent ces paroles que j'ai dites en suppliant devant Yahvé rester présentes jour et nuit à Yahvé notre Dieu, pour qu'il rende justice à son serviteur et justice à son peuple Israël, selon les besoins de chaque jour ; 
###### 60
tous les peuples de la terre sauront alors que Yahvé seul est Dieu, qu'il n'y en a point d'autre, 
###### 61
et votre cœur sera tout entier à Yahvé, notre Dieu, observant ses lois et gardant ses commandements comme maintenant. "
###### 62
Le roi et tout Israël avec lui sacrifièrent devant Yahvé. 
###### 63
Comme sacrifices de communion qu'il présenta à Yahvé, Salomon offrit vingt-deux mille bœufs et cent vingt mille moutons, et le roi et tous les Israélites dédièrent le Temple de Yahvé. 
###### 64
En ce jour, le roi consacra le milieu de la cour qui est devant le Temple de Yahvé ; c'est là qu'il offrit l'holocauste, l'oblation et les graisses des sacrifices de communion, parce que l'autel de bronze qui était devant Yahvé était trop petit pour contenir l'holocauste, l'oblation et les graisses des sacrifices de communion. 
###### 65
En ce temps-là, Salomon célébra la fête, et tous les Israélites avec lui, un grand rassemblement depuis l'Entrée de Hamat jusqu'au Torrent d'Égypte, devant Yahvé notre Dieu, pendant sept jours. 
###### 66
Puis, le huitième jour, il congédia les gens ; ils bénirent le roi et s'en allèrent chacun chez soi, joyeux et le cœur content de tout le bien que Yahvé avait fait à son serviteur David et à son peuple Israël. 
