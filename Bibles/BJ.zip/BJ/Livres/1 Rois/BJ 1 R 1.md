---
aliases : 
- 1 Rois 1
- 1 Rois 1
- 1 R 1
- 1 Kings 1
tags : 
- Bible/1R/1
- français
cssclass : français
---

# 1 Rois 1

###### 1
Le roi David était un vieillard avancé en âge ; on lui mit des couvertures sans qu'il pût se réchauffer. 
###### 2
Alors ses serviteurs lui dirent : " Qu'on cherche pour Monseigneur le roi une jeune fille qui assiste le roi et qui le soigne : elle couchera sur ton sein et cela tiendra chaud à Monseigneur le roi. " 
###### 3
Ayant donc cherché une belle jeune fille dans tout le territoire d'Israël, on trouva Abishag de Shunem et on l'amena au roi. 
###### 4
Cette jeune fille était extrêmement belle ; elle soigna le roi et le servit, mais il ne la connut pas. 
###### 5
Or Adonias, le fils de Haggit, jouait au prince en disant : " C'est moi qui régnerai ! " Il s'était procuré char et attelage et cinquante gardes qui couraient devant lui. 
###### 6
De sa vie, son père ne l'avait contrarié en disant : " Pourquoi agis-tu ainsi ? " Il avait lui aussi très belle apparence et sa mère l'avait enfanté après Absalom. 
###### 7
Il s'aboucha avec Joab fils de Çeruya et avec le prêtre Ébyatar, qui se rallièrent à la cause d'Adonias ; 
###### 8
mais ni le prêtre Sadoq, ni Benayahu fils de Yehoyada, ni le prophète Natân, ni Shiméï et Reï, ni les preux de David, n'étaient avec Adonias. 
###### 9
Un jour qu'Adonias immolait des moutons, des bœufs et des veaux gras à la Pierre-qui-glisse, qui est près de la source du Foulon, il invita tous ses frères, les princes royaux, et tous les Judéens au service du roi, 
###### 10
mais il n'invita pas le prophète Natân, ni Benayahu, ni les preux, ni son frère Salomon. 
###### 11
Alors Natân dit à Bethsabée, la mère de Salomon : " N'as-tu pas appris qu'Adonias fils de Haggit est devenu roi à l'insu de notre seigneur David ? 
###### 12
Eh bien ! laisse-moi te donner maintenant un conseil, pour que tu sauves ta vie et celle de ton fils Salomon. 
###### 13
Va, entre chez le roi David, et dis-lui : "N'est-ce pas toi, Monseigneur le roi, qui as fait ce serment à ta servante : Ton fils Salomon régnera après moi et c'est lui qui s'assiéra sur mon trône ? Comment donc Adonias est-il devenu roi ?" 
###### 14
Et pendant que tu seras là, conversant encore avec le roi, j'entrerai après toi et j'appuierai tes paroles. "
###### 15
Bethsabée se rendit chez le roi dans sa chambre il était très vieux et Abishag de Shunem le servait . 
###### 16
Elle s'agenouilla et se prosterna devant le roi, et le roi dit : " Que désires-tu ? " 
###### 17
Elle lui répondit : " Monseigneur, tu as juré à ta servante par Yahvé ton Dieu : "Ton fils Salomon régnera après moi, et c'est lui qui s'assiéra sur mon trône. " 
###### 18
Voici maintenant qu'Adonias est devenu roi, et toi, Monseigneur le roi, tu n'en saurais rien ! 
###### 19
Car il a immolé quantité de bœufs, de veaux gras et de moutons, et il a invité tous les princes royaux, le prêtre Ébyatar, le général Joab, mais ton serviteur Salomon, il ne l'a pas invité ! 
###### 20
Pourtant c'est vers toi, Monseigneur le roi, que tout Israël regarde pour que tu lui désignes le successeur de Monseigneur le roi. 
###### 21
Et quand Monseigneur le roi sera couché avec ses pères, moi et mon fils Salomon, nous expierons cela ! "
###### 22
Elle parlait encore que le prophète Natân arriva. 
###### 23
On annonça au roi : " Le prophète Natân est là. " Il entra chez le roi et se prosterna devant lui, la face contre terre. 
###### 24
Natân dit : " Monseigneur le roi, tu as donc décrété : "Adonias régnera après moi et s'assiéra sur mon trône" ! 
###### 25
Car il est descendu aujourd'hui, il a immolé quantité de bœufs, de veaux gras et de moutons et il a invité tous les princes royaux, les officiers de l'armée et le prêtre Ébyatar ; les voilà qui mangent et boivent en sa présence et qui crient : "Vive le roi Adonias ! " 
###### 26
Mais moi ton serviteur, le prêtre Sadoq, Benayahu fils de Yehoyada et ton serviteur Salomon, il ne nous a pas invités. 
###### 27
Se peut-il que la chose vienne de Monseigneur le roi et que tu n'aies pas fait savoir à tes fidèles qui succéderait sur le trône à Monseigneur le roi ? "
###### 28
Le roi David prit la parole et dit : " Appelez-moi Bethsabée. " Elle entra chez le roi et se tint devant lui. 
###### 29
Alors le roi lui fit ce serment : " Par Yahvé vivant, qui m'a délivré de toutes les angoisses, 
###### 30
comme je t'ai juré par Yahvé, Dieu d'Israël, que ton fils Salomon régnerait après moi et s'assiérait à ma place sur le trône, ainsi ferai-je aujourd'hui même. " 
###### 31
Bethsabée s'agenouilla, la face contre terre, se prosterna devant le roi et dit : " Vive à jamais Monseigneur le roi David ! " 
###### 32
Puis le roi David dit : " Appelez-moi le prêtre Sadoq, le prophète Natân et Benayahu fils de Yehoyada. " Ils entrèrent chez le roi 
###### 33
et celui-ci leur dit : " Prenez avec vous la garde royale, faites monter mon fils Salomon sur ma propre mule et faites-le descendre à Gihôn. 
###### 34
Là, le prêtre Sadoq et le prophète Natân lui donneront l'onction comme roi d'Israël, vous sonnerez du cor et vous crierez : "Vive le roi Salomon ! " 
###### 35
Vous remonterez à sa suite, il entrera s'asseoir sur mon trône et régnera à ma place, car c'est lui que j'ai institué chef sur Israël et sur Juda. " 
###### 36
Benayahu fils de Yehoyada répondit au roi : " Amen ! Que parle ainsi Yahvé, le Dieu de Monseigneur le roi ! 
###### 37
Comme Yahvé a été avec Monseigneur le roi, qu'il soit avec Salomon et qu'il magnifie son trône encore plus que le trône de Monseigneur le roi David ! "
###### 38
Le prêtre Sadoq, le prophète Natân, Benayahu fils de Yehoyada, les Kerétiens et les Pelétiens descendirent ; ils mirent Salomon sur la mule du roi David et ils le menèrent à Gihôn. 
###### 39
Le prêtre Sadoq prit dans la Tente la corne d'huile et oignit Salomon, on sonna du cor et tout le peuple cria : " Vive le roi Salomon ! " 
###### 40
Puis tout le peuple monta à sa suite, et le peuple jouait de la flûte et manifestait une grande joie, avec des clameurs à fendre la terre. 
###### 41
Adonias et tous ses convives entendirent le bruit ; ils avaient alors fini de manger. Joab aussi entendit le son du cor et demanda : " Pourquoi cette rumeur de la ville en émoi ? " 
###### 42
Comme il parlait encore, voici qu'arriva Yonatân, le fils du prêtre Ébyatar, et Adonias dit : " Viens ! car tu es un honnête homme et tu dois apporter une bonne nouvelle. " 
###### 43
Yonatân répondit : " Ah oui ! notre seigneur le roi David a fait roi Salomon ! 
###### 44
Le roi a envoyé avec lui le prêtre Sadoq, le prophète Natân, Benayahu fils de Yehoyada, les Kerétiens et les Pelétiens, ils l'ont mis sur la mule du roi, 
###### 45
le prêtre Sadoq et le prophète Natân l'ont sacré roi à Gihôn, ils sont remontés de là en poussant des cris de joie et la ville est en émoi ; voilà le bruit que vous avez entendu. 
###### 46
Plus que cela : Salomon s'est assis sur le trône royal, 
###### 47
et les officiers du roi sont venus féliciter notre seigneur le roi David en disant : "Que ton Dieu glorifie le nom de Salomon plus encore que ton nom et qu'il exalte son trône plus que le tien ! " et le roi s'est prosterné sur son lit, 
###### 48
et puis il a parlé ainsi : "Béni soit Yahvé, Dieu d'Israël, qui a permis que mes yeux voient aujourd'hui l'un de mes descendants assis sur mon trône. " "
###### 49
Alors tous les invités d'Adonias furent pris de panique, ils se levèrent et partirent chacun de son côté. 
###### 50
Pour Adonias, il eut peur de Salomon, il se leva et s'en alla saisir les cornes de l'autel. 
###### 51
On en informa ainsi Salomon : " Voici qu'Adonias a eu peur du roi Salomon et qu'il a saisi les cornes de l'autel en disant : Que le roi Salomon me jure d'abord qu'il ne fera pas mourir son serviteur par l'épée. " 
###### 52
Salomon dit : " S'il se conduit en honnête homme, pas un de ses cheveux ne tombera à terre, mais si on le trouve en défaut, alors il mourra. " 
###### 53
Et Salomon ordonna qu'on le fit descendre de l'autel ; il vint se prosterner devant Salomon qui lui dit : " Va dans ta maison. " 
