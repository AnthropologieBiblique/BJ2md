---
aliases : 
- 1 Rois 5
- 1 Rois 5
- 1 R 5
- 1 Kings 5
tags : 
- Bible/1R/5
- français
cssclass : français
---

# 1 Rois 5

###### 1
Salomon étendit son pouvoir sur tous les royaumes depuis le Fleuve jusqu'au pays des Philistins et jusqu'à la frontière d'Egypte. Ils apportèrent leur tribut et servirent Salomon toute sa vie.
###### 2
Salomon recevait chaque jour comme vivres : 30 muids de fleur de farine et 60 muids de farine,
###### 3
dix boeufs d'engrais, vingt boeufs de pâture, cent moutons, sans compter les cerfs, gazelles, antilopes et coucous engraissés.
###### 4
Car il dominait sur toute la Transeuphratène depuis Thapsaque jusqu'à Gaza sur tous les rois de Transeuphratène et il avait la paix sur toutes ses frontières alentour.
###### 5
Juda et Israël habitèrent en sécurité chacun sous sa vigne et sous son figuier, depuis Dan jusqu'à Bersabée, pendant toute la vie de Salomon.
###### 6
Salomon avait pour le service de ses chars 4.000 stalles et 12.000 chevaux.
###### 7
Ces préfets pourvoyaient à l'entretien de Salomon et de tous ceux qui avaient accès à la table du roi, chacun pendant un mois ; ils ne le laissaient manquer de rien. 
###### 8
Ils fournissaient aussi l'orge et la paille pour les chevaux et les bêtes de trait, à l'endroit où il fallait, chacun selon la consigne qu'il avait reçue. 
###### 9
Dieu donna à Salomon une sagesse et une intelligence extrêmement grandes et un cœur aussi vaste que le sable qui est au bord de la mer. 
###### 10
La sagesse de Salomon fut plus grande que la sagesse de tous les fils de l'Orient et que toute la sagesse de l'Égypte. 
###### 11
Il fut sage plus que n'importe qui, plus que l'Ezrahite Étân, que les fils de Mahôl, Hémân, Kalkol et Darda ; sa renommée s'étendait à toutes les nations d'alentour. 
###### 12
Il prononça trois mille sentences et ses cantiques étaient au nombre de mille cinq. 
###### 13
Il parla des plantes, depuis le cèdre qui est au Liban jusqu'à l'hysope qui croît sur les murs ; il parla aussi des quadrupèdes, des oiseaux, des reptiles et des poissons. 
###### 14
On vint de tous les peuples pour entendre la sagesse de Salomon et il reçut un tribut de tous les rois de la terre, qui avaient ouï parler de sa sagesse. 
###### 15
Le roi de Tyr, Hiram, envoya ses serviteurs en ambassade auprès de Salomon, car il avait appris qu'on l'avait sacré roi à la place de son père et Hiram avait toujours été l'ami de David. 
###### 16
Et Salomon envoya ce message à Hiram : 
###### 17
" Tu sais bien que mon père David n'a pu construire un temple pour le Nom de Yahvé, son Dieu, à cause de la guerre que les ennemis lui ont faite de tous côtés, jusqu'à ce que Yahvé les eût mis sous la plante de ses pieds. 
###### 18
Maintenant, Yahvé mon Dieu m'a donné la tranquillité alentour : je n'ai ni adversaire ni contrariété du sort. 
###### 19
Je pense donc à construire un temple au Nom de Yahvé mon Dieu, selon ce que Yahvé a dit à mon père David : "Ton fils que je mettrai à ta place sur ton trône, c'est lui qui construira le Temple pour mon Nom. " 
###### 20
Maintenant, ordonne que l'on me coupe des arbres du Liban ; mes serviteurs seront avec tes serviteurs et je te payerai la location de tes serviteurs selon tout ce que tu me fixeras. Tu sais en effet qu'il n'y a personne chez nous qui soit habile à abattre les arbres comme les Sidoniens. " 
###### 21
Lorsque Hiram entendit les paroles de Salomon, il éprouva une grande joie et dit : " Béni soit aujourd'hui Yahvé qui a donné à David un fils sage qui commande à ce grand peuple ! " 
###### 22
Et Hiram manda ceci à Salomon : " J'ai reçu ton message. Pour moi, je satisferai tout ton désir en bois de cèdre et en bois de genévrier. 
###### 23
Mes serviteurs les descendront du Liban à la mer, je les ferai remorquer à l'endroit que tu me manderas, je les délierai là et toi, tu les prendras. De ton côté, tu assureras selon mon désir l'approvisionnement de ma maison. " 
###### 24
Hiram procura à Salomon des bois de cèdre et des bois de genévrier autant qu'il en voulut, 
###### 25
et Salomon donna à Hiram vingt mille muids de froment, comme nourriture de sa maison, et vingt mille mesures d'huile vierge. Voilà ce que Salomon donnait à Hiram chaque année. 
###### 26
Yahvé accorda la sagesse à Salomon, comme il le lui avait promis ; la bonne entente régna entre Hiram et Salomon et tous les deux conclurent un accord. 
###### 27
Le roi Salomon leva des hommes de corvée dans tout Israël ; il y eut trente mille hommes de corvée. 
###### 28
Il les envoya au Liban, dix mille par mois, à tour de rôle : ils étaient un mois au Liban et deux mois à la maison ; Adoram était chef de la corvée. 
###### 29
Salomon eut aussi soixante-dix mille porteurs et quatre-vingt-mille carriers dans la montagne, 
###### 30
sans compter les officiers des préfets qui dirigeaient ses travaux ; ceux-ci étaient trois mille trois cents et commandaient au peuple employé aux travaux. 
###### 31
Le roi ordonna d'extraire de grands blocs, des pierres de choix, pour établir les fondations du Temple, des pierres de taille. 
###### 32
Les ouvriers de Salomon et ceux de Hiram et les Giblites taillèrent et mirent en place le bois et la pierre pour la construction du Temple. 
