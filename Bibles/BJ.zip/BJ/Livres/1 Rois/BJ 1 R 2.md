---
aliases : 
- 1 Rois 2
- 1 Rois 2
- 1 R 2
- 1 Kings 2
tags : 
- Bible/1R/2
- français
cssclass : français
---

# 1 Rois 2

###### 1
Comme la vie de David approchait de sa fin, il fit ces recommandations à son fils Salomon : 
###### 2
" Je m'en vais par le chemin de tout le monde. Sois fort et montre-toi un homme ! 
###### 3
Tu suivras les observances de Yahvé ton Dieu, en marchant selon ses voies, en gardant ses lois, ses commandements, ses ordonnances et ses instructions, selon qu'il est écrit dans la loi de Moïse, afin de réussir en toutes tes œuvres et tous tes projets, 
###### 4
pour que Yahvé accomplisse cette promesse qu'il m'a faite : "Si tes fils surveillent leur conduite en marchant loyalement devant moi, de tout leur cœur et de toute leur âme, tu ne manqueras jamais de quelqu'un sur le trône d'Israël. "
###### 5
Tu sais aussi ce que m'a fait Joab fils de Çeruya, ce qu'il a fait aux deux chefs de l'armée d'Israël, Abner fils de Ner et Amasa fils de Yéter, comment il les a tués, comment il a vengé pendant la paix le sang de la guerre et taché d'un sang innocent le ceinturon de mes reins et la sandale de mes pieds ; 
###### 6
tu agiras sagement en ne laissant pas ses cheveux blancs descendre en paix au shéol. 
###### 7
Quant aux fils de Barzillaï le Galaadite, tu les traiteras avec bonté et ils seront parmi ceux qui mangent à ta table, car ils m'ont ainsi secouru quand je fuyais devant ton frère Absalom. 
###### 8
Tu as près de toi Shiméï fils de Géra, le Benjaminite de Bahurim, qui m'a maudit atrocement au jour de mon départ pour Mahanayim, mais il est descendu à ma rencontre au Jourdain et je lui ai juré par Yahvé que je ne le tuerais pas par l'épée. 
###### 9
Pour toi, tu ne le laisseras pas impuni et, en homme avisé que tu es, tu sauras quoi lui faire pour conduire dans le sang ses cheveux blancs au shéol. "
###### 10
Et David se coucha avec ses pères et on l'ensevelit dans la Cité de David. 
###### 11
Le règne de David sur Israël a duré quarante ans : à Hébron il a régné sept ans, à Jérusalem il a régné trente-trois ans. 
###### 12
Salomon s'assit sur le trône de David son père et son pouvoir devint très ferme. 
###### 13
Adonias fils de Haggit se rendit chez Bethsabée, mère de Salomon. Elle demanda : " Est-ce la paix que tu apportes ? " Il répondit : " Oui. " 
###### 14
Il dit : " J'ai à te parler. " Elle dit : " Parle. " 
###### 15
Il reprit : " Tu sais bien que la royauté me revenait et que tout Israël s'attendait à ce que je règne, mais la royauté m'a échappé et est échue à mon frère, car elle lui est venue de Yahvé. 
###### 16
Maintenant, j'ai une seule demande à te faire, ne me rebute pas. " Elle lui dit : " Parle. " 
###### 17
Il reprit : " Dis, je te prie, au roi Salomon - car il ne te rebutera pas - qu'il me donne Abishag de Shunem pour femme. " 
###### 18
Elle répondit : " C'est bien, je parlerai de toi au roi. " 
###### 19
Bethsabée se rendit donc chez le roi Salomon pour lui parler d'Adonias, et le roi se leva à sa rencontre et se prosterna devant elle, puis il s'assit sur son trône, on mit un siège pour la mère du roi et elle s'assit à sa droite. 
###### 20
Elle dit : " Je n'ai qu'une petite demande à te faire, ne me rebute pas. " Le roi lui répondit : " Demande, ô ma mère, car je ne te rebuterai pas. " 
###### 21
Elle continua : " Qu'on donne Abishag de Shunem pour femme à ton frère Adonias. " 
###### 22
Le roi Salomon reprit et dit à sa mère : " Et pourquoi demandes-tu pour Adonias Abishag de Shunem ? Demande donc pour lui la royauté ! Car il est mon frère aîné et il a pour lui le prêtre Ébyatar et Joab fils de Çeruya ! " 
###### 23
Et le roi Salomon jura ainsi par Yahvé : " Que Dieu me fasse tel mal et y ajoute encore tel autre, si ce n'est pas au prix de sa vie qu'Adonias a prononcé cette parole ! 
###### 24
Eh bien, par Yahvé vivant, qui m'a confirmé et fait asseoir sur le trône de mon père David et qui lui a donné une maison comme il avait promis, aujourd'hui même Adonias sera mis à mort. " 
###### 25
Et le roi Salomon en chargea Benayahu fils de Yehoyada, qui le frappa, et il mourut. 
###### 26
Quant au prêtre Ébyatar, le roi lui dit : " Va à Anatot dans ton domaine, car tu mérites la mort, mais je ne te ferai pas mourir aujourd'hui, car tu as porté l'arche de Yahvé en présence de mon père David et partagé toutes les épreuves de mon père. " 
###### 27
Et Salomon exclut Ébyatar du sacerdoce de Yahvé, accomplissant ainsi la parole que Yahvé avait prononcée contre la maison d'Éli à Silo. 
###### 28
Lorsque la nouvelle parvint à Joab -car Joab avait pris parti pour Adonias bien qu'il n'eût pas pris parti pour Absalom -, il s'enfuit à la Tente de Yahvé et saisit les cornes de l'autel. 
###### 29
On avertit le roi Salomon : " Joab s'est réfugié à la Tente de Yahvé et voici qu'il est à côté de l'autel. " Alors Salomon envoya dire à Joab : " Qu'est-ce qui t'a pris de fuir à l'autel ? " Joab répondit : " J'ai eu peur de toi et je me suis réfugié près de Yahvé. " Alors Salomon envoya Benayahu fils de Yehoyada en disant : " Va et frappe-le ! " 
###### 30
Benayahu alla à la Tente de Yahvé et lui dit : " Par ordre du roi, sors ! " Il répondit : " Non, je mourrai ici. " Benayahu rapporta la chose au roi : " Voilà ce que Joab a dit et ce qu'il m'a répondu. " 
###### 31
Le roi lui dit : " Fais comme il a dit ; frappe-le, puis enterre-le. Ainsi tu ôteras aujourd'hui de sur moi et de sur ma famille le sang innocent qu'a versé Joab. 
###### 32
Yahvé fera retomber son sang sur sa tête parce qu'il a frappé deux hommes plus justes et meilleurs que lui et les a tués par l'épée à l'insu de mon père David : Abner fils de Ner, chef de l'armée d'Israël, et Amasa fils de Yéter, chef de l'armée de Juda. 
###### 33
Que leur sang retombe sur la tête de Joab et de sa postérité à jamais, mais que David et sa postérité et sa dynastie et son trône aient toujours la paix par Yahvé ! " 
###### 34
Benayahu fils de Yehoyada partit, il frappa Joab et le mit à mort, et on l'enterra chez lui au désert. 
###### 35
Le roi mit Benayahu fils de Yehoyada à sa place à la tête de l'armée ; et le roi mit le prêtre Sadoq à la place d'Ébyatar. 
###### 36
Le roi fit appeler Shiméï et lui dit : " Construis-toi une maison, à Jérusalem : tu y habiteras, mais ne t'en écarte pas où que ce soit. 
###### 37
Le jour où tu sortiras et franchiras le ravin du Cédron, sache bien que tu mourras certainement. Ton sang sera sur ta tête. " 
###### 38
Shiméï répondit au roi : " C'est bien. Comme Monseigneur le roi a ordonné, ainsi fera ton serviteur ", et Shiméï demeura longtemps à Jérusalem. 
###### 39
Mais, au bout de trois ans, il arriva que deux esclaves de Shiméï s'enfuirent chez Akish fils de Maaka, le roi de Gat, et on avertit Shiméï : " Tes esclaves sont à Gat. " 
###### 40
Alors Shiméï se leva, sella son âne et partit pour Gat chez Akish chercher ses esclaves ; Shiméï alla et ramena ses esclaves de Gat. 
###### 41
On apprit à Salomon que Shiméï était allé de Jérusalem à Gat et qu'il était revenu. 
###### 42
Le roi fit appeler Shiméï et lui dit : " Ne t'avais-je pas fait jurer par Yahvé et ne t'avais-je pas averti : "Le jour où tu sortiras pour aller où que ce soit, sache bien que tu mourras certainement" ? Et tu m'as dit : "Bonne est la parole que j'ai entendue. " 
###### 43
Pourquoi n'as-tu pas observé le serment de Yahvé et l'ordre que je t'avais intimé ? " 
###### 44
Puis le roi dit à Shiméï : " Tu connais par cœur tout le mal que tu as fait à mon père David ; Yahvé va faire retomber ta méchanceté sur ta propre tête. 
###### 45
Mais béni soit le roi Salomon, et que le trône de David subsiste devant Yahvé pour toujours ! " 
###### 46
Le roi fit commandement à Benayahu fils de Yehoyada ; il sortit et frappa Shiméï qui mourut. La royauté fut alors affermie dans la main de Salomon. 
