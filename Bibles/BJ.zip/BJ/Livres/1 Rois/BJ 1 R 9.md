---
aliases : 
- 1 Rois 9
- 1 Rois 9
- 1 R 9
- 1 Kings 9
tags : 
- Bible/1R/9
- français
cssclass : français
---

# 1 Rois 9

###### 1
Après que Salomon eut achevé de construire le Temple de Yahvé, le palais royal et tout ce qu'il plut à Salomon de réaliser, 
###### 2
Yahvé apparut une seconde fois à Salomon comme il lui était apparu à Gabaôn. 
###### 3
Yahvé lui dit : " J'exauce la prière et la supplication que tu m'as présentées. Je consacre cette maison que tu as bâtie, en y plaçant mon Nom à jamais ; mes yeux et mon cœur y seront toujours. 
###### 4
Pour toi, si tu marches devant moi comme a fait ton père David, dans l'innocence du cœur et la droiture, si tu agis selon tout ce que je te commande et si tu observes mes lois et mes ordonnances, 
###### 5
je maintiendrai pour toujours ton trône royal sur Israël, comme je l'ai promis à ton père David quand j'ai dit : "Il ne te manquera jamais un descendant sur le trône d'Israël" ; 
###### 6
mais si vous m'abandonnez, vous et vos fils, si vous n'observez pas les commandements et les lois que je vous ai proposés, si vous allez servir d'autres dieux et leur rendez hommage, 
###### 7
alors je retrancherai Israël du pays que je lui ai donné ; ce Temple que j'ai consacré à mon Nom, je le rejetterai de ma présence, et Israël sera la fable et la risée de tous les peuples. 
###### 8
Ce Temple en ruines, tous ceux qui le longeront seront stupéfaits ; ils siffleront et diront : "Pourquoi Yahvé a-t-il fait cela à ce pays et à ce Temple ?" 
###### 9
et l'on répondra : "Parce qu'ils ont abandonné Yahvé leur Dieu qui avait fait sortir leurs pères du pays d'Égypte, qu'ils se sont attachés à d'autres dieux et qu'ils leur ont rendu hommage et culte, voilà pourquoi Yahvé leur a envoyé tous ces maux". "
###### 10
Au bout des vingt années pendant lesquelles Salomon construisit les deux édifices, le Temple de Yahvé et le palais royal 
###### 11
Hiram, roi de Tyr, lui avait fourni du bois de cèdre et de genévrier, et de l'or, tant qu'il en avait voulu , alors le roi Salomon donna à Hiram vingt villes dans le pays de Galilée. 
###### 12
Hiram vint de Tyr pour voir les villes que Salomon lui avait données, et elles ne lui plurent pas ; 
###### 13
il dit : " Qu'est-ce que ces villes que tu m'as données, mon frère ? " et, jusqu'à ce jour, on les appelle " le pays de Kabul ". 
###### 14
Hiram envoya au roi cent vingt talents d'or. 
###### 15
Voici ce qui concerne la corvée que le roi Salomon leva pour construire le Temple de Yahvé, son propre palais, le Millo et le mur de Jérusalem, Haçor, Megiddo, Gézèr, 
###### 16
Pharaon, le roi d'Égypte, fit une expédition, prit Gézèr, l'incendia et massacra les Cananéens qui y habitaient, puis il donna la ville en cadeau de noces à sa fille, la femme de Salomon, 
###### 17
et Salomon reconstruisit Gézèr , Bet-Horôn-le-Bas, 
###### 18
Baalat, Tamar au désert, dans le pays, 
###### 19
toutes les villes-entrepôts qu'avait Salomon, les villes de chars et de chevaux, et ce qu'il plut à Salomon de construire à Jérusalem, au Liban et dans tous les pays qui lui étaient soumis. 
###### 20
Tout ce qui restait des Amorites, des Hittites, des Perizzites, des Hivvites et des Jébuséens, qui n'étaient pas des Israélites, 
###### 21
leurs descendants restés après eux dans le pays, ceux que les Israélites n'avaient pas pu vouer à l'anathème, Salomon les leva comme hommes de corvée servile ; ils le sont encore. 
###### 22
Mais il n'imposa pas la corvée servile aux Israélites, plutôt ceux-ci servaient comme soldats : ils étaient ses gardes, ses officiers et ses écuyers, les officiers de sa charrerie et de sa cavalerie. 
###### 23
Voici les officiers des préfets qui dirigeaient les travaux de Salomon : cinq cent cinquante, qui commandaient au peuple occupé aux travaux. 
###### 24
Dès que la fille de Pharaon fut montée de la Cité de David à sa maison qu'il lui avait construite, alors il bâtit le Millo. 
###### 25
Salomon offrait trois fois par an des holocaustes et des sacrifices de communion sur l'autel qu'il avait dressé à Yahvé et il faisait fumer devant Yahvé ses offrandes brûlées. Il maintenait le Temple en bon état. 
###### 26
Le roi Salomon arma une flotte à Éçyôn-Gébèr, qui est près d'Élat, sur le bord de la mer Rouge, au pays d'Édom. 
###### 27
Hiram envoya sur les vaisseaux ses serviteurs, des matelots qui connaissaient la mer, avec les serviteurs de Salomon. 
###### 28
Ils allèrent à Ophir et en rapportèrent quatre cent vingt talents d'or, qu'ils remirent au roi Salomon.
