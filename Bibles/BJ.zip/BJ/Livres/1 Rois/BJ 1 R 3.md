---
aliases : 
- 1 Rois 3
- 1 Rois 3
- 1 R 3
- 1 Kings 3
tags : 
- Bible/1R/3
- français
cssclass : français
---

# 1 Rois 3

###### 1
Salomon devint le gendre de Pharaon, le roi d'Égypte ; il prit pour femme la fille de Pharaon et l'introduisit dans la cité de David, en attendant d'avoir achevé de construire son palais, le Temple de Yahvé et le rempart de Jérusalem. 
###### 2
Le peuple sacrifiait sur les hauts lieux, car on n'avait pas encore bâti en ce temps-là une maison pour le Nom de Yahvé. 
###### 3
Salomon aima Yahvé : il se conduisait selon les préceptes de son père David ; seulement il offrait des sacrifices et de l'encens sur les hauts lieux. 
###### 4
Le roi alla à Gabaôn pour y sacrifier, car le plus grand haut lieu se trouvait là - Salomon a offert mille holocaustes sur cet autel. 
###### 5
A Gabaôn, Yahvé apparut la nuit en songe à Salomon. Dieu dit : " Demande ce que je dois te donner. " 
###### 6
Salomon répondit : " Tu as témoigné une grande bienveillance à ton serviteur David, mon père, et celui-ci a marché devant toi dans la fidélité, la justice et la droiture du cœur ; tu lui as gardé cette grande bienveillance et tu as permis qu'un de ses fils soit aujourd'hui assis sur son trône. 
###### 7
Maintenant, Yahvé mon Dieu, tu as établi roi ton serviteur à la place de mon père David, et moi, je suis un tout jeune homme, je ne sais pas agir en chef. 
###### 8
Ton serviteur est au milieu du peuple que tu as élu, un peuple nombreux, si nombreux qu'on ne peut le compter ni le recenser. 
###### 9
Donne à ton serviteur un cœur plein de jugement pour gouverner ton peuple, pour discerner entre le bien et le mal, car qui pourrait gouverner ton peuple, qui est si grand ? " 
###### 10
Il plut au regard du Seigneur que Salomon ait fait cette demande ; 
###### 11
et Dieu lui dit : " Parce que tu as demandé cela, que tu n'as pas demandé pour toi de longs jours, ni la richesse, ni la vie de tes ennemis, mais que tu as demandé pour toi le discernement du jugement, 
###### 12
voici que je fais ce que tu as dit : je te donne un cœur sage et intelligent comme personne ne l'a eu avant toi et comme personne ne l'aura après toi. 
###### 13
Et même ce que tu n'as pas demandé, je te le donne aussi : une richesse et une gloire comme à personne parmi les rois. 
###### 14
Et si tu suis mes voies, gardant mes lois et mes commandements comme a fait ton père David, je t'accorderai une longue vie. " 
###### 15
Salomon s'éveilla et voilà que c'était un songe. Il rentra à Jérusalem et se tint devant l'arche de l'alliance du Seigneur ; il offrit des holocaustes et des sacrifices de communion et donna un banquet à tous ses serviteurs. 
###### 16
Alors deux prostituées vinrent vers le roi et se tinrent devant lui. 
###### 17
L'une des femmes dit : " S'il te plaît, Monseigneur ! Moi et cette femme nous habitons la même maison, et j'ai eu un enfant, alors qu'elle était dans la maison. 
###### 18
Il est arrivé que, le troisième jour après ma délivrance, cette femme aussi a eu un enfant ; nous étions ensemble, il n'y avait pas d'étranger avec nous, rien que nous deux dans la maison. 
###### 19
Or le fils de cette femme est mort une nuit parce qu'elle s'était couchée sur lui. 
###### 20
Elle se leva au milieu de la nuit, prit mon fils d'à côté de moi pendant que ta servante dormait ; elle le mit sur son sein et son fils mort elle le mit sur mon sein. 
###### 21
Je me levai pour allaiter mon fils, et voici qu'il était mort ! Mais, au matin, je l'examinai, et voici que ce n'était pas mon fils que j'avais enfanté ! " 
###### 22
Alors l'autre femme dit : " Ce n'est pas vrai ! Mon fils est celui qui est vivant, et ton fils est celui qui est mort ! " et celle-là reprenait : " Ce n'est pas vrai ! Ton fils est celui qui est mort et mon fils est celui qui est vivant ! " Elles se disputaient ainsi devant le roi 
###### 23
qui prononça : " Celle-ci dit : "Voici mon fils qui est vivant et c'est ton fils qui est mort ! " et celle-là dit : "Ce n'est pas vrai ! Ton fils est celui qui est mort et mon fils est celui qui est vivant ! " 
###### 24
Apportez-moi une épée ", ordonna le roi ; et on apporta l'épée devant le roi, 
###### 25
qui dit : " Partagez l'enfant vivant en deux et donnez la moitié à l'une et la moitié à l'autre. " 
###### 26
Alors la femme dont le fils était vivant s'adressa au roi, car sa pitié s'était enflammée pour son fils, et elle dit : " S'il te plaît, Monseigneur ! Qu'on lui donne l'enfant vivant, qu'on ne le tue pas ! " mais celle-là disait : " Il ne sera ni à moi ni à toi, partagez ! " 
###### 27
Alors le roi prit la parole et dit : " Donnez l'enfant vivant à la première, ne le tuez pas. C'est elle la mère. " 
###### 28
Tout Israël apprit le jugement qu'avait rendu le roi, et ils révérèrent le roi car ils virent qu'il y avait en lui une sagesse divine pour rendre la justice. 
