---
aliases : 
- 1 Rois 6
- 1 Rois 6
- 1 R 6
- 1 Kings 6
tags : 
- Bible/1R/6
- français
cssclass : français
---

# 1 Rois 6

###### 1
En la quatre cent quatre-vingtième année après la sortie des Israélites du pays d'Égypte, en la quatrième année du règne de Salomon sur Israël, au mois de Ziv qui est le second mois, il bâtit le Temple de Yahvé. 
###### 2
Le Temple que le roi Salomon bâtit pour Yahvé avait soixante coudées de long, vingt de large et vingt-cinq de haut. 
###### 3
Le Ulam devant le Hékal du Temple avait vingt coudées de long dans le sens de la largeur du Temple et dix coudées de large dans le sens de la longueur du Temple. 
###### 4
Il fit au Temple des fenêtres à cadres et à grilles. 
###### 5
Il adossa au mur du Temple une annexe autour du Hékal et du Debir, et il fit des étages latéraux autour. 
###### 6
L'étage inférieur avait cinq coudées de large, l'intermédiaire six coudées, et le troisième sept coudées, car il avait disposé des retraits autour du Temple à l'extérieur, en sorte que cela n'était pas lié aux murs du Temple. 
###### 7
La construction du Temple se fit en pierres de carrière ; on n'entendit ni marteaux, ni pics, ni aucun outil de fer dans le Temple pendant sa construction. 
###### 8
L'entrée de l'étage inférieur était à l'angle droit du Temple, et par des trappes on montait à l'étage intermédiaire, et de l'intermédiaire au troisième. 
###### 9
Il construisit le Temple et l'acheva, et il couvrit le Temple d'un plafond à caissons de cèdre. 
###### 10
Il construisit l'annexe à tout le Temple ; elle avait cinq coudées de hauteur et elle était liée au Temple par des poutres de cèdre. 
###### 11
La parole de Yahvé fut adressée à Salomon : 
###### 12
" Quant à cette maison que tu es en train de construire, si tu marches selon mes lois, si tu accomplis mes ordonnances et si tu suis fidèlement mes commandements, alors j'accomplirai ma parole sur toi, celle que j'ai dite à ton père David, 
###### 13
et j'habiterai au milieu des Israélites et je n'abandonnerai pas mon peuple Israël. " 
###### 14
Salomon construisit le Temple et il l'acheva. 
###### 15
Il garnit de planches de cèdre la face interne des murs du Temple - depuis le sol du Temple jusqu'aux poutres du plafond, il mit un revêtement de bois à l'intérieur - et il couvrit de planches de genévrier le sol du Temple. 
###### 16
Il construisit les vingt coudées à partir du fond du Temple avec des planches de cèdre depuis le sol jusqu'aux poutres, et elles furent mises à part du Temple pour le Debir, le Saint des Saints. 
###### 17
Le Temple avait quarante coudées - c'est le Hékal - devant le Debir. 
###### 18
Il y avait du cèdre à l'intérieur du Temple, sculpté d'un décor de coloquintes et de rosaces ; tout était en cèdre, aucune pierre ne paraissait. 
###### 19
Il aménagea un Debir dans le Temple, à l'intérieur, pour y placer l'arche de l'alliance de Yahvé. 
###### 20
Le Debir avait vingt coudées de long, vingt coudées de large et vingt coudées de haut, et il le revêtit d'or fin ; il fit un autel de cèdre 
###### 21
devant le Debir et il le revêtit d'or. 
###### 22
Tout le Temple, il le revêtit d'or, absolument tout le Temple. 
###### 23
Dans le Debir, il fit deux chérubins en bois d'olivier sauvage... Il avait dix coudées de haut. 
###### 24
Une aile du chérubin avait cinq coudées et la seconde aile du chérubin avait cinq coudées, soit dix coudées d'une extrémité à l'autre de ses ailes. 
###### 25
Le second chérubin avait aussi dix coudées : même dimension et même facture pour les deux chérubins. 
###### 26
La hauteur d'un chérubin était de dix coudées, et de même l'autre. 
###### 27
Il plaça les chérubins au milieu de la chambre intérieure ; ils déployaient leurs ailes, en sorte que l'aile de l'un touchait au mur, que l'aile de l'autre touchait à l'autre mur et que leurs ailes se touchaient au milieu de la chambre, aile contre aile. 
###### 28
Et il revêtit d'or les chérubins. 
###### 29
Sur tous les murs du Temple, à l'entour, il sculpta des figures de chérubins, des palmiers et des rosaces, à l'intérieur et à l'extérieur. 
###### 30
Il couvrit d'or le plancher du Temple, à l'intérieur et à l'extérieur. 
###### 31
Il fit la porte du Debir à montants en bois d'olivier sauvage, le jambage à cinq retraits, 
###### 32
deux vantaux en bois d'olivier sauvage. Il sculpta des figures de chérubins, des palmiers et des rosaces, qu'il revêtit d'or ; il étendit l'or en pellicule sur les chérubins et les palmiers. 
###### 33
De même, il fit à la porte du Hékal des montants en bois d'olivier sauvage, le jambage à quatre retraits, 
###### 34
deux vantaux en bois de genévrier : un vantail avait deux bandes qui le cerclaient et l'autre vantail avait deux bandes qui le cerclaient. 
###### 35
Il sculpta des chérubins, des palmiers et des rosaces, qu'il revêtit d'or ajusté sur la sculpture. 
###### 36
Il construisit le mur de la cour intérieure par trois assises de pierres de taille et une assise de madriers de cèdre. 
###### 37
En la quatrième année, au mois de Ziv, les fondations du Temple furent posées ; 
###### 38
en la onzième année, au mois de Bûl - c'est le huitième mois -, le Temple fut achevé selon tout son plan et toute son ordonnance. Salomon le construisit en sept ans. 
