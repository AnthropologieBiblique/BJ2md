---
aliases : 
- Exode 40
- Exode 40
- Ex 40
- Exodus 40
tags : 
- Bible/Ex/40
- français
cssclass : français
---

# Exode 40

###### 1
Yahvé parla à Moïse et lui dit : 
###### 2
" Le premier jour du premier mois, tu dresseras la Demeure, la Tente du Rendez-vous, 
###### 3
tu y placeras l'arche du Témoignage et tu voileras l'arche avec le rideau. 
###### 4
Tu apporteras la table et tu disposeras sa garniture. Tu apporteras le candélabre et tu monteras ses lampes. 
###### 5
Tu mettras l'autel d'or des parfums devant l'arche du Témoignage, et tu placeras le voile à l'entrée de la Demeure. 
###### 6
Tu mettras l'autel des holocaustes devant l'entrée de la Demeure, de la Tente du Rendez-vous. 
###### 7
Tu mettras le bassin entre la Tente du Rendez-vous et l'autel, et tu y mettras de l'eau. 
###### 8
Tu placeras le parvis tout autour et tu mettras le voile à la porte du parvis. 
###### 9
Tu prendras l'huile d'onction et tu oindras la Demeure et tout ce qui est dedans ; tu la consacreras, elle et tous ses accessoires, et elle sera éminemment sainte. 
###### 10
Tu oindras l'autel des holocaustes et tous ses accessoires, tu consacreras l'autel, et l'autel sera éminemment saint. 
###### 11
Tu oindras le bassin et son socle et tu le consacreras. 
###### 12
Puis tu feras approcher Aaron et ses fils de l'entrée de la Tente du Rendez-vous, tu les laveras avec de l'eau, 
###### 13
et tu revêtiras Aaron de ses vêtements sacrés, tu l'oindras et tu le consacreras pour qu'il exerce mon sacerdoce. 
###### 14
Ses fils, tu les feras approcher, tu les revêtiras de tuniques, 
###### 15
et tu les oindras comme tu auras oint leur père, pour qu'ils exercent mon sacerdoce. Cela se fera pour que leur onction leur confère un sacerdoce éternel, dans leurs générations. 
###### 16
Moïse le fit. Il fit tout comme Yahvé l'avait ordonné. 
###### 17
Le premier jour du premier mois de la seconde année, on dressa la Demeure. 
###### 18
Moïse dressa la Demeure ; il mit ses socles, plaça ses cadres, mit ses traverses et dressa ses colonnes. 
###### 19
Il étendit la tente pour la Demeure et plaça dessus la couverture de la tente, comme Yahvé l'avait ordonné à Moïse. 
###### 20
Il prit le Témoignage, le mit dans l'arche, plaça les barres sur l'arche et mit le propitiatoire sur l'arche. 
###### 21
Il introduisit l'arche dans la Demeure et plaça le rideau du voile ; il voila ainsi l'arche du Témoignage, comme Yahvé l'avait ordonné à Moïse. 
###### 22
Il mit la table dans la Tente du Rendez-vous, sur le côté de la Demeure, au nord, à l'extrémité du voile, 
###### 23
et il disposa avec ordre le pain devant Yahvé, comme Yahvé l'avait ordonné à Moïse. 
###### 24
Il plaça le candélabre dans la Tente du Rendez-vous, en face de la table, sur le côté de la Demeure, au sud, 
###### 25
et monta les lampes devant Yahvé, comme Yahvé l'avait ordonné à Moïse. 
###### 26
Il plaça l'autel d'or dans la Tente du Rendez-vous, devant le voile, 
###### 27
et fit fumer dessus l'encens aromatique, comme Yahvé l'avait ordonné à Moïse. 
###### 28
Puis il plaça le voile à l'entrée de la Demeure. 
###### 29
L'autel des holocaustes, il le plaça à l'entrée de la Demeure, de la Tente du Rendez-vous, et offrit dessus l'holocauste et l'oblation, comme Yahvé l'avait ordonné à Moïse. 
###### 30
Il plaça le bassin entre la Tente du Rendez-vous et l'autel et il y mit, pour les ablutions, de l'eau 
###### 31
avec laquelle Moïse, Aaron et ses fils se lavaient les mains et les pieds. 
###### 32
Quand ils entraient dans la Tente du Rendez-vous ou qu'ils s'approchaient de l'autel, ils se lavaient, comme Yahvé l'avait ordonné à Moïse. 
###### 33
Il dressa le parvis autour de la Demeure et de l'autel, et il mit le voile à la porte du parvis. Ainsi Moïse termina les travaux. 
###### 34
La nuée couvrit la Tente du Rendez-vous, et la gloire de Yahvé emplit la Demeure. 
###### 35
Moïse ne put entrer dans la Tente du Rendez-vous, car la nuée demeurait sur elle, et la gloire de Yahvé emplissait la Demeure. 
###### 36
A toutes leurs étapes, lorsque la nuée s'élevait au-dessus de la Demeure, les Israélites se mettaient en marche. 
###### 37
Si la nuée ne s'élevait pas, ils ne se mettaient pas en marche jusqu'au jour où elle s'élevait. 
###### 38
Car, le jour, la nuée de Yahvé était sur la Demeure et, la nuit, il y avait dedans un feu, aux yeux de toute la maison d'Israël, à toutes leurs étapes. 
