---
aliases : 
- Exode 1
- Exode 1
- Ex 1
- Exodus 1
tags : 
- Bible/Ex/1
- français
cssclass : français
---

# Exode 1

###### 1
Voici les noms des Israélites qui entrèrent en Égypte avec Jacob ; ils y vinrent chacun avec sa famille : 
###### 2
Ruben, Siméon, Lévi et Juda, 
###### 3
Issachar, Zabulon et Benjamin, 
###### 4
Dan et Nephtali, Gad et Asher. 
###### 5
Les descendants de Jacob étaient, en tout, soixante-dix personnes. Joseph, lui, était déjà en Égypte. 
###### 6
Puis Joseph mourut, ainsi que tous ses frères et toute cette génération. 
###### 7
Les Israélites furent féconds et se multiplièrent, ils devinrent de plus en plus nombreux et puissants, au point que le pays en fut rempli. 
###### 8
Un nouveau roi vint au pouvoir en Égypte, qui n'avait pas connu Joseph. 
###### 9
Il dit à son peuple : " Voici que le peuple des Israélites est devenu plus nombreux et plus puissant que nous. 
###### 10
Allons, prenons de sages mesures pour l'empêcher de s'accroître, sinon, en cas de guerre, il grossirait le nombre de nos adversaires. Il combattrait contre nous pour, ensuite, sortir du pays. " 
###### 11
On imposa donc à Israël des chefs de corvée pour lui rendre la vie dure par les travaux qu'ils exigeraient. C'est ainsi qu'il bâtit pour Pharaon les villes-entrepôts de Pitom et de Ramsès. 
###### 12
Mais plus on lui rendait la vie dure, plus il croissait en nombre et surabondait, ce qui fit redouter les Israélites. 
###### 13
Les Égyptiens contraignirent les Israélites au travail 
###### 14
et leur rendirent la vie amère par de durs travaux : préparation de l'argile, moulage des briques, divers travaux des champs, toutes sortes de travaux auxquels ils les contraignirent. 
###### 15
Le roi d'Égypte dit aux accoucheuses des femmes des Hébreux, dont l'une s'appelait Shiphra et l'autre Pua : 
###### 16
" Quand vous accoucherez les femmes des Hébreux, regardez les deux pierres. Si c'est un fils, faites-le mourir, si c'est une fille, laissez-la vivre. " 
###### 17
Mais les accoucheuses craignirent Dieu, elles ne firent pas ce que leur avait dit le roi d'Égypte et laissèrent vivre les garçons. 
###### 18
Le roi d'Égypte les appela et leur dit : " Pourquoi avez-vous agi de la sorte et laissé vivre les garçons ? " 
###### 19
Elles répondirent à Pharaon : " Les femmes des Hébreux ne sont pas comme les Egyptiennes, elles sont vigoureuses. Avant que l'accoucheuse n'arrive auprès d'elles, elles se sont délivrées. " 
###### 20
Dieu favorisa les accoucheuses ; quant au peuple, il devint très nombreux et très puissant. 
###### 21
Comme les accoucheuses avaient craint Dieu, il leur accorda une postérité. 
###### 22
Pharaon donna alors cet ordre à tout son peuple : " Tout fils qui naîtra, jetez-le au Fleuve, mais laissez vivre toute fille. 
