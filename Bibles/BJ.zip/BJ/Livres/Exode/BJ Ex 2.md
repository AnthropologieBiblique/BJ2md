---
aliases : 
- Exode 2
- Exode 2
- Ex 2
- Exodus 2
tags : 
- Bible/Ex/2
- français
cssclass : français
---

# Exode 2

###### 1
Un homme de la maison de Lévi s'en alla prendre pour femme une fille de Lévi. 
###### 2
Celle-ci conçut et enfanta un fils. Voyant combien il était beau, elle le dissimula pendant trois mois. 
###### 3
Ne pouvant le dissimuler plus longtemps, elle prit pour lui une corbeille de papyrus qu'elle enduisit de bitume et de poix, y plaça l'enfant et la déposa dans les roseaux sur la rive du Fleuve. 
###### 4
La sœur de l'enfant se posta à distance pour voir ce qui lui adviendrait. 
###### 5
Or la fille de Pharaon descendit au Fleuve pour s'y baigner, tandis que ses servantes se promenaient sur la rive du Fleuve. Elle aperçut la corbeille parmi les roseaux et envoya sa servante la prendre. 
###### 6
Elle l'ouvrit et vit l'enfant : c'était un garçon qui pleurait. Touchée de compassion pour lui, elle dit : " C'est un des petits Hébreux. " 
###### 7
La sœur de l'enfant dit alors à la fille de Pharaon : " Veux-tu que j'aille te chercher, parmi les femmes des Hébreux, une nourrice qui te nourrira cet enfant ? - 
###### 8
Va ", lui répondit la fille de Pharaon. La jeune fille alla donc chercher la mère de l'enfant. 
###### 9
La fille de Pharaon lui dit : " Emmène cet enfant et nourris-le moi, je te donnerai moi-même ton salaire. " Alors la femme emporta l'enfant et le nourrit. 
###### 10
Quand l'enfant eut grandi, elle le ramena à la fille de Pharaon qui le traita comme un fils et lui donna le nom de Moïse, car, disait-elle, " je l'ai tiré des eaux ". 
###### 11
Il advint, en ces jours-là, que Moïse, qui avait grandi, alla voir ses frères. Il vit les corvées auxquelles ils étaient astreints ; il vit aussi un Égyptien qui frappait un Hébreu, un de ses frères. 
###### 12
Il se tourna de-ci de-là, et voyant qu'il n'y avait personne, il tua l'Égyptien et le cacha dans le sable. 
###### 13
Le jour suivant, il revint alors que deux Hébreux se battaient. " Pourquoi frappes-tu ton compagnon ? " dit-il à l'agresseur. 
###### 14
Celui-ci répondit : " Qui t'a constitué notre chef et notre juge ? Veux-tu me tuer comme tu as tué l'Égyptien ? " Moïse effrayé se dit : " Certainement l'affaire se sait. " 
###### 15
Pharaon entendit parler de cette affaire et chercha à tuer Moïse. Moïse s'enfuit loin de Pharaon ; il se rendit au pays de Madiân et s'assit auprès d'un puits. 
###### 16
Or un prêtre de Madiân avait sept filles. Elles vinrent puiser et remplir les auges pour abreuver le petit bétail de leur père. 
###### 17
Des bergers survinrent et les chassèrent. Moïse se leva, vint à leur secours et abreuva le petit bétail. 
###### 18
Elles revinrent auprès de Réuel, leur père, qui leur dit : " Pourquoi revenez-vous si tôt aujourd'hui ? " 
###### 19
Elles lui dirent : " Un Égyptien nous a tirées des mains des bergers ; il a même puisé pour nous et abreuvé le petit bétail. - 
###### 20
Et où est-il ? demanda-t-il à ses filles. Pourquoi donc avez-vous abandonné cet homme ? Invitez-le à manger. " 
###### 21
Moïse consentit à s'établir auprès de cet homme qui lui donna sa fille, Çippora. 
###### 22
Elle mit au monde un fils qu'il nomma Gershom car, dit-il, " je suis un immigré en terre étrangère ". 
###### 23
Au cours de cette longue période, le roi d'Égypte mourut. Les Israélites, gémissant de leur servitude, crièrent, et leur appel à l'aide monta vers Dieu, du fond de leur servitude. 
###### 24
Dieu entendit leur gémissement ; Dieu se souvint de son alliance avec Abraham, Isaac et Jacob. 
###### 25
Dieu vit les Israélites et Dieu connut...
