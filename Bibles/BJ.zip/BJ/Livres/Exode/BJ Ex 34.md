---
aliases : 
- Exode 34
- Exode 34
- Ex 34
- Exodus 34
tags : 
- Bible/Ex/34
- français
cssclass : français
---

# Exode 34

###### 1
Yahvé dit à Moïse : " Taille deux tables de pierre semblables aux premières, monte vers moi sur la montagne, et j'écrirai sur les tables les paroles qui étaient sur les premières tables que tu as brisées. 
###### 2
Sois prêt au matin, monte dès le matin sur le mont Sinaï et attends-moi là, au sommet de la montagne. 
###### 3
Que personne ne monte avec toi ; que personne même ne paraisse sur toute la montagne. Que même le bétail, petit et gros, ne paisse pas devant cette montagne. " 
###### 4
Il tailla donc deux tables de pierre, semblables aux premières, et, s'étant levé de bon matin, Moïse monta sur le mont Sinaï, comme Yahvé le lui avait ordonné, et il prit dans sa main les deux tables de pierre. 
###### 5
Yahvé descendit dans une nuée et il se tint là avec lui. Il invoqua le nom de Yahvé. 
###### 6
Yahvé passa devant lui et il cria : " Yahvé, Yahvé, Dieu de tendresse et de pitié, lent à la colère, riche en grâce et en fidélité ; 
###### 7
qui garde sa grâce à des milliers, tolère faute, transgression et péché mais ne laisse rien impuni et châtie les fautes des pères sur les enfants et les petits-enfants, jusqu'à la troisième et la quatrième génération. " 
###### 8
Aussitôt Moïse tomba à genoux sur le sol et se prosterna, 
###### 9
puis il dit : " Si vraiment, Seigneur, j'ai trouvé grâce à tes yeux, que mon Seigneur veuille bien aller au milieu de nous, bien que ce soit un peuple à la nuque raide, pardonne nos fautes et nos péchés et fais de nous ton héritage. 
###### 10
Il dit : " Voici que je vais conclure une alliance : devant tout ton peuple je ferai des merveilles telles qu'il n'en a été accompli dans aucun pays ni aucune nation. Le peuple au milieu duquel tu te trouves verra l'œuvre de Yahvé, car c'est chose redoutable, ce que je vais faire avec toi. 
###### 11
Observe donc ce que je te commande aujourd'hui. Je vais chasser devant toi les Amorites, les Cananéens, les Hittites, les Perizzites, les Hivvites et les Jébuséens. 
###### 12
Garde-toi de faire alliance avec les habitants du pays où tu vas entrer, de peur qu'ils ne constituent un piège au milieu de toi. 
###### 13
Vous démolirez leurs autels, vous mettrez leurs stèles en pièces et vous couperez leurs pieux sacrés. 
###### 14
Tu ne te prosterneras pas devant un autre dieu, car Yahvé a pour nom Jaloux : c'est un Dieu jaloux. 
###### 15
Ne fais pas alliance avec les habitants du pays, car lorsqu'ils se prostituent à leurs dieux et leur offrent des sacrifices, ils t'inviteraient et tu mangerais de leur sacrifice, 
###### 16
tu prendrais de leurs filles pour tes fils, leurs filles se prostitueraient à leurs dieux et feraient se prostituer tes fils à leurs dieux. 
###### 17
Tu ne te feras pas de dieu de métal fondu. 
###### 18
Tu observeras la fête des Azymes. Pendant sept jours tu mangeras des azymes, comme je te l'ai ordonné, au temps fixé du mois d'Abib, car c'est au mois d'Abib que tu es sorti d'Égypte. 
###### 19
Tout être sorti le premier du sein maternel est à moi : tout mâle, tout premier-né de ton petit ou de ton gros bétail. 
###### 20
Les premiers ânons mis bas tu les rachèteras par une tête de petit bétail et si tu ne les rachètes pas, tu leur briseras la nuque. Tous les premiers-nés de tes fils, tu les rachèteras, et l'on ne se présentera pas devant moi les mains vides. 
###### 21
Pendant six jours tu travailleras, mais le septième jour, tu chômeras, que ce soient les labours ou la moisson, tu chômeras. 
###### 22
Tu célébreras la fête des Semaines, prémices de la moisson des blés, et la fête de la récolte au retour de l'année. 
###### 23
Trois fois l'an, toute la population mâle se présentera devant le Seigneur Yahvé, Dieu d'Israël. 
###### 24
Je déposséderai les nations devant toi et j'élargirai tes frontières, et nul ne convoitera ta terre quand tu monteras te présenter devant Yahvé ton Dieu, trois fois l'an. 
###### 25
Tu n'offriras pas avec du pain levé le sang de ma victime, et la victime de la fête de Pâque ne sera pas gardée jusqu'au lendemain. 
###### 26
Le meilleur des prémices de ton terroir, tu l'apporteras à la maison de Yahvé ton Dieu et tu ne feras pas cuire un chevreau dans le lait de sa mère. "
###### 27
Yahvé dit à Moïse : " Mets par écrit ces paroles car selon ces clauses, j'ai conclu mon alliance avec toi et avec Israël. "
###### 28
Moïse demeura là, avec Yahvé, quarante jours et quarante nuits. Il ne mangea ni ne but, et il écrivit sur les tables les paroles de l'alliance, les dix paroles. 
###### 29
Lorsque Moïse redescendit de la montagne du Sinaï, les deux tables du Témoignage étaient dans la main de Moïse quand il descendit de la montagne, et Moïse ne savait pas que la peau de son visage rayonnait parce qu'il avait parlé avec lui. 
###### 30
Aaron et tous les Israélites virent Moïse, et voici que la peau de son visage rayonnait, et ils avaient peur de l'approcher. 
###### 31
Moïse les appela ; Aaron et tous les chefs de la communauté revinrent alors vers lui, et Moïse leur parla. 
###### 32
Ensuite tous les Israélites s'approchèrent, et il leur ordonna tout ce dont Yahvé avait parlé sur le mont Sinaï. 
###### 33
Quand Moïse eut fini de leur parler, il mit un voile sur son visage. 
###### 34
Lorsque Moïse entrait devant Yahvé pour parler avec lui, il ôtait le voile jusqu'à sa sortie. En sortant, il disait aux Israélites ce qui lui avait été ordonné, 
###### 35
et les Israélites voyaient le visage de Moïse rayonner. Puis Moïse remettait le voile sur son visage, jusqu'à ce qu'il entrât pour parler avec lui. 
