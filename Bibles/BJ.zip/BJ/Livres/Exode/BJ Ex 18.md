---
aliases : 
- Exode 18
- Exode 18
- Ex 18
- Exodus 18
tags : 
- Bible/Ex/18
- français
cssclass : français
---

# Exode 18

###### 1
Jéthro, prêtre de Madiân, beau-père de Moïse, entendit raconter tout ce que Dieu avait fait pour Moïse et pour Israël son peuple : comment Yahvé avait fait sortir Israël d'Égypte. 
###### 2
Jéthro, le beau-père de Moïse, prit Çippora, la femme de Moïse, après qu'il l'eut renvoyée, 
###### 3
ainsi que ses deux fils. L'un s'appelait Gershom car, avait-il dit, " Je suis un immigré en terre étrangère ", 
###### 4
l'autre s'appelait Éliézer car, " le Dieu de mon père est mon secours et m'a délivré de l'épée de Pharaon ". 
###### 5
Jéthro, le beau-père de Moïse, vint trouver Moïse avec ses fils et sa femme au désert où il campait, à la montagne de Dieu. 
###### 6
L'on dit à Moïse : " Voici ton beau-père Jéthro qui vient vers toi, accompagné de ta femme avec ses deux fils. " 
###### 7
Moïse sortit à la rencontre de son beau-père, se prosterna devant lui, l'embrassa et, s'étant mutuellement interrogés sur leur santé, ils se rendirent à la tente. 
###### 8
Moïse raconta à son beau-père tout ce que Yahvé avait fait à Pharaon et aux Égyptiens à cause d'Israël, ainsi que toutes les tribulations qu'ils avaient rencontrées en chemin, et dont Yahvé les avait délivrés. 
###### 9
Jéthro se réjouit de tout le bien que Yahvé avait fait à Israël, de ce qu'il l'avait délivré de la main des Égyptiens. 
###### 10
Jéthro dit alors : " Béni soit Yahvé qui vous a délivrés de la main des Égyptiens et de la main de Pharaon, qui a délivré le peuple de la sujétion égyptienne. 
###### 11
Maintenant je sais que Yahvé est plus grand que tous les dieux... "
###### 12
Jéthro, le beau-père de Moïse, offrit à Dieu un holocauste et des sacrifices. Aaron et tous les anciens d'Israël vinrent manger avec le beau-père de Moïse en présence de Dieu. 
###### 13
Le lendemain, Moïse s'assit pour rendre la justice au peuple, tandis que le peuple demeurait debout auprès de lui du matin au soir. 
###### 14
Le beau-père de Moïse, voyant tout ce qu'il faisait pour le peuple, lui dit : " Comment t'y prends-tu pour traiter seul les affaires du peuple ? Pourquoi sièges-tu seul alors que tout le peuple se tient auprès de toi du matin au soir ? " 
###### 15
Moïse dit à son beau-père : " C'est que le peuple vient à moi pour consulter Dieu. 
###### 16
Lorsqu'ils ont une affaire, ils viennent à moi. Je juge entre l'un et l'autre et je leur fais connaître les décrets de Dieu et ses lois. " 
###### 17
Le beau-père de Moïse lui dit : " Tu t'y prends mal !
###### 18
A coup sûr tu t'épuiseras, toi et le peuple qui est avec toi, car la tâche est trop lourde pour toi ; tu ne pourras pas l'accomplir seul. 
###### 19
Maintenant écoute le conseil que je vais te donner pour que Dieu soit avec toi. Tiens-toi à la place du peuple devant Dieu, et introduis toi-même leurs causes auprès de Dieu. 
###### 20
Instruis-les des décrets et des lois, fais-leur connaître la voie à suivre et la conduite à tenir. 
###### 21
Mais choisis-toi parmi tout le peuple des hommes capables, craignant Dieu, sûrs, incorruptibles, et établis-les sur eux comme chefs de milliers, chefs de centaines, chefs de cinquantaines et chefs de dizaines. 
###### 22
Ils jugeront le peuple en tout temps. Toute affaire importante, ils te la déféreront et toute affaire mineure, ils la jugeront eux-mêmes. Allège ainsi ta charge et qu'ils la portent avec toi. 
###### 23
Si tu fais cela et que Dieu te l'ordonne tu pourras tenir et tout ce peuple, de son côté, pourra rentrer en paix chez lui. "
###### 24
Moïse suivit le conseil de son beau-père et fit tout ce qu'il lui avait dit. 
###### 25
Moïse choisit dans tout Israël des hommes capables, et il les mit chefs du peuple : chefs de milliers, chefs de centaines, chefs de cinquantaines et chefs de dizaines. 
###### 26
Et ils jugeaient le peuple en tout temps. Toute affaire importante, ils la déféraient à Moïse, et toute affaire mineure, ils la jugeaient eux-mêmes. 
###### 27
Puis Moïse laissa repartir son beau-père qui reprit le chemin de son pays. 
