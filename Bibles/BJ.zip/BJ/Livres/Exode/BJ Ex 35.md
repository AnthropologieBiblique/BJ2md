---
aliases : 
- Exode 35
- Exode 35
- Ex 35
- Exodus 35
tags : 
- Bible/Ex/35
- français
cssclass : français
---

# Exode 35

###### 1
Moïse assembla toute la communauté des Israélites et leur dit : " Voici ce que Yahvé a ordonné de faire : 
###### 2
Pendant six jours on fera le travail, mais le septième jour sera pour vous un jour saint, un jour de repos complet consacré à Yahvé. Quiconque fera ce jour-là un travail quelconque sera mis à mort. 
###### 3
Vous n'allumerez de feu, le jour du sabbat, dans aucune de vos demeures. 
###### 4
Moïse dit à toute la communauté des Israélites : " Voici ce qu'a ordonné Yahvé. 
###### 5
Prélevez sur vos biens une contribution pour Yahvé. Que tous ceux que leur cœur y incite apportent la contribution de Yahvé : de l'or, de l'argent et du bronze ; 
###### 6
de la pourpre violette et écarlate, du cramoisi, du lin fin et du poil de chèvre ; 
###### 7
des peaux de béliers teintes en rouge, du cuir fin et du bois d'acacia ; 
###### 8
de l'huile pour le luminaire, des aromates pour l'huile d'onction et l'encens aromatique ; 
###### 9
des pierres de cornaline et des pierreries à enchâsser pour l'éphod et le pectoral. 
###### 10
Que ceux parmi vous qui sont habiles viennent faire tout ce qu'a ordonné Yahvé : 
###### 11
la Demeure, sa tente et sa couverture, ses agrafes, ses cadres, ses traverses, ses colonnes et ses socles ; 
###### 12
l'arche et ses barres, le propitiatoire et le rideau du voile ; 
###### 13
la table, ses barres et tous ses accessoires ainsi que les pains d'oblation ; 
###### 14
le candélabre pour la lumière, ses accessoires, ses lampes ainsi que l'huile pour le luminaire ; 
###### 15
l'autel des parfums et ses barres, l'huile d'onction, l'encens aromatique et le voile de l'entrée, pour l'entrée de la Demeure ; 
###### 16
l'autel des holocaustes et son treillis de bronze, ses barres et tous ses accessoires, le bassin et son socle ; 
###### 17
les courtines du parvis, ses colonnes, ses socles et le rideau de l'entrée du parvis ; 
###### 18
les piquets de la Demeure et les piquets du parvis avec leurs cordes ; 
###### 19
les vêtements d'apparat pour officier dans le sanctuaire - les vêtements sacrés pour le prêtre Aaron et les vêtements de ses fils pour l'exercice du sacerdoce. "
###### 20
Alors toute la communauté des Israélites se retira de la présence de Moïse. 
###### 21
Puis tous ceux que leur cœur y portait et tous ceux que leur âme y incitait apportèrent la contribution de Yahvé, pour le travail de la Tente du Rendez-vous, pour son service général et pour les vêtements sacrés. 
###### 22
Les hommes et les femmes vinrent, tous ceux que leur cœur y incitait apportèrent des broches, des anneaux, des bagues, des colliers, toutes sortes d'objets d'or - tous ceux qui avaient voué de l'or à Yahvé. 
###### 23
Tous ceux qui se trouvaient avoir de la pourpre violette et écarlate, du cramoisi, du lin fin, du poil de chèvre, des peaux de béliers teintes en rouge et du cuir fin, l'apportèrent. 
###### 24
Tous ceux qui offraient une contribution d'argent et de bronze apportèrent la contribution de Yahvé, et tous ceux qui se trouvaient avoir du bois d'acacia pour tous les travaux à exécuter l'apportèrent. 
###### 25
Toutes les femmes habiles filèrent de leurs mains et apportèrent ce qu'elles avaient filé : pourpre violette et écarlate, cramoisi et lin fin. 
###### 26
Toutes les femmes que leur cœur y portait en raison de leur habileté, filèrent le poil de chèvre. 
###### 27
Les chefs apportèrent les pierres de cornaline et les pierres à enchâsser dans l'éphod et le pectoral, 
###### 28
les aromates et l'huile pour le luminaire, pour l'huile d'onction et pour l'encens aromatique. 
###### 29
Tous les Israélites, hommes et femmes, que leur cœur incitait à contribuer à l'ensemble de l'ouvrage que Yahvé, par l'intermédiaire de Moïse, avait ordonné d'exécuter, apportèrent une offrande à Yahvé. 
###### 30
Moïse dit aux Israélites : " Voyez, Yahvé a désigné nommément Beçaléel, fils de Uri, fils de Hur, de la tribu de Juda. 
###### 31
Il l'a comblé de l'esprit de Dieu, d'habileté, d'intelligence et de savoir, pour toute sorte d'ouvrages ; 
###### 32
pour concevoir les projets et les exécuter en or, en argent et en bronze, 
###### 33
pour tailler les pierres à enchâsser, pour tailler le bois et pour exécuter toutes sortes d'œuvres d'art. 
###### 34
Il a mis en son cœur, à lui ainsi qu'à Oholiab, fils d'Ahisamak, de la tribu de Dan, le don d'enseigner. 
###### 35
Il les a comblés d'habileté pour exécuter toute sorte d'ouvrages, tous les ouvrages du ciseleur, du brodeur, du brocheur de pourpre violette et écarlate, de cramoisi et de lin fin, et du tisserand, de tous ceux qui font toute sorte d'ouvrages et de ceux qui conçoivent des projets. 
