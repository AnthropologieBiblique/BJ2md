---
aliases : 
- Exode 19
- Exode 19
- Ex 19
- Exodus 19
tags : 
- Bible/Ex/19
- français
cssclass : français
---

# Exode 19

###### 1
Le troisième mois après leur sortie du pays d'Égypte, ce jour-là, les Israélites atteignirent le désert du Sinaï. 
###### 2
Ils partirent de Rephidim et atteignirent le désert du Sinaï, et ils campèrent dans le désert ; Israël campa là, en face de la montagne. 
###### 3
Moïse alors monta vers Dieu. Yahvé l'appela de la montagne et lui dit : " Tu parleras ainsi à la maison de Jacob, tu déclareras aux Israélites : 
###### 4
"Vous avez vu vous-mêmes ce que j'ai fait aux Égyptiens, et comment je vous ai emportés sur des ailes d'aigles et amenés vers moi. 
###### 5
Maintenant, si vous écoutez ma voix et gardez mon alliance, je vous tiendrai pour mon bien propre parmi tous les peuples, car toute la terre est à moi. 
###### 6
Je vous tiendrai pour un royaume de prêtres, une nation sainte. " Voilà les paroles que tu diras aux Israélites. " 
###### 7
Moïse alla et convoqua les anciens du peuple et leur exposa tout ce que Yahvé lui avait ordonné, 
###### 8
et le peuple entier, d'un commun accord, répondit : " Tout ce que Yahvé a dit, nous le ferons. " Moïse rapporta à Yahvé les paroles du peuple. 
###### 9
Yahvé dit à Moïse : " Je vais venir à toi dans l'épaisseur de la nuée, afin que le peuple entende quand je parlerai avec toi et croie en toi pour toujours. " Et Moïse rapporta à Yahvé les paroles du peuple. 
###### 10
Yahvé dit à Moïse : " Va trouver le peuple et fais-le se sanctifier aujourd'hui et demain ; qu'ils lavent leurs vêtements 
###### 11
et se tiennent prêts pour après-demain, car après-demain Yahvé descendra aux yeux de tout le peuple sur la montagne du Sinaï. 
###### 12
Puis délimite le pourtour de la montagne et dis : "Gardez-vous de gravir la montagne et même d'en toucher le bord. Quiconque touchera la montagne sera mis à mort. 
###### 13
Personne ne portera la main sur lui ; il sera lapidé ou percé de flèches, homme ou bête, il ne vivra pas. " Quand la corne de bélier mugira, eux graviront la montagne. "
###### 14
Moïse descendit de la montagne et vint trouver le peuple qu'il fit se sanctifier, et ils lavèrent leurs vêtements. 
###### 15
Puis il dit au peuple : " Tenez-vous prêts pour après-demain, ne vous approchez pas de la femme. 
###### 16
Or le surlendemain, dès le matin, il y eut des coups de tonnerre, des éclairs et une épaisse nuée sur la montagne, ainsi qu'un très puissant son de trompe et, dans le camp, tout le peuple trembla. 
###### 17
Moïse fit sortir le peuple du camp, à la rencontre de Dieu, et ils se tinrent au bas de la montagne. 
###### 18
Or la montagne du Sinaï était toute fumante, parce que Yahvé y était descendu dans le feu ; la fumée s'en élevait comme d'une fournaise et toute la montagne tremblait violemment. 
###### 19
Le son de trompe allait en s'amplifiant ; Moïse parlait et Dieu lui répondait dans le tonnerre. 
###### 20
Yahvé descendit sur la montagne du Sinaï, au sommet de la montagne. Yahvé appela Moïse au sommet de la montagne et Moïse monta. 
###### 21
Yahvé dit à Moïse : " Descends et avertis le peuple de ne pas franchir les limites pour venir voir Yahvé, car beaucoup d'entre eux périraient. 
###### 22
Même les prêtres qui approchent Yahvé doivent se sanctifier de peur que Yahvé ne se déchaîne contre eux. " 
###### 23
Moïse dit à Yahvé : " Le peuple ne peut pas gravir la montagne du Sinaï puisque toi-même tu nous as avertis : délimite la montagne et déclare-la sacrée. " 
###### 24
Yahvé reprit : " Allons, descends et remontez, toi et Aaron. Mais que les prêtres et le peuple ne franchissent pas les limites pour monter vers Yahvé, de peur qu'il ne se déchaîne contre eux. " 
###### 25
Moïse descendit alors vers le peuple et lui dit:
