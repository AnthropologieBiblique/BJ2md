---
aliases : 
- Exode 5
- Exode 5
- Ex 5
- Exodus 5
tags : 
- Bible/Ex/5
- français
cssclass : français
---

# Exode 5

###### 1
Après cela, Moïse et Aaron vinrent trouver Pharaon et lui dirent : " Ainsi parle Yahvé, le Dieu d'Israël : laisse partir mon peuple, qu'il célèbre une fête pour moi dans le désert. " 
###### 2
Pharaon répondit : " Qui est Yahvé, pour que j'écoute sa voix et que je laisse partir Israël ? Je ne connais pas Yahvé, et quant à Israël, je ne le laisserai pas partir. " 
###### 3
Ils dirent : " Le Dieu des Hébreux est venu à notre rencontre. Accorde-nous d'aller à trois jours de marche dans le désert pour sacrifier à Yahvé notre Dieu, sinon il nous frapperait de la peste ou de l'épée. " 
###### 4
Le roi d'Égypte leur dit : " Pourquoi, Moïse et Aaron, voulez-vous débaucher le peuple de ses travaux ? Retournez à vos corvées. " 
###### 5
Pharaon dit : " Maintenant que le peuple est nombreux dans le pays, vous voudriez lui faire interrompre ses corvées ? 
###### 6
Le jour même, Pharaon donna cet ordre aux surveillants du peuple et aux scribes : 
###### 7
" Ne continuez plus à donner de la paille hachée au peuple pour mouler les briques, comme hier et avant-hier ; qu'ils aillent eux-mêmes ramasser la paille qu'il leur faut. 
###### 8
Mais vous leur imposerez la même quantité de briques qu'ils fabriquaient hier et avant-hier, sans rien en retrancher car ce sont des paresseux. C'est pour cela qu'ils crient : "Allons sacrifier à notre Dieu. " 
###### 9
Qu'on alourdisse le travail de ces gens, qu'ils le fassent et ne prêtent plus attention à ces paroles trompeuses. "
###### 10
Les surveillants du peuple et les scribes allèrent dire au peuple : " Ainsi parle Pharaon : Je ne vous donne plus de paille hachée. 
###### 11
Allez vous-mêmes vous chercher de la paille hachée où vous pourrez en trouver, mais rien ne sera retranché de votre travail. " 
###### 12
Alors le peuple se dispersa dans tout le pays d'Égypte pour ramasser du chaume pour en faire de la paille hachée. 
###### 13
Les surveillants les harcelaient : " Terminez votre travail quotidien comme lorsqu'il y avait de la paille hachée. " 
###### 14
On frappa les scribes des Israélites, ceux que les surveillants de Pharaon leur avaient imposés en disant : " Pourquoi n'avez-vous pas terminé la quantité de briques prescrite, aujourd'hui comme hier et avant-hier ? 
###### 15
Les scribes des Israélites vinrent se plaindre auprès de Pharaon en disant : " Pourquoi traiter ainsi tes serviteurs ? 
###### 16
On ne donne plus de paille hachée à tes serviteurs et l'on nous dit : "Faites des briques", et voici que l'on frappe tes serviteurs... " 
###### 17
Il répondit : " Vous êtes des paresseux, des paresseux, voilà pourquoi vous dites : "Nous voulons aller sacrifier à Yahvé. " 
###### 18
Maintenant allez travailler. On ne vous donnera pas de paille hachée mais vous livrerez la quantité de briques fixée. 
###### 19
Les scribes des Israélites se virent dans un mauvais cas quand on leur dit : " Vous ne diminuerez rien de votre production quotidienne de briques. " 
###### 20
Ayant quitté Pharaon, ils se heurtèrent à Moïse et à Aaron qui se tenaient devant eux. 
###### 21
Ils leur dirent : " Que Yahvé vous observe et qu'il juge !Vous nous avez rendus odieux aux yeux de Pharaon et de ses serviteurs et vous leur avez mis l'épée en main pour nous tuer. " 
###### 22
Moïse retourna vers Yahvé et lui dit : " Seigneur, pourquoi maltraites-tu ce peuple ? Pourquoi m'as-tu envoyé ? 
###### 23
Depuis que je suis venu trouver Pharaon et que je lui ai parlé en ton nom, il maltraite ce peuple, et tu ne fais rien pour délivrer ton peuple. " 
