---
aliases : 
- Exode 16
- Exode 16
- Ex 16
- Exodus 16
tags : 
- Bible/Ex/16
- français
cssclass : français
---

# Exode 16

###### 1
Ils partirent d'Élim, et toute la communauté des Israélites arriva au désert de Sîn, situé entre Élim et le Sinaï, le quinzième jour du second mois qui suivit leur sortie d'Égypte. 
###### 2
Toute la communauté des Israélites se mit à murmurer contre Moïse et Aaron dans le désert. 
###### 3
Les Israélites leur dirent : " Que ne sommes-nous morts de la main de Yahvé au pays d'Égypte, quand nous étions assis auprès de la marmite de viande et mangions du pain à satiété !A coup sûr, vous nous avez amenés dans ce désert pour faire mourir de faim toute cette multitude. "
###### 4
Yahvé dit à Moïse : " Je vais faire pleuvoir pour vous du pain du haut du ciel. Les gens sortiront et recueilleront chaque jour leur ration du jour ; je veux ainsi les mettre à l'épreuve pour voir s'ils marcheront selon ma loi ou non. 
###### 5
Et le sixième jour, quand ils prépareront ce qu'ils auront rapporté, il y en aura le double de ce qu'ils recueillent chaque jour. "
###### 6
Moïse et Aaron dirent à toute la communauté des Israélites : " Ce soir vous saurez que c'est Yahvé qui vous a fait sortir du pays d'Égypte 
###### 7
et au matin vous verrez la gloire de Yahvé. Car il a entendu vos murmures contre Yahvé. Et nous, que sommes-nous pour que vous murmuriez contre nous ? " 
###### 8
Moïse dit : " Yahvé vous donnera ce soir de la viande à manger et, au matin, du pain à satiété, car Yahvé a entendu vos murmures contre lui. Nous, que sommes-nous ? Ce n'est pas contre nous que vont vos murmures, mais contre Yahvé. "
###### 9
Moïse dit à Aaron : " Dis à toute la communauté des Israélites : Approchez-vous devant Yahvé, car il a entendu vos murmures. " 
###### 10
Comme Aaron parlait à toute la communauté des Israélites, ils se tournèrent vers le désert, et voici que la gloire de Yahvé apparut dans la nuée. 
###### 11
Yahvé parla à Moïse et lui dit : 
###### 12
" J'ai entendu les murmures des Israélites. Parle-leur et dis-leur : Au crépuscule vous mangerez de la viande et au matin vous serez rassasiés de pain. Vous saurez alors que je suis Yahvé votre Dieu. " 
###### 13
Le soir, des cailles montèrent et couvrirent le camp, et au matin, il y avait une couche de rosée tout autour du camp. 
###### 14
Cette couche de rosée évaporée, apparut sur la surface du désert quelque chose de menu, de granuleux, de fin comme du givre sur le sol. 
###### 15
Lorsque les Israélites virent cela, ils se dirent l'un à l'autre : " Qu'est-ce cela ? " car ils ne savaient pas ce que c'était. Moïse leur dit : " Cela, c'est le pain que Yahvé vous a donné à manger. 
###### 16
Voici ce qu'a ordonné Yahvé : Recueillez-en chacun selon ce qu'il peut manger, un gomor par personne. Vous en prendrez chacun selon le nombre de personnes qu'il a dans sa tente. "
###### 17
Les Israélites firent ainsi et en recueillirent les uns beaucoup, les autres peu. 
###### 18
Quand ils mesurèrent au gomor, celui qui avait beaucoup recueilli n'en avait pas trop, et celui qui avait peu recueilli en avait assez : chacun avait recueilli ce qu'il pouvait manger. 
###### 19
Moïse leur dit : " Que personne n'en mette en réserve jusqu'au lendemain. " 
###### 20
Certains n'écoutèrent pas Moïse et en mirent en réserve jusqu'au lendemain, mais les vers s'y mirent et cela devint infect. Moïse s'irrita contre eux. 
###### 21
Ils en recueillirent chaque matin, chacun selon ce qu'il pouvait manger, et quand le soleil devenait chaud, cela fondait. 
###### 22
Or le sixième jour, ils recueillirent le double de pain, deux gomor par personne, et tous les chefs de la communauté vinrent l'annoncer à Moïse. 
###### 23
Il leur dit : " Voici ce qu'a dit Yahvé : Demain est un jour de repos complet, un saint sabbat pour Yahvé. Cuisez ce que vous voulez cuire, faites bouillir ce que vous voulez faire bouillir, et tout le surplus, mettez-le en réserve jusqu'à demain. " 
###### 24
Ils le mirent en réserve jusqu'au lendemain, comme Moïse l'avait ordonné ; ce ne fut pas infect et il n'y eut pas de vers dedans. 
###### 25
Moïse dit : " Mangez-le aujourd'hui, car ce jour est un sabbat pour Yahvé ; aujourd'hui vous n'en trouveriez pas dans les champs. 
###### 26
Pendant six jours vous en recueillerez mais le septième jour, le sabbat, il n'y en aura pas. " 
###### 27
Le septième jour cependant, des gens sortirent pour en recueillir mais ils n'en trouvèrent pas. 
###### 28
Yahvé dit à Moïse : " Jusqu'à quand refuserez-vous d'écouter mes commandements et mes lois ? 
###### 29
Voyez, Yahvé vous a donné le sabbat, c'est pourquoi le sixième jour il vous donne du pain pour deux jours. Restez chacun là où vous êtes, que personne ne sorte de chez soi le septième jour. " 
###### 30
Le peuple chôma donc le septième jour. 
###### 31
La maison d'Israël donna à cela le nom de manne. On eût dit de la graine de coriandre, c'était blanc et cela avait un goût de galette au miel. 
###### 32
Moïse dit : " Voici ce qu'a ordonné Yahvé : Remplissez-en un gomor et préservez-le pour vos descendants, afin qu'ils voient le pain dont je vous ai nourris dans le désert, quand je vous ai fait sortir du pays d'Égypte. " 
###### 33
Moïse dit à Aaron : " Prends un vase, mets-y un plein gomor de manne et place-le devant Yahvé afin de le préserver pour vos générations. " 
###### 34
Comme Yahvé l'avait ordonné à Moïse, Aaron le plaça devant le Témoignage, pour qu'il y soit préservé. 
###### 35
Les Israélites mangèrent de la manne pendant quarante ans, jusqu'à ce qu'ils arrivent en pays habité ; ils mangèrent la manne jusqu'à ce qu'ils arrivent aux confins du pays de Canaan. 
###### 36
Le gomor, c'est un dixième de mesure. 
