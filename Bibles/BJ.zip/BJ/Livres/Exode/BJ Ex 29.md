---
aliases : 
- Exode 29
- Exode 29
- Ex 29
- Exodus 29
tags : 
- Bible/Ex/29
- français
cssclass : français
---

# Exode 29

###### 1
" Voici ce que tu leur feras pour les consacrer à mon sacerdoce. Prends un jeune taureau et deux béliers sans défaut, 
###### 2
puis des pains sans levain, des gâteaux sans levain pétris à l'huile, des galettes sans levain frottées d'huile que tu auras faites de fleur de farine de froment. 
###### 3
Tu les mettras dans une même corbeille et tu les offriras, dans la corbeille, en même temps que le taureau et les deux béliers. 
###### 4
" Tu feras approcher Aaron et ses fils de l'entrée de la Tente du Rendez-vous, et tu les laveras avec de l'eau. 
###### 5
Tu prendras les vêtements et tu revêtiras Aaron de la tunique, du manteau de l'éphod, de l'éphod, du pectoral, et tu lui fixeras l'écharpe de l'éphod. 
###### 6
Tu placeras le turban sur sa tête, et tu y mettras le signe de la sainte consécration. 
###### 7
Tu prendras l'huile d'onction, tu en répandras sur sa tête et tu l'oindras. 
###### 8
Tu feras alors approcher ses fils et tu les revêtiras de tuniques. 
###### 9
Tu les ceindras d'une ceinture et tu assujettiras leur calotte. Le sacerdoce leur appartiendra alors par un décret perpétuel. Tu investiras Aaron et ses fils. 
###### 10
" Tu amèneras le jeune taureau devant la Tente du Rendez-vous. Aaron et ses fils poseront leurs mains sur la tête du taureau 
###### 11
puis tu abattras le taureau devant Yahvé, à l'entrée de la Tente du Rendez-vous. 
###### 12
Tu prendras du sang du taureau et tu le mettras avec ton doigt sur les cornes de l'autel : tout le sang, tu le répandras à la base de l'autel. 
###### 13
Tu prendras toute la graisse qui recouvre les entrailles, la masse graisseuse partant du foie, les deux rognons avec la graisse qui y adhère, et tu les feras fumer à l'autel. 
###### 14
Mais la chair du jeune taureau, sa peau et sa fiente, tu les brûleras au feu hors du camp, car c'est un sacrifice pour le péché. 
###### 15
Tu prendras ensuite l'un des béliers ; Aaron et ses fils poseront leurs mains sur la tête du bélier, 
###### 16
puis tu abattras le bélier et tu prendras son sang que tu répandras contre l'autel, tout autour. 
###### 17
Tu couperas le bélier en quartiers, tu en laveras les entrailles et les pattes, et tu les mettras sur ses quartiers et sur sa tête. 
###### 18
Puis tu feras fumer le bélier tout entier à l'autel. C'est là un holocauste pour Yahvé. C'est un parfum d'apaisement, un mets consumé pour Yahvé. 
###### 19
Tu prendras ensuite le second bélier ; Aaron et ses fils poseront leurs mains sur la tête du bélier ; 
###### 20
tu abattras le bélier. Tu prendras de son sang et tu le mettras sur le lobe de l'oreille droite d'Aaron, sur le lobe de l'oreille droite de ses fils, sur le pouce de leur main droite et sur le gros orteil de leur pied droit. Puis tu répandras le sang contre l'autel, tout autour. 
###### 21
Tu prendras du sang qui est sur l'autel et de l'huile d'onction, et tu en aspergeras Aaron et ses vêtements, ainsi que ses fils et les vêtements de ses fils ; ils seront ainsi consacrés, lui et ses vêtements, ainsi que ses fils et les vêtements de ses fils. 
###### 22
" Du bélier, tu prendras la graisse, la queue, la graisse qui recouvre les entrailles et la masse graisseuse partant du foie, les rognons et la graisse qui y adhère, ainsi que la patte droite, car c'est un bélier d'investiture. 
###### 23
Tu prendras aussi un pain rond, un gâteau à l'huile et une galette dans la corbeille d'azymes qui est devant Yahvé. 
###### 24
Tu placeras le tout sur les paumes d'Aaron et les paumes de ses fils, et tu feras le geste de présentation devant Yahvé. 
###### 25
Tu les prendras ensuite de leurs mains et tu les feras fumer à l'autel, par-dessus l'holocauste, en parfum d'apaisement devant Yahvé ; c'est là un mets consumé pour Yahvé. 
###### 26
Tu prendras la poitrine du bélier d'investiture d'Aaron, et tu feras avec elle le geste de présentation devant Yahvé ; ce sera ta part. 
###### 27
Tu consacreras la poitrine qui a été présentée, ainsi que la patte qui a été prélevée, qui ont été présentées et prélevées sur le bélier d'investiture d'Aaron et de ses fils. 
###### 28
Ce sera, selon un décret perpétuel, ce qu'Aaron et ses fils recevront des Israélites, car c'est un prélèvement, le prélèvement de Yahvé, fait par les Israélites sur leurs sacrifices de communion ; un prélèvement pour Yahvé. 
###### 29
Les vêtements sacrés d'Aaron passeront après lui à ses fils qui les revêtiront lors de leur onction et de leur investiture. 
###### 30
Pendant sept jours il les revêtira, celui des fils d'Aaron qui sera prêtre après lui et qui entrera dans la Tente du Rendez-vous pour servir dans le sanctuaire. 
###### 31
" Tu prendras le bélier d'investiture et tu en feras cuire la viande dans un lieu saint. 
###### 32
Aaron et ses fils mangeront la viande du bélier et le pain qui est dans la corbeille, à l'entrée de la Tente du Rendez-vous. 
###### 33
Ils mangeront ce qui aura servi à faire l'expiation pour eux, lors de leur investiture et de leur consécration. Nul profane n'en mangera, car ce sont choses saintes. 
###### 34
Si, au matin, il reste de la viande du sacrifice d'investiture et du pain, tu brûleras le reste au feu, on ne le mangera pas : c'est chose sainte. 
###### 35
Tu feras ainsi pour Aaron et ses fils, conformément à tout ce que je t'ai ordonné : tu emploieras sept jours pour leur investiture. 
###### 36
" Chaque jour tu offriras aussi un jeune taureau en sacrifice pour le péché - en expiation. Tu offriras pour l'autel un sacrifice pour le péché, quand tu feras pour lui l'expiation, et tu l'oindras pour le consacrer. 
###### 37
Pendant sept jours tu feras l'expiation pour l'autel et tu le consacreras ; il sera alors éminemment saint et tout ce qui touchera l'autel sera saint. 
###### 38
" Voici ce que tu offriras sur l'autel : deux agneaux mâles d'un an, chaque jour, à perpétuité. 
###### 39
Tu offriras l'un de ces agneaux le matin et l'autre au crépuscule ; 
###### 40
avec le premier agneau, un dixième de mesure de fleur de farine pétrie avec un quart de setier d'huile d'olives broyées et une libation d'un quart de setier de vin. 
###### 41
Le second agneau, tu l'offriras au crépuscule ; tu l'offriras avec une oblation et une libation semblables à celles du matin : en parfum d'apaisement, en offrande consumée pour Yahvé. 
###### 42
Ce sera un holocauste perpétuel pour toutes vos générations, à l'entrée de la Tente du Rendez-vous, en présence de Yahvé, où je te donnerai rendez-vous pour te parler. 
###### 43
Je donnerai rendez-vous aux Israélites en ce lieu, et il sera consacré par ma gloire. 
###### 44
Je consacrerai la Tente du Rendez-vous et l'autel. Je consacrerai aussi Aaron et ses fils pour qu'ils exercent mon sacerdoce. 
###### 45
Je demeurerai au milieu des Israélites et je serai leur Dieu, 
###### 46
et ils sauront que je suis Yahvé, leur Dieu, qui les a fait sortir du pays d'Égypte pour demeurer parmi eux, moi Yahvé, leur Dieu. 
