---
aliases : 
- Exode 24
- Exode 24
- Ex 24
- Exodus 24
tags : 
- Bible/Ex/24
- français
cssclass : français
---

# Exode 24

###### 1
Il dit à Moïse : " Montez vers Yahvé, toi, Aaron, Nadab, Abihu et soixante-dix des anciens d'Israël, et vous vous prosternerez à distance. 
###### 2
Moïse s'approchera seul de Yahvé. Eux n'approcheront pas et le peuple ne montera pas avec lui. "
###### 3
Moïse vint rapporter au peuple toutes les paroles de Yahvé et toutes les lois, et tout le peuple répondit d'une seule voix ; ils dirent : " Toutes les paroles que Yahvé a prononcées, nous les mettrons en pratique. " 
###### 4
Moïse mit par écrit toutes les paroles de Yahvé puis, se levant de bon matin, il bâtit un autel au bas de la montagne et douze stèles pour les douze tribus d'Israël. 
###### 5
Puis il envoya de jeunes Israélites offrir des holocaustes et immoler à Yahvé de jeunes taureaux en sacrifice de communion. 
###### 6
Moïse prit la moitié du sang et la mit dans des bassins, et l'autre moitié du sang, il la répandit sur l'autel. 
###### 7
Il prit le livre de l'Alliance et il en fit la lecture au peuple qui déclara : " Tout ce que Yahvé a dit, nous le ferons et nous y obéirons. " 
###### 8
Moïse, ayant pris le sang, le répandit sur le peuple et dit : " Ceci est le sang de l'Alliance que Yahvé a conclue avec vous moyennant toutes ces clauses. "
###### 9
Moïse monta, ainsi qu'Aaron, Nadab, Abihu et soixante-dix des anciens d'Israël. 
###### 10
Ils virent le Dieu d'Israël. Sous ses pieds il y avait comme un pavement de saphir, aussi pur que le ciel même. 
###### 11
Il ne porta pas la main sur les notables des Israélites. Ils contemplèrent Dieu puis ils mangèrent et burent. 
###### 12
Yahvé dit à Moïse : " Monte vers moi sur la montagne et demeure là, que je te donne les tables de pierre - la loi et le commandement - que j'ai écrites pour leur instruction. " 
###### 13
Moïse se leva, ainsi que Josué son serviteur, et ils montèrent à la montagne de Dieu. 
###### 14
Il dit aux anciens : " Attendez-nous ici jusqu'à notre retour ; vous avez avec vous Aaron et Hur, que celui qui a une affaire à régler s'adresse à eux. " 
###### 15
Puis Moïse monta sur la montagne. La nuée couvrit la montagne. 
###### 16
La gloire de Yahvé s'établit sur le mont Sinaï, et la nuée le couvrit pendant six jours. Le septième jour, Yahvé appela Moïse du milieu de la nuée. 
###### 17
L'aspect de la gloire de Yahvé était aux yeux des Israélites celui d'une flamme dévorante au sommet de la montagne. 
###### 18
Moïse entra dans la nuée et monta sur la montagne. Et Moïse demeura sur la montagne quarante jours et quarante nuits. 
