---
aliases : 
- Exode 33
- Exode 33
- Ex 33
- Exodus 33
tags : 
- Bible/Ex/33
- français
cssclass : français
---

# Exode 33

###### 1
Yahvé dit à Moïse : " Va, monte d'ici, toi et le peuple que tu as fait monter du pays d'Égypte, vers la terre dont j'ai dit par serment à Abraham, Isaac et Jacob que je la donnerais à leur descendance. 
###### 2
J'enverrai un ange devant toi et j'expulserai les Cananéens, les Amorites, les Hittites, les Perizzites, les Hivvites et les Jébuséens. 
###### 3
Monte vers une terre qui ruisselle de lait et de miel, mais je ne monterai pas au milieu de toi, de peur que je ne t'extermine en chemin car tu es un peuple à la nuque raide. " 
###### 4
Lorsqu'il eut entendu cette parole sévère, le peuple prit le deuil et personne ne porta plus ses parures. 
###### 5
Alors Yahvé dit à Moïse : " Dis aux Israélites : Vous êtes un peuple à la nuque raide, si je montais au milieu de toi, ne fût-ce qu'un moment, je t'exterminerais. Et maintenant, dépouille-toi de tes parures, que je sache comment te traiter. " 
###### 6
Alors les Israélites se débarrassèrent de leurs parures, à partir du mont Horeb. 
###### 7
Moïse prenait la Tente et la plantait pour lui hors du camp, loin du camp. Il la nomma Tente du Rendez-vous, et quiconque avait à consulter Yahvé sortait vers la Tente du Rendez-vous qui se trouvait hors du camp. 
###### 8
Chaque fois que Moïse sortait vers la Tente, tout le peuple se levait, chacun se postait à l'entrée de sa tente, et suivait Moïse du regard jusqu'à ce qu'il entrât dans la Tente. 
###### 9
Chaque fois que Moïse entrait dans la Tente, la colonne de nuée descendait, se tenait à l'entrée de la Tente et Il parlait avec Moïse. 
###### 10
Tout le peuple voyait la colonne de nuée qui se tenait à l'entrée de la Tente, et tout le peuple se levait et se prosternait, chacun à l'entrée de sa tente. 
###### 11
Yahvé parlait à Moïse face à face, comme un homme parle à son ami, puis il rentrait au camp, mais son serviteur Josué, fils de Nûn, un jeune homme, ne quittait pas l'intérieur de la Tente. 
###### 12
Moïse dit à Yahvé : " Vois, tu me dis : "Fais monter ce peuple", et tu ne me fais pas connaître qui tu enverras avec moi. Tu avais pourtant dit : "Je te connais par ton nom et tu as trouvé grâce à mes yeux. " 
###### 13
Si donc j'ai trouvé grâce à tes yeux, daigne me faire connaître tes voies pour que je te connaisse et que je trouve grâce à tes yeux. Considère aussi que cette nation est ton peuple. " 
###### 14
Yahvé dit : " J'irai moi-même, et je te donnerai le repos. " 
###### 15
Et il dit : " Si tu ne viens pas toi-même, ne nous fais pas monter d'ici ; 
###### 16
comment saura-t-on alors que j'ai trouvé grâce à tes yeux, moi et ton peuple ? N'est-ce pas à ce que tu iras avec nous ? En sorte que nous soyons distincts, moi et ton peuple, de tous les peuples qui sont sur la face de la terre. " 
###### 17
Yahvé dit à Moïse : " Cette chose que tu as dite, je la ferai encore parce que tu as trouvé grâce à mes yeux et que je te connais par ton nom. 
###### 18
Il lui dit : " Fais-moi de grâce voir ta gloire. " 
###### 19
Et il dit : " Je ferai passer devant toi toute ma beauté et je prononcerai devant toi le nom de Yahvé. Je fais grâce à qui je fais grâce et j'ai pitié de qui j'ai pitié. " 
###### 20
" Mais, dit-il, tu ne peux pas voir ma face, car l'homme ne peut me voir et vivre. " 
###### 21
Yahvé dit encore : " Voici une place près de moi ; tu te tiendras sur le rocher. 
###### 22
Quand passera ma gloire, je te mettrai dans la fente du rocher et je te couvrirai de ma main jusqu'à ce que je sois passé. 
###### 23
Puis j'écarterai ma main et tu verras mon dos ; mais ma face, on ne peut la voir. 
