---
aliases : 
- Exode 7
- Exode 7
- Ex 7
- Exodus 7
tags : 
- Bible/Ex/7
- français
cssclass : français
---

# Exode 7

###### 1
Yahvé dit à Moïse : " Vois, j'ai fait de toi un dieu pour Pharaon, et Aaron, ton frère, sera ton prophète. 
###### 2
Toi, tu lui diras tout ce que je t'ordonnerai, et Aaron, ton frère, le répétera à Pharaon pour qu'il laisse les Israélites partir de son pays. 
###### 3
Pour moi, j'endurcirai le cœur de Pharaon et je multiplierai mes signes et mes prodiges dans le pays d'Égypte. 
###### 4
Pharaon ne vous écoutera pas, alors je porterai la main sur l'Égypte et je ferai sortir mes armées, mon peuple, les Israélites, du pays d'Égypte, avec de grands jugements. 
###### 5
Ils sauront, les Égyptiens, que suis Yahvé, quand j'étendrai ma main contre les Égyptiens et que je ferai sortir de chez eux les Israélites. "
###### 6
Moïse et Aaron firent comme Yahvé leur avait ordonné. 
###### 7
Moïse était âgé de quatre-vingts ans et Aaron de quatre-vingt-trois ans lorsqu'ils parlèrent à Pharaon. 
###### 8
Yahvé dit à Moïse et à Aaron : 
###### 9
" Si Pharaon vous dit d'accomplir un prodige, tu diras à Aaron : Prends ton bâton, jette-le devant Pharaon, et qu'il se change en serpent. " 
###### 10
Moïse et Aaron allèrent trouver Pharaon et firent comme l'avait ordonné Yahvé. Aaron jeta son bâton devant Pharaon et ses serviteurs, et il se changea en serpent. 
###### 11
Pharaon à son tour convoqua les sages et les enchanteurs, et, avec leurs sortilèges, les magiciens d'Égypte en firent autant. 
###### 12
Ils jetèrent chacun son bâton qui se changea en serpent, mais le bâton d'Aaron engloutit leurs bâtons. 
###### 13
Cependant le cœur de Pharaon s'endurcit et il ne les écouta pas, comme l'avait prédit Yahvé. 
###### 14
Yahvé dit à Moïse : " Le cœur de Pharaon s'est appesanti et il a refusé de laisser partir le peuple. 
###### 15
Va, demain matin, trouver Pharaon, à l'heure où il se rend au bord de l'eau, et tiens-toi à l'attendre sur la rive du Fleuve. Tu prendras en main le bâton qui s'est changé en serpent. 
###### 16
Tu lui diras : Yahvé, le Dieu des Hébreux, m'a envoyé vers toi pour te dire : "Laisse partir mon peuple, qu'il me serve dans le désert. " Jusqu'à présent tu n'as pas écouté. 
###### 17
Ainsi parle Yahvé : En ceci tu sauras que je suis Yahvé. Du bâton que j'ai en main, je vais frapper les eaux du Fleuve et elles se changeront en sang. 
###### 18
Les poissons du Fleuve crèveront, le Fleuve s'empuantira, et les Égyptiens ne pourront plus boire l'eau du Fleuve. "
###### 19
Yahvé dit à Moïse : " Dis à Aaron : Prends ton bâton et étends la main sur les eaux d'Égypte - sur ses fleuves et sur ses canaux, sur ses marais et sur tous ses réservoirs d'eau - et elles se changeront en sang, et tout le pays d'Égypte sera plein de sang, même les arbres et les pierres. " 
###### 20
Moïse et Aaron firent comme l'avait ordonné Yahvé. Il leva son bâton et il frappa les eaux qui sont dans le Fleuve aux yeux de Pharaon et de ses serviteurs, et toutes les eaux qui sont dans le Fleuve se changèrent en sang. 
###### 21
Les poissons du Fleuve crevèrent et le Fleuve s'empuantit ; et les Égyptiens ne purent plus boire l'eau du Fleuve ; il y eut du sang dans tout le pays d'Égypte. 
###### 22
Mais les magiciens d'Égypte avec leurs sortilèges en firent autant ; le cœur de Pharaon s'endurcit et il ne les écouta pas, comme l'avait prédit Yahvé. 
###### 23
Pharaon s'en retourna et rentra dans sa maison sans même prêter attention à cela. 
###### 24
Tous les Égyptiens firent des sondages aux abords du Fleuve en quête d'eau potable, car ils ne pouvaient boire l'eau du Fleuve. 
###### 25
Sept jours s'écoulèrent après que Yahvé eut frappé le Fleuve. 
###### 26
Yahvé dit à Moïse : " Va trouver Pharaon et dis-lui : Ainsi parle Yahvé : "Laisse partir mon peuple, qu'il me serve. " 
###### 27
Si tu refuses, toi, de le laisser partir, moi je vais infester de grenouilles tout ton territoire. 
###### 28
Le Fleuve grouillera de grenouilles, elles monteront et entreront dans ta maison, dans la chambre où tu couches, sur ton lit, dans les maisons de tes serviteurs et de ton peuple, dans tes fours et dans tes huches. 
###### 29
Les grenouilles grimperont même sur toi, sur ton peuple et sur tous tes serviteurs. " 
