---
aliases : 
- Exode 10
- Exode 10
- Ex 10
- Exodus 10
tags : 
- Bible/Ex/10
- français
cssclass : français
---

# Exode 10

###### 1
Yahvé dit à Moïse : " Va trouver Pharaon car c'est moi qui ai appesanti son cœur et le cœur de ses serviteurs afin d'opérer mes signes au milieu d'eux, 
###### 2
pour que tu puisses raconter à ton fils et au fils de ton fils comment je me suis joué des Égyptiens et quels signes j'ai opérés parmi eux, et que vous sachiez que je suis Yahvé. " 
###### 3
Moïse et Aaron allèrent trouver Pharaon et lui dirent : " Ainsi parle Yahvé le Dieu des Hébreux : Jusqu'à quand refuseras-tu de t'humilier devant moi ? Laisse partir mon peuple, qu'il me serve. 
###### 4
Si tu refuses de laisser partir mon peuple, dès demain je ferai venir des sauterelles sur ton territoire. 
###### 5
Elles couvriront la surface du sol et l'on ne pourra plus voir le sol. Elles dévoreront le reste de ce qui a échappé, ce que vous a laissé la grêle ; elles dévoreront tous vos arbres qui croissent dans les champs. 
###### 6
Elles rempliront tes maisons, les maisons de tous tes serviteurs et les maisons de tous les Égyptiens, ce que tes pères et les pères de tes pères n'ont jamais vu, depuis le jour où ils sont venus sur terre, jusqu'à ce jour. " Puis il se retourna et sortit de chez Pharaon. 
###### 7
Les serviteurs de Pharaon lui dirent : " Jusqu'à quand celui-ci nous sera-t-il un piège ? Laisse partir ces gens, qu'ils servent Yahvé leur Dieu. Ne sais-tu pas encore que l'Égypte va à sa ruine ? "
###### 8
On fit revenir Moïse et Aaron auprès de Pharaon qui leur dit : " Allez servir Yahvé votre Dieu, mais qui sont ceux qui vont s'en aller ? " 
###### 9
Moïse répondit : " Nous emmènerons nos jeunes gens et nos vieillards, nous emmènerons nos fils et nos filles, notre petit et notre gros bétail, car c'est pour nous une fête de Yahvé. " 
###### 10
Pharaon dit : " Que Yahvé soit avec vous comme je vais vous laisser partir, vous, vos femmes et vos enfants !Voyez comme vous avez de mauvais desseins !
###### 11
Non !Allez, vous, les hommes, servir Yahvé, puisque c'est là ce que vous demandez. " Et on les expulsa de la présence de Pharaon. 
###### 12
Yahvé dit à Moïse : " Étends ta main sur le pays d'Égypte pour que viennent les sauterelles ; qu'elles montent sur le pays d'Égypte et qu'elles dévorent toute l'herbe du pays, tout ce qu'a épargné la grêle. " 
###### 13
Moïse étendit son bâton sur le pays d'Égypte, et Yahvé fit lever sur le pays un vent d'est qui souffla tout ce jour-là et toute la nuit. Le matin venu, le vent d'est avait apporté les sauterelles. 
###### 14
Les sauterelles montèrent sur tout le pays d'Égypte en très grand nombre. Auparavant il n'y avait jamais eu autant de sauterelles, et par la suite il ne devait plus y en avoir autant. 
###### 15
Elles couvrirent toute la surface du pays et le pays fut dévasté. Elles dévorèrent toute l'herbe du pays et tous les fruits des arbres qu'avait laissés la grêle ; rien de vert ne resta sur les arbres ou sur l'herbe des champs, dans tout le pays d'Égypte. 
###### 16
Pharaon se hâta d'appeler Moïse et Aaron et dit : " J'ai péché contre Yahvé votre Dieu et contre vous. 
###### 17
Et maintenant pardonne-moi ma faute, je t'en prie, cette fois seulement, et priez Yahvé votre Dieu qu'il détourne de moi ce fléau meurtrier. " 
###### 18
Moïse sortit de chez Pharaon et pria Yahvé. 
###### 19
Yahvé changea le vent en un vent d'ouest très fort qui emporta les sauterelles et les entraîna vers la mer des Roseaux. Il ne resta plus une seule sauterelle dans tout le territoire d'Égypte. 
###### 20
Mais Yahvé endurcit le cœur de Pharaon et il ne laissa pas partir les Israélites. 
###### 21
Yahvé dit à Moïse : " Étends ta main vers le ciel et que des ténèbres palpables recouvrent le pays d'Égypte. " 
###### 22
Moïse étendit la main vers le ciel et il y eut d'épaisses ténèbres sur tout le pays d'Égypte pendant trois jours. 
###### 23
Les gens ne se voyaient plus l'un l'autre et personne ne se leva de sa place pendant trois jours, mais tous les Israélites avaient de la lumière là où ils habitaient. 
###### 24
Pharaon appela Moïse et lui dit : " Allez servir Yahvé, mais votre petit et votre gros bétail devra rester ici. Même vos femmes et vos enfants pourront aller avec vous. " 
###### 25
Moïse dit : " Tu dois toi-même mettre à notre disposition des sacrifices et des holocaustes pour que nous les offrions à Yahvé notre Dieu. 
###### 26
Même nos troupeaux viendront avec nous, pas une tête ne restera, car c'est d'eux que nous prendrons de quoi servir Yahvé notre Dieu ; et nous-mêmes, jusqu'à notre arrivée là-bas, nous ne saurons comment servir Yahvé. "
###### 27
Mais Yahvé endurcit le cœur de Pharaon et il ne voulut pas les laisser partir. 
###### 28
Pharaon dit à Moïse : " Hors d'ici !Prends garde à toi !ne te présente plus devant moi, car le jour où tu te présenteras devant moi, tu mourras. " 
###### 29
Et Moïse dit : " Tu l'as dit, je ne reviendrai plus me présenter devant toi. 
