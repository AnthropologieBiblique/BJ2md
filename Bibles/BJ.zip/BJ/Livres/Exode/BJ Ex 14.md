---
aliases : 
- Exode 14
- Exode 14
- Ex 14
- Exodus 14
tags : 
- Bible/Ex/14
- français
cssclass : français
---

# Exode 14

###### 1
Yahvé parla à Moïse et lui dit : 
###### 2
" Dis aux Israélites de rebrousser chemin et de camper devant Pi-Hahirot, entre Migdol et la mer, devant Baal-Çephôn ; vous camperez face à ce lieu, au bord de la mer. 
###### 3
Pharaon dira des Israélites : "Les voilà qui errent dans le pays, le désert s'est refermé sur eux. " 
###### 4
J'endurcirai le cœur de Pharaon et il se lancera à leur poursuite. Je me glorifierai aux dépens de Pharaon et de toute son armée, et les Égyptiens sauront que je suis Yahvé. " C'est ce qu'ils firent. 
###### 5
Lorsqu'on annonça au roi d'Égypte que le peuple avait fui, le cœur de Pharaon et de ses serviteurs changea à l'égard du peuple. Ils dirent : " Qu'avons-nous fait là, de laisser Israël quitter notre service !" 
###### 6
Pharaon fit atteler son char et emmena son armée. 
###### 7
Il prit six cents des meilleurs chars et tous les chars d'Égypte, chacun d'eux monté par des officiers. 
###### 8
Yahvé endurcit le cœur de Pharaon, le roi d'Égypte, qui se lança à la poursuite des Israélites sortant la main haute. 
###### 9
Les Égyptiens se lancèrent à leur poursuite et les rejoignirent alors qu'ils campaient au bord de la mer - tous les chevaux de Pharaon, ses chars, ses cavaliers et son armée - près de Pi-Hahirot, devant Baal-Çephôn. 
###### 10
Comme Pharaon approchait, les Israélites levèrent les yeux, et voici que les Égyptiens les poursuivaient. Les Israélites eurent grand-peur et crièrent vers Yahvé. 
###### 11
Ils dirent à Moïse : " Manquait-il de tombeaux en Égypte, que tu nous aies menés mourir dans le désert ? Que nous as-tu fait en nous faisant sortir d'Égypte ? 
###### 12
Ne te disions-nous pas en Égypte : Laisse-nous servir les Égyptiens, car mieux vaut pour nous servir les Égyptiens que de mourir dans le désert ? " 
###### 13
Moïse dit au peuple : " Ne craignez pas !Tenez ferme et vous verrez ce que Yahvé va faire pour vous sauver aujourd'hui, car les Égyptiens que vous voyez aujourd'hui, vous ne les reverrez plus jamais; 
###### 14
Yahvé combattra pour vous ; vous, vous n'aurez qu'à rester tranquilles. 
###### 15
Yahvé dit à Moïse : " Pourquoi cries-tu vers moi ? Dis aux Israélites de repartir. 
###### 16
Toi, lève ton bâton, étends ta main sur la mer et fends-la, que les Israélites puissent pénétrer à pied sec au milieu de la mer. 
###### 17
Moi, j'endurcirai le cœur des Égyptiens, ils pénétreront à leur suite et je me glorifierai aux dépens de Pharaon, de toute son armée, de ses chars et de ses cavaliers. 
###### 18
Les Égyptiens sauront que je suis Yahvé quand je me serai glorifié aux dépens de Pharaon, de ses chars et de ses cavaliers. "
###### 19
L'Ange de Dieu qui marchait en avant du camp d'Israël se déplaça et marcha derrière eux, et la colonne de nuée se déplaça de devant eux et se tint derrière eux. 
###### 20
Elle vint entre le camp des Égyptiens et le camp d'Israël. La nuée était ténébreuse et la nuit s'écoula sans que l'un puisse s'approcher de l'autre de toute la nuit. 
###### 21
Moïse étendit la main sur la mer, et Yahvé refoula la mer toute la nuit par un fort vent d'est ; il la mit à sec et toutes les eaux se fendirent. 
###### 22
Les Israélites pénétrèrent à pied sec au milieu de la mer, et les eaux leur formaient une muraille à droite et à gauche. 
###### 23
Les Égyptiens les poursuivirent, et tous les chevaux de Pharaon, ses chars et ses cavaliers pénétrèrent à leur suite au milieu de la mer. 
###### 24
A la veille du matin, Yahvé regarda de la colonne de feu et de nuée vers le camp des Égyptiens, et jeta la confusion vers le camp des Égyptiens. 
###### 25
Il enraya les roues de leurs chars qui n'avançaient plus qu'à grand-peine. Les Égyptiens dirent : " Fuyons devant Israël car Yahvé combat avec eux contre les Égyptiens !" 
###### 26
Yahvé dit à Moïse : " Étends ta main sur la mer, que les eaux refluent sur les Égyptiens, sur leurs chars et sur leurs cavaliers. " 
###### 27
Moïse étendit la main sur la mer et, au point du jour, la mer rentra dans son lit. Les Égyptiens en fuyant la rencontrèrent, et Yahvé culbuta les Égyptiens au milieu de la mer. 
###### 28
Les eaux refluèrent et recouvrirent les chars et les cavaliers de toute l'armée de Pharaon, qui avaient pénétré derrière eux dans la mer. Il n'en resta pas un seul. 
###### 29
Les Israélites, eux, marchèrent à pied sec au milieu de la mer, et les eaux leur formèrent une muraille à droite et à gauche. 
###### 30
Ce jour-là, Yahvé sauva Israël des mains des Égyptiens, et Israël vit les Égyptiens morts au bord de la mer. 
###### 31
Israël vit la prouesse accomplie par Yahvé contre les Égyptiens. Le peuple craignit Yahvé, il crut en Yahvé et en Moïse son serviteur. 
