---
aliases : 
- Exode 3
- Exode 3
- Ex 3
- Exodus 3
tags : 
- Bible/Ex/3
- français
cssclass : français
---

# Exode 3

###### 1
Moïse faisait paître le petit bétail de Jéthro, son beau-père, prêtre de Madiân ; il l'emmena par-delà le désert et parvint à la montagne de Dieu, l'Horeb. 
###### 2
L'Ange de Yahvé lui apparut, dans une flamme de feu, du milieu d'un buisson. Moïse regarda : le buisson était embrasé mais le buisson ne se consumait pas. 
###### 3
Moïse dit : " Je vais faire un détour pour voir cet étrange spectacle, et pourquoi le buisson ne se consume pas. " 
###### 4
Yahvé vit qu'il faisait un détour pour voir, et Dieu l'appela du milieu du buisson. " Moïse, Moïse ", dit-il, et il répondit : " Me voici. " 
###### 5
Il dit : " N'approche pas d'ici, retire tes sandales de tes pieds car le lieu où tu te tiens est une terre sainte. " 
###### 6
Et il dit : " Je suis le Dieu de tes pères, le Dieu d'Abraham, le Dieu d'Isaac et le Dieu de Jacob. " Alors Moïse se voila la face, car il craignait de fixer son regard sur Dieu. 
###### 7
Yahvé dit : " J'ai vu, j'ai vu la misère de mon peuple qui est en Égypte. J'ai entendu son cri devant ses oppresseurs ; oui, je connais ses angoisses. 
###### 8
Je suis descendu pour le délivrer de la main des Égyptiens et le faire monter de cette terre vers une terre plantureuse et vaste, vers une terre qui ruisselle de lait et de miel, vers la demeure des Cananéens, des Hittites, des Amorites, des Perizzites, des Hivvites et des Jébuséens. 
###### 9
Maintenant, le cri des Israélites est venu jusqu'à moi, et j'ai vu l'oppression que font peser sur eux les Égyptiens. 
###### 10
Maintenant va, je t'envoie auprès de Pharaon, fais sortir d'Égypte mon peuple, les Israélites. "
###### 11
Moïse dit à Dieu : " Qui suis-je pour aller trouver Pharaon et faire sortir d'Égypte les Israélites ? " 
###### 12
Dieu dit : " Je serai avec toi, et voici le signe qui te montrera que c'est moi qui t'ai envoyé. Quand tu feras sortir le peuple d'Égypte, vous servirez Dieu sur cette montagne. 
###### 13
Moïse dit à Dieu : " Voici, je vais trouver les Israélites et je leur dis : "Le Dieu de vos pères m'a envoyé vers vous. " Mais s'ils me disent : "Quel est son nom ?", que leur dirai-je ? " 
###### 14
Dieu dit à Moïse : " Je suis celui qui est. " Et il dit : " Voici ce que tu diras aux Israélites : "Je suis" m'a envoyé vers vous. " 
###### 15
Dieu dit encore à Moïse : " Tu parleras ainsi aux Israélites : "Yahvé, le Dieu de vos pères, le Dieu d'Abraham, le Dieu d'Isaac et le Dieu de Jacob m'a envoyé vers vous. C'est mon nom pour toujours, c'est ainsi que l'on m'invoquera de génération en génération. 
###### 16
" Va, réunis les anciens d'Israël et dis-leur : "Yahvé, le Dieu de vos pères, m'est apparu - le Dieu d'Abraham, d'Isaac et de Jacob - et il m'a dit : Je vous ai visités et j'ai vu ce qu'on vous fait en Égypte, 
###### 17
alors j'ai dit : Je vous ferai monter de l'affliction d'Égypte vers la terre des Cananéens, des Hittites, des Amorites, des Perizzites, des Hivvites et des Jébuséens, vers une terre qui ruisselle de lait et de miel. " 
###### 18
Ils écouteront ta voix et vous irez, toi et les anciens d'Israël, trouver le roi d'Égypte et vous lui direz : "Yahvé, le Dieu des Hébreux, est venu à notre rencontre. Toi, permets-nous d'aller à trois jours de marche dans le désert pour sacrifier à Yahvé notre Dieu. " 
###### 19
Je sais bien que le roi d'Égypte ne vous laissera aller que s'il y est contraint par une main forte. 
###### 20
Aussi j'étendrai la main et je frapperai l'Égypte par les merveilles de toute sorte que j'accomplirai au milieu d'elle ; après quoi, il vous laissera partir. 
###### 21
" Je ferai gagner à ce peuple la faveur des Égyptiens, et quand vous partirez, vous ne partirez pas les mains vides. 
###### 22
La femme demandera à sa voisine et à celle qui séjourne dans sa maison des objets d'argent, des objets d'or et des vêtements. Vous les ferez porter à vos fils et à vos filles et vous en dépouillerez les Égyptiens. 
