---
aliases : 
- Exode 4
- Exode 4
- Ex 4
- Exodus 4
tags : 
- Bible/Ex/4
- français
cssclass : français
---

# Exode 4

###### 1
Moïse reprit la parole et dit : " Et s'ils ne me croient pas et n'écoutent pas ma voix, mais me disent : Yahvé ne t'est pas apparu " ? 
###### 2
Yahvé lui dit : Qu'as-tu en main ? - Un bâton, dit-il. - 
###### 3
Jette-le à terre ", lui dit Yahvé. Moïse le jeta à terre, le bâton se changea en serpent et Moïse fuit devant lui. 
###### 4
Yahvé dit à Moïse : " Avance la main et prends-le par la queue. " Il avança la main, le prit, et dans sa main il redevint un bâton. 
###### 5
" Afin qu'ils croient que Yahvé t'est apparu, le Dieu de leurs pères, le Dieu d'Abraham, le Dieu d'Isaac et le Dieu de Jacob. "
###### 6
Yahvé lui dit encore : " Mets ta main dans ton sein. " Il mit la main dans son sein, puis la retira, et voici que sa main était lépreuse, blanche comme neige. 
###### 7
Yahvé lui dit : " Remets ta main dans ton sein. " Il remit la main dans son sein et la retira de son sein, et voici qu'elle était redevenue comme le reste de son corps. 
###### 8
" Ainsi, s'ils ne te croient pas et ne sont pas convaincus par le premier signe, ils croiront à cause du second signe. 
###### 9
Et s'ils ne croient pas, même avec ces deux signes, et qu'ils n'écoutent pas ta voix, tu prendras de l'eau du Fleuve et tu la répandras par terre, et l'eau que tu auras puisée au Fleuve se changera en sang sur la terre sèche. 
###### 10
Moïse dit à Yahvé : " Excuse-moi, mon Seigneur, je ne suis pas doué pour la parole, ni d'hier ni d'avant-hier, ni même depuis que tu adresses la parole à ton serviteur, car ma bouche et ma langue sont pesantes. " 
###### 11
Yahvé lui dit : " Qui a doté l'homme d'une bouche ? Qui rend muet ou sourd, clairvoyant ou aveugle ? N'est-ce pas moi, Yahvé ? 
###### 12
Va maintenant, je serai avec ta bouche et je t'indiquerai ce que tu devras dire. "
###### 13
Moïse dit encore : " Excuse-moi, mon Seigneur, envoie, je te prie, qui tu voudras. " 
###### 14
La colère de Yahvé s'enflamma contre Moïse et il dit : " N'y a-t-il pas Aaron ton frère, le lévite ? Je sais qu'il parle bien, lui ; le voici qui vient à ta rencontre et à ta vue il se réjouira en son cœur. 
###### 15
Tu lui parleras et tu mettras les paroles dans sa bouche. Moi, je serai avec ta bouche et avec sa bouche, et je vous indiquerai ce que vous devrez faire. 
###### 16
C'est lui qui parlera pour toi au peuple ; il te tiendra lieu de bouche et tu seras pour lui un dieu. 
###### 17
Quant à ce bâton, prends-le dans ta main, c'est par lui que tu accompliras les signes. 
###### 18
Moïse s'en alla et retourna vers Jéthro, son beau-père. Il lui dit : " Permets que je m'en aille et que je retourne vers mes frères qui sont en Égypte pour voir s'ils sont encore en vie. " Jéthro lui répondit : " Va en paix. "
###### 19
Yahvé dit à Moïse en Madiân : " Va, retourne en Égypte, car ils sont morts, tous ceux qui cherchaient à te faire périr. " 
###### 20
Moïse prit sa femme et son fils, les fit monter sur un âne et s'en retourna au pays d'Égypte. Moïse prit en main le bâton de Dieu. 
###### 21
Yahvé dit à Moïse : " Tandis que tu retourneras en Égypte, vois les prodiges que j'ai mis en ton pouvoir : tu les accompliras devant Pharaon, mais moi, j'endurcirai son cœur et il ne laissera pas partir le peuple. 
###### 22
Alors tu diras à Pharaon : Ainsi parle Yahvé : mon fils premier-né, c'est Israël. 
###### 23
Je t'avais dit : "Laisse aller mon fils, qu'il me serve. " Puisque tu refuses de le laisser aller, eh bien, moi, je vais faire périr ton fils premier-né. 
###### 24
Et ce fut en route, à la halte de la nuit, que Yahvé vint à sa rencontre et chercha à le faire mourir. 
###### 25
Çippora prit un silex, coupa le prépuce de son fils et elle en toucha ses pieds. Et elle dit : " Tu es pour moi un époux de sang. " 
###### 26
Et il se retira de lui. Elle avait dit alors " Époux de sang ", ce qui s'applique aux circoncisions. 
###### 27
Yahvé dit à Aaron : " Va à la rencontre de Moïse en direction du désert. " Il partit, le rencontra à la montagne de Dieu et l'embrassa. 
###### 28
Moïse informa Aaron de toutes les paroles de Yahvé, qui l'avait envoyé, et de tous les signes qu'il lui avait ordonné d'accomplir. 
###### 29
Moïse partit avec Aaron et ils réunirent tous les anciens des Israélites. 
###### 30
Aaron répéta toutes les paroles que Yahvé avait dites à Moïse ; il accomplit les signes aux yeux du peuple. 
###### 31
Le peuple crut et se réjouit de ce que Yahvé avait visité les Israélites et avait vu leur misère. Ils s'agenouillèrent et se prosternèrent. 
