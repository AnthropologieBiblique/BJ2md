---
aliases : 
- Exode 32
- Exode 32
- Ex 32
- Exodus 32
tags : 
- Bible/Ex/32
- français
cssclass : français
---

# Exode 32

###### 1
Quand le peuple vit que Moïse tardait à descendre de la montagne, le peuple s'assembla auprès d'Aaron et lui dit : " Allons, fais-nous un dieu qui aille devant nous, car ce Moïse, l'homme qui nous a fait monter du pays d'Égypte, nous ne savons pas ce qui lui est arrivé. " 
###### 2
Aaron leur répondit : " Otez les anneaux d'or qui sont aux oreilles de vos femmes, de vos fils et de vos filles et apportez-les-moi. " 
###### 3
Tout le peuple ôta les anneaux d'or qui étaient à leurs oreilles et ils les apportèrent à Aaron. 
###### 4
Il reçut l'or de leurs mains, le fit fondre dans un moule et en fit une statue de veau ; alors ils dirent : " Voici ton Dieu, Israël, celui qui t'a fait monter du pays d'Égypte. " 
###### 5
Voyant cela, Aaron bâtit un autel devant la statue et fit cette proclamation : " Demain, fête pour Yahvé. "
###### 6
Le lendemain, ils se levèrent de bon matin, ils offrirent des holocaustes et apportèrent des sacrifices de communion. Le peuple s'assit pour manger et pour boire, puis ils se levèrent pour se divertir. 
###### 7
Yahvé dit alors à Moïse : " Allons !descends, car ton peuple que tu as fait monter du pays d'Égypte s'est perverti. 
###### 8
Ils n'ont pas tardé à s'écarter de la voie que je leur avais prescrite. Ils se sont fabriqué un veau en métal fondu, et se sont prosternés devant lui. Ils lui ont offert des sacrifices et ils ont dit : Voici ton Dieu, Israël, qui t'a fait monter du pays d'Égypte. " 
###### 9
Yahvé dit à Moïse : " J'ai vu ce peuple : c'est un peuple à la nuque raide. 
###### 10
Maintenant laisse-moi, ma colère va s'enflammer contre eux et je les exterminerai ; mais de toi je ferai une grande nation. 
###### 11
Moïse s'efforça d'apaiser Yahvé son Dieu et dit : " Pourquoi, Yahvé, ta colère s'enflammerait-elle contre ton peuple que tu as fait sortir d'Égypte par ta grande force et ta main puissante ? 
###### 12
Pourquoi les Égyptiens diraient-ils : "C'est par méchanceté qu'il les a fait sortir, pour les faire périr dans les montagnes et les exterminer de la face de la terre" ? Reviens de ta colère ardente et renonce au mal que tu voulais faire à ton peuple. 
###### 13
Souviens-toi de tes serviteurs Abraham, Isaac et Israël, à qui tu as juré par toi-même et à qui tu as dit : Je multiplierai votre postérité comme les étoiles du ciel, et tout ce pays dont je vous ai parlé, je le donnerai à vos descendants et il sera leur héritage à jamais. " 
###### 14
Et Yahvé renonça à faire le mal dont il avait menacé son peuple. 
###### 15
Moïse se retourna et descendit de la montagne avec, en main, les deux tables du Témoignage, tables écrites des deux côtés, écrites sur l'une et l'autre face. 
###### 16
Les tables étaient l'œuvre de Dieu et l'écriture était celle de Dieu, gravée sur les tables. 
###### 17
Josué entendit le bruit du peuple qui poussait des cris et il dit à Moïse : " Il y a un bruit de bataille dans le camp !" 
###### 18
Mais il dit :" Ce n'est pas le bruit de chants de victoire, ce n'est pas le bruit de chants de défaite, c'est le bruit de chants alternés que j'entends. "
###### 19
Et voici qu'en approchant du camp il aperçut le veau et des chœurs de danse. Moïse s'enflamma de colère ; il jeta de sa main les tables et les brisa au pied de la montagne. 
###### 20
Il prit le veau qu'ils avaient fabriqué, le brûla au feu, le moulut en poudre fine, et en saupoudra la surface de l'eau qu'il fit boire aux Israélites. 
###### 21
Moïse dit à Aaron : " Que t'a fait ce peuple pour l'avoir chargé d'un si grand péché ? " 
###### 22
Aaron répondit : " Que la colère de Monseigneur ne s'enflamme pas, tu sais toi-même que ce peuple est mauvais. 
###### 23
Ils m'ont dit : "Fais-nous un dieu qui aille devant nous, car ce Moïse, l'homme qui nous a fait monter du pays d'Égypte, nous ne savons pas ce qui lui est arrivé. " 
###### 24
Je leur ai dit : "Quiconque a de l'or s'en dessaisisse. " Ils me l'ont donné. Je l'ai jeté dans le feu et il en est sorti le veau que voici. 
###### 25
Moïse vit que le peuple s'était déchaîné - car Aaron les avait abandonnés à la honte parmi leurs adversaires - 
###### 26
et Moïse se tint à la porte du camp et dit : " Qui est pour Yahvé, à moi !" Tous les fils de Lévi se groupèrent autour de lui. 
###### 27
Il leur dit : " Ainsi parle Yahvé, le Dieu d'Israël : ceignez chacun votre épée sur votre hanche, allez et venez dans le camp, de porte en porte, et tuez qui son frère, qui son ami, qui son proche. " 
###### 28
Les fils de Lévi firent ce que Moïse avait dit, et du peuple, il tomba ce jour-là environ trois mille hommes. 
###### 29
Moïse dit : " Vous vous êtes aujourd'hui conféré l'investiture pour Yahvé, qui au prix de son fils, qui au prix de son frère, de sorte qu'il vous donne aujourd'hui la bénédiction. 
###### 30
Le lendemain, Moïse dit au peuple : " Vous avez commis, vous, un grand péché. Je m'en vais maintenant monter vers Yahvé. Peut-être pourrai-je expier votre péché !" 
###### 31
Moïse retourna donc vers Yahvé et dit : " Hélas, ce peuple a commis un grand péché. Ils se sont fabriqué un dieu en or. 
###### 32
Pourtant, s'il te plaisait de pardonner leur péché... Sinon, efface-moi, de grâce, du livre que tu as écrit !" 
###### 33
Yahvé dit à Moïse : " Celui qui a péché contre moi, c'est lui que j'effacerai de mon livre. 
###### 34
Va maintenant, conduis le peuple où je t'ai dit. Voici que mon ange ira devant toi, mais au jour de ma visite, je les punirai de leur péché. " 
###### 35
Et Yahvé frappa le peuple parce qu'ils avaient fabriqué le veau, celui qu'avait fabriqué Aaron. 
