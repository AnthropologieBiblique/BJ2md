---
aliases : 
- Exode 20
- Exode 20
- Ex 20
- Exodus 20
tags : 
- Bible/Ex/20
- français
cssclass : français
---

# Exode 20

###### 1
Dieu prononça toutes ces paroles, et dit : 
###### 2
" Je suis Yahvé, ton Dieu, qui t'ai fait sortir du pays d'Égypte, de la maison de servitude. 
###### 3
Tu n'auras pas d'autres dieux devant moi. 
###### 4
Tu ne te feras aucune image sculptée, rien qui ressemble à ce qui est dans les cieux, là-haut, ou sur la terre, ici-bas, ou dans les eaux, au-dessous de la terre. 
###### 5
Tu ne te prosterneras pas devant ces dieux et tu ne les serviras pas, car moi Yahvé, ton Dieu, je suis un Dieu jaloux qui punis la faute des pères sur les enfants, les petits-enfants et les arrière-petits-enfants pour ceux qui me haïssent, 
###### 6
mais qui fais grâce à des milliers pour ceux qui m'aiment et gardent mes commandements. 
###### 7
Tu ne prononceras pas le nom de Yahvé ton Dieu à faux, car Yahvé ne laisse pas impuni celui qui prononce son nom à faux. 
###### 8
Tu te souviendras du jour du sabbat pour le sanctifier. 
###### 9
Pendant six jours tu travailleras et tu feras tout ton ouvrage ; 
###### 10
mais le septième jour est un sabbat pour Yahvé ton Dieu. Tu ne feras aucun ouvrage, toi, ni ton fils, ni ta fille, ni ton serviteur, ni ta servante, ni tes bêtes, ni l'étranger qui est dans tes portes. 
###### 11
Car en six jours Yahvé a fait le ciel, la terre, la mer et tout ce qu'ils contiennent, mais il s'est reposé le septième jour, c'est pourquoi Yahvé a béni le jour du sabbat et l'a consacré. 
###### 12
Honore ton père et ta mère, afin que se prolongent tes jours sur la terre que te donne Yahvé ton Dieu. 
###### 13
Tu ne tueras pas. 
###### 14
Tu ne commettras pas d'adultère. 
###### 15
Tu ne voleras pas. 
###### 16
Tu ne porteras pas de témoignage mensonger contre ton prochain. 
###### 17
Tu ne convoiteras pas la maison de ton prochain. Tu ne convoiteras pas la femme de ton prochain, ni son serviteur, ni sa servante, ni son bœuf, ni son âne, rien de ce qui est à ton prochain. "
###### 18
Tout le peuple, voyant ces coups de tonnerre, ces lueurs, ce son de trompe et la montagne fumante, eut peur et se tint à distance. 
###### 19
Ils dirent à Moïse : " Parle-nous, toi, et nous t'écouterons ; mais que Dieu ne nous parle pas, car alors c'est la mort. " 
###### 20
Moïse dit au peuple : " Ne craignez pas. C'est pour vous mettre à l'épreuve que Dieu est venu, pour que sa crainte vous demeure présente et que vous ne péchiez pas. " 
###### 21
Le peuple se tint à distance et Moïse s'approcha de la nuée obscure où était Dieu. 
###### 22
Yahvé dit à Moïse : " Tu parleras ainsi aux Israélites : Vous avez vu vous-mêmes comment je vous ai parlé du haut du ciel. 
###### 23
Vous ne ferez pas à côté de moi des dieux d'argent, et des dieux d'or vous ne vous en ferez pas. 
###### 24
Tu me feras un autel de terre sur quoi immoler tes holocaustes et tes sacrifices de communion, ton petit et ton gros bétail. En tout lieu où je rappellerai mon nom, je viendrai à toi et je te bénirai. 
###### 25
Si tu me fais un autel de pierre, ne le bâtis pas de pierres taillées, car, en le travaillant au ciseau, tu le profanerais. 
###### 26
Et tu ne monteras pas à mon autel par des marches pour n'y pas laisser voir ta nudité. 
