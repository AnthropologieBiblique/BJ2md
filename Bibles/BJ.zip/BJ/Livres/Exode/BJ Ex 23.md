---
aliases : 
- Exode 23
- Exode 23
- Ex 23
- Exodus 23
tags : 
- Bible/Ex/23
- français
cssclass : français
---

# Exode 23

###### 1
" Tu ne colporteras pas de fausses rumeurs. Tu ne prêteras pas la main au méchant en témoignant injustement. 
###### 2
Tu ne prendras pas le parti du plus grand nombre pour commettre le mal, ni ne témoigneras dans un procès en suivant le plus grand nombre pour faire dévier le droit, 
###### 3
ni ne favoriseras le miséreux dans son procès. 
###### 4
Si tu rencontres le bœuf ou l'âne de ton ennemi qui vague, tu dois le lui ramener. 
###### 5
Si tu vois l'âne de celui qui te déteste tomber sous sa charge, cesse de te tenir à l'écart ; avec lui tu lui viendras en aide. 
###### 6
Tu ne feras pas dévier le droit de ton pauvre dans son procès. 
###### 7
Tu te tiendras loin d'une cause mensongère. Ne fais pas périr l'innocent ni le juste et ne justifie pas le coupable. 
###### 8
Tu n'accepteras pas de présents, car le présent aveugle les gens clairvoyants et ruine les causes des justes. 
###### 9
Tu n'opprimeras pas l'étranger. Vous savez ce qu'éprouve l'étranger, car vous-mêmes avez été étrangers au pays d'Égypte. 
###### 10
" Pendant six ans tu ensemenceras la terre et tu en engrangeras le produit. 
###### 11
Mais la septième année, tu la laisseras en jachère et tu en abandonneras le produit ; les pauvres de ton peuple le mangeront et les bêtes des champs mangeront ce qu'ils auront laissé. Tu feras de même pour ta vigne et pour ton olivier. 
###### 12
Pendant six jours tu feras tes travaux, et le septième jour tu chômeras, afin que se reposent ton bœuf et ton âne et que reprennent souffle le fils de ta servante ainsi que l'étranger. 
###### 13
Vous prendrez garde à tout ce que je vous ai dit et vous ne ferez pas mention du nom d'autres dieux : qu'on ne l'entende pas sortir de ta bouche. 
###### 14
" Tu me fêteras trois fois l'an. 
###### 15
Tu observeras la fêtes des Azymes. Pendant sept jours tu mangeras des azymes, comme je te l'ai ordonné, au temps fixé du mois d'Abib, car c'est en ce mois que tu es sorti d'Égypte. On ne se présentera pas devant moi les mains vides. 
###### 16
Tu observeras la fête de la Moisson, des prémices de tes travaux de semailles dans les champs, et la fête de la Récolte, en fin d'année, quand tu rentreras des champs le fruit de tes travaux. 
###### 17
Trois fois l'an, toute ta population mâle se présentera devant le Seigneur Yahvé. 
###### 18
Tu ne sacrifieras pas avec du pain levé le sang de ma victime, et la graisse de ma fête ne sera pas gardée jusqu'au lendemain. 
###### 19
Tu apporteras à la maison de Yahvé ton Dieu le meilleur des prémices de ton terroir. Tu ne feras pas cuire un chevreau dans le lait de sa mère. 
###### 20
" Voici que je vais envoyer un ange devant toi, pour qu'il veille sur toi en chemin et te mène au lieu que je t'ai fixé. 
###### 21
Révère-le et écoute sa voix, ne lui sois pas rebelle, il ne pardonnerait pas vos transgressions car mon Nom est en lui. 
###### 22
Mais si tu écoutes bien sa voix et fais ce que je dis, je serai l'ennemi de tes ennemis et l'adversaire de tes adversaires. 
###### 23
Mon ange ira devant toi et te mènera chez les Amorites, les Hittites, les Perizzites, les Cananéens, les Hivvites, les Jébuséens, et je les exterminerai. 
###### 24
Tu ne te prosterneras pas devant leurs dieux ni ne les serviras ; tu ne feras pas ce qu'ils font, mais tu détruiras leurs dieux et tu briseras leurs stèles. 
###### 25
Vous servirez Yahvé votre Dieu, alors je bénirai ton pain et ton eau et je détournerai de toi la maladie. 
###### 26
Nulle femme dans ton pays n'avortera ou ne sera stérile et je laisserai s'achever le nombre de tes jours. 
###### 27
Je sèmerai devant toi ma terreur, je jetterai la confusion chez tous les peuples où tu pénétreras, et je ferai détaler tous tes ennemis. 
###### 28
J'enverrai devant toi des frelons qui chasseront les Hivvites, les Cananéens et les Hittites devant toi. 
###### 29
Je ne les chasserai pas devant toi en une seule année, de peur que le pays ne devienne un désert où se multiplieraient à tes dépens les bêtes des champs. 
###### 30
Je les chasserai devant toi peu à peu, jusqu'à ce que tu aies assez fructifié pour hériter du pays. 
###### 31
Je fixerai tes frontières de la mer des Roseaux à la mer des Philistins, et du désert au Fleuve, car je livrerai entre vos mains les habitants du pays, et tu les chasseras devant toi. 
###### 32
Tu ne feras pas alliance avec eux ni avec leurs dieux. 
###### 33
Ils n'habiteront pas ton pays, de peur qu'ils ne te fassent pécher contre moi, car tu servirais leurs dieux et ce serait pour toi un piège. "
