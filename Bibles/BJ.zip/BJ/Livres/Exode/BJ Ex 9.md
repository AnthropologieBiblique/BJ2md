---
aliases : 
- Exode 9
- Exode 9
- Ex 9
- Exodus 9
tags : 
- Bible/Ex/9
- français
cssclass : français
---

# Exode 9

###### 1
Yahvé dit à Moïse : " Va trouver Pharaon et dis-lui : Ainsi parle Yahvé, le Dieu des Hébreux : "Laisse partir mon peuple, qu'il me serve. " 
###### 2
Si tu refuses de le laisser partir et le retiens plus longtemps, 
###### 3
voici que la main de Yahvé frappera tes troupeaux qui sont dans les champs, les chevaux, les ânes, les chameaux, les bœufs et le petit bétail, d'une peste très grave. 
###### 4
Yahvé discernera les troupeaux d'Israël des troupeaux des Égyptiens, et rien ne mourra de ce qui appartient aux Israélites. 
###### 5
Yahvé a fixé le temps en disant : Demain Yahvé fera cela dans le pays. " 
###### 6
Le lendemain, Yahvé fit cela, et tous les troupeaux des Égyptiens moururent, mais des troupeaux des Israélites, pas une bête ne mourut. 
###### 7
Pharaon fit une enquête, et voici que des troupeaux d'Israël pas une seule bête n'était morte. Mais le cœur de Pharaon s'appesantit et il ne laissa pas partir le peuple. 
###### 8
Yahvé dit à Moïse et à Aaron : " Prenez plein vos mains de suie de fourneau et que Moïse la lance en l'air, sous les yeux de Pharaon. 
###### 9
Elle se changera en fine poussière sur tout le pays d'Égypte et provoquera, sur les gens et sur les bêtes, des ulcères bourgeonnant en pustules, dans toute l'Égypte. " 
###### 10
Ils prirent de la suie de fourneau et se tinrent devant Pharaon ; Moïse la lança en l'air et gens et bêtes furent couverts d'ulcères bourgeonnant en pustules. 
###### 11
Les magiciens ne purent se tenir devant Moïse à cause des ulcères, car les magiciens étaient couverts d'ulcères comme tous les Égyptiens. 
###### 12
Yahvé endurcit le cœur de Pharaon et il ne les écouta pas, comme l'avait prédit Yahvé à Moïse. 
###### 13
Yahvé dit à Moïse : " Lève-toi de bon matin et tiens-toi devant Pharaon. Tu lui diras : Ainsi parle Yahvé, le Dieu des Hébreux : "Laisse partir mon peuple, qu'il me serve. " 
###### 14
Car cette fois-ci, je vais envoyer tous mes fléaux contre toi-même, contre tes serviteurs et contre ton peuple, afin que tu apprennes qu'il n'y en a pas comme moi sur toute la terre. 
###### 15
Si j'avais étendu la main et vous avais frappés de la peste, toi et ton peuple, tu aurais été effacé de la terre. 
###### 16
Mais je t'ai laissé subsister afin que tu voies ma force et qu'on publie mon nom par toute la terre. 
###### 17
Tu le prends de haut avec mon peuple en ne le laissant pas partir. 
###### 18
Eh bien demain, à pareille heure, je ferai tomber une grêle très forte, comme il n'y en a jamais eu en Égypte depuis le jour de sa fondation jusqu'à maintenant. 
###### 19
Et maintenant, envoie mettre tes troupeaux à l'abri, et tout ce qui, dans les champs, t'appartient. Tout ce qui, homme ou bête, se trouvera dans les champs et n'aura pas été ramené à la maison, la grêle tombera sur lui et il mourra. " 
###### 20
Celui des serviteurs de Pharaon qui craignit la parole de Yahvé fit rentrer en hâte ses esclaves et ses troupeaux dans les maisons. 
###### 21
Mais celui qui ne prit pas à cœur la parole de Yahvé laissa aux champs ses esclaves et ses troupeaux. 
###### 22
Yahvé dit à Moïse : " Étends ta main vers le ciel et qu'il grêle dans tout le pays d'Égypte, sur les hommes et sur les bêtes, sur toute l'herbe des champs au pays d'Égypte. " 
###### 23
Moïse étendit son bâton vers le ciel, et Yahvé tonna et fit tomber la grêle. La foudre frappa le sol, et Yahvé fit tomber la grêle sur le pays d'Égypte. 
###### 24
Il y eut de la grêle et le feu jaillissait au milieu de la grêle, une grêle très forte, comme il n'y en avait jamais eu au pays des Égyptiens depuis qu'ils formaient une nation. 
###### 25
La grêle frappa, dans tout le pays d'Égypte, tout ce qui était dans les champs, hommes et bêtes. La grêle frappa toutes les herbes des champs et brisa tous les arbres des champs. 
###### 26
Ce n'est qu'au pays de Goshèn, où se trouvaient les Israélites, qu'il n'y eut pas de grêle. 
###### 27
Pharaon fit appeler Moïse et Aaron et leur dit : " Cette fois, j'ai péché ; c'est Yahvé qui est juste, moi et mon peuple, nous sommes coupables. 
###### 28
Priez Yahvé. Il y a eu assez de tonnerre et de grêle. Je m'engage à vous laisser partir et vous ne resterez pas plus longtemps. " 
###### 29
Moïse lui dit : " Quand je sortirai de la ville, j'étendrai les mains vers Yahvé, le tonnerre cessera et il n'y aura plus de grêle, afin que tu saches que la terre est à Yahvé. 
###### 30
Mais ni toi ni tes serviteurs, je le sais bien, vous ne craindrez encore Yahvé Dieu. " 
###### 31
Le lin et l'orge furent abattus, car l'orge était en épis et le lin en fleur. 
###### 32
Le froment et l'épeautre ne furent pas abattus car ils sont tardifs. 
###### 33
Moïse sortit de chez Pharaon et de la ville ; il étendit les mains vers Yahvé ; le tonnerre et la grêle cessèrent, et la pluie ne se déversa plus sur la terre. 
###### 34
Quand Pharaon vit que la pluie, la grêle et le tonnerre avaient cessé, il recommença à pécher, et lui et ses serviteurs appesantirent leur cœur. 
###### 35
Le cœur de Pharaon s'endurcit et il ne laissa pas partir les Israélites, comme Yahvé l'avait prédit par Moïse. 
