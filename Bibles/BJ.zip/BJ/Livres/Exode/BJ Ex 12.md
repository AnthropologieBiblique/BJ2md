---
aliases : 
- Exode 12
- Exode 12
- Ex 12
- Exodus 12
tags : 
- Bible/Ex/12
- français
cssclass : français
---

# Exode 12

###### 1
Yahvé dit à Moïse et à Aaron au pays d'Égypte : 
###### 2
" Ce mois sera pour vous en tête des autres mois, il sera pour vous le premier mois de l'année. 
###### 3
Parlez à toute la communauté d'Israël et dites-lui : Le dix de ce mois, que chacun prenne une tête de petit bétail par famille, une tête de petit bétail par maison. 
###### 4
Si la maison est trop peu nombreuse pour une tête de petit bétail, on s'associera avec son voisin le plus proche de la maison, selon le nombre des personnes. Vous choisirez la tête de petit bétail selon ce que chacun peut manger. 
###### 5
La tête de petit bétail sera un mâle sans tare, âgé d'un an. Vous la choisirez parmi les moutons ou les chèvres. 
###### 6
Vous la garderez jusqu'au quatorzième jour de ce mois, et toute l'assemblée de la communauté d'Israël l'égorgera au crépuscule. 
###### 7
On prendra de son sang et on en mettra sur les deux montants et le linteau des maisons où on le mangera. 
###### 8
Cette nuit-là, on mangera la chair rôtie au feu ; on la mangera avec des azymes et des herbes amères. 
###### 9
N'en mangez rien cru ni bouilli dans l'eau, mais rôti au feu, avec la tête, les pattes et les tripes. 
###### 10
Vous n'en réserverez rien jusqu'au lendemain. Ce qui en resterait le lendemain, vous le brûlerez au feu. 
###### 11
C'est ainsi que vous la mangerez : vos reins ceints, vos sandales aux pieds et votre bâton en main. Vous la mangerez en toute hâte, c'est une pâque pour Yahvé. 
###### 12
Cette nuit-là je parcourrai l'Égypte et je frapperai tous les premiers-nés dans le pays d'Égypte, tant hommes que bêtes, et de tous les dieux d'Égypte, je ferai justice, moi Yahvé. 
###### 13
Le sang sera pour vous un signe sur les maisons où vous vous tenez. En voyant ce signe, je passerai outre et vous échapperez au fléau destructeur lorsque je frapperai le pays d'Égypte. 
###### 14
Ce jour-là, vous en ferez mémoire et vous le fêterez comme une fête pour Yahvé, dans vos générations vous la fêterez, c'est un décret perpétuel. 
###### 15
" Pendant sept jours, vous mangerez des azymes. Dès le premier jour vous ferez disparaître le levain de vos maisons car quiconque, du premier au septième jour, mangera du pain levé, celui-là sera retranché d'Israël. 
###### 16
Le premier jour vous aurez une sainte assemblée, et le septième jour, une sainte assemblée. On n'y fera aucun ouvrage, vous préparerez seulement ce que chacun doit manger. 
###### 17
Vous observerez la fête des Azymes, car c'est en ce jour-là que j'ai fait sortir vos armées du pays d'Égypte. Vous observerez ce jour-là dans vos générations, c'est un décret perpétuel. 
###### 18
Le premier mois, le soir du quatorzième jour, vous mangerez des azymes jusqu'au soir du vingt et unième jour. 
###### 19
Pendant sept jours il ne se trouvera pas de levain dans vos maisons, car quiconque mangera du pain levé sera retranché de la communauté d'Israël, qu'il soit étranger ou né dans le pays. 
###### 20
Vous ne mangerez pas de pain levé, en tout lieu où vous habiterez vous mangerez des azymes. 
###### 21
Moïse convoqua tous les anciens d'Israël et leur dit : " Allez vous procurer du petit bétail pour vos familles et immolez la pâque. 
###### 22
Puis vous prendrez un bouquet d'hysope, vous le tremperez dans le sang qui est dans le bassin et vous toucherez le linteau et les deux montants avec le sang qui est dans le bassin. Quant à vous, que personne ne franchisse la porte de sa maison jusqu'au matin. 
###### 23
Lorsque Yahvé traversera l'Égypte pour la frapper, il verra le sang sur le linteau et sur les deux montants, il passera au-delà de cette porte et ne laissera pas l'Exterminateur pénétrer dans vos maisons pour frapper. 
###### 24
Vous observerez cette disposition comme un décret pour toi et tes fils, à perpétuité. 
###### 25
Quand vous serez entrés dans la terre que Yahvé vous donnera comme il l'a dit, vous observerez ce rite. 
###### 26
Et quand vos fils vous diront : "Que signifie pour vous ce rite ?" 
###### 27
vous leur direz : "C'est le sacrifice de la Pâque pour Yahvé qui a passé au-delà des maisons des Israélites en Égypte, lorsqu'il frappait l'Égypte, mais épargnait nos maisons. " Le peuple alors s'agenouilla et se prosterna. 
###### 28
Les Israélites s'en allèrent et firent ce que Yahvé avait ordonné à Moïse et à Aaron. 
###### 29
Au milieu de la nuit, Yahvé frappa tous les premiers-nés dans le pays d'Égypte, aussi bien le premier-né de Pharaon qui devait s'asseoir sur son trône, que le premier-né du captif dans la prison et tous les premiers-nés du bétail. 
###### 30
Pharaon se leva pendant la nuit, ainsi que tous ses serviteurs et tous les Égyptiens, et ce fut en Égypte une grande clameur car il n'y avait pas de maison où il n'y eût un mort. 
###### 31
Pharaon appela Moïse et Aaron pendant la nuit et leur dit : " Levez-vous et sortez du milieu de mon peuple, vous et les Israélites, et allez servir Yahvé comme vous l'avez demandé. 
###### 32
Prenez aussi votre petit et votre gros bétail comme vous l'avez demandé, partez et bénissez-moi, moi aussi. " 
###### 33
Les Égyptiens pressèrent le peuple en se hâtant de le faire partir du pays car, disaient-ils : " Nous allons tous mourir. " 
###### 34
Le peuple emporta sa pâte avant qu'elle n'eût levé, ses huches serrées dans les manteaux, sur les épaules. 
###### 35
Les Israélites firent ce qu'avait dit Moïse et demandèrent aux Égyptiens des objets d'argent, des objets d'or et des vêtements. 
###### 36
Yahvé fit que le peuple trouvât grâce aux yeux des Égyptiens qui les leur prêtèrent. Ils dépouillèrent ainsi les Égyptiens. 
###### 37
Les Israélites partirent de Ramsès en direction de Sukkot au nombre de près de six cent mille hommes de pied - rien que les hommes, sans compter leur famille. 
###### 38
Une foule mêlée monta avec eux, ainsi que du petit et du gros bétail, formant d'immenses troupeaux. 
###### 39
Ils firent cuire la pâte qu'ils avaient emportée d'Égypte en galettes non levées, car la pâte n'était pas levée : chassés d'Égypte, ils n'avaient pu s'attarder ni se préparer des provisions de route. 
###### 40
Le séjour des Israélites en Égypte avait duré quatre cent trente ans. 
###### 41
Le jour même où prenaient fin les quatre cent trente ans, toutes les armées de Yahvé sortirent du pays d'Égypte. 
###### 42
Cette nuit durant laquelle Yahvé a veillé pour les faire sortir d'Égypte doit être pour tous les Israélites une veille pour Yahvé, pour leurs générations. 
###### 43
Yahvé dit à Moïse et à Aaron : " Voici le rituel de la pâque : aucun étranger n'en mangera. 
###### 44
Mais tout esclave acquis à prix d'argent, quand tu l'auras circoncis, pourra en manger. 
###### 45
Le résident et le serviteur à gages n'en mangeront pas. 
###### 46
On la mangera dans une seule maison et vous ne ferez sortir de cette maison aucun morceau de viande. Vous n'en briserez aucun os. 
###### 47
Toute la communauté d'Israël la fera. 
###### 48
Si un étranger en résidence chez toi veut faire la Pâque pour Yahvé, tous les mâles de sa maison devront être circoncis ; il sera alors admis à la faire, il sera comme un citoyen du pays ; mais aucun incirconcis ne pourra en manger. 
###### 49
La loi sera la même pour le citoyen et pour l'étranger en résidence parmi vous. " 
###### 50
Tous les Israélites firent comme Yahvé l'avait ordonné à Moïse et à Aaron. 
###### 51
Ce jour-là même, Yahvé fit sortir les Israélites du pays d'Égypte, selon leurs armées. 
