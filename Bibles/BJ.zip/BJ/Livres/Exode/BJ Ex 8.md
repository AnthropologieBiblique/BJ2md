---
aliases : 
- Exode 8
- Exode 8
- Ex 8
- Exodus 8
tags : 
- Bible/Ex/8
- français
cssclass : français
---

# Exode 8

###### 1
Yahvé dit à Moïse : " Dis à Aaron : Étends ta main avec ton bâton sur les fleuves, les canaux et les marais, et fais monter les grenouilles sur la terre d'Égypte. " 
###### 2
Aaron étendit la main sur les eaux d'Égypte, les grenouilles montèrent et recouvrirent la terre d'Égypte. 
###### 3
Mais les magiciens avec leurs sortilèges en firent autant, et firent monter les grenouilles sur la terre d'Égypte. 
###### 4
Pharaon appela Moïse et Aaron et dit : " Priez Yahvé de détourner les grenouilles de moi et de mon peuple, et je m'engage à laisser partir le peuple pour qu'il sacrifie à Yahvé. " 
###### 5
Moïse dit à Pharaon : " A toi l'avantage !Pour quand dois-je prier pour toi, pour tes serviteurs et pour ton peuple, afin que les grenouilles soient supprimées de chez toi et de vos maisons pour ne rester que dans le Fleuve ? " 
###### 6
Il dit" Pour demain. " Moïse reprit : " Il en sera selon ta parole afin que tu saches qu'il n'y a personne comme Yahvé notre Dieu. 
###### 7
Les grenouilles s'éloigneront de toi, de tes maisons, de tes serviteurs, de ton peuple, et il n'en restera plus que dans le Fleuve. " 
###### 8
Moïse et Aaron sortirent de chez Pharaon, et Moïse cria vers Yahvé au sujet des grenouilles qu'il avait infligées à Pharaon. 
###### 9
Yahvé fit ce que demandait Moïse, et les grenouilles crevèrent dans les maisons, dans les cours et dans les champs. 
###### 10
On les amassa en tas et le pays en fut empuanti. 
###### 11
Pharaon vit qu'il y avait un répit ; il appesantit son cœur et il ne les écouta pas, comme l'avait prédit Yahvé. 
###### 12
Yahvé dit à Moïse : " Dis à Aaron : Étends ton bâton et frappe la poussière du sol, et elle se changera en moustiques dans tout le pays d'Égypte. " 
###### 13
Aaron étendit la main avec son bâton et frappa la poussière du sol, et il y eut des moustiques sur les gens et les bêtes, toute la poussière du sol se changea en moustiques dans tout le pays d'Égypte. " 
###### 14
Les magiciens d'Égypte avec leurs sortilèges firent la même chose pour faire sortir les moustiques mais ils ne le purent, et il y eut des moustiques sur les gens et les bêtes. 
###### 15
Les magiciens dirent à Pharaon : " C'est le doigt de Dieu ", mais le cœur de Pharaon s'endurcit et il ne les écouta pas, comme l'avait prédit Yahvé. 
###### 16
Yahvé dit à Moïse : " Lève-toi de bon matin et tiens-toi devant Pharaon quand il se rendra au bord de l'eau. Tu lui diras : Ainsi parle Yahvé : "Laisse partir mon peuple, qu'il me serve. " 
###### 17
Si tu ne veux pas laisser partir mon peuple, je vais envoyer des taons sur toi, sur tes serviteurs, sur ton peuple et sur tes maisons. Les maisons des Égyptiens seront pleines de taons, et même le sol sur lequel ils se tiennent. 
###### 18
Et ce jour-là, je mettrai à part la terre de Goshèn où réside mon peuple pour que là il n'y ait pas de taons, afin que tu saches que je suis Yahvé, au milieu du pays. 
###### 19
Je discernerai mon peuple de ton peuple ; c'est demain que se produira ce signe. " 
###### 20
Yahvé fit ainsi, et des taons en grand nombre entrèrent dans la maison de Pharaon, dans les maisons de ses serviteurs et dans tout le pays d'Égypte ; le pays fut ruiné à cause des taons. 
###### 21
Pharaon appela Moïse et Aaron et leur dit : " Allez sacrifier à votre Dieu dans le pays. " 
###### 22
Moïse répondit : " Il ne convient pas d'agir ainsi, car nos sacrifices à Yahvé notre Dieu sont une abomination pour les Égyptiens. Si nous offrons sous les yeux des Égyptiens des sacrifices qu'ils abominent, ne nous lapideront-ils pas ? 
###### 23
C'est à trois jours de marche dans le désert que nous irons sacrifier à Yahvé notre Dieu, comme il nous l'a dit. " 
###### 24
Pharaon dit : " Moi je vais vous laisser partir pour sacrifier à votre Dieu dans le désert, seulement vous n'irez pas très loin. Priez pour moi. " 
###### 25
Moïse dit : " Dès que je serai sorti de chez toi, je prierai Yahvé. Demain les taons s'éloigneront de Pharaon, de ses serviteurs et de son peuple. Que Pharaon, toutefois, cesse de se moquer de nous en ne laissant pas le peuple partir pour sacrifier à Yahvé. " 
###### 26
Moïse sortit de chez Pharaon et pria Yahvé. 
###### 27
Yahvé fit ce que demandait Moïse et les taons s'éloignèrent de Pharaon, de ses serviteurs et de son peuple ; il n'en resta plus un seul. 
###### 28
Mais Pharaon appesantit son cœur, cette fois encore, et il ne laissa pas partir le peuple. 
