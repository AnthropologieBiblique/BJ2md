---
aliases : 
- Exode 38
- Exode 38
- Ex 38
- Exodus 38
tags : 
- Bible/Ex/38
- français
cssclass : français
---

# Exode 38

###### 1
Il fit l'autel des holocaustes en bois d'acacia ; de cinq coudées de long, de cinq coudées de large - donc carré - et de trois coudées de haut. 
###### 2
Il fit à ses quatre angles des cornes qui faisaient corps avec lui, et il le plaqua de bronze. 
###### 3
Il fit tous les accessoires de l'autel : les vases à cendres et les pelles, les bols à aspersion, les fourchettes et les encensoirs. Tous les accessoires de l'autel, il les fit de bronze. 
###### 4
Il fit pour l'autel un treillis de bronze en forme de filet, sous la corniche, depuis le bas jusqu'à mi-hauteur. 
###### 5
Il fondit quatre anneaux aux quatre angles du treillis de bronze pour recevoir les barres. 
###### 6
Il fit les barres en bois d'acacia et les plaqua de bronze. 
###### 7
Il engagea les barres dans les anneaux fixés sur les deux côtés de l'autel, pour le transporter grâce à elles ; il le fit creux, en planches. 
###### 8
Il fit le bassin en bronze et son socle en bronze avec les miroirs des femmes qui faisaient le service à l'entrée de la Tente du Rendez-vous. 
###### 9
Il fit le parvis ; du côté du sud, au midi, les rideaux du parvis, en fin lin retors, avaient cent coudées. 
###### 10
Leurs vingt colonnes et leurs vingt socles étaient de bronze ; les crochets des colonnes et leurs tringles étaient d'argent. 
###### 11
Cent coudées aussi du côté du nord ; leurs vingt colonnes et leurs vingt socles étaient de bronze ; les crochets des colonnes et leurs tringles étaient d'argent. 
###### 12
Du côté de l'ouest les rideaux avaient cinquante coudées, avec leurs dix colonnes et leurs dix socles. Les crochets des colonnes et leurs tringles étaient d'argent. 
###### 13
Et du côté de l'est, à l'orient, cinquante coudées. 
###### 14
A l'un des côtés il y avait quinze coudées de rideaux avec leurs trois colonnes et leurs trois socles. 
###### 15
Au second côté - de part et d'autre de la porte du parvis - il y avait quinze coudées de rideaux avec leurs trois colonnes et leurs trois socles. 
###### 16
Tous les rideaux entourant l'enceinte du parvis étaient de fin lin retors. 
###### 17
Les socles des colonnes étaient de bronze ; les crochets des colonnes et leurs tringles étaient d'argent ; le revêtement de leurs chapiteaux était d'argent, et toutes les colonnes du parvis étaient munies de tringles d'argent. 
###### 18
Le voile de la porte du parvis étaient broché, fait de pourpre violette et écarlate, de cramoisi et de fin lin retors. Il avait vingt coudées de long et cinq coudées de haut -dans la largeur-, comme les rideaux du parvis. 
###### 19
Leurs quatre colonnes et leurs quatre socles étaient de bronze, leurs crochets étaient d'argent, le revêtement de leurs chapiteaux et leurs tringles étaient d'argent. 
###### 20
Tous les piquets autour de la Demeure et du parvis étaient de bronze. 
###### 21
Voici les comptes de la Demeure - la Demeure du Témoignage - établis sur l'ordre de Moïse, travail des Lévites, par l'intermédiaire d'Itamar, fils d'Aaron, le prêtre. 
###### 22
Beçaléel, fils de Uri, fils de Hur, de la tribu de Juda, fit tout ce que Yahvé avait ordonné à Moïse, 
###### 23
et avec lui Oholiab, fils de Ahisamak, de la tribu de Dan, ciseleur, brodeur, brocheur en pourpre violette et écarlate, en cramoisi et en lin fin. 
###### 24
Total de l'or employé pour les travaux, pour l'ensemble des travaux du sanctuaire -c'était l'or consacré- : vingt-neuf talents et sept cent trente sicles, selon le sicle du sanctuaire. 
###### 25
L'argent du recensement de la communauté : cent talents et mille sept cent soixante-quinze sicles, selon le sicle du sanctuaire : 
###### 26
un beqa par tête, un demi-sicle, selon le sicle du sanctuaire, pour tous ceux qui furent recensés, âgés de vingt ans et plus, pour six cent trois mille cinq cent cinquante. 
###### 27
Cent talents d'argent pour fondre les socles du sanctuaire et les socles du rideau : cent socles pour cent talents, un talent par socle. 
###### 28
Avec les mille sept cent soixante-quinze sicles, il fit les crochets pour les colonnes, il plaqua leurs chapiteaux et fit leurs tringles. 
###### 29
Le bronze consacré se montait à soixante-dix talents et deux mille quatre cents sicles ; 
###### 30
il en fit les socles pour l'entrée de la Tente du Rendez-vous, l'autel de bronze, son treillis de bronze et tous les accessoires de l'autel ; 
###### 31
les socles du pourtour du parvis, les socles de la porte du parvis, tous les piquets de la Demeure et tous les piquets du pourtour du parvis. 
