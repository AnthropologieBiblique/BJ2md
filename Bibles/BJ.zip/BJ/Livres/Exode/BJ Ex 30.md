---
aliases : 
- Exode 30
- Exode 30
- Ex 30
- Exodus 30
tags : 
- Bible/Ex/30
- français
cssclass : français
---

# Exode 30

###### 1
" Tu feras un autel où faire fumer l'encens, tu le feras en bois d'acacia. 
###### 2
D'une coudée de long et d'une coudée de large, il sera carré, et il aura deux coudées de haut ; ses cornes feront corps avec lui. 
###### 3
Tu plaqueras d'or pur sa partie supérieure, ses parois tout autour et ses cornes, et tu lui feras tout autour une moulure d'or. 
###### 4
Tu lui feras deux anneaux d'or au-dessous de la moulure, sur ses deux côtés ; tu les feras sur les deux faces pour y loger les barres servant à son transport. 
###### 5
Tu feras ces barres en bois d'acacia, et tu les plaqueras d'or. 
###### 6
Tu le mettras devant le rideau qui pend devant l'arche du Témoignage - devant le propitiatoire qui est sur le Témoignage - où je te donnerai rendez-vous. 
###### 7
Aaron y fera fumer l'encens aromatique chaque matin, quand il mettra les lampes en ordre il le fera fumer. 
###### 8
Et quand Aaron replacera les lampes, au crépuscule, il le fera encore fumer. C'est un encens perpétuel devant Yahvé, pour vos générations. 
###### 9
Vous n'offrirez dessus ni encens profane ni holocauste ni oblation, et vous n'y verserez aucune libation. 
###### 10
Une fois l'an, Aaron fera l'expiation sur les cornes de l'autel ; avec le sang du sacrifice pour le péché, au jour de l'Expiation, une fois l'an, il fera l'expiation pour lui, pour vos générations ; il est éminemment saint, pour Yahvé. 
###### 11
Yahvé parla à Moïse et lui dit : 
###### 12
" Quand tu dénombreras les Israélites par le recensement, chacun d'eux donnera à Yahvé la rançon de sa vie pour qu'aucun fléau n'éclate parmi eux à l'occasion du recensement. 
###### 13
Quiconque est soumis au recensement donnera un demi-sicle sur la base du sicle du sanctuaire : vingt géras par sicle. Ce demi-sicle sera un prélèvement pour Yahvé. 
###### 14
Quiconque est soumis au recensement, c'est-à-dire âgé de vingt ans et au-delà, donnera le prélèvement de Yahvé. 
###### 15
Le riche ne donnera pas plus et le pauvre ne donnera pas moins d'un demi-sicle lorsqu'il donnera le prélèvement pour Yahvé, en rançon de vos vies. 
###### 16
Tu prendras l'argent de la rançon des Israélites, et tu le donneras au service de la Tente du Rendez-vous ; il sera pour les Israélites un mémorial devant Yahvé, pour la rançon de vos vies. 
###### 17
Yahvé parla à Moïse et lui dit : 
###### 18
" Tu feras pour les ablutions un bassin de bronze à socle de bronze ; tu le mettras entre la Tente du Rendez-vous et l'autel, et tu y mettras de l'eau, 
###### 19
avec quoi Aaron et ses fils laveront leurs mains et leurs pieds. 
###### 20
Quand ils entreront dans la Tente du Rendez-vous, ils se laveront avec de l'eau afin de ne pas mourir ; de même, quand ils s'approcheront de l'autel pour le service, pour faire fumer une offrande consumée pour Yahvé, 
###### 21
ils laveront leurs mains et leurs pieds, afin de ne pas mourir ; c'est là un décret perpétuel pour lui et sa descendance, pour leurs générations. 
###### 22
Yahvé parla à Moïse et lui dit : 
###### 23
" Pour toi, prends des parfums de choix : cinq cents sicles de myrrhe vierge, la moitié de cinnamome odoriférant : deux cent cinquante sicles, et de roseau odoriférant : deux cent cinquante sicles. 
###### 24
Cinq cents sicles de casse - selon le sicle du sanctuaire - et un setier d'huile d'olive. 
###### 25
Tu en feras une huile d'onction sainte, un mélange odoriférant comme en compose le parfumeur : ce sera une huile d'onction sainte. 
###### 26
Tu en oindras la Tente du Rendez-vous et l'arche du Témoignage, 
###### 27
la table et tous ses accessoires, le candélabre et ses accessoires, l'autel des parfums, 
###### 28
l'autel des holocaustes et tous ses accessoires, le bassin et son socle. 
###### 29
Tu les consacreras, ils seront alors éminemment saints, et tout ce qui les touchera sera saint. 
###### 30
Tu oindras Aaron et ses fils, et tu les consacreras pour qu'ils exercent mon sacerdoce. 
###### 31
Puis tu parleras aux Israélites et tu leur diras : ceci sera pour vous, pour vos générations, une huile d'onction sainte. 
###### 32
On n'en versera pas sur le corps d'un homme quelconque et vous n'en ferez pas de semblable, de même composition. C'est une chose sainte, elle sera sainte pour vous. 
###### 33
Quiconque fera le même parfum et en mettra sur un profane sera retranché de son peuple. 
###### 34
Yahvé dit à Moïse : " Prends des aromates : storax, onyx, galbanum, aromates et pur encens, chacun en quantité égale 
###### 35
et tu en feras un parfum à brûler comme en opère le parfumeur, salé, pur, saint. 
###### 36
Tu en broieras finement une partie et tu en mettras devant le Témoignage, dans la Tente du Rendez-vous, là où je te donnerai rendez-vous. Il sera pour vous éminemment saint. 
###### 37
Le parfum que tu fais là, vous n'en ferez pas pour vous-mêmes de même composition. Il sera saint pour toi, réservé à Yahvé. Quiconque fera le même pour en humer l'odeur, sera retranché de son peuple. 
###### 38

