---
aliases : 
- Exode 6
- Exode 6
- Ex 6
- Exodus 6
tags : 
- Bible/Ex/6
- français
cssclass : français
---

# Exode 6

###### 1
Yahvé dit alors à Moïse : " Maintenant, tu vas voir ce que je vais faire à Pharaon. Une main forte l'obligera à les laisser partir, une main forte l'obligera à les expulser de son pays. 
###### 2
Dieu parla à Moïse et lui dit : " Je suis Yahvé. 
###### 3
Je suis apparu à Abraham, à Isaac et à Jacob comme El Shaddaï, mais mon nom de Yahvé, je ne le leur ai pas fait connaître. 
###### 4
J'ai aussi établi mon alliance avec eux pour leur donner le pays de Canaan, la terre où ils résidaient en étrangers. 
###### 5
Et moi, j'ai entendu le gémissement des Israélites asservis par les Égyptiens et je me suis souvenu de mon alliance. 
###### 6
C'est pourquoi tu diras aux Israélites : Je suis Yahvé et je vous soustrairai aux corvées des Égyptiens ; je vous délivrerai de leur servitude et je vous rachèterai à bras étendu et par de grands jugements. 
###### 7
Je vous prendrai pour mon peuple et je serai votre Dieu. Et vous saurez que je suis Yahvé, votre Dieu, qui vous aura soustraits aux corvées des Égyptiens. 
###### 8
Puis je vous ferai entrer dans la terre que j'ai juré de donné à Abraham, à Isaac et à Jacob, et je vous la donnerai en patrimoine, moi Yahvé. " 
###### 9
Moïse parla ainsi aux Israélites mais ils n'écoutèrent pas Moïse car ils étaient à bout de souffle à cause de leur dure servitude. 
###### 10
Yahvé parla à Moïse et lui dit : 
###### 11
" Va dire à Pharaon, le roi d'Égypte, qu'il laisse partir les Israélites de son pays. " 
###### 12
Mais Moïse prit la parole en présence de Yahvé et dit : " Les Israélites ne m'ont pas écouté, comment Pharaon m'écouterait-il, moi qui n'ai pas la parole facile ? " 
###### 13
Yahvé parla à Moïse et à Aaron et les envoya auprès de Pharaon, le roi d'Égypte, pour faire sortir les Israélites du pays d'Égypte. 
###### 14
Voici leurs chefs de familles :Fils de Ruben, premier-né d'Israël : Hénok, Pallu, Héçron et Karmi ; tels sont les clans de Ruben. 
###### 15
Fils de Siméon : Yemuel, Yamîn, Ohad, Yakîn, Çohar et Shaûl, le fils de la Cananéenne ; tels sont les clans de Siméon. 
###### 16
Voici les noms des fils de Lévi avec leurs descendances : Gershôn, Qehat et Merari. Lévi vécut cent trente-sept ans. 
###### 17
Fils de Gershôn : Libni et Shiméï avec leurs clans. 
###### 18
Fils de Qehat : Amram, Yiçhar, Hébrôn et Uzziel. Qehat vécut cent trente-trois ans. 
###### 19
Fils de Merari : Mahli et Mushi. Tels sont les clans de Lévi avec leurs descendances. 
###### 20
Amram épousa Yokébed, sa tante, qui lui donna Aaron et Moïse. Amram vécut cent trente-sept ans. 
###### 21
Les fils de Yiçhar furent : Coré, Népheg et Zikri, 
###### 22
et les fils d'Uzziel : Mishaèl, Elçaphân et Sitri. 
###### 23
Aaron épousa Élishéba, fille d'Amminadab, sœur de Nahshôn, et elle lui donna Nadab, Abihu, Éléazar et Itamar. 
###### 24
Fils de Coré : Assir, Elqana et Abiasaph ; tels sont les clans des Coréites. 
###### 25
Éléazar, fils d'Aaron, épousa l'une des filles de Putiel, qui lui enfanta Pinhas. Tels sont les chefs des familles des Lévites, selon leurs clans. 
###### 26
Ce sont eux, Aaron et Moïse, à qui Yahvé avait dit : " Faites sortir les Israélites du pays d'Égypte, selon leurs armées. " 
###### 27
Ce sont eux qui parlèrent à Pharaon, le roi d'Égypte, pour faire sortir d'Égypte les Israélites, - Moïse et Aaron. 
###### 28
Or le jour où Yahvé parla à Moïse en terre d'Égypte, 
###### 29
Yahvé dit à Moïse : " Je suis Yahvé. Dis à Pharaon, le roi d'Égypte, tout ce que moi je vais te dire. " 
###### 30
Moïse dit en présence de Yahvé : " Je n'ai pas la parole facile, comment Pharaon m'écouterait-il ? " 
