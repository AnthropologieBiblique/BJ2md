---
aliases : 
- Exode 11
- Exode 11
- Ex 11
- Exodus 11
tags : 
- Bible/Ex/11
- français
cssclass : français
---

# Exode 11

###### 1
Yahvé dit à Moïse : " Je vais encore envoyer une plaie à Pharaon et à l'Égypte, après quoi il vous renverra d'ici. Quand il vous renverra, ce sera fini, et même, il vous expulsera d'ici. 
###### 2
Parle donc au peuple pour que chaque homme demande à son voisin, chaque femme à sa voisine, des objets d'argent et des objets d'or. " 
###### 3
Yahvé fit que le peuple trouvât grâce aux yeux des Égyptiens. Moïse lui-même était un très grand personnage au pays d'Égypte, aux yeux des serviteurs de Pharaon et aux yeux du peuple. 
###### 4
Alors Moïse dit : " Ainsi parle Yahvé : Vers le milieu de la nuit je parcourrai l'Égypte, 
###### 5
et tous les premiers-nés mourront dans le pays d'Égypte, aussi bien le premier-né de Pharaon qui doit s'asseoir sur son trône, que le premier-né de la servante qui est derrière la meule, ainsi que tous les premiers-nés du bétail. 
###### 6
Ce sera alors, dans tout le pays d'Égypte, une grande clameur, telle qu'il n'y en eut jamais et qu'il n'y en aura jamais plus. 
###### 7
Mais chez tous les Israélites, pas un chien ne jappera contre qui que ce soit, homme ou bête, afin que tu saches que Yahvé discerne Israël de l'Égypte. 
###### 8
Alors tous tes serviteurs que voici viendront me trouver et se prosterneront devant moi en disant : "Va-t'en, toi et tout le peuple qui marche à ta suite ! " Après quoi je partirai. " Et, enflammé de colère, il sortit de chez Pharaon. 
###### 9
Yahvé dit à Moïse : " Pharaon ne vous écoutera pas, afin que se multiplient mes prodiges au pays d'Égypte. " 
###### 10
Moïse et Aaron accomplirent tous ces prodiges devant Pharaon ; mais Yahvé endurcit le cœur de Pharaon et il ne laissa pas les Israélites partir de son pays. 
