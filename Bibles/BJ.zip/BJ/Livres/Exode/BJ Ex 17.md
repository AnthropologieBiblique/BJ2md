---
aliases : 
- Exode 17
- Exode 17
- Ex 17
- Exodus 17
tags : 
- Bible/Ex/17
- français
cssclass : français
---

# Exode 17

###### 1
Toute la communauté des Israélites partit du désert de Sîn pour les étapes suivantes, sur l'ordre de Yahvé, et ils campèrent à Rephidim où il n'y avait pas d'eau à boire pour le peuple. 
###### 2
Celui-ci s'en prit à Moïse ; ils dirent : " Donne-nous de l'eau, que nous buvions !" Moïse leur dit : " Pourquoi vous en prenez-vous à moi ? Pourquoi mettez-vous Yahvé à l'épreuve ? " 
###### 3
Le peuple y souffrit de la soif, le peuple murmura contre Moïse et dit : " Pourquoi nous as-tu fait monter d'Égypte ? Est-ce pour me faire mourir de soif, moi, mes enfants et mes bêtes ? " 
###### 4
Moïse cria vers Yahvé en disant : " Que ferai-je pour ce peuple ? Encore un peu et ils me lapideront. " 
###### 5
Yahvé dit à Moïse : " Passe en tête du peuple et prends avec toi quelques anciens d'Israël ; prends en main ton bâton, celui dont tu as frappé le Fleuve, et va. 
###### 6
Voici que je vais me tenir devant toi, là sur le rocher -en Horeb-, tu frapperas le rocher, l'eau en sortira et le peuple boira. " C'est ce que fit Moïse, aux yeux des anciens d'Israël. 
###### 7
Il donna à ce lieu le nom de Massa et Meriba, parce que les Israélites cherchèrent querelle et parce qu'ils mirent Yahvé à l'épreuve en disant : " Yahvé est-il au milieu de nous, ou non ? 
###### 8
Les Amalécites survinrent et combattirent contre Israël à Rephidim. 
###### 9
Moïse dit alors à Josué : " Choisis-toi des hommes et demain, sors combattre Amaleq ; moi, je me tiendrai au sommet de la colline, le bâton de Dieu à la main. " 
###### 10
Josué fit ce que lui avait dit Moïse, il sortit pour combattre Amaleq, et Moïse, Aaron et Hur montèrent au sommet de la colline. 
###### 11
Lorsque Moïse tenait ses mains levées, Israël l'emportait, et quand il les laissait retomber, Amaleq l'emportait. 
###### 12
Comme les mains de Moïse s'alourdissaient, ils prirent une pierre et la mirent sous lui. Il s'assit dessus tandis qu'Aaron et Hur lui soutenaient les mains, l'un d'un côté, l'autre de l'autre. Ainsi ses mains restèrent-elles fermes jusqu'au coucher du soleil. 
###### 13
Josué défit Amaleq et son peuple au fil de l'épée. 
###### 14
Yahvé dit alors à Moïse : " Écris cela dans un livre pour en garder le souvenir, et déclare à Josué que j'effacerai la mémoire d'Amaleq de dessous les cieux. " 
###### 15
Puis Moïse bâtit un autel qu'il nomma Yahvé-Nissi 
###### 16
car, dit-il : " La bannière de Yahvé en main !Yahvé est en guerre contre Amaleq de génération en génération. 
