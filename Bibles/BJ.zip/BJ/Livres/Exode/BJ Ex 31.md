---
aliases : 
- Exode 31
- Exode 31
- Ex 31
- Exodus 31
tags : 
- Bible/Ex/31
- français
cssclass : français
---

# Exode 31

###### 1
Yahvé parla à Moïse et lui dit : 
###### 2
" Vois, j'ai désigné nommément Beçaléel, fils de Uri, fils de Hur, de la tribu de Juda. 
###### 3
Je l'ai comblé de l'esprit de Dieu en habileté, intelligence et savoir pour toutes sortes d'ouvrages ; 
###### 4
pour concevoir des projets et les exécuter en or, en argent et en bronze ; 
###### 5
pour tailler les pierres à enchâsser, pour tailler le bois et pour exécuter toute sorte d'ouvrage. 
###### 6
Voici que je lui adjoins Oholiab, fils d'Ahisamak, de la tribu de Dan, et j'ai mis la sagesse dans le cœur de tous les hommes au cœur sage pour qu'ils fassent tout ce que je t'ai ordonné : 
###### 7
la Tente du Rendez-vous, l'arche du Témoignage, le propitiatoire qui est sur elle et tout le mobilier de la Tente ; 
###### 8
la table et tous ses accessoires, le candélabre pur et tous ses accessoires, l'autel des parfums, 
###### 9
l'autel des holocaustes et tous ses accessoires, le bassin et son socle ; 
###### 10
les vêtements d'apparat, les vêtements sacrés pour Aaron le prêtre, et les vêtements de ses fils, pour exercer le sacerdoce ; 
###### 11
l'huile d'onction et l'encens aromatique pour le sanctuaire. En tout, ils feront comme je te l'ai ordonné. 
###### 12
Yahvé dit à Moïse : 
###### 13
" Toi, parle aux Israélites et dis-leur : vous garderez bien mes sabbats, car c'est un signe entre moi et vous pour vos générations, afin qu'on sache que je suis Yahvé, celui qui vous sanctifie. 
###### 14
Vous garderez le sabbat car il est saint pour vous. Qui le profanera sera mis à mort ; quiconque fera ce jour-là quelque ouvrage sera retranché du milieu de son peuple. 
###### 15
Pendant six jours on fera l'ouvrage à faire, mais le septième jour sera jour de repos complet, consacré à Yahvé. Quiconque travaillera le jour du sabbat sera mis à mort. 
###### 16
Les Israélites garderont le sabbat, en observant le sabbat dans leurs générations, c'est une alliance éternelle. 
###### 17
Entre moi et les Israélites c'est un signe à perpétuité, car en six jours Yahvé a fait les cieux et la terre, mais le septième jour il a chômé et repris haleine. 
###### 18
Quand Il eut fini de parler avec Moïse sur le mont Sinaï, Il lui remit les deux tables du Témoignage, tables de pierre écrites du doigt de Dieu. 
