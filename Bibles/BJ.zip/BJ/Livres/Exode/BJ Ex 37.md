---
aliases : 
- Exode 37
- Exode 37
- Ex 37
- Exodus 37
tags : 
- Bible/Ex/37
- français
cssclass : français
---

# Exode 37

###### 1
Beçaléel fit l'arche en bois d'acacia. Elle était longue de deux coudées et demie, large d'une coudée et demie et haute d'une coudée et demie. 
###### 2
Il la plaqua d'or pur au-dedans et au-dehors et fit une moulure d'or tout autour. 
###### 3
Il fondit, pour l'arche, quatre anneaux d'or, à ses quatre pieds :deux anneaux sur un côté, et deux anneaux sur l'autre. 
###### 4
Il fit des barres en bois d'acacia et les plaqua d'or. 
###### 5
Puis il introduisit les barres dans les anneaux fixés sur les côtés de l'arche pour porter l'arche. 
###### 6
Il fit un propitiatoire d'or pur, de deux coudées et demie de long et d'une coudée et demie de large. 
###### 7
Il fit deux chérubins d'or repoussé, il les fit aux deux extrémités du propitiatoire : 
###### 8
un chérubin à cette extrémité-ci, un chérubin à cette extrémité-là, il fit faire corps aux chérubins avec le propitiatoire à ses deux extrémités. 
###### 9
Les chérubins avaient les ailes déployées vers le haut et protégeaient de leurs ailes le propitiatoire, en se faisant face ; les faces des chérubins étaient tournées vers le propitiatoire. 
###### 10
Il fit la table en bois d'acacia ; elle avait deux coudées de long, une coudée de large et une coudée et demie de haut. 
###### 11
Il la plaqua d'or pur et fit une moulure d'or tout autour. 
###### 12
Il fit, tout autour, des entretoises larges d'un palme et fit une moulure d'or autour des entretoises. 
###### 13
Il fondit pour elle quatre anneaux d'or et il mit les anneaux aux quatre angles formés par les quatre pieds. 
###### 14
Les anneaux étaient placés près des entretoises et servaient de logement aux barres qui servaient pour porter la table. 
###### 15
Il fit les barres en bois d'acacia et les plaqua d'or, pour porter la table. 
###### 16
Il fit les accessoires qui devaient être sur la table : ses plats, ses coupes, ses bols et ses aiguières pour les libations, tous d'or pur. 
###### 17
Il fit le candélabre d'or pur. D'or repoussé, il fit le candélabre, sa base et son fût. Ses calices, boutons et fleurs, faisaient corps avec lui. 
###### 18
Six branches s'en détachaient sur les côtés : trois branches du candélabre d'un côté, trois branches du candélabre de l'autre côté. 
###### 19
La première branche portait trois calices en forme de fleur d'amandier, avec bouton et fleur. La deuxième branche portait trois calices en forme de fleur d'amandier, avec bouton et fleur. Il en était ainsi pour les six branches partant du candélabre. 
###### 20
Le candélabre lui-même portait quatre calices en forme de fleur d'amandier, avec bouton et fleur : 
###### 21
un bouton sous les deux premières branches partant du candélabre, un bouton sous les deux branches suivantes, un bouton sous les deux dernières branches : donc aux six branches s'en détachant. 
###### 22
Les boutons et les branches faisaient corps avec le candélabre, et le tout était fait d'un bloc d'or pur repoussé. 
###### 23
Puis il fit ses sept lampes, avec leurs mouchettes et leurs cendriers d'or pur. 
###### 24
D'un talent d'or pur, il fit le candélabre et tous ses accessoires. 
###### 25
Il fit l'autel des parfums en bois d'acacia, d'une coudée de long, d'une coudée de large - donc carré - et de deux coudées de haut : ses cornes faisaient corps avec lui. 
###### 26
Il le plaqua d'or pur, sa partie supérieure, ses parois tout autour et ses cornes, et fit une moulure d'or tout autour. 
###### 27
Il lui fit deux anneaux d'or au-dessous de la moulure, sur les deux côtés, sur les deux faces pour loger les barres servant à son transport. 
###### 28
Il fit les barres en bois d'acacia et les plaqua d'or. 
###### 29
Il fit aussi l'huile d'onction sainte et l'encens aromatique - comme un parfumeur. 
