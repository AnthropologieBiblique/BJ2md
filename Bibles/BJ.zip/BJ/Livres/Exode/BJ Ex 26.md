---
aliases : 
- Exode 26
- Exode 26
- Ex 26
- Exodus 26
tags : 
- Bible/Ex/26
- français
cssclass : français
---

# Exode 26

###### 1
" Quant à la Demeure, tu la feras de dix bandes d'étoffes de fin lin retors, de pourpre violette et écarlate et de cramoisi. Tu les feras brodées de chérubins. 
###### 2
La longueur d'une bande sera de vingt-huit coudées, sa largeur de quatre coudées, et toutes les bandes auront la même dimension. 
###### 3
Cinq des bandes seront assemblées l'une à l'autre, et les cinq autres bandes seront assemblées l'une à l'autre. 
###### 4
Tu feras des brides de pourpre violette à la lisière de la première bande, à l'extrémité de l'assemblage, et tu feras de même à la lisière de la bande qui termine le second assemblage. 
###### 5
Tu feras cinquante brides à la première bande, et cinquante brides à l'extrémité de la bande du second assemblage, les brides se correspondant l'une à l'autre. 
###### 6
Tu feras aussi cinquante agrafes d'or, et tu assembleras les bandes l'une à l'autre avec les agrafes. Ainsi la Demeure sera d'un seul tenant. 
###### 7
Tu feras des bandes d'étoffe en poil de chèvre pour former une tente au-dessus de la Demeure. Tu en feras onze. 
###### 8
La longueur d'une bande sera de trente coudées et sa largeur de quatre coudées ; les onze bandes auront mêmes dimensions. 
###### 9
Tu assembleras cinq bandes d'une part et six bandes d'autre part, et tu rabattras la sixième sur le devant de la tente. 
###### 10
Tu feras cinquante brides à la lisière de la première bande, à l'extrémité du premier assemblage, et cinquante brides à la lisière de la bande du second assemblage. 
###### 11
Tu feras cinquante agrafes de bronze, et tu introduiras les agrafes dans les brides pour assembler la tente qui sera ainsi d'un seul tenant. 
###### 12
De ce qui retombera en surplus des bandes de la tente, la moitié de la bande en surplus retombera sur l'arrière de la Demeure. 
###### 13
La coudée en surplus de part et d'autre, sur la longueur des bandes de la tente, retombera sur les côtés de la Demeure, de part et d'autre, pour la couvrir. 
###### 14
Tu feras pour la tente une couverture en peaux de béliers teintes en rouge, et une couverture en cuir fin, par-dessus. 
###### 15
" Tu feras pour la Demeure des cadres en bois d'acacia qui seront dressés debout. 
###### 16
Chaque cadre sera long de dix coudées et large d'une coudée et demie. 
###### 17
Chaque cadre aura deux tenons jumelés ; tu feras de même pour tous les cadres de la Demeure. 
###### 18
Tu feras les cadres pour constituer la Demeure : vingt cadres pour le côté sud, vers le midi. 
###### 19
Tu feras quarante socles d'argent sous les vingt cadres : deux socles sous un cadre pour ses deux tenons, deux socles sous un autre cadre pour ses deux tenons. 
###### 20
Du second côté de la Demeure, le côté nord, il y aura vingt cadres 
###### 21
et quarante socles d'argent : deux socles sous un cadre, deux socles sous un autre cadre. 
###### 22
Pour le fond de la Demeure, vers la mer, tu feras six cadres, 
###### 23
et tu feras deux cadres pour les angles du fond de la Demeure. 
###### 24
Les cadres seront jumelés à leur base et le resteront jusqu'à leur sommet, à la hauteur du premier anneau. Ainsi en sera-t-il pour les deux cadres destinés aux deux angles. 
###### 25
Il y aura donc huit cadres avec leurs socles d'argent, soit seize socles : deux socles sous un premier cadre, deux socles sous un autre cadre. 
###### 26
Tu feras des traverses en bois d'acacia : cinq pour les cadres du premier côté de la Demeure, 
###### 27
cinq traverses pour les cadres du second côté de la Demeure, et cinq traverses pour les cadres qui forment le fond de la Demeure, vers l'ouest. 
###### 28
La traverse médiane, placée à mi-hauteur, assemblera les cadres d'une extrémité à l'autre. 
###### 29
Tu plaqueras d'or les cadres, tu leur feras des anneaux d'or où se logeront les traverses, et tu plaqueras les traverses d'or. 
###### 30
Ainsi tu dresseras la Demeure, selon le modèle qui t'a été montré sur la montagne. 
###### 31
" Tu feras un rideau de pourpre violette et écarlate, de cramoisi et de fin lin retors, brodé de chérubins. 
###### 32
Tu le mettras sur quatre colonnes d'acacia plaquées d'or, munies de crochets d'or, posées sur quatre socles d'argent. 
###### 33
Tu mettras le rideau sous les agrafes, tu introduiras là, derrière le rideau, l'arche du Témoignage, et le rideau marquera pour vous la séparation entre le Saint et le Saint des Saints. 
###### 34
Tu mettras le propitiatoire sur l'arche du Témoignage, dans le Saint des Saints. 
###### 35
Tu placeras la table à l'extérieur du rideau, et le candélabre en face d'elle, du côté sud de la Demeure, et tu mettras la table du côté nord. 
###### 36
Tu feras pour l'entrée de la tente un voile broché de pourpre violette et écarlate, de cramoisi et de fin lin retors. 
###### 37
Tu feras pour ce voile cinq colonnes d'acacia et tu les plaqueras d'or, leurs crochets seront en or, et tu couleras pour elles cinq socles de bronze. 
