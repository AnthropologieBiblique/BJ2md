---
aliases : 
- Exode 15
- Exode 15
- Ex 15
- Exodus 15
tags : 
- Bible/Ex/15
- français
cssclass : français
---

# Exode 15

###### 1
Alors Moïse et les Israélites chantèrent pour Yahvé le chant que voici : " Je chante pour Yahvé car il s'est couvert de gloire, il a jeté à la mer cheval et cavalier. 
###### 2
Yah est ma force et mon chant, à lui je dois mon salut. Il est mon Dieu, je le célèbre, le Dieu de mon père et je l'exalte. 
###### 3
Yahvé est un guerrier, son nom est Yahvé. 
###### 4
Les chars de Pharaon et son armée, il les a jetés à la mer, l'élite de ses officiers, la mer des Roseaux l'a engloutie. 
###### 5
Les abîmes les recouvrent, ils ont coulé au fond du gouffre comme une pierre. 
###### 6
Ta droite, Yahvé, s'illustre par sa force, ta droite, Yahvé, taille en pièces l'ennemi. 
###### 7
Par l'excès de ta majesté, tu renverses tes adversaires, tu déchaînes ta colère, elle les dévore comme du chaume. 
###### 8
Au souffle de tes narines, les eaux s'amoncelèrent, les flots se dressèrent comme une digue, les abîmes se figèrent au cœur de la mer. 
###### 9
L'ennemi s'était dit : "Je poursuivrai, j'atteindrai, je partagerai le butin, mon âme s'en gorgera, je dégainerai mon épée, ma main les supprimera. "
###### 10
Tu soufflas de ton haleine, la mer les recouvrit, ils s'enfoncèrent comme du plomb dans les eaux formidables. 
###### 11
Qui est comme toi parmi les dieux, Yahvé ?Qui est comme toi illustre en sainteté, redoutable en exploits, artisan de merveilles ?
###### 12
Tu étendis ta droite, la terre les engloutit. 
###### 13
Ta grâce a conduit ce peuple que tu as racheté, ta force l'a guidé vers ta sainte demeure. 
###### 14
Les peuples ont entendu, ils frémissent, des douleurs poignent les habitants de Philistie. 
###### 15
Alors sont bouleversés les chefs d'Édom, les princes de Moab, la terreur s'en empare, ils titubent, tous ceux qui habitent Canaan. 
###### 16
Sur eux s'abattent terreur et crainte, la puissance de ton bras les laisse pétrifiés, tant que passe ton peuple, Yahvé, tant que passe ce peuple que tu t'es acheté. 
###### 17
Tu les amèneras et tu les planteras sur la montagne de ton héritage, lieu dont tu fis, Yahvé, ta résidence, sanctuaire, Seigneur, qu'ont préparé tes mains. 
###### 18
Yahvé régnera pour toujours et à jamais. "
###### 19
Car lorsque la cavalerie de Pharaon avec ses chars et ses cavaliers était entrée dans la mer, Yahvé avait fait refluer sur eux les eaux de la mer, alors que les Israélites avaient marché à pied sec au milieu de la mer. 
###### 20
Miryam, la prophétesse, sœur d'Aaron, prit en main un tambourin et toutes les femmes la suivirent avec des tambourins, formant des chœurs de danse. 
###### 21
Et Miryam leur entonna :" Chantez pour Yahvé, car il s'est couvert de gloire, il a jeté à la mer cheval et cavalier. 
###### 22
Moïse fit partir Israël de la mer des Roseaux. Ils se dirigèrent vers le désert de Shur et marchèrent trois jours dans le désert sans trouver d'eau. 
###### 23
Mais quand ils arrivèrent à Mara ils ne purent boire l'eau de Mara, car elle était amère, c'est pourquoi on l'a appelé Mara. 
###### 24
Le peuple murmura contre Moïse en disant : " Qu'allons-nous boire ? " 
###### 25
Moïse cria vers Yahvé, et Yahvé lui montra un morceau de bois. Moïse le jeta dans l'eau, et l'eau devint douce. C'est là qu'il leur fixa un statut et un droit ;c'est là qu'il les mit à l'épreuve. 
###### 26
Puis il dit : " Si tu écoutes bien la voix de Yahvé ton Dieu et fais ce qui est droit à ses yeux, si tu prêtes l'oreille à ses commandements et observes toutes ses lois, tous les maux que j'ai infligés à l'Égypte, je ne te les infligerai pas, car je suis Yahvé, celui qui te guérit. "
###### 27
Ils arrivèrent ensuite à Élim où se trouvent douze sources et soixante-dix palmiers, et ils y campèrent au bord de l'eau. 
