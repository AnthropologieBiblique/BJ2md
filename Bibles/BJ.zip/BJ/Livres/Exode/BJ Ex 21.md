---
aliases : 
- Exode 21
- Exode 21
- Ex 21
- Exodus 21
tags : 
- Bible/Ex/21
- français
cssclass : français
---

# Exode 21

###### 1
" Voici les lois que tu leur donneras. 
###### 2
Lorsque tu acquerras un esclave hébreu, son service durera six ans, la septième année il s'en ira, libre, sans rien payer. 
###### 3
S'il est venu seul, il s'en ira seul, et s'il était marié, sa femme s'en ira avec lui. 
###### 4
Si son maître le marie et que sa femme lui donne des fils ou des filles, la femme et ses enfants resteront la propriété du maître et lui s'en ira seul. 
###### 5
Mais si l'esclave dit : "J'aime mon maître, ma femme et mes enfants, je ne veux pas être libéré", 
###### 6
son maître le fera s'approcher de Dieu, il le fera s'approcher du vantail ou du montant de la porte ; il lui percera l'oreille avec un poinçon et l'esclave sera pour toujours à son service. 
###### 7
Si quelqu'un vend sa fille comme servante, elle ne s'en ira pas comme s'en vont les esclaves. 
###### 8
Si elle déplaît à son maître qui se l'était destinée, il la fera racheter ; il ne pourra la vendre à un peuple étranger, usant ainsi de fraude envers elle. 
###### 9
S'il la destine à son fils, il la traitera selon la coutume en vigueur pour les filles. 
###### 10
S'il prend pour lui-même une autre femme, il ne diminuera pas la nourriture, le vêtement ni les droits conjugaux de la première. 
###### 11
S'il la frustre de ces trois choses, elle s'en ira sans rien payer, sans verser d'argent. 
###### 12
" Quiconque frappe quelqu'un et cause sa mort sera mis à mort. 
###### 13
S'il ne l'a pas traqué mais que Dieu l'a mis à portée de sa main, je te fixerai un lieu où il pourra se réfugier. 
###### 14
Mais si un homme va jusqu'à en tuer un autre par ruse, tu l'arracheras même de mon autel pour qu'il soit mis à mort. 
###### 15
Qui frappe son père ou sa mère sera mis à mort. 
###### 16
Qui enlève un homme - qu'il l'ait vendu ou qu'on le trouve en sa possession - sera mis à mort. 
###### 17
Qui maudit son père ou sa mère sera mis à mort. 
###### 18
" Si des hommes se querellent et que l'un frappe l'autre avec une pierre ou avec le poing de telle sorte qu'il n'en meure pas mais doive garder le lit, s'il se relève et peut circuler dehors, fût-ce appuyé sur un bâton, 
###### 19
celui qui a frappé sera quitte, mais il devra le dédommager pour son immobilisation et le soigner jusqu'à sa guérison. 
###### 20
Si quelqu'un frappe son esclave ou sa servante avec un bâton et que celui-ci meure sous sa main, il subira la vengeance. 
###### 21
Mais s'il survit un jour ou deux il ne sera pas vengé, car il a été acquis à prix d'argent. 
###### 22
Si des hommes, en se battant, bousculent une femme enceinte et que celle-ci avorte mais sans autre accident, le coupable paiera l'indemnité imposée par le maître de la femme, il paiera selon la décision des arbitres. 
###### 23
Mais s'il y a accident, tu donneras vie pour vie, 
###### 24
œil pour œil, dent pour dent, pied pour pied, 
###### 25
brûlure pour brûlure, meurtrissure pour meurtrissure, plaie pour plaie. 
###### 26
Si un homme frappe l'œil de son esclave ou l'œil de sa servante et l'éborgne, il lui rendra la liberté en compensation de son œil. 
###### 27
Et s'il fait tomber une dent de son esclave ou une dent de sa servante, il lui rendra la liberté en compensation de sa dent. 
###### 28
Si un bœuf encorne un homme ou une femme et cause sa mort, le bœuf sera lapidé et l'on n'en mangera pas la viande, mais le propriétaire du bœuf sera quitte. 
###### 29
Mais si le bœuf donnait déjà de la corne auparavant, et que le propriétaire, averti de cela, ne l'a pas surveillé, s'il cause la mort d'un homme ou d'une femme, ce bœuf sera lapidé et son propriétaire sera mis à mort. 
###### 30
Si on lui impose une rançon, il devra donner pour le rachat de sa vie tout ce qui lui est imposé. 
###### 31
Si c'est un garçon ou une fille qu'il encorne, on le traitera selon cette coutume. 
###### 32
Si c'est un esclave ou une servante que le bœuf encorne, son propriétaire versera le prix - trente sicles - à leur maître, et le bœuf sera lapidé. 
###### 33
Si quelqu'un laisse une citerne ouverte, ou si quelqu'un creuse une citerne sans la couvrir et qu'un bœuf ou un âne y tombe, 
###### 34
le propriétaire de la citerne indemnisera, il dédommagera en argent son propriétaire, et la bête morte sera pour lui. 
###### 35
Si le bœuf de quelqu'un frappe le bœuf d'autrui et cause sa mort, les propriétaires vendront le bœuf vivant et s'en partageront le prix, ils se partageront aussi la bête morte. 
###### 36
Mais s'il est notoire que le bœuf donnait de la corne auparavant, et que son propriétaire ne l'a pas surveillé, il donnera un bœuf vivant en compensation du bœuf mort, et la bête morte sera pour lui. 
###### 37
" Si quelqu'un vole un bœuf ou un agneau puis l'abat et le vend, il rendra cinq têtes de gros bétail pour le bœuf et quatre têtes de petit bétail pour l'agneau. 
