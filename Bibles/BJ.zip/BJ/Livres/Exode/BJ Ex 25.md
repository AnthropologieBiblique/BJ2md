---
aliases : 
- Exode 25
- Exode 25
- Ex 25
- Exodus 25
tags : 
- Bible/Ex/25
- français
cssclass : français
---

# Exode 25

###### 1
Yahvé parla à Moïse et lui dit : 
###### 2
" Dis aux Israélites de prélever pour moi une contribution. Vous prendrez la contribution de tous ceux que leur cœur incite. 
###### 3
Et voici la contribution que vous accepterez d'eux : de l'or, de l'argent et du bronze ; 
###### 4
de la pourpre violette et écarlate, du cramoisi, du lin fin et du poil de chèvre ; 
###### 5
des peaux de béliers teintes en rouge, du cuir fin et du bois d'acacia ; 
###### 6
de l'huile pour le luminaire, des aromates pour l'huile d'onction et l'encens aromatique ; 
###### 7
des pierres de cornaline et des pierres à enchâsser dans l'éphod et le pectoral. 
###### 8
Fais-moi un sanctuaire, que je puisse résider parmi eux. 
###### 9
Tu feras tout selon le modèle de la Demeure et le modèle de son mobilier que je vais te montrer. 
###### 10
" Tu feras en bois d'acacia une arche longue de deux coudées et demie, large d'une coudée et demie et haute d'une coudée et demie. 
###### 11
Tu la plaqueras d'or pur, au-dedans et au-dehors, et tu feras sur elle une moulure d'or, tout autour. 
###### 12
Tu fondras pour elle quatre anneaux d'or, et tu les mettras à ses quatre pieds : deux anneaux d'un côté et deux anneaux de l'autre. 
###### 13
Tu feras aussi des barres en bois d'acacia ; tu les plaqueras d'or, 
###### 14
et tu engageras dans les anneaux fixés sur les côtés de l'arche les barres qui serviront à la porter. 
###### 15
Les barres resteront dans les anneaux de l'arche et n'en seront pas ôtées. 
###### 16
Tu mettras dans l'arche le Témoignage que je te donnerai. 
###### 17
Tu feras aussi un propitiatoire d'or pur, de deux coudées et demie de long et d'une coudée et demie de large. 
###### 18
Tu feras deux chérubins d'or repoussé, tu les feras aux deux extrémités du propitiatoire. 
###### 19
Fais l'un des chérubins à une extrémité et l'autre chérubin à l'autre extrémité : tu feras les chérubins faisant corps avec le propitiatoire, à ses deux extrémités. 
###### 20
Les chérubins auront les ailes déployées vers le haut et protégeront le propitiatoire de leurs ailes en se faisant face. Les faces des chérubins seront tournées vers le propitiatoire. 
###### 21
Tu mettras le propitiatoire sur le dessus de l'arche, et tu mettras dans l'arche le Témoignage que je te donnerai. 
###### 22
C'est là que je te rencontrerai. C'est de sur le propitiatoire, d'entre les deux chérubins qui sont sur l'arche du Témoignage, que je te donnerai mes ordres pour les Israélites. 
###### 23
" Tu feras une table en bois d'acacia, longue de deux coudées, large d'une coudée et haute d'une coudée et demie. 
###### 24
Tu la plaqueras d'or pur, et tu lui feras tout autour une moulure d'or. 
###### 25
Tout autour, tu lui feras des entretoises larges d'un palme, et tu feras autour des entretoises une moulure d'or. 
###### 26
Tu lui feras quatre anneaux d'or, et tu mettras les anneaux aux quatre angles formés par les quatre pieds. 
###### 27
Les anneaux seront placés près des entretoises pour loger les barres qui serviront à porter la table. 
###### 28
Tu feras les barres en bois d'acacia et tu les plaqueras d'or ; elles serviront à porter la table. 
###### 29
Tu feras ses plats, ses coupes, ses aiguières ainsi que ses bols pour les libations ; c'est d'or pur que tu les feras, 
###### 30
et tu placeras toujours sur la table, devant moi, les pains d'oblation. 
###### 31
" Tu feras un candélabre d'or pur ; le candélabre, sa base et son fût seront repoussés ; ses calices, boutons et fleurs feront corps avec lui. 
###### 32
Six branches s'en détacheront sur les côtés : trois branches du candélabre d'un côté, trois branches du candélabre de l'autre côté. 
###### 33
La première branche portera trois calices en forme de fleur d'amandier, avec bouton et fleur ; la deuxième branche portera aussi trois calices en forme de fleur d'amandier, avec bouton et fleur ; il en sera ainsi pour les six branches partant du candélabre. 
###### 34
Le candélabre lui-même portera quatre calices en forme de fleur d'amandier, avec bouton et fleur : 
###### 35
un bouton sous les deux premières branches partant du candélabre, un bouton sous les deux branches suivantes et un bouton sous les deux dernières branches - donc aux six branches se détachant du candélabre. 
###### 36
Les boutons et les branches feront corps avec le candélabre et le tout sera fait d'un bloc d'or pur repoussé. 
###### 37
Puis tu feras ses sept lampes. On montera les lampes de telle sorte qu'elles éclairent en avant de lui. 
###### 38
Ses mouchettes et ses cendriers seront d'or pur. 
###### 39
Tu le feras, avec tous ses accessoires, d'un talent d'or pur. 
###### 40
Regarde et exécute selon le modèle qui t'est montré sur la montagne. 
