---
aliases : 
- Exode 39
- Exode 39
- Ex 39
- Exodus 39
tags : 
- Bible/Ex/39
- français
cssclass : français
---

# Exode 39

###### 1
Avec la pourpre violette et écarlate et le cramoisi, ils firent les vêtements liturgiques pour officier dans le sanctuaire. Ils firent les vêtements sacrés destinés à Aaron, comme Yahvé l'avait ordonné à Moïse. 
###### 2
Ils firent l'éphod d'or, de pourpre violette et écarlate, de cramoisi et de fin lin retors. 
###### 3
Ils battirent les plaques d'or et les découpèrent en fils pour les entremêler à la pourpre violette et écarlate, au cramoisi et au lin fin, à la manière du brocheur. 
###### 4
Ils lui firent deux épaulettes qui y furent fixées, il y fut fixé par ses deux bords. 
###### 5
L'écharpe qui était dessus pour l'attacher faisait corps avec lui et était de même travail. Elle était d'or, de pourpre violette et écarlate, de cramoisi et de fin lin retors, comme Yahvé l'avait ordonné à Moïse. 
###### 6
Ils travaillèrent les pierres de cornaline, serties dans des chatons d'or, où furent gravés en gravure de sceau les noms des Israélites. 
###### 7
Ils placèrent sur les épaulettes de l'éphod les pierres comme mémorial des Israélites, comme Yahvé l'avait ordonné à Moïse. 
###### 8
Ils firent le pectoral, brodé comme l'éphod, d'or, de pourpre violette et écarlate, de cramoisi et de fin lin retors. 
###### 9
Il était carré et double, d'un empan de long et d'un empan de large. 
###### 10
Ils le garnirent de quatre rangées de pierres. Une sardoine, une topaze, une émeraude pour la première rangée ; 
###### 11
pour la deuxième rangée, une escarboucle, un saphir et un diamant ; 
###### 12
pour la troisième rangée, une agate, une hyacinthe et une améthyste ; 
###### 13
pour la quatrième rangée, une chrysolithe, une cornaline et un jaspe. Elles étaient serties dans des chatons d'or. 
###### 14
Les pierres étaient aux noms des Israélites, elles étaient douze, selon leurs noms, gravées comme des sceaux, chacune au nom de l'une des douze tribus. 
###### 15
Ils firent pour le pectoral des chaînettes d'or pur en forme de torsades. 
###### 16
Ils firent deux rosettes d'or et deux anneaux d'or, et ils mirent les deux anneaux aux deux bords du pectoral. 
###### 17
Ils mirent les deux torsades d'or aux deux anneaux, aux bords du pectoral, 
###### 18
et les deux bords des torsades, ils les mirent aux deux rosettes : ils les mirent ainsi sur les épaulettes de l'éphod, par-devant. 
###### 19
Ils firent aussi deux anneaux d'or et les mirent aux deux bords du pectoral, sur le bord intérieur, du côté de l'éphod. 
###### 20
Ils firent encore deux anneaux d'or, et ils les mirent sur les épaulettes de l'éphod, vers le bas en avant, près de leur point d'attache, au-dessus de l'écharpe de l'éphod. 
###### 21
Ils lièrent le pectoral par ses anneaux aux anneaux de l'éphod avec un cordon de pourpre violette, afin que le pectoral soit au-dessus de l'écharpe de l'éphod et ne puisse se séparer de l'éphod, comme Yahvé l'avait ordonné à Moïse. 
###### 22
Puis ils firent le manteau de l'éphod, tissé tout entier de pourpre violette. 
###### 23
L'ouverture au milieu du manteau était comme l'ouverture d'un corselet de mailles ; l'ouverture avait tout autour une lisière indéchirable. 
###### 24
Ils firent sur l'ourlet du manteau des grenades de pourpre violette et écarlate, de cramoisi et de fin lin retors. 
###### 25
Ils firent aussi des clochettes d'or pur et placèrent les clochettes au milieu des grenades ; 
###### 26
une clochette une grenade, une clochette une grenade, tout autour de l'ourlet du manteau à porter pour officier, comme Yahvé l'avait ordonné à Moïse. 
###### 27
Puis ils firent les tuniques de fin lin tissé, pour Aaron et pour ses fils ; 
###### 28
le turban de lin fin, les calottes de lin fin, les caleçons de fin lin retors, 
###### 29
les ceintures brochées de fin lin retors, de pourpre violette et écarlate et de cramoisi, comme Yahvé l'avait ordonné à Moïse. 
###### 30
Puis ils firent la fleur - le signe de la sainte consécration, en or pur - et ils y gravèrent en intaille, comme un sceau : " Consacré à Yahvé. " 
###### 31
Ils mirent dessus un cordon de pourpre violette, pour le mettre sur le turban, en haut, comme Yahvé l'avait ordonné à Moïse. 
###### 32
Ainsi furent achevés tous les travaux de la Demeure, de la Tente du Rendez-vous ; en tout les Israélites avaient fait comme Yahvé l'avait ordonné à Moïse. 
###### 33
Ils apportèrent à Moïse la Demeure, la Tente et tous ses accessoires, ses agrafes, ses cadres, ses traverses, ses colonnes et ses socles ; 
###### 34
la couverture en peaux de béliers teintes en rouge, la couverture en cuir fin et le rideau du voile ; 
###### 35
l'arche du Témoignage avec ses barres et le propitiatoire ; 
###### 36
la table, tous ses accessoires et les pains d'oblation ; 
###### 37
le candélabre d'or pur, ses lampes - une rangée de lampes - et tous ses accessoires, ainsi que l'huile pour le luminaire ; 
###### 38
l'autel d'or, l'huile d'onction, l'encens aromatique et le voile pour l'entrée de la Tente ; 
###### 39
l'autel de bronze et son treillis de bronze, ses barres et tous ses accessoires ; le bassin et son socle ; 
###### 40
les courtines du parvis, ses colonnes, ses socles et le voile pour la porte du parvis, ses cordes, ses piquets ainsi que tous les accessoires du service de la Demeure, pour la Tente du Rendez-vous ; 
###### 41
les vêtements liturgiques pour officier dans le sanctuaire - les vêtements sacrés pour Aaron, le prêtre, et les vêtements de ses fils pour exercer le sacerdoce. 
###### 42
Les Israélites avaient fait tous les travaux comme Yahvé l'avait ordonné à Moïse. 
###### 43
Moïse vit tout l'ouvrage : ils l'avaient fait comme Yahvé l'avait ordonné. Et Moïse les bénit. 
