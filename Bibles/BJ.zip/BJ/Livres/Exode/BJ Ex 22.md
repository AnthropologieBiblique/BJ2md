---
aliases : 
- Exode 22
- Exode 22
- Ex 22
- Exodus 22
tags : 
- Bible/Ex/22
- français
cssclass : français
---

# Exode 22

###### 1
Si le voleur surpris à percer un mur reçoit un coup mortel, son sang ne sera pas vengé. 
###### 2
Mais si le soleil était déjà levé, son sang sera vengé. Il devra restituer, et s'il n'a pas de quoi, on le vendra pour rembourser ce qu'il a volé. 
###### 3
Si l'animal volé, bœuf, âne ou tête de petit bétail, est retrouvé vivant en sa possession, il restituera au double. 
###### 4
" Si quelqu'un fait brouter un champ ou une vigne et laisse brouter le champ d'autrui, il restituera la partie broutée de ce champ d'après ce qu'il rapporte. S'il a laissé brouter le champ entier, il restituera sur la base de la meilleure récolte du champ ou de la vigne. 
###### 5
Si un feu prend et rencontre des buissons épineux et qu'il consume meules, moissons ou champs, l'auteur de l'incendie restituera ce qui a brûlé. 
###### 6
Si quelqu'un donne en garde à un autre de l'argent ou des objets, et qu'on les vole chez celui-ci, le voleur, si on le découvre, devra restituer au double. 
###### 7
Si on ne découvre pas le voleur, le maître de la maison s'approchera de Dieu pour attester qu'il n'a pas porté la main sur le bien de l'autre. 
###### 8
Dans toute cause litigieuse relative à un bœuf, à un âne, à une tête de petit bétail, à un vêtement ou à n'importe quel objet perdu dont on dit : "C'est bien lui", le différend sera porté devant Dieu. Celui que Dieu aura déclaré coupable restituera le double à l'autre. 
###### 9
Si quelqu'un confie à la garde d'un autre un âne, un taureau, une tête de petit bétail ou tout autre animal, et que la bête crève, se brise un membre ou est enlevée sans témoins, 
###### 10
un serment par Yahvé décidera entre les deux parties si le gardien a porté la main sur le bien de l'autre ou non. Le propriétaire prendra ce qui reste et le gardien n'aura pas à restituer. 
###### 11
Mais si l'animal volé se trouvait auprès de lui, il le restituera à son propriétaire. 
###### 12
Si l'animal est déchiqueté par une bête de proie, il apportera en témoignage l'animal déchiqueté et n'aura pas à restituer. 
###### 13
Si quelqu'un emprunte une bête à un autre et qu'elle se brise un membre ou crève en l'absence de son propriétaire, il devra restituer. 
###### 14
Mais si le propriétaire est auprès de l'animal, il n'aura pas à restituer. Si le propriétaire est un loueur, il touchera son prix de louage. 
###### 15
" Si quelqu'un séduit une vierge non encore fiancée et couche avec elle, il versera le prix et la prendra pour femme. 
###### 16
Si son père refuse de la lui donner, il versera une somme équivalente au prix fixé pour les vierges. 
###### 17
" Tu ne laisseras pas en vie la magicienne. 
###### 18
Quiconque s'accouple avec une bête sera mis à mort. 
###### 19
Qui sacrifie à d'autres dieux sera voué à l'anathème. 
###### 20
Tu ne molesteras pas l'étranger ni ne l'opprimeras, car vous-mêmes avez été étrangers dans le pays d'Égypte. 
###### 21
Vous ne maltraiterez pas une veuve ni un orphelin. 
###### 22
Si tu le maltraites et qu'il crie vers moi, j'écouterai son cri ; 
###### 23
ma colère s'enflammera et je vous ferai périr par l'épée ; vos femmes seront veuves et vos fils orphelins. 
###### 24
Si tu prêtes de l'argent à un compatriote, à l'indigent qui est chez toi, tu ne te comporteras pas envers lui comme un prêteur à gages, vous ne lui imposerez pas d'intérêts. 
###### 25
Si tu prends en gage le manteau de quelqu'un, tu le lui rendras au coucher du soleil. 
###### 26
C'est sa seule couverture, c'est le manteau dont il enveloppe son corps, dans quoi se couchera-t-il ? S'il crie vers moi je l'écouterai, car je suis compatissant, moi ! 
###### 27
Tu ne blasphémeras pas Dieu ni ne maudiras un chef de ton peuple. 
###### 28
" Ne diffère pas d'offrir de ton abondance et de ton surplus. Le premier-né de tes fils, tu me le donneras. 
###### 29
Tu feras de même pour ton gros et ton petit bétail : pendant sept jours il restera avec sa mère, le huitième jour tu me le donneras. 
###### 30
Vous serez pour moi des hommes saints. Vous ne mangerez pas la viande d'une bête déchiquetée par un fauve dans la campagne, vous la jetterez aux chiens. 
