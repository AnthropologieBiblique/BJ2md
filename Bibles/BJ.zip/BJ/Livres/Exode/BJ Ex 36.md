---
aliases : 
- Exode 36
- Exode 36
- Ex 36
- Exodus 36
tags : 
- Bible/Ex/36
- français
cssclass : français
---

# Exode 36

###### 1
Beçaléel, Oholiab et tous les hommes à qui Yahvé a donné l'habileté et l'intelligence pour qu'ils sachent faire tout le travail à accomplir au sanctuaire, feront tout comme Yahvé l'a ordonné. 
###### 2
Moïse appela donc Beçaléel, Oholiab et tous les hommes habiles à qui Yahvé avait donné l'habileté, tous ceux que leur cœur portait à s'appliquer à l'ouvrage pour le faire. 
###### 3
Ils reçurent de Moïse tout ce que les Israélites avaient apporté en contribution pour exécuter le travail d'édification du sanctuaire. Comme ils continuaient d'apporter, chaque matin, leurs offrandes, 
###### 4
tous les hommes habiles faisant tout le travail du sanctuaire vinrent, chacun quittant le travail qu'il était en train de faire, 
###### 5
et dirent à Moïse : " Le peuple apporte plus qu'il n'en faut pour le travail que Yahvé a ordonné de faire. " 
###### 6
Moïse donna un ordre et l'on fit passer dans le camp une proclamation : " Que personne, homme ou femme, ne fasse plus quoi que ce soit pour la contribution du sanctuaire ", et l'on empêcha le peuple de rien apporter. 
###### 7
Les matériaux suffisaient pour faire tout le travail et il y en avait même en surplus. 
###### 8
Tous les hommes habiles, parmi ceux qui faisaient le travail, firent la Demeure. Il la fit de dix bandes d'étoffe de fin lin retors, de pourpre violette et écarlate et de cramoisi, brodées de chérubins. 
###### 9
La longueur d'une bande était de vingt-huit coudées et sa largeur de quatre coudées. Toutes les bandes avaient les mêmes dimensions. 
###### 10
Il assembla les bandes cinq d'un côté, cinq de l'autre. 
###### 11
Il fit des brides de pourpre violette à la lisière de la première bande, à l'extrémité du premier assemblage, et fit de même à la lisière de la dernière bande du second assemblage. 
###### 12
Il fit cinquante brides à la première bande et cinquante brides à l'extrémité de la bande du second assemblage, les brides se correspondant l'une à l'autre. 
###### 13
Il fit cinquante agrafes d'or et assembla les bandes l'une à l'autre avec les agrafes : la Demeure fut ainsi d'un seul tenant. 
###### 14
Puis il fit des bandes d'étoffe de poil de chèvre pour la tente qui est sur la Demeure. Il en fit onze. 
###### 15
La longueur d'une bande était de trente coudées et sa largeur de quatre coudées : les onze bandes avaient mêmes dimensions. 
###### 16
Il assembla cinq bandes d'une part et six bandes d'autre part. 
###### 17
Il fit cinquante brides à la lisière de la dernière bande du premier assemblage, et il fit cinquante brides à la lisière de la bande du second assemblage. 
###### 18
Il fit cinquante agrafes de bronze pour assembler la tente afin qu'elle soit d'un seul tenant. 
###### 19
Il fit pour la tente une couverture en peaux de béliers teintes en rouge, et une en cuir fin par-dessus. 
###### 20
Il fit pour la Demeure des cadres en bois d'acacia dressés debout. 
###### 21
Chaque cadre était long de dix coudées et large d'une coudée et demie ; 
###### 22
chaque cadre avait deux tenons jumelés. Il fit de même pour les cadres de la Demeure. 
###### 23
Il fit les cadres pour la Demeure : vingt cadres pour le côté sud, vers le midi. 
###### 24
Il fit quarante socles d'argent pour les vingt cadres : deux socles sous un cadre pour ses deux tenons, deux socles sous un autre cadre pour ses deux tenons. 
###### 25
Il fit pour le second côté de la Demeure, vers le nord, vingt cadres 
###### 26
et quarante socles d'argent : deux socles sous un cadre, deux socles sous un autre cadre. 
###### 27
Pour le fond de la Demeure, vers l'ouest, il fit six cadres. 
###### 28
Il fit aussi deux cadres pour les angles du fond de la Demeure. 
###### 29
Ils étaient jumelés à leur partie inférieure et le demeuraient jusqu'au sommet, à la hauteur du premier anneau. Ainsi fit-il pour les deux cadres des deux angles. 
###### 30
Il y avait huit cadres avec leurs seize socles d'argent, deux socles sous chaque cadre. 
###### 31
Il fit des traverses en bois d'acacia, 
###### 32
cinq pour les cadres du premier côté de la Demeure, cinq pour les cadres du second côté de la Demeure et cinq pour les cadres du fond de la Demeure, du côté de la mer. 
###### 33
Il fit la traverse médiane pour assembler les cadres à mi-hauteur, d'une extrémité à l'autre. 
###### 34
Il plaqua d'or les cadres et leur fit des anneaux d'or où s'engageraient les traverses, et il plaqua d'or leurs traverses. 
###### 35
Il fit le rideau de pourpre violette et écarlate, de cramoisi et de fin lin retors, brodé de chérubins. 
###### 36
Il lui fit quatre colonnes en acacia qu'il plaqua d'or, avec leurs crochets d'or, et il fondit pour elles quatre socles d'argent. 
###### 37
Il fit pour l'entrée de la tente un voile broché de pourpre violette et écarlate, de cramoisi et de fin lin retors, 
###### 38
ainsi que ses cinq colonnes avec leurs crochets ; il plaqua d'or leurs chapiteaux et leurs tringles ; leurs cinq socles étaient en bronze. 
