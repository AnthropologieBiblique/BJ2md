---
aliases : 
- Exode 28
- Exode 28
- Ex 28
- Exodus 28
tags : 
- Bible/Ex/28
- français
cssclass : français
---

# Exode 28

###### 1
" Quant à toi, fais approcher de toi Aaron ton frère et ses fils, d'entre les Israélites, pour qu'il exerce mon sacerdoce : Aaron, Nadab et Abihu, Éléazar et Itamar, fils d'Aaron. 
###### 2
Tu feras pour Aaron ton frère des vêtements sacrés qui lui feront une glorieuse parure. 
###### 3
Tu t'adresseras à tous les hommes habiles que j'ai comblés d'habileté et ils feront les vêtements d'Aaron, pour qu'il soit consacré à l'exercice de mon sacerdoce. 
###### 4
Voici les vêtements qu'ils feront : un pectoral, un éphod, un manteau et une tunique brodée, un turban et une ceinture. Ils feront des vêtements sacrés pour ton frère Aaron et pour ses fils, afin qu'ils exercent mon sacerdoce. 
###### 5
Ils prendront l'or, la pourpre violette et écarlate, le cramoisi et le fin lin. 
###### 6
" Ils feront l'éphod brodé en or, en pourpre violette et écarlate, en cramoisi et en fin lin retors. 
###### 7
Deux épaulettes y seront fixées : il y sera fixé par ses deux bords. 
###### 8
L'écharpe qui est dessus pour l'attacher sera de même travail et fera corps avec lui, elle sera d'or, de pourpre violette et écarlate, de cramoisi et de fin lin retors. 
###### 9
Tu prendras ensuite deux pierres de cornaline sur lesquelles tu graveras les noms des Israélites, 
###### 10
six de leurs noms sur la première pierre, et les six noms restants sur la deuxième pierre, selon l'ordre de leur naissance. 
###### 11
C'est selon l'art du lapidaire - en gravure de sceau - que tu graveras les deux pierres aux noms des Israélites, et tu les sertiras dans des chatons d'or. 
###### 12
Tu placeras les deux pierres aux épaulettes de l'éphod, comme mémorial des Israélites. Ainsi Aaron portera leurs noms sur ses deux épaules en présence de Yahvé, pour en faire mémoire. 
###### 13
Tu feras des rosettes d'or, 
###### 14
et deux chaînettes d'or pur que tu feras comme des cordelettes, en forme de torsades, et tu mettras les chaînettes en torsades aux rosettes. 
###### 15
" Tu feras le pectoral du jugement brodé comme l'éphod - tu le feras d'or, de pourpre violette et écarlate, de cramoisi et de fin lin retors. 
###### 16
Il sera carré et double, d'un empan de long et d'un empan de large. 
###### 17
Tu le garniras de pierres serties disposées sur quatre rangs : une sardoine, une topaze, une émeraude pour la première rangée ; 
###### 18
pour la deuxième rangée, une escarboucle, un saphir et un diamant ; 
###### 19
pour la troisième rangée, une agate, une hyacinthe et une améthyste ; 
###### 20
pour la quatrième rangée, une chrysolithe, une cornaline et un jaspe ; elles seront serties dans des chatons d'or. 
###### 21
Les pierres seront aux noms des Israélites, elles seront douze selon leurs noms, gravées comme des sceaux, chacune sera au nom de l'une des douze tribus. 
###### 22
Tu feras pour le pectoral des chaînettes d'or pur en forme de torsades. 
###### 23
Tu feras pour le pectoral deux anneaux d'or, tu les mettras à ses deux extrémités, 
###### 24
et tu mettras les deux torsades d'or aux deux anneaux fixés aux deux extrémités du pectoral. 
###### 25
Les deux autres bords des deux torsades, tu les mettras aux deux rosettes, et tu les mettras sur les épaulettes de l'éphod, par-devant. 
###### 26
Tu feras deux anneaux d'or et tu les placeras sur les deux extrémités du pectoral, sur la lisière intérieure de l'éphod. 
###### 27
Tu feras deux anneaux d'or et tu les mettras sur les deux épaulettes de l'éphod, vers le bas, en avant, près de leur point d'attache au-dessus de l'écharpe de l'éphod. 
###### 28
On liera le pectoral par ses anneaux aux anneaux de l'éphod avec un cordon de pourpre violette, afin qu'il soit sur l'écharpe, et que le pectoral ne puisse se séparer de l'éphod. 
###### 29
Ainsi Aaron portera les noms des Israélites sur le pectoral du jugement, sur son cœur, quand il entrera dans le sanctuaire, comme mémorial devant Yahvé, toujours. 
###### 30
Tu joindras au pectoral du jugement le Urim et le Tummim, ils seront sur le cœur d'Aaron quand il pénétrera devant Yahvé, et Aaron portera sur son cœur le jugement des Israélites devant Yahvé, toujours. 
###### 31
" Tu feras le manteau de l'éphod tout entier de pourpre violette ; 
###### 32
il aura en son milieu une ouverture pour la tête ; son ouverture aura tout autour une lisière tissée comme l'ouverture d'un corselet de mailles, indéchirable. 
###### 33
Sur son ourlet tu feras des grenades de pourpre violette et écarlate, de cramoisi et de fin lin retors, tout autour de l'ourlet, avec, tout autour, des clochettes d'or intercalées : 
###### 34
une clochette d'or et une grenade, une clochette d'or et une grenade tout autour de l'ourlet de son manteau. 
###### 35
Aaron le portera pour officier, on en entendra le bruit quand il entrera dans le sanctuaire devant Yahvé, ou qu'il en sortira, et il ne mourra pas. 
###### 36
" Tu feras une fleur d'or pur et tu y graveras en intaille, comme un sceau : "Consacré à Yahvé. " 
###### 37
Tu la placeras sur un cordon de pourpre violette, et elle sera sur le turban : c'est sur le devant du turban qu'elle sera. 
###### 38
Elle sera sur le front d'Aaron, et Aaron se chargera ainsi des fautes concernant les choses saintes que consacreront les Israélites, pour toutes leurs saintes offrandes. Elle sera sur son front toujours pour leur attirer la faveur de Yahvé. 
###### 39
Tu tisseras la tunique de lin fin, tu feras un turban de lin fin et une ceinture brochée. 
###### 40
" Pour les fils d'Aaron, tu feras des tuniques et des ceintures. Tu leur feras aussi des calottes qui leur feront une glorieuse parure. 
###### 41
Tu en revêtiras Aaron, ton frère, et ses fils, puis tu les oindras, tu les investiras et tu les consacreras à mon sacerdoce. 
###### 42
Fais-leur, pour couvrir leur nudité, des caleçons de lin qui iront des reins jusqu'aux cuisses. 
###### 43
Aaron et ses fils les porteront quand ils entreront dans la Tente du Rendez-vous, ou qu'ils s'approcheront de l'autel pour faire le service dans le sanctuaire, afin de ne pas se charger d'une faute qui entraînerait leur mort. C'est là un décret perpétuel pour Aaron et sa postérité après lui. 
