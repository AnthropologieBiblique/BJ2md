---
aliases : 
- Exode 27
- Exode 27
- Ex 27
- Exodus 27
tags : 
- Bible/Ex/27
- français
cssclass : français
---

# Exode 27

###### 1
" Tu feras l'autel en bois d'acacia ; de cinq coudées de long et de cinq coudées de large, l'autel sera carré ; il aura trois coudées de haut. 
###### 2
Tu feras à ses quatre angles des cornes faisant corps avec lui, et tu le plaqueras de bronze. 
###### 3
Tu feras ses vases pour en ôter les cendres grasses, ses pelles, ses bols à aspersion, ses fourchettes et ses encensoirs. Tous les accessoires de l'autel, tu les feras de bronze. 
###### 4
Tu lui feras un treillis de bronze en forme de filet, et tu feras aux quatre extrémités de ce filet quatre anneaux de bronze. 
###### 5
Tu le mettras sous la corniche de l'autel, en bas, de telle sorte qu'il soit à mi-hauteur de l'autel. 
###### 6
Tu feras des barres pour l'autel, des barres en bois d'acacia, et tu les plaqueras de bronze. 
###### 7
On engagera les barres dans les anneaux, de telle sorte que les barres soient des deux côtés de l'autel lorsqu'on le transporte. 
###### 8
Tu le feras creux, en planches ; tu le feras comme on t'a montré sur la montagne. 
###### 9
" Tu feras le parvis de la Demeure. Pour le côté sud, vers le midi, les courtines du parvis, de fin lin retors, auront une longueur de cent coudées -pour le premier côté-. 
###### 10
Ses vingt colonnes et ses vingt socles seront en bronze ; les crochets des colonnes et leurs tringles en argent. 
###### 11
De même pour le côté nord, tu feras des rideaux d'une longueur de cent coudées, ses vingt colonnes et leurs vingt socles seront en bronze ; les crochets des colonnes et leurs tringles en argent. 
###### 12
La largeur du parvis, du côté de la mer, comportera cinquante coudées de courtines, avec leurs dix colonnes et leurs dix socles. 
###### 13
La largeur du parvis sur le côté est, à l'orient, sera de cinquante coudées. 
###### 14
Quinze coudées de courtines pour un côté de l'entrée, avec leurs trois colonnes et leurs trois socles ; 
###### 15
pour le second côté de l'entrée, quinze coudées de courtines, avec leurs trois colonnes et leurs trois socles. 
###### 16
A la porte du parvis il y aura vingt coudées de voile damassé, de pourpre violette et écarlate, de cramoisi et de fin lin retors, avec leurs quatre colonnes et leurs quatre socles. 
###### 17
Toutes les colonnes autour du parvis seront réunies par des tringles d'argent ; leurs crochets seront d'argent et leurs socles de bronze. 
###### 18
La longueur du parvis sera de cent coudées, sa largeur de cinquante coudées et sa hauteur de cinq coudées. Tous les rideaux seront de fin lin retors et leurs socles de bronze. 
###### 19
Tous les accessoires pour le service général de la Demeure, tous ses piquets et ceux du parvis seront de bronze. 
###### 20
" Quant à toi, tu ordonneras aux Israélites de te procurer de l'huile d'olives broyées pour le luminaire, afin qu'une lampe brûle en permanence. 
###### 21
Aaron et ses fils disposeront cette lampe dans la Tente du Rendez-vous, à l'extérieur du rideau qui pend devant le Témoignage, pour qu'elle brûle du soir au matin devant Yahvé. C'est un décret perpétuel pour les générations des Israélites. 
