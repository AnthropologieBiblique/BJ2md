---
aliases : 
- Exode 13
- Exode 13
- Ex 13
- Exodus 13
tags : 
- Bible/Ex/13
- français
cssclass : français
---

# Exode 13

###### 1
Yahvé parla à Moïse et lui dit : 
###### 2
Consacre-moi tout premier-né, prémices du sein maternel, parmi les Israélites. Homme ou animal, il est à moi. 
###### 3
Moïse dit au peuple : " Souvenez-vous de ce jour, celui où vous êtes sortis d'Égypte, de la maison de servitude, car c'est par la force de sa main que Yahvé vous en a fait sortir, et l'on ne mangera pas de pain levé. 
###### 4
Aujourd'hui vous sortez dans le mois d'Abib. 
###### 5
Quand Yahvé t'aura fait entrer dans la terre des Cananéens, des Hittites, des Amorites, des Hivvites et des Jébuséens, qu'il a juré à tes pères de te donner, terre qui ruisselle de lait et de miel, tu pratiqueras ce rite en ce même mois. 
###### 6
Pendant sept jours tu mangeras des azymes et le septième jour il y aura une fête pour Yahvé. 
###### 7
Ce sont des azymes que l'on mangera pendant les sept jours et l'on ne verra pas chez toi de pain levé, ni on ne verra chez toi de levain, dans tout ton territoire. 
###### 8
Ce jour-là, tu parleras ainsi à ton fils : "C'est à cause de ce que Yahvé a fait pour moi lors de ma sortie d'Égypte. " 
###### 9
Ce sera pour toi un signe sur ta main, un mémorial sur ton front, afin que la loi de Yahvé soit toujours dans ta bouche, car c'est à main forte que Yahvé t'a fait sortir d'Égypte. 
###### 10
Tu observeras cette loi au temps prescrit, d'année en année. 
###### 11
" Quand Yahvé t'aura fait entrer dans le pays des Cananéens, comme il te l'a juré ainsi qu'à tes pères, et qu'il te l'aura donné, 
###### 12
tu céderas à Yahvé tout être sorti le premier du sein maternel et toute la première portée des bêtes qui t'appartiennent : les mâles sont à Yahvé. 
###### 13
Les premiers ânons mis bas, tu les rachèteras par une tête de petit bétail. Si tu ne les rachètes pas, tu leur briseras la nuque, mais tous les premiers-nés de l'homme, parmi tes fils, tu les rachèteras. 
###### 14
Lorsque ton fils te demandera demain : "Que signifie ceci ?" tu lui diras : "C'est par la force de sa main que Yahvé nous a fait sortir d'Égypte, de la maison de servitude. 
###### 15
Comme Pharaon s'entêtait à ne pas nous laisser partir, Yahvé fit périr tous les premiers-nés au pays d'Égypte, aussi bien les premiers-nés des hommes que les premiers-nés du bétail. C'est pourquoi je sacrifie à Yahvé tout mâle sorti le premier du sein maternel et je rachète tout premier-né de mes fils. " 
###### 16
Ce sera pour toi un signe sur ta main, un bandeau sur ton front, car c'est par la force de sa main que Yahvé nous a fait sortir d'Égypte. 
###### 17
Lorsque Pharaon eut laissé partir le peuple, Dieu ne lui fit pas prendre la route du pays des Philistins, bien qu'elle fût plus proche, car Dieu s'était dit qu'à la vue des combats le peuple pourrait se repentir et retourner en Égypte. 
###### 18
Dieu fit donc faire au peuple un détour par la route du désert de la mer des Roseaux. C'est bien armés que les Israélites montèrent du pays d'Égypte. 
###### 19
Moïse emporta les ossements de Joseph avec lui, car celui-ci avait adjuré les Israélites en disant : " Oui, Dieu vous visitera, et alors vous emporterez d'ici mes ossements avec vous. "
###### 20
Ils partirent de Sukkot et campèrent à Étam, en bordure du désert. 
###### 21
Yahvé marchait avec eux, le jour dans une colonne de nuée pour leur indiquer la route, et la nuit dans une colonne de feu pour les éclairer, afin qu'ils puissent marcher de jour et de nuit. 
###### 22
La colonne de nuée ne se retirait pas le jour devant le peuple, ni la colonne de feu la nuit. 
