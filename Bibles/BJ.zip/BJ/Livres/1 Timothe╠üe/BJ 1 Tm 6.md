---
aliases : 
- 1 Timothée 6
- 1 Timothée 6
- 1 Tm 6
- 1 Timothy 6
tags : 
- Bible/1Tm/6
- français
cssclass : français
---

# 1 Timothée 6

###### 1
Tous ceux qui sont sous le joug de l'esclavage doivent considérer leurs maîtres comme dignes d'un entier respect, afin que le nom de Dieu et la doctrine ne soient pas blasphémés. 
###### 2
Quant à ceux qui ont pour maîtres des croyants, qu'ils n'aillent pas les mépriser sous prétexte que ce sont des frères ; qu'au contraire ils les servent d'autant mieux que ce sont des croyants et des amis de Dieu qui bénéficient de leurs services. Voilà ce que tu dois enseigner et recommander. 
###### 3
Si quelqu'un enseigne autre chose et ne reste pas attaché à de saines paroles, celles de notre Seigneur Jésus Christ, et à la doctrine conforme à la piété, 
###### 4
c'est un être aveuglé par l'orgueil, un ignorant en mal de questions oiseuses et de querelles de mots ; de là viennent l'envie, la discorde, les outrages, les soupçons malveillants, 
###### 5
les disputes interminables de gens à l'esprit corrompu, privés de la vérité, aux yeux de qui la piété est une source de profits. 
###### 6
Profitable, oui, la piété l'est grandement pour qui se contente de ce qu'il a. 
###### 7
Car nous n'avons rien apporté dans le monde et de même nous n'en pouvons rien emporter. 
###### 8
Lors donc que nous avons nourriture et vêtement, sachons être satisfaits. 
###### 9
Quant à ceux qui veulent amasser des richesses, ils tombent dans la tentation, dans le piège, dans une foule de convoitises insensées et funestes, qui plongent les hommes dans la ruine et la perdition. 
###### 10
Car la racine de tous les maux, c'est l'amour de l'argent. Pour s'y être livrés, certains se sont égarés loin de la foi et se sont transpercé l'âme de tourments sans nombre. 
###### 11
Pour toi, homme de Dieu, fuis tout cela. Poursuis la justice, la piété, la foi, la charité, la constance, la douceur. 
###### 12
Combats le bon combat de la foi, conquiers la vie éternelle à laquelle tu as été appelé et en vue de laquelle tu as fait ta belle profession de foi en présence de nombreux témoins. 
###### 13
Je t'en prie devant Dieu qui donne la vie à toutes choses et devant le Christ Jésus qui, sous Ponce Pilate, a rendu son beau témoignage, 
###### 14
garde le commandement sans tache et sans reproche, jusqu'à l'Apparition de notre Seigneur Jésus Christ, 
###### 15
que fera paraître aux temps marqués le Bienheureux et unique Souverain, le Roi des rois et Seigneur des seigneurs, 
###### 16
le seul qui possède l'immortalité, qui habite une lumière inaccessible, que nul d'entre les hommes n'a vu ni ne peut voir. A lui appartiennent honneur et puissance à jamais ! Amen. 
###### 17
Aux riches de ce monde, recommande de ne pas juger de haut, de ne pas placer leur confiance en des richesses précaires, mais en Dieu qui nous pourvoit largement de tout, afin que nous en jouissions. 
###### 18
Qu'ils fassent le bien, s'enrichissent de bonnes œuvres, donnent de bon cœur, sachent partager ; 
###### 19
de cette manière, ils s'amassent pour l'avenir un solide capital, avec lequel ils pourront acquérir la vie véritable. 
###### 20
O Timothée, garde le dépôt. Évite les discours creux et impies, les objections d'une pseudo-science. 
###### 21
Pour l'avoir professée, certains se sont écartés de la foi. La grâce soit avec vous ! 
