---
aliases : 
- 1 Timothée 2
- 1 Timothée 2
- 1 Tm 2
- 1 Timothy 2
tags : 
- Bible/1Tm/2
- français
cssclass : français
---

# 1 Timothée 2

###### 1
Je recommande donc, avant tout, qu'on fasse des demandes, des prières, des supplications, des actions de grâces pour tous les hommes, 
###### 2
pour les rois et tous les dépositaires de l'autoritié, afin que nous puissions mener une vie calme et paisible en toute piété et dignité. 
###### 3
Voilà ce qui est bon et ce qui plaît à Dieu notre Sauveur, 
###### 4
lui qui veut que tous les hommes soient sauvés et parviennent à la connaissance de la vérité. 
###### 5
Car Dieu est unique, unique aussi le médiateur entre Dieu et les hommes, le Christ Jésus, homme lui-même, 
###### 6
qui s'est livré en rançon pour tous. Tel est le témoignage rendu aux temps marqués 
###### 7
et dont j'ai été établi, moi, héraut et apôtre - je dis vrai, je ne mens pas -, docteur des païens, dans la foi et la vérité. 
###### 8
Ainsi donc je veux que les hommes prient en tout lieu, élevant vers le ciel des mains pieuses, sans colère ni dispute. 
###### 9
Que les femmes, de même, aient une tenue décente ; que leur parure, modeste et réservée, ne soit pas faite de cheveux tressés, d'or, de pierreries, de somptueuses toilettes, 
###### 10
mais bien plutôt de bonnes œuvres, ainsi qu'il convient à des femmes qui font profession de piété. 
###### 11
Pendant l'instruction, la femme doit garder le silence, en toute soumission. 
###### 12
Je ne permets pas à la femme d'enseigner ni de faire la loi à l'homme. Qu'elle garde le silence. 
###### 13
C'est Adam en effet qui fut formé le premier, Eve ensuite. 
###### 14
Et ce n'est pas Adam qui se laissa séduire, mais la femme qui, séduite, se rendit coupable de transgression. 
###### 15
Néanmoins elle sera sauvée en devenant mère, à condition de persévérer avec modestie dans la foi, la charité et la sainteté. 
