---
aliases : 
- 1 Timothée 3
- 1 Timothée 3
- 1 Tm 3
- 1 Timothy 3
tags : 
- Bible/1Tm/3
- français
cssclass : français
---

# 1 Timothée 3

###### 1
Elle est sûre cette parole : celui qui aspire à la charge d'épiscope désire une noble fonction. 
###### 2
Aussi faut-il que l'épiscope soit irréprochable, mari d'une seule femme, qu'il soit sobre, pondéré, courtois, hospitalier, apte à l'enseignement, 
###### 3
ni buveur ni batailleur, mais bienveillant, ennemi des chicanes, détaché de l'argent, 
###### 4
sachant bien gouverner sa propre maison et tenir ses enfants dans la soumission d'une manière parfaitement digne. 
###### 5
Car celui qui ne sait pas gouverner sa propre maison, comment pourrait-il prendre soin de l'Église de Dieu ? 
###### 6
Que ce ne soit pas un converti de fraîche date, de peur que, l'orgueil lui tournant la tête, il ne vienne à encourir la même condamnation que le diable. 
###### 7
Il faut en outre que ceux du dehors rendent de lui un bon témoignage, de peur qu'il ne tombe dans l'opprobre et dans les filets du diable. 
###### 8
Les diacres, eux aussi, seront des hommes dignes, n'ayant qu'une parole, modérés dans l'usage du vin, fuyant les profits déshonnêtes. 
###### 9
Qu'ils gardent le mystère de la foi dans une conscience pure. 
###### 10
On commencera par les mettre à l'épreuve, et ensuite, si on n'a rien à leur reprocher, on les admettra aux fonctions de diacres. 
###### 11
Que pareillement les femmes soient dignes, point médisantes, sobres, fidèles en tout. 
###### 12
Les diacres doivent être maris d'une seule femme, savoir bien gouverner leurs enfants et leur propre maison. 
###### 13
Ceux qui remplissent bien leurs fonctions s'acquièrent un rang honorable et une ferme assurance en la foi au Christ Jésus. 
###### 14
En t'écrivant cela, j'espère te rejoindre bientôt. 
###### 15
Si toutefois je tardais, il faut que tu saches comment te comporter dans la maison de Dieu - je veux dire l'Église du Dieu vivant - : colonne et support de la vérité. 
###### 16
Oui, c'est incontestablement un grand mystère que celui de la piété : Il a été manifesté dans la chair, justifié dans l'Esprit, vu des anges, proclamé chez les païens, cru dans le monde, enlevé dans la gloire. 
