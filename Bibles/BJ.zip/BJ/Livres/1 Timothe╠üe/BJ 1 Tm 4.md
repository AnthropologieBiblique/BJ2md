---
aliases : 
- 1 Timothée 4
- 1 Timothée 4
- 1 Tm 4
- 1 Timothy 4
tags : 
- Bible/1Tm/4
- français
cssclass : français
---

# 1 Timothée 4

###### 1
L'esprit dit expressément que, dans les derniers temps, certains renieront la foi pour s'attacher à des esprits trompeurs et à des doctrines diaboliques, 
###### 2
séduits par des menteurs hypocrites marqués au fer rouge dans leur conscience : 
###### 3
ces gens-là interdisent le mariage et l'usage d'aliments que Dieu a créés pour être pris avec action de grâces par les croyants et ceux qui ont la connaissance de la vérité. 
###### 4
Car tout ce que Dieu a créé est bon et aucun aliment n'est à proscrire, si on le prend avec action de grâces : 
###### 5
la parole de Dieu et la prière le sanctifient. 
###### 6
Si tu exposes cela aux frères, tu seras un bon serviteur du Christ Jésus, nourri des enseignements de la foi et de la bonne doctrine dont tu t'es toujours montré le disciple fidèle. 
###### 7
Quant aux fables profanes, racontars de vieilles femmes, rejette-les. Exerce-toi à la piété. 
###### 8
Les exercices corporels, eux, ne servent pas à grand-chose : la piété au contraire est utile à tout, car elle a la promesse de la vie, de la vie présente comme de la vie future. 
###### 9
Elle est sûre cette parole et digne d'une entière créance. 
###### 10
Si en effet nous peinons et combattons, c'est que nous avons mis notre espérance dans le Dieu vivant, le Sauveur de tous les hommes, des croyants surtout. 
###### 11
Tel doit être l'objet de tes prescriptions et de ton enseignement. 
###### 12
Que personne ne méprise ton jeune âge. Au contraire, montre-toi un modèle pour les croyants, par la parole, la conduite, la charité, la foi, la pureté. 
###### 13
En attendant que je vienne, consacre-toi à la lecture, à l'exhortation, à l'enseignement. 
###### 14
Ne néglige pas le don spirituel qui est en toi, qui t'a été conféré par une intervention prophétique accompagnée de l'imposition des mains du collège des presbytres. 
###### 15
Prends cela à cœur. Sois-y tout entier, afin que tes progrès soient manifestes à tous. 
###### 16
Veille sur ta personne et sur ton enseignement ; persévère en ces dispositions. Agissant ainsi, tu te sauveras, toi et ceux qui t'écoutent. 
