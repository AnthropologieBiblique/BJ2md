---
aliases : 
- 1 Timothée 5
- 1 Timothée 5
- 1 Tm 5
- 1 Timothy 5
tags : 
- Bible/1Tm/5
- français
cssclass : français
---

# 1 Timothée 5

###### 1
Ne rudoie pas un vieillard ; au contraire, exhorte-le comme un père, les jeunes gens comme des frères, 
###### 2
les femmes âgées comme des mères, les jeunes comme des sœurs, en toute pureté. 
###### 3
Honore les veuves - j'entends les vraies veuves. 
###### 4
Si une veuve a des enfants ou des petits-enfants, il faut avant tout leur apprendre à pratiquer la piété envers leur propre famille et à payer leurs parents de retour. Voilà ce qui plaît à Dieu. 
###### 5
Mais la vraie veuve, celle qui reste absolument seule, s'en remet à Dieu et consacre ses jours et ses nuits à la prière et à l'oraison. 
###### 6
Quant à celle qui ne pense qu'au plaisir, quoique vivante, elle est morte. 
###### 7
Cela aussi tu le rappelleras, afin qu'elles soient irréprochables. 
###### 8
Si quelqu'un ne prend pas soin des siens, surtout de ceux qui vivent avec lui, il a renié la foi : il est pire qu'un infidèle. 
###### 9
Ne peut être inscrite au groupe des veuves qu'une femme d'au moins soixante ans, ayant été la femme d'un seul mari. 
###### 10
Elle devra produire le témoignage de sa bonne conduite : avoir élevé des enfants, exercé l'hospitalité, lavé les pieds des saints, secouru les affligés, pratiqué toutes les formes de la bienfaisance. 
###### 11
Les jeunes veuves, écarte-les. Dès que des désirs indignes du Christ les assaillent, elles veulent se remarier, 
###### 12
méritant ainsi d'être condamnées pour avoir manqué à leur premier engagement. 
###### 13
Avec cela, n'ayant rien à faire, elles apprennent à courir les maisons ; si encore c'était pour ne rien faire, mais c'est pour bavarder, s'occuper de ce qui ne les regarde pas, parler à tort et à travers. 
###### 14
Je veux donc que les jeunes veuves se remarient, qu'elles aient des enfants, gouvernent leur maison et ne donnent à l'adversaire aucune occasion d'insulte. 
###### 15
Il en est déjà qui se sont fourvoyées à la suite de Satan. 
###### 16
Si une croyante a des veuves dans sa parenté, qu'elle les assiste, afin que l'Église n'en supporte pas la charge, et puisse ainsi secourir les vraies veuves. 
###### 17
Les presbytres qui exercent bien la présidence méritent une double rémunération, surtout ceux qui peinent à la parole et à l'enseignement. 
###### 18
L'Écriture dit en effet : Tu ne muselleras pas le bœuf qui foule le grain ; et encore : L'ouvrier mérite son salaire. 
###### 19
N'accueille d'accusation contre un presbytre que sur déposition de deux ou trois témoins. 
###### 20
Les coupables, reprends-les devant tous, afin que les autres en éprouvent de la crainte. 
###### 21
Je t'en conjure devant Dieu, le Christ Jésus et les anges élus, observe ces règles avec impartialité, sans rien faire par favoritisme. 
###### 22
Ne te hâte pas d'imposer les mains à qui que ce soit. Ne te fais pas complice des péchés d'autrui. Garde-toi pur. 
###### 23
Cesse de ne boire que de l'eau. Prends un peu de vin à cause de ton estomac et de tes fréquents malaises. 
###### 24
Il est des hommes dont les fautes apparaissent avant même tout jugement ; d'autres au contraire chez qui elles ne se découvrent qu'après ; 
###### 25
les bonnes actions, elles aussi, se voient : même celles dont ce n'est pas le cas ne sauraient demeurer cachées. 
