---
aliases : 
- 1 Timothée 1
- 1 Timothée 1
- 1 Tm 1
- 1 Timothy 1
tags : 
- Bible/1Tm/1
- français
cssclass : français
---

# 1 Timothée 1

###### 1
Paul, apôtre du Christ Jésus selon l'ordre de Dieu notre Sauveur et du Christ Jésus, notre espérance, 
###### 2
à Timothée, mon véritable enfant dans la foi : grâce, miséricorde, paix, de par Dieu le Père et le Christ Jésus notre Seigneur. 
###### 3
Ainsi donc, en partant pour la Macédoine, je t'ai prié de demeurer à Éphèse, pour enjoindre à certains de cesser d'enseigner des doctrines étrangères 
###### 4
et de s'attacher à des fables et à des généalogies sans fin, plus propres à soulever de vains problèmes qu'à servir le dessein de Dieu fondé sur la foi. 
###### 5
Cette injonction ne vise qu'à promouvoir la charité qui procède d'un cœur pur, d'une bonne conscience et d'une foi sans détours. 
###### 6
Pour avoir dévié de cette ligne, certains se sont fourvoyés en un creux verbiage ; 
###### 7
ils ont la prétention d'être des docteurs de la Loi, alors qu'ils ne savent ni ce qu'ils disent, ni de quoi ils se font les champions. 
###### 8
Certes, nous le savons, la Loi est bonne, si on en fait un usage légitime, 
###### 9
en sachant bien qu'elle n'a pas été instituée pour le juste, mais pour les insoumis et les rebelles, les impies et les pécheurs, les sacrilèges et les profanateurs, les parricides et les matricides, les assassins, 
###### 10
les impudiques, les homosexuels, les trafiquants d'hommes, les menteurs, les parjures, et pour tout ce qui s'oppose à la saine doctrine, 
###### 11
celle qui est conforme à l'Évangile de la gloire du Dieu bienheureux, qui m'a été confié. 
###### 12
Je rends grâces à celui qui m'a donné la force, le Christ Jésus, notre Seigneur, qui m'a jugé assez fidèle pour m'appeler à son service, 
###### 13
moi, naguère un blasphémateur, un persécuteur, un insulteur. Mais il m'a été fait miséricorde parce que j'agissais par ignorance, étranger à la foi ; 
###### 14
et la grâce de notre Seigneur a surabondé avec la foi et la charité qui est dans le Christ Jésus. 
###### 15
Elle est sûre, cette parole et digne d'une entière créance : le Christ Jésus est venu dans le monde pour sauver les pécheurs, dont je suis, moi, le premier. 
###### 16
Et s'il m'a été fait miséricorde, c'est pour qu'en moi, le premier, Jésus Christ manifestât toute sa patience, faisant de moi un exemple pour ceux qui doivent croire en lui en vue de la vie éternelle. 
###### 17
Au Roi des siècles, Dieu incorruptible, invisible, unique, honneur et gloire dans les siècles des siècles ! Amen. 
###### 18
Tel est l'avertissement que je t'adresse, Timothée, mon enfant, en accord avec les prophéties jadis prononcées sur toi, afin que, pénétré de celles-ci, tu combattes le bon combat, 
###### 19
possédant foi et bonne conscience ; pour s'en être affranchis, certains ont fait naufrage dans la foi ; 
###### 20
entre autres, Hyménée et Alexandre, que j'ai livrés à Satan pour leur apprendre à ne plus blasphémer. 
