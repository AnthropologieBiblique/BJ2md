---
aliases : 
- 2 Jean 1
- 2 Jean 1
- 2 Jn 1
- 2 John 1
tags : 
- Bible/2Jn/1
- français
cssclass : français
---

# 2 Jean 1

###### 
Moi, l'Ancien, à la Dame élue et à ses enfants, que j'aime en vérité - non pas moi seulement mais tous ceux qui ont connu la Vérité - 
###### 
en raison de la vérité qui demeure en nous et restera avec nous éternellement. 
###### 
Avec nous seront grâce, miséricorde, paix, de la part de Dieu le Père et de la part de Jésus Christ, le Fils du Père, en vérité et amour. 
###### 
Je me suis beaucoup réjoui d'avoir rencontré de tes enfants qui vivent dans la vérité, selon le commandement que nous avons reçu du Père. 
###### 
Et maintenant, Dame, bien que ce ne soit pas un commandement nouveau que je t'écris mais celui que nous possédons depuis le début, je te le demande, aimons-nous les uns les autres. 
###### 
L'amour consiste à vivre selon ses commandements. Et le premier commandement, ainsi que vous l'avez appris dès le début, c'est que vous viviez dans l'amour. 
###### 
C'est que beaucoup de séducteurs se sont répandus dans le monde, qui ne confessent pas Jésus Christ venu dans la chair. Voilà bien le Séducteur, l'Antichrist. 
###### 
Ayez les yeux sur vous, pour ne pas perdre le fruit de nos travaux, mais recevoir au contraire une pleine récompense. 
###### 
Quiconque va plus avant et ne demeure pas dans la doctrine du Christ ne possède pas Dieu. Celui qui demeure dans la doctrine, c'est lui qui possède et le Père et le Fils. 
###### 
Si quelqu'un vient à vous sans apporter cette doctrine, ne le recevez pas chez vous et abstenez-vous de le saluer. 
###### 
Celui qui le salue participe à ses œuvres mauvaises. 
###### 
Ayant beaucoup de choses à vous écrire, j'ai préféré ne pas le faire avec du papier et de l'encre. Mais j'espère vous rejoindre et vous parler de vive voix, afin que notre joie soit parfaite. 
###### 
Les enfants de ta sœur Élue te saluent. 
