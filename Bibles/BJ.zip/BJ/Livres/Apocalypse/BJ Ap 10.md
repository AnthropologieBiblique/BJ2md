---
aliases : 
- Apocalypse 10
- Apocalypse 10
- Ap 10
- Revelation 10
tags : 
- Bible/Ap/10
- français
cssclass : français
---

# Apocalypse 10

###### 1
Je vis ensuite un autre Ange puissant, descendre du ciel enveloppé d'une nuée, un arc-en-ciel au-dessus de la tête, le visage comme le soleil et les jambes comme des colonnes de feu. 
###### 2
Il tenait en sa main un petit livre ouvert. Il posa le pied droit sur la mer, le gauche sur la terre, 
###### 3
et il poussa une puissante clameur pareille au rugissement du lion. Après quoi, les sept tonnerres firent retentir leurs voix. 
###### 4
Quand les sept tonnerres eurent parlé, j'allais écrire mais j'entendis du ciel une voix me dire : " Tiens secrètes les paroles des sept tonnerres et ne les écris pas. " 
###### 5
Alors l'Ange que j'avais vu, debout sur la mer et la terre, leva la main droite au ciel 
###### 6
et jura par Celui qui vit dans les siècles des siècles, qui créa le ciel et tout ce qu'il contient, la terre et tout ce qu'elle contient, la mer et tout ce qu'elle contient : " Plus de délai ! 
###### 7
Mais aux jours où l'on entendra le septième Ange, quand il sonnera de la trompette, alors sera consommé le mystère de Dieu, selon la bonne nouvelle qu'il en a donnée à ses serviteurs les prophètes. " 
###### 8
Puis la voix du ciel, que j'avais entendue, me parla de nouveau : " Va prendre le petit livre ouvert dans la main de l'Ange debout sur la mer et sur la terre. " 
###### 9
Je m'en fus alors prier l'Ange de me donner le petit livre ; et lui me dit : " Tiens, mange-le ; il te remplira les entrailles d'amertume, mais en ta bouche il aura la douceur du miel. " 
###### 10
Je pris le petit livre de la main de l'Ange et l'avalai ; dans ma bouche, il avait la douceur du miel, mais quand je l'eus mangé, il remplit mes entrailles d'amertume. 
###### 11
Alors on me dit : " Il te faut de nouveau prophétiser contre une foule de peuples, de nations, de langues et de rois. " 
