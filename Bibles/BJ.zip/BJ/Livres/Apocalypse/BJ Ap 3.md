---
aliases : 
- Apocalypse 3
- Apocalypse 3
- Ap 3
- Revelation 3
tags : 
- Bible/Ap/3
- français
cssclass : français
---

# Apocalypse 3

###### 1
" A l'Ange de l'Église de Sardes, écris : Ainsi parle celui qui possède les sept Esprits de Dieu et les sept étoiles. Je connais ta conduite ; tu passes pour vivant, mais tu es mort. 
###### 2
Réveille-toi, ranime ce qui te reste de vie défaillante ! Non, je n'ai pas trouvé ta vie bien pleine aux yeux de mon Dieu. 
###### 3
Allons ! rappelle-toi comment tu accueillis la parole ; garde-la et repens-toi. Car si tu ne veilles pas, je viendrai comme un voleur sans que tu saches à quelle heure je te surprendrai. 
###### 4
A Sardes, néanmoins, quelques-uns des tiens n'ont pas souillé leurs vêtements ; ils m'accompagneront, en blanc, car ils en sont dignes. 
###### 5
Le vainqueur sera donc revêtu de blanc ; et son nom, je ne l'effacerai pas du livre de vie, mais j'en répondrai devant mon Père et devant ses Anges. 
###### 6
Celui qui a des oreilles, qu'il entende ce que l'Esprit dit aux Églises. 
###### 7
" A l'Ange de l'Église de Philadelphie, écris : Ainsi parle le Saint, le Vrai, celui qui détient la clef de David : s'il ouvre, nul ne fermera, et s'il ferme, nul n'ouvrira. 
###### 8
Je connais ta conduite : voici, j'ai ouvert devant toi une porte que nul ne peut fermer, et, disposant pourtant de peu de puissance, tu as gardé ma parole sans renier mon nom. 
###### 9
Voici, je forcerai ceux de la synagogue de Satan - ils usurpent la qualité de Juifs, les menteurs -, oui, je les forcerai à venir se prosterner devant tes pieds, à reconnaître que je t'ai aimé. 
###### 10
Puisque tu as gardé ma consigne de constance, à mon tour je te garderai de l'heure de l'épreuve qui va fondre sur le monde entier pour éprouver les habitants de la terre. 
###### 11
Mon retour est proche : tiens ferme ce que tu as, pour que nul ne ravisse ta couronne. 
###### 12
Le vainqueur, je le ferai colonne dans le temple de mon Dieu : il n'en sortira plus jamais et je graverai sur lui le nom de mon Dieu, et le nom de la Cité de mon Dieu, la nouvelle Jérusalem qui descend du Ciel, de chez mon Dieu, et le nom nouveau que je porte. 
###### 13
Celui qui a des oreilles, qu'il entende ce que l'Esprit dit aux Églises. 
###### 14
" A l'Ange de l'Église de Laodicée, écris : Ainsi parle l'Amen, le Témoin fidèle et vrai, le Principe de la création de Dieu. 
###### 15
Je connais ta conduite : tu n'es ni froid ni chaud - que n'es-tu l'un ou l'autre ! - 
###### 16
ainsi, puisque te voilà tiède, ni chaud ni froid, je vais te vomir de ma bouche. 
###### 17
Tu t'imagines : me voilà riche, je me suis enrichi et je n'ai besoin de rien ; mais tu ne le vois donc pas : c'est toi qui es malheureux, pitoyable, pauvre, aveugle et nu ! 
###### 18
Aussi, suis donc mon conseil : achète chez moi de l'or purifié au feu pour t'enrichir ; des habits blancs pour t'en revêtir et cacher la honte de ta nudité ; un collyre enfin pour t'en oindre les yeux et recouvrer la vue. 
###### 19
Ceux que j'aime, je les semonce et les corrige. Allons ! Un peu d'ardeur, et repens-toi ! 
###### 20
Voici, je me tiens à la porte et je frappe ; si quelqu'un entend ma voix et ouvre la porte, j'entrerai chez lui pour souper, moi près de lui et lui près de moi. 
###### 21
Le vainqueur, je lui donnerai de siéger avec moi sur mon trône, comme moi-même, après ma victoire, j'ai siégé avec mon Père sur son trône. 
###### 22
Celui qui a des oreilles, qu'il entende ce que l'Esprit dit aux Églises. " Dieu remet à l'Agneau les destinées du monde. 
