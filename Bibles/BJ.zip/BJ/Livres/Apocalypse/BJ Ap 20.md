---
aliases : 
- Apocalypse 20
- Apocalypse 20
- Ap 20
- Revelation 20
tags : 
- Bible/Ap/20
- français
cssclass : français
---

# Apocalypse 20

###### 1
Puis je vis un Ange descendre du ciel, ayant en main la clef de l'Abîme, ainsi qu'une énorme chaîne. 
###### 2
Il maîtrisa le Dragon, l'antique Serpent - c'est le Diable, Satan - et l'enchaîna pour mille années. 
###### 3
Il le jeta dans l'Abîme, tira sur lui les verrous, apposa des scellés, afin qu'il cessât de fourvoyer les nations jusqu'à l'achèvement des mille années. Après quoi, il doit être relâché pour un peu de temps. 
###### 4
Puis je vis des trônes sur lesquels ils s'assirent, et on leur remit le jugement ; et aussi les âmes de ceux qui furent décapités pour le témoignage de Jésus et la Parole de Dieu, et tous ceux qui refusèrent d'adorer la Bête et son image, de se faire marquer sur le front ou sur la main ; ils reprirent vie et régnèrent avec le Christ mille années. 
###### 5
Les autres morts ne purent reprendre vie avant l'achèvement des mille années. C'est la première résurrection. 
###### 6
Heureux et saint celui qui participe à la première résurrection ! La seconde mort n'a pas pouvoir sur eux, mais ils seront prêtres de Dieu et du Christ avec qui ils régneront mille années. 
###### 7
Les mille ans écoulés, Satan, relâché de sa prison, 
###### 8
s'en ira séduire les nations des quatre coins de la terre, Gog et Magog, et les rassembler pour la guerre, aussi nombreux que le sable de la mer ; 
###### 9
ils montèrent sur toute l'étendue du pays, puis ils investirent le camp des saints, la Cité bien-aimée. Mais un feu descendit du ciel et les dévora. 
###### 10
Alors, le diable, leur séducteur, fut jeté dans l'étang de feu et de soufre, y rejoignant la Bête et le faux prophète, et leur supplice durera jour et nuit, pour les siècles des siècles. 
###### 11
Puis je vis un trône blanc, très grand, et Celui qui siège dessus. Le ciel et la terre s'enfuirent de devant sa face sans laisser de traces. 
###### 12
Et je vis les morts, grands et petits, debout devant le trône ; on ouvrit des livres, puis un autre livre, celui de la vie ; alors, les morts furent jugés d'après le contenu des livres, chacun selon ses œuvres. 
###### 13
Et la mer rendit les morts qu'elle gardait, la Mort et l'Hadès rendirent les morts qu'ils gardaient, et chacun fut jugé selon ses œuvres. 
###### 14
Alors la Mort et l'Hadès furent jetés dans l'étang de feu - c'est la seconde mort cet étang de feu - 
###### 15
et celui qui ne se trouva pas inscrit dans le livre de vie, on le jeta dans l'étang de feu. 
