---
aliases : 
- Apocalypse 13
- Apocalypse 13
- Ap 13
- Revelation 13
tags : 
- Bible/Ap/13
- français
cssclass : français
---

# Apocalypse 13

###### 1
Alors je vis surgir de la mer une Bête ayant sept têtes et dix cornes, sur ses cornes dix diadèmes, et sur ses têtes des titres blasphématoires. 
###### 2
La Bête que je vis ressemblait à une panthère, avec les pattes comme celles d'un ours et la gueule comme une gueule de lion ; et le Dragon lui transmit sa puissance et son trône et un pouvoir immense. 
###### 3
L'une de ses têtes paraissait blessée à mort, mais sa plaie mortelle fut guérie ; alors émerveillée, la terre entière suivit la Bête. 
###### 4
On se prosterna devant le Dragon, parce qu'il avait remis le pouvoir à la Bête ; et l'on se prosterna devant la Bête en disant : " Qui égale la Bête, et qui peut lutter contre elle ? " 
###### 5
On lui donna de proférer des paroles d'orgueil et de blasphème ; on lui donna pouvoir d'agir durant quarante-deux mois ; 
###### 6
alors elle se mit à proférer des blasphèmes contre Dieu, à blasphémer son nom et sa demeure, ceux qui demeurent au ciel. 
###### 7
On lui donna de mener campagne contre les saints et de les vaincre ; on lui donna pouvoir sur toute race, peuple, langue ou nation. 
###### 8
Et ils l'adoreront, tous les habitants de la terre dont le nom ne se trouve pas écrit, dès l'origine du monde, dans le livre de vie de l'Agneau égorgé. 
###### 9
Celui qui a des oreilles, qu'il entende ! 
###### 10
Les chaînes pour qui doit être enchaîné ; la mort par le glaive pour qui doit périr par le glaive ! Voilà qui fonde l'endurance et la confiance des saints. 
###### 11
Je vis ensuite surgir de la terre une autre Bête ; elle avait deux cornes comme un agneau, mais parlait comme un dragon. 
###### 12
Au service de la première Bête, elle en établit partout le pouvoir, amenant la terre et ses habitants à adorer cette première Bête dont la plaie mortelle fut guérie. 
###### 13
Elle accomplit des prodiges étonnants : jusqu'à faire descendre, aux yeux de tous, le feu du ciel sur la terre ; 
###### 14
et, par les prodiges qu'il lui a été donné d'accomplir au service de la Bête, elle fourvoie les habitants de la terre, leur disant de dresser une image en l'honneur de cette Bête qui, frappée du glaive, a repris vie. 
###### 15
On lui donna même d'animer l'image de la Bête pour la faire parler, et de faire en sorte que fussent mis à mort tous ceux qui n'adoreraient pas l'image de la Bête. 
###### 16
Par ses manœuvres, tous, petits et grands, riches ou pauvres, libres et esclaves, se feront marquer sur la main droite ou sur le front, 
###### 17
et nul ne pourra rien acheter ni vendre s'il n'est marqué au nom de la Bête ou au chiffre de son nom. 
###### 18
C'est ici qu'il faut de la finesse ! Que l'homme doué d'esprit calcule le chiffre de la Bête, c'est un chiffre d'homme : son chiffre, c'est 666
