---
aliases : 
- Apocalypse 1
- Apocalypse 1
- Ap 1
- Revelation 1
tags : 
- Bible/Ap/1
- français
cssclass : français
---

# Apocalypse 1

###### 1
Révélation de Jésus Christ : Dieu la lui donna pour montrer à ses serviteurs ce qui doit arriver bientôt ; Il envoya son Ange pour la faire connaître à Jean son serviteur, 
###### 2
lequel a attesté la Parole de Dieu et le témoignage de Jésus Christ : toutes ses visions. 
###### 3
Heureux le lecteur et les auditeurs de ces paroles prophétiques s'ils en retiennent le contenu, car le Temps est proche ! 
###### 4
Jean, aux sept Églises d'Asie. Grâce et paix vous soient données par " Il est, Il était et Il vient ", par les sept Esprits présents devant son trône, 
###### 5
et par Jésus Christ, le témoin fidèle, le Premier-né d'entre les morts, le Prince des rois de la terre. Il nous aime et nous a lavés de nos péchés par son sang, 
###### 6
il a fait de nous une Royauté de Prêtres, pour son Dieu et Père ; à lui donc la gloire et la puissance pour les siècles des siècles. Amen. 
###### 7
Voici, il vient avec les nuées ; chacun le verra, même ceux qui l'ont transpercé, et sur lui se lamenteront toutes les races de la terre. Oui, Amen ! 
###### 8
Je suis l'Alpha et l'Oméga, dit le Seigneur Dieu, " Il est, Il était et Il vient ", le Maître-de-tout. 
###### 9
Moi, Jean, votre frère et votre compagnon dans l'épreuve, la royauté et la constance, en Jésus. Je me trouvais dans l'île de Patmos, à cause de la Parole de Dieu et du témoignage de Jésus. 
###### 10
Je tombai en extase, le jour du Seigneur, et j'entendis derrière moi une voix clamer, comme une trompette : 
###### 11
" Ce que tu vois, écris-le dans un livre pour l'envoyer aux sept Églises : à Éphèse, Smyrne, Pergame, Thyatire, Sardes, Philadelphie et Laodicée. " 
###### 12
Je me retournai pour regarder la voix qui me parlait ; et m'étant retourné, je vis sept candélabres d'or, 
###### 13
et, au milieu des candélabres, comme un Fils d'homme revêtu d'une longue robe serrée à la taille par une ceinture en or. 
###### 14
Sa tête, avec ses cheveux blancs, est comme de la laine blanche, comme de la neige, ses yeux comme une flamme ardente, 
###### 15
ses pieds pareils à de l'airain précieux que l'on aurait purifié au creuset, sa voix comme la voix des grandes eaux. 
###### 16
Dans sa main droite il a sept étoiles, et de sa bouche sort une épée acérée, à double tranchant ; et son visage, c'est comme le soleil qui brille dans tout son éclat. 
###### 17
A sa vue, je tombai à ses pieds, comme mort ; mais il posa sur moi sa main droite en disant : " Ne crains pas, je suis le Premier et le Dernier, 
###### 18
le Vivant ; je fus mort, et me voici vivant pour les siècles des siècles, détenant la clef de la Mort et de l'Hadès. 
###### 19
Écris donc ce que tu as vu : le présent et ce qui doit arriver plus tard. 
###### 20
Quant au mystère des sept étoiles que tu as vues dans ma main droite et des sept candélabres d'or, le voici : les sept étoiles sont les Anges des sept Églises ; et les sept candélabres sont les sept Églises. 
