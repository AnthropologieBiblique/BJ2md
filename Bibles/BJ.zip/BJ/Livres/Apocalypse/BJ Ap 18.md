---
aliases : 
- Apocalypse 18
- Apocalypse 18
- Ap 18
- Revelation 18
tags : 
- Bible/Ap/18
- français
cssclass : français
---

# Apocalypse 18

###### 1
Après quoi, je vis descendre du ciel un autre Ange, ayant un grand pouvoir, et la terre fut illuminée de sa splendeur. 
###### 2
Il s'écria d'une voix puissante : " Elle est tombée, elle est tombée, Babylone la Grande ; elle s'est changée en demeure de démons, en repaire pour toutes sortes d'esprits impurs, en repaire pour toutes sortes d'oiseaux impurs et dégoûtants. 
###### 3
Car au vin de ses prostitutions se sont abreuvées toutes les nations, et les rois de la terre ont forniqué avec elle, et les trafiquants de la terre se sont enrichis de son luxe effréné. " 
###### 4
Puis j'entendis une autre voix qui disait, du ciel : " Sortez, ô mon peuple, quittez-la, de peur que, solidaires de ses fautes, vous n'ayez à pâtir de ses plaies ! 
###### 5
Car ses péchés se sont amoncelés jusqu'au ciel, et Dieu s'est souvenu de ses iniquités. 
###### 6
Payez-la de sa propre monnaie ! Rendez-lui au double de ses forfaits ! Dans la coupe de ses mixtures, mélangez une double dose ! 
###### 7
A la mesure de son faste et de son luxe, donnez-lui tourments et malheurs ! Je trône en reine, se dit-elle, et je ne suis pas veuve, et jamais je ne verrai le deuil... 
###### 8
Voilà pourquoi, en un seul jour, des plaies vont fondre sur elle : peste, deuil et famine ; elle sera consumée par le feu. Car il est puissant, le Seigneur Dieu qui l'a condamnée. " 
###### 9
Ils pleureront, ils se lamenteront sur elle, les rois de la terre, les compagnons de sa vie lascive et fastueuse, quand ils verront la fumée de ses flammes, 
###### 10
retenus à distance par peur de son supplice : " Hélas, hélas ! Immense cité, ô Babylone, cité puissante, car une heure a suffi pour que tu sois jugée ! " 
###### 11
Ils pleurent et se désolent sur elle, les trafiquants de la terre ; les cargaisons de leurs navires, nul désormais ne les achète! 
###### 12
Cargaisons d'or et d'argent, de pierres précieuses et de perles, de lin et de pourpre, de soie et d'écarlate ; et les bois de thuya, et les objets d'ivoire, et les objets de bois précieux, de bronze, de fer ou de marbre ; 
###### 13
le cinnamome, l'amome et les parfums, la myrrhe et l'encens, le vin et l'huile, la farine et le blé, les bestiaux et les moutons, les chevaux et les chars, les esclaves et la marchandise humaine... 
###### 14
Et les fruits mûrs, que convoitait ton âme, s'en sont allés, loin de toi ; et tout le luxe et la splendeur, c'est à jamais fini pour toi, sans retour ! 
###### 15
Les trafiquants qu'elle enrichit de ce commerce se tiendront à distance, par peur de son supplice, pleurant et gémissant : 
###### 16
" Hélas, hélas ! Immense cité, vêtue de lin, de pourpre et d'écarlate, parée d'or, de pierres précieuses et de perles, 
###### 17
car une heure a suffi pour ruiner tout ce luxe ! " Capitaines et gens qui font le cabotage, matelots et tous ceux qui vivent de la mer, se tinrent à distance 
###### 18
et criaient, regardant la fumée de ses flammes : " Qui donc était semblable à l'immense cité ? " 
###### 19
Et jetant la poussière sur leur tête, ils s'écriaient, pleurant et gémissant : " Hélas, hélas ! Immense cité, dont la vie luxueuse enrichissait tous les patrons des navires de mer, car une heure a suffi pour consommer sa ruine ! " 
###### 20
O ciel, sois dans l'allégresse sur elle, et vous, saints, apôtres et prophètes, car Dieu, en la condamnant, a jugé votre cause. 
###### 21
Un Ange puissant prit alors une pierre, comme une grosse meule, et la jeta dans la mer en disant : " Ainsi, d'un coup, on jettera Babylone, la grande cité, on ne la verra jamais plus... " 
###### 22
Le chant des harpistes et des trouvères et des joueurs de flûte ou de trompette chez toi ne s'entendra jamais plus ; les artisans de tout métier chez toi ne se verront jamais plus ; et la voix de la meule chez toi ne s'entendra jamais plus ; 
###### 23
la lumière de la lampe chez toi ne brillera jamais plus ; la voix du jeune époux et de l'épousée chez toi ne s'entendra jamais plus. Car tes marchands étaient les princes de la terre, et tes sortilèges ont fourvoyé tous les peuples ; 
###### 24
et c'est en elle que l'on a vu le sang des prophètes et des saints, et de tous ceux qui furent égorgés sur la terre. 
