---
aliases : 
- Apocalypse 6
- Apocalypse 6
- Ap 6
- Revelation 6
tags : 
- Bible/Ap/6
- français
cssclass : français
---

# Apocalypse 6

###### 1
Et ma vision se poursuivit. Lorsque l'agneau ouvrit le premier des sept sceaux, j'entendis le premier des quatre Vivants crier comme d'une voix de tonnerre : " Viens ! " 
###### 2
Et voici qu'apparut à mes yeux un cheval blanc ; celui qui le montait tenait un arc ; on lui donna une couronne et il partit en vainqueur, et pour vaincre encore. 
###### 3
Lorsqu'il ouvrit le deuxième sceau, j'entendis le deuxième Vivant crier : " Viens ! " 
###### 4
Alors surgit un autre cheval, rouge feu ; celui qui le montait, on lui donna de bannir la paix hors de la terre, et de faire que l'on s'entr'égorgeât ; on lui donna une grande épée. 
###### 5
Lorsqu'il ouvrit le troisième sceau, j'entendis le troisième Vivant crier : " Viens ! " Et voici qu'apparut à mes yeux un cheval noir ; celui qui le montait tenait à la main une balance, 
###### 6
et j'entendis comme une voix, du milieu des quatre Vivants, qui disait : " Un litre de blé pour un denier, trois litres d'orge pour un denier ! Quant à l'huile et au vin, ne les gâche pas ! " 
###### 7
Lorsqu'il ouvrit le quatrième sceau, j'entendis le cri du quatrième Vivant : " Viens ! " 
###### 8
Et voici qu'apparut à mes yeux un cheval verdâtre ; celui qui le montait, on le nomme : la Mort ; et l'Hadès le suivait. Alors, on leur donna pouvoir sur le quart de la terre, pour exterminer par l'épée, par la faim, par la peste, et par les fauves de la terre. 
###### 9
Lorsqu'il ouvrit le cinquième sceau, je vis sous l'autel les âmes de ceux qui furent égorgés pour la Parole de Dieu et le témoignage qu'ils avaient rendu. 
###### 10
Ils crièrent d'une voix puissante : " Jusques à quand, Maître saint et vrai, tarderas-tu à faire justice, à tirer vengeance de notre sang sur les habitants de la terre ? " 
###### 11
Alors on leur donna à chacun une robe blanche en leur disant de patienter encore un peu, le temps que fussent au complet leurs compagnons de service et leurs frères qui doivent être mis à mort comme eux. 
###### 12
Et ma vision se poursuivit. Lorsqu'il ouvrit le sixième sceau, alors il se fit un violent tremblement de terre, et le soleil devint noir comme une étoffe de crin, et la lune devint tout entière comme du sang, 
###### 13
et les astres du ciel s'abattirent sur la terre comme les figures avortées que projette un figuier tordu par la tempête, 
###### 14
et le ciel disparut comme un livre qu'on roule, et les monts et les îles s'arrachèrent de leur place ; 
###### 15
et les rois de la terre, et les hauts personnages, et les grands capitaines, et les gens enrichis, et les gens influents, et tous enfin, esclaves ou libres, ils allèrent se terrer dans les cavernes et parmi les rochers des montagnes, 
###### 16
disant aux montagnes et aux rochers : " Croulez sur nous et cachez-nous loin de Celui qui siège sur le trône et loin de la colère de l'Agneau. " 
###### 17
Car il est arrivé, le grand Jour de sa colère, et qui donc peut tenir ? 
