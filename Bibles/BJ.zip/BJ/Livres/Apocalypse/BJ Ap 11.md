---
aliases : 
- Apocalypse 11
- Apocalypse 11
- Ap 11
- Revelation 11
tags : 
- Bible/Ap/11
- français
cssclass : français
---

# Apocalypse 11

###### 1
Puis on me donna un roseau, une sorte de baguette, en me disant : " Lève-toi pour mesurer le Temple de Dieu, l'autel et les adorateurs qui s'y trouvent ; 
###### 2
quant au parvis extérieur du Temple, laisse-le, ne le mesure pas, car on l'a donné aux païens : ils fouleront la Ville Sainte durant quarante-deux mois. 
###### 3
Mais je donnerai à mes deux témoins de prophétiser pendant mille deux cent soixante jours, revêtus de sacs. " 
###### 4
Ce sont les deux oliviers et les deux flambeaux qui se tiennent devant le Maître de la terre. 
###### 5
Si l'on s'avisait de les malmener, un feu jaillirait de leur bouche pour dévorer leurs ennemis ; oui, qui s'aviserait de les malmener, c'est ainsi qu'il lui faudrait périr. 
###### 6
Ils ont pouvoir de clore le ciel afin que nulle pluie ne tombe durant le temps de leur mission ; ils ont aussi pouvoir sur les eaux, de les changer en sang, et pouvoir de frapper la terre de mille fléaux, aussi souvent qu'ils le voudront. 
###### 7
Mais quand ils auront fini de rendre témoignage, la Bête qui surgit de l'Abîme viendra guerroyer contre eux, les vaincre et les tuer. 
###### 8
Et leurs cadavres, sur la place de la Grande Cité, Sodome ou Égypte comme on l'appelle symboliquement, là où leur Seigneur aussi fut crucifié, 
###### 9
leurs cadavres demeurent exposés aux regards des peuples, des races, des langues et des nations, durant trois jours et demi, sans qu'il soit permis de les mettre au tombeau. 
###### 10
Les habitants de la terre s'en réjouissent et s'en félicitent ; ils échangent des présents, car ces deux prophètes leur avaient causé bien des tourments. 
###### 11
Mais, passé les trois jours et demi, Dieu leur infusa un souffle de vie qui les remit sur pieds, au grand effroi de ceux qui les regardaient. 
###### 12
J'entendis alors une voix puissante leur crier du ciel : " Montez ici ! " Ils montèrent donc au ciel dans la nuée, aux yeux de leurs ennemis. 
###### 13
A cette heure-là, il se fit un violent tremblement de terre, et le dixième de la ville croula, et dans le cataclysme périrent sept mille personnes. Les survivants, saisis d'effroi, rendirent gloire au Dieu du ciel. 
###### 14
Le deuxième " Malheur " a passé, voici que le troisième accourt ! 
###### 15
Et le septième Ange sonna... Alors, au ciel, des voix clamèrent : " La royauté du monde est acquise à notre Seigneur ainsi qu'à son Christ ; il régnera dans les siècles des siècles. " 
###### 16
Et les vingt-quatre Vieillards qui sont assis devant Dieu, sur leurs sièges, se prosternèrent pour adorer Dieu en disant : 
###### 17
" Nous te rendons grâce, Seigneur, Dieu Maître-de-tout, "Il est et Il était", parce que tu as pris en main ton immense puissance pour établir ton règne. 
###### 18
Les nations s'étaient mises en fureur ; mais voici ta fureur à toi, et le temps pour les morts d'être jugés ; le temps de récompenser tes serviteurs les prophètes, les saints, et ceux qui craignent ton nom, petits et grands, et de perdre ceux qui perdent la terre. " 
###### 19
Alors s'ouvrit le temple de Dieu, dans le ciel et son arche d'alliance apparut, dans le temple ; puis ce furent des éclairs et des voix et des tonnerres et un tremblement de terre, et la grêle tombait dru... 
