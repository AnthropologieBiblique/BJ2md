---
aliases : 
- Apocalypse 4
- Apocalypse 4
- Ap 4
- Revelation 4
tags : 
- Bible/Ap/4
- français
cssclass : français
---

# Apocalypse 4

###### 1
J'eus ensuite une vision. Voici, une porte était ouverte au ciel, et la voix que j'avais naguère entendue me parler comme une trompette me dit : Monte ici, que je te montre ce qui doit arriver par la suite. 
###### 2
A l'instant, je tombai en extase. Voici, un trône était dressé dans le ciel, et, siégeant sur le trône, Quelqu'un... 
###### 3
Celui qui siège est comme une vision de jaspe et de cornaline ; un arc-en-ciel autour du trône est comme une vision d'émeraude. 
###### 4
Vingt-quatre sièges entourent le trône, sur lesquels sont assis vingt-quatre Vieillards vêtus de blanc, avec des couronnes d'or sur leurs têtes. 
###### 5
Du trône partent des éclairs, des voix et des tonnerres, et sept lampes de feu brûlent devant lui, les sept Esprits de Dieu. 
###### 6
Devant le trône, on dirait une mer, transparente autant que du cristal. Au milieu du trône et autour de lui, se tiennent quatre Vivants, constellés d'yeux par-devant et par-derrière. 
###### 7
Le premier Vivant est comme un lion ; le deuxième Vivant est comme un jeune taureau ; le troisième Vivant a comme un visage d'homme ; le quatrième Vivant est comme un aigle en plein vol. 
###### 8
Les quatre Vivants, portant chacun six ailes, sont constellés d'yeux tout autour et en dedans. Ils ne cessent de répéter jour et nuit : " Saint, Saint, Saint, Seigneur, Dieu Maître-de-tout, "Il était, Il est et Il vient". " 
###### 9
Et chaque fois que les Vivants offrent gloire, honneur et action de grâces à Celui qui siège sur le trône et qui vit dans les siècles des siècles, 
###### 10
les vingt-quatre Vieillards se prosternent devant Celui qui siège sur le trône pour adorer Celui qui vit dans les siècles des siècles ; ils lancent leurs couronnes devant le trône en disant : 
###### 11
" Tu es digne, ô notre Seigneur et notre Dieu, de recevoir la gloire, l'honneur et la puissance, car c'est toi qui créas l'univers ; par ta volonté, il n'était pas et fut créé. " 
