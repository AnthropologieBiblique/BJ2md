---
aliases : 
- Apocalypse 12
- Apocalypse 12
- Ap 12
- Revelation 12
tags : 
- Bible/Ap/12
- français
cssclass : français
---

# Apocalypse 12

###### 1
Un signe grandiose apparut au ciel : une Femme ! le soleil l'enveloppe, la lune est sous ses pieds et douze étoiles couronnent sa tête ; 
###### 2
elle est enceinte et crie dans les douleurs et le travail de l'enfantement. 
###### 3
Puis un second signe apparut au ciel : un énorme Dragon rouge feu, à sept têtes et dix cornes, chaque tête surmontée d'un diadème. 
###### 4
Sa queue balaie le tiers des étoiles du ciel et les précipite sur la terre. En arrêt devant la Femme en travail, le Dragon s'apprête à dévorer son enfant aussitôt né. 
###### 5
Or la Femme mit au monde un enfant mâle, celui qui doit mener toutes les nations avec un sceptre de fer ; et son enfant fut enlevé jusqu'auprès de Dieu et de son trône, 
###### 6
tandis que la Femme s'enfuyait au désert, où Dieu lui a ménagé un refuge pour qu'elle y soit nourrie mille deux cent soixante jours. 
###### 7
Alors, il y eut une bataille dans le ciel : Michel et ses Anges combattirent le Dragon. Et le Dragon riposta, avec ses Anges, 
###### 8
mais ils eurent le dessous et furent chassés du ciel. 
###### 9
On le jeta donc, l'énorme Dragon, l'antique Serpent, le Diable ou le Satan, comme on l'appelle, le séducteur du monde entier, on le jeta sur la terre et ses Anges furent jetés avec lui. 
###### 10
Et j'entendis une voix clamer dans le ciel : " Désormais, la victoire, la puissance et la royauté sont acquises à notre Dieu, et la domination à son Christ, puisqu'on a jeté bas l'accusateur de nos frères, celui qui les accusait jour et nuit devant notre Dieu. 
###### 11
Mais eux l'ont vaincu par le sang de l'Agneau et par la parole dont ils ont témoigné, car ils ont méprisé leur vie jusqu'à mourir. 
###### 12
Soyez donc dans la joie, vous, les cieux et leurs habitants. Malheur à vous, la terre et la mer, car le Diable est descendu chez vous, frémissant de colère et sachant que ses jours sont comptés. " 
###### 13
Se voyant rejeté sur la terre, le Dragon se lança à la poursuite de la Femme, la mère de l'Enfant mâle. 
###### 14
Mais elle reçut les deux ailes du grand aigle pour voler au désert jusqu'au refuge où, loin du Serpent, elle doit être nourrie un temps et des temps et la moitié d'un temps. 
###### 15
Le Serpent vomit alors de sa gueule comme un fleuve d'eau derrière la Femme pour l'entraîner dans ses flots. 
###### 16
Mais la terre vint au secours de la Femme : ouvrant la bouche, elle engloutit le fleuve vomi par la gueule du Dragon. 
###### 17
Alors, furieux contre la Femme, le Dragon s'en alla guerroyer contre le reste de ses enfants, ceux qui gardent les commandements de Dieu et possèdent le témoignage de Jésus. 
###### 18
Et je me tins sur la grève de la mer. 
