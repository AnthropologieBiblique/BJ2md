---
aliases : 
- Apocalypse 22
- Apocalypse 22
- Ap 22
- Revelation 22
tags : 
- Bible/Ap/22
- français
cssclass : français
---

# Apocalypse 22

###### 1
Puis l'Ange me montra le fleuve de Vie, limpide comme du cristal, qui jaillissait du trône de Dieu et de l'Agneau. 
###### 2
Au milieu de la place de part et d'autre du fleuve, il y a des arbres de Vie qui fructifient douze fois, une fois chaque mois ; et leurs feuilles peuvent guérir les païens. 
###### 3
De malédiction, il n'y en aura plus ; le trône de Dieu et de l'Agneau sera dressé dans la ville, et les serviteurs de Dieu l'adoreront ; 
###### 4
ils verront sa face, et son nom sera sur leurs fronts. 
###### 5
De nuit, il n'y en aura plus ; ils se passeront de lampe ou de soleil pour s'éclairer, car le Seigneur Dieu répandra sur eux sa lumière, et ils régneront pour les siècles des siècles. 
###### 6
Puis il me dit : " Ces paroles sont certaines et vraies ; le Seigneur Dieu, qui inspire les prophètes, a envoyé son Ange pour montrer à ses serviteurs ce qui doit arriver bientôt. 
###### 7
Voici que mon retour est proche ! Heureux celui qui garde les paroles prophétiques de ce livre. " 
###### 8
C'est moi, Jean, qui voyais et entendais tout cela ; une fois les paroles et les visions achevées, je tombai aux pieds de l'Ange qui m'avait tout montré, pour l'adorer. 
###### 9
Mais lui me dit : " Non, attention, je suis un serviteur comme toi et tes frères les prophètes et ceux qui gardent les paroles de ce livre ; c'est Dieu qu'il faut adorer. " 
###### 10
Il me dit encore : " Ne tiens pas secrètes les paroles prophétiques de ce livre, car le Temps est proche. 
###### 11
Que le pécheur pèche encore, et que l'homme souillé se souille encore ; que l'homme de bien vive encore dans le bien, et que le saint se sanctifie encore. 
###### 12
Voici que mon retour est proche, et j'apporte avec moi le salaire que je vais payer à chacun, en proportion de son travail. 
###### 13
Je suis l'Alpha et l'Oméga, le Premier et le Dernier, le Principe et la Fin. 
###### 14
Heureux ceux qui lavent leurs robes ; ils pourront disposer de l'arbre de Vie, et pénétrer dans la Cité, par les portes. 
###### 15
Dehors les chiens, les sorciers, les impurs, les assassins, les idolâtres et tous ceux qui se plaisent à faire le mal ! " 
###### 16
Moi, Jésus, j'ai envoyé mon Ange publier chez vous ces révélations concernant les Églises. Je suis le rejeton de la race de David, l'Étoile radieuse du matin. 
###### 17
L'Esprit et l'Épouse disent : " Viens ! " Que celui qui entend dise : " Viens ! " Et que l'homme assoiffé s'approche, que l'homme de désir reçoive l'eau de la vie, gratuitement. 
###### 18
Je déclare, moi, à quiconque écoute les paroles prophétiques de ce livre : " Qui oserait y faire des surcharges, Dieu le chargera de tous les fléaux décrits dans ce livre ! 
###### 19
Et qui oserait retrancher aux paroles de ce livre prophétique, Dieu retranchera son lot de l'arbre de Vie et de la Cité sainte, décrits dans ce livre ! " 
###### 20
Le garant de ces révélations l'affirme : " Oui, mon retour est proche ! " Amen, viens, Seigneur Jésus ! 
###### 21
Que la grâce du Seigneur Jésus soit avec tous ! Amen. 
