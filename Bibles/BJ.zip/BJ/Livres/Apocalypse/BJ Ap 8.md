---
aliases : 
- Apocalypse 8
- Apocalypse 8
- Ap 8
- Revelation 8
tags : 
- Bible/Ap/8
- français
cssclass : français
---

# Apocalypse 8

###### 1
Et lorsque l'Agneau ouvrit le septième sceau, il se fit un silence dans le ciel, environ une demi-heure... 
###### 2
Et je vis les sept Anges qui se tiennent devant Dieu ; on leur remit sept trompettes. 
###### 3
Un autre Ange vint alors se placer près de l'autel, muni d'une pelle en or. On lui donna beaucoup de parfums pour qu'il les offrît, avec les prières de tous les saints, sur l'autel d'or placé devant le trône. 
###### 4
Et, de la main de l'Ange, la fumée des parfums s'éleva devant Dieu, avec les prières des saints. 
###### 5
Puis l'Ange saisit la pelle et l'emplit du feu de l'autel qu'il jeta sur la terre. Ce furent alors des tonnerres, des voix et des éclairs, et tout trembla. 
###### 6
Les sept Anges aux sept trompettes s'apprêtèrent à sonner. 
###### 7
Et le premier sonna... Il y eut alors de la grêle et du feu mêlés de sang qui furent jetés sur la terre : et le tiers de la terre fut consumé, et le tiers des arbres fut consumé, et toute herbe verte fut consumée. 
###### 8
Et le deuxième Ange sonna... Alors une énorme masse embrasée, comme une montagne, fut projetée dans la mer, et le tiers de la mer devint du sang : 
###### 9
il périt ainsi le tiers des créatures vivant dans la mer, et le tiers des navires fut détruit. 
###### 10
Et le troisième Ange sonna... Alors tomba du ciel un grand astre, brûlant comme une torche. Il tomba sur le tiers des fleuves et sur les sources ; 
###### 11
l'astre se nomme " Absinthe " : le tiers des eaux se changea en absinthe, et bien des gens moururent de ces eaux devenues amères. 
###### 12
Et le quatrième Ange sonna... Alors furent frappés le tiers du soleil et le tiers de la lune et le tiers des étoiles : ils s'assombrirent d'un tiers, et le jour perdit le tiers de sa clarté, et la nuit de même. 
###### 13
Et ma vision se poursuivit. J'entendis un aigle volant au zénith et criant d'une voix puissante : " Malheur, malheur, malheur aux habitants de la terre, à cause de la voix des dernières trompettes dont les trois Anges vont sonner. 
