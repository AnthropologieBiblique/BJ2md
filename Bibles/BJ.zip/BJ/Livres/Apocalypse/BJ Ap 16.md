---
aliases : 
- Apocalypse 16
- Apocalypse 16
- Ap 16
- Revelation 16
tags : 
- Bible/Ap/16
- français
cssclass : français
---

# Apocalypse 16

###### 1
Et j'entendis une voix qui, du temple, criait aux sept Anges : " Allez, répandez sur la terre les sept coupes de la colère de Dieu. " 
###### 2
Et le premier s'en alla répandre sa coupe sur la terre ; alors, ce fut un ulcère mauvais et pernicieux sur les gens qui portaient la marque de la Bête et se prosternaient devant son image. 
###### 3
Et le deuxième répandit sa coupe dans la mer ; alors, ce fut du sang - on aurait dit un meurtre ! - et tout être vivant mourut dans la mer. 
###### 4
Et le troisième répandit sa coupe dans les fleuves et les sources ; alors, ce fut du sang. 
###### 5
Et j'entendis l'Ange des eaux qui disait : " Tu es juste, "Il est et Il était", le Saint, d'avoir ainsi châtié ; 
###### 6
c'est le sang des saints et des prophètes qu'ils ont versé, c'est donc du sang que tu leur as fait boire, ils le méritent ! " 
###### 7
Et j'entendis l'autel dire : " Oui, Seigneur, Dieu Maître-de-tout, tes châtiments sont vrais et justes. " 
###### 8
Et le quatrième répandit sa coupe sur le soleil ; alors, il lui fut donné de brûler les hommes par le feu, 
###### 9
et les hommes furent brûlés par une chaleur torride. Mais, loin de se repentir en rendant gloire à Dieu, ils blasphémèrent le nom du Dieu qui détenait en son pouvoir de tels fléaux. 
###### 10
Et le cinquième répandit sa coupe sur le trône de la Bête ; alors, son royaume devint ténèbres, et l'on se mordait la langue de douleur. 
###### 11
Mais, loin de se repentir de leurs agissements, les hommes blasphémèrent le Dieu du ciel sous le coup des douleurs et des plaies. 
###### 12
Et le sixième répandit sa coupe sur le grand fleuve Euphrate ; alors, ses eaux tarirent, livrant passage aux rois de l'Orient. 
###### 13
Puis, de la gueule du Dragon, et de la gueule de la Bête, et de la gueule du faux prophète, je vis surgir trois esprits impurs, comme des grenouilles - 
###### 14
et de fait, ce sont des esprits démoniaques, des faiseurs de prodiges, qui s'en vont rassembler les rois du monde entier pour la guerre, pour le grand Jour du Dieu Maître-de-tout. - 
###### 15
Voici que je viens comme un voleur : heureux celui qui veille et garde ses vêtements pour ne pas aller nu et laisser voir sa honte. 
###### 16
Ils les rassemblèrent au lieu dit, en hébreu, Harmagedôn. 
###### 17
Et le septième répandit sa coupe dans l'air ; alors, partant du temple, une voix clama : " C'en est fait ! " 
###### 18
Et ce furent des éclairs et des voix et des tonnerres, avec un violent tremblement de terre ; non, depuis qu'il y a des hommes sur la terre, jamais on n'avait vu pareil tremblement de terre, aussi violent ! 
###### 19
La Grande Cité se scinda en trois parties, et les cités des nations croulèrent ; et Babylone la grande, Dieu s'en souvint pour lui donner la coupe où bouillonne le vin de sa colère. 
###### 20
Alors, toute île prit la fuite, et les montagnes disparurent. 
###### 21
Et des grêlons énormes - près de quatre-vingts livres ! - s'abattirent du ciel sur les hommes. Et les hommes blasphémèrent Dieu, à cause de cette grêle désastreuse ; oui, elle est bien cause d'un effrayant désastre. 
