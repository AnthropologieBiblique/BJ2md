---
aliases : 
- Apocalypse 14
- Apocalypse 14
- Ap 14
- Revelation 14
tags : 
- Bible/Ap/14
- français
cssclass : français
---

# Apocalypse 14

###### 1
Puis voici que l'Agneau apparut à mes yeux ; il se tenait sur le mont Sion, avec cent quarante-quatre milliers de gens portant inscrits sur le front son nom et le nom de son Père. 
###### 2
Et j'entendis un bruit venant du ciel, comme le mugissement des grandes eaux ou le grondement d'un orage violent, et ce bruit me faisait songer à des joueurs de harpe touchant de leurs instruments ; 
###### 3
ils chantent un cantique nouveau devant le trône et devant les quatre Vivants et les Vieillards. Et nul ne pouvait apprendre le cantique, hormis les cent quarante-quatre milliers, les rachetés à la terre. 
###### 4
Ceux-là, ils ne se sont pas souillés avec des femmes, ils sont vierges ; ceux-là suivent l'Agneau partout où il va ; ceux-là ont été rachetés d'entre les hommes comme prémices pour Dieu et pour l'Agneau. 
###### 5
Jamais leur bouche ne connut le mensonge : ils sont immaculés. 
###### 6
Puis je vis un autre Ange qui volait au zénith, ayant une bonne nouvelle éternelle à annoncer à ceux qui demeurent sur la terre, à toute nation, race, langue et peuple. 
###### 7
Il criait d'une voix puissante : " Craignez Dieu et glorifiez-le, car voici l'heure de son Jugement ; adorez donc Celui qui a fait le ciel et la terre et la mer et les sources. " 
###### 8
Un autre Ange, un deuxième, le suivit en criant : " Elle est tombée, elle est tombée, Babylone la Grande, elle qui a abreuvé toutes les nations du vin de la colère. " 
###### 9
Un autre Ange, un troisième, les suivit, criant d'une voix puissante : " Quiconque adore la Bête et son image, et se fait marquer sur le front ou sur la main, 
###### 10
lui aussi boira le vin de la fureur de Dieu, qui se trouve préparé, pur, dans la coupe de sa colère. Il subira le supplice du feu et du soufre, devant les saints Anges et devant l'Agneau. 
###### 11
Et la fumée de leur supplice s'élève pour les siècles des siècles ; non, point de repos, ni le jour ni la nuit, pour ceux qui adorent la Bête et son image, pour qui reçoit la marque de son nom. " 
###### 12
Voilà qui fonde la constance des saints, ceux qui gardent les commandements de Dieu et la foi en Jésus. 
###### 13
Puis j'entendis une voix me dire, du ciel : " Écris : Heureux les morts qui meurent dans le Seigneur ; dès maintenant - oui, dit l'Esprit - qu'ils se reposent de leurs fatigues, car leurs œuvres les accompagnent. " 
###### 14
Et voici qu'apparut à mes yeux une nuée blanche et sur la nuée était assis comme un Fils d'homme, ayant sur la tête une couronne d'or et dans la main une faucille aiguisée. 
###### 15
Puis un autre Ange sortit du temple et cria d'une voix puissante à celui qui était assis sur la nuée : " Jette ta faucille et moissonne, car c'est l'heure de moissonner, la moisson de la terre est mûre. " 
###### 16
Alors celui qui était assis sur la nuée jeta sa faucille sur la terre, et la terre fut moissonnée. 
###### 17
Puis un autre Ange sortit du temple, au ciel, tenant également une faucille aiguisée. 
###### 18
Et un autre Ange sortit de l'autel - l'Ange préposé au feu - et cria d'une voix puissante à celui qui tenait la faucille : " Jette ta faucille aiguisée, vendange les grappes dans la vigne de la terre, car ses raisins sont mûrs. " 
###### 19
L'Ange alors jeta sa faucille sur la terre, il en vendangea la vigne et versa le tout dans la cuve de la colère de Dieu, cuve immense ! 
###### 20
Puis on la foula hors de la ville, et il en coula du sang qui monta jusqu'au mors des chevaux et sur une étendue de mille six cents stades. 
