---
aliases : 
- Apocalypse 15
- Apocalypse 15
- Ap 15
- Revelation 15
tags : 
- Bible/Ap/15
- français
cssclass : français
---

# Apocalypse 15

###### 1
Puis je vis dans le ciel encore un signe, grand et merveilleux : sept Anges, portant sept fléaux, les derniers puisqu'ils doivent consommer la colère de Dieu. 
###### 2
Et je vis comme une mer de cristal mêlée de feu, et ceux qui ont triomphé de la Bête, de son image et du chiffre de son nom, debout près de cette mer de cristal. S'accompagnant sur les harpes de Dieu, 
###### 3
ils chantent le cantique de Moïse, le serviteur de Dieu, et le cantique de l'Agneau : " Grandes et merveilleuses sont tes œuvres, Seigneur, Dieu Maître-de-tout ; justes et droites sont tes voies, ô Roi des nations. 
###### 4
Qui ne craindrait, Seigneur, et ne glorifierait ton nom ? Car seul tu es saint ; et tous les païens viendront se prosterner devant toi, parce que tu as fait éclater tes vengeances. " 
###### 5
Après quoi, ma vision se poursuivit. Au ciel s'ouvrit le temple, la tente du Témoignage, 
###### 6
d'où sortirent les sept Anges aux sept fléaux, vêtus de robes de lin pur, éblouissantes, serrées à la taille par des ceintures en or. 
###### 7
Puis, l'un des quatre Vivants remit aux sept Anges sept coupes en or remplies de la colère du Dieu qui vit pour les siècles des siècles. 
###### 8
Et le temple se remplit d'une fumée produite par la gloire de Dieu et par sa puissance, en sorte que nul ne put y pénétrer jusqu'à la consommation des sept fléaux des sept Anges. 
