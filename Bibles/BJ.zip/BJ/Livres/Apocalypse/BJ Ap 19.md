---
aliases : 
- Apocalypse 19
- Apocalypse 19
- Ap 19
- Revelation 19
tags : 
- Bible/Ap/19
- français
cssclass : français
---

# Apocalypse 19

###### 1
Après quoi j'entendis comme un grand bruit de foule immense au ciel, qui clamait : " Alleluia ! Salut et gloire et puissance à notre Dieu, 
###### 2
car ses jugements sont vrais et justes : il a jugé la Prostituée fameuse qui corrompait la terre par sa prostitution, et vengé sur elle le sang de ses serviteurs. " 
###### 3
Puis ils reprirent : " Alleluia ! Oui, sa fumée s'élève pour les siècles des siècles ! " 
###### 4
Alors, les vingt-quatre Vieillards et les quatre Vivants se prosternèrent pour adorer Dieu, qui siège sur le trône, en disant : " Amen, alleluia ! ". 
###### 5
Puis une voix partit du trône : " Louez notre Dieu, vous tous qui le servez, et vous qui le craignez, les petits et les grands. " 
###### 6
Alors j'entendis comme le bruit d'une foule immense, comme le mugissement des grandes eaux, comme le grondement de violents tonnerres ; on clamait : " Alleluia ! Car il a pris possession de son règne, le Seigneur, le Dieu Maître-de-tout. 
###### 7
Soyons dans l'allégresse et dans la joie, rendons gloire à Dieu, car voici les noces de l'Agneau, et son épouse s'est faite belle : 
###### 8
on lui a donné de se vêtir de lin d'une blancheur éclatante " - le lin, c'est en effet les bonnes actions des saints. 
###### 9
Puis il me dit : " Écris : Heureux les gens invités au festin de noce de l'Agneau. Ces paroles de Dieu, ajouta-t-il, sont vraies. " 
###### 10
Alors je me prosternai à ses pieds pour l'adorer, mais lui me dit : " Non, attention, je suis un serviteur comme toi et comme tes frères qui possèdent le témoignage de Jésus. C'est Dieu que tu dois adorer. " Le témoignage de Jésus, c'est l'esprit de prophétie. 
###### 11
Alors je vis le ciel ouvert, et voici un cheval blanc ; celui qui le monte s'appelle " Fidèle " et " Vrai ", il juge et fait la guerre avec justice. 
###### 12
Ses yeux ? une flamme ardente ; sur sa tête, plusieurs diadèmes ; inscrit sur lui, un nom qu'il est seul à connaître ; 
###### 13
le manteau qui l'enveloppe est trempé de sang ; et son nom ? le Verbe de Dieu. 
###### 14
Les armées du ciel le suivaient sur des chevaux blancs, vêtues de lin d'une blancheur parfaite. 
###### 15
De sa bouche sort une épée acérée pour en frapper les païens ; c'est lui qui les mènera avec un sceptre de fer ; c'est lui qui foule dans la cuve le vin de l'ardente colère de Dieu, le Maître-de-tout. 
###### 16
Un nom est inscrit sur son manteau et sur sa cuisse : Roi des rois et Seigneur des seigneurs. 
###### 17
Puis je vis un Ange, debout sur le soleil, crier d'une voix puissante à tous les oiseaux qui volent au zénith : " Venez, ralliez le grand festin de Dieu ! 
###### 18
Vous y avalerez chairs de rois, et chairs de grands capitaines, et chairs de héros, et chairs de chevaux avec leur cavaliers, et chairs de toutes gens, libres et esclaves, petits et grands ! " 
###### 19
Je vis alors la Bête, avec les rois de la terre et leurs armées rassemblés pour engager le combat contre le Cavalier et son armée. 
###### 20
Mais la Bête fut capturée, avec le faux prophète - celui qui accomplit au service de la Bête des prodiges par lesquels il fourvoyait les gens ayant reçu la marque de la Bête et les adorateurs de son image, - on les jeta tous deux, vivants, dans l'étang de feu, de soufre embrasé. 
###### 21
Tout le reste fut exterminé par l'épée du Cavalier, qui sort de sa bouche, et tous les oiseaux se repurent de leurs chairs. 
