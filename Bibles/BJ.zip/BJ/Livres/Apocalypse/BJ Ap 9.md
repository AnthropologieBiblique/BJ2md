---
aliases : 
- Apocalypse 9
- Apocalypse 9
- Ap 9
- Revelation 9
tags : 
- Bible/Ap/9
- français
cssclass : français
---

# Apocalypse 9

###### 1
Et le cinquième Ange sonna... Alors je vis un astre qui du ciel avait chu sur la terre. On lui remit la clef du puits de l'Abîme. 
###### 2
Il ouvrit le puits de l'Abîme et il en monta une fumée, comme celle d'une immense fournaise - le soleil et l'atmosphère en furent obscurcis - 
###### 3
et, de cette fumée, des sauterelles se répandirent sur la terre ; on leur donna un pouvoir pareil à celui des scorpions de la terre. 
###### 4
On leur dit d'épargner les prairies, toute verdure et tout arbre, et de s'en prendre seulement aux hommes qui ne porteraient pas sur le front le sceau de Dieu. 
###### 5
On leur donna, non de les tuer, mais de les tourmenter durant cinq mois. La douleur qu'elles provoquent ressemble à celle d'une piqûre de scorpion. 
###### 6
Et ces jours-là, les hommes rechercheront la mort sans la trouver, ils souhaiteront mourir et la mort les fuira ! 
###### 7
Or ces sauterelles, à les voir, font penser à des chevaux équipés pour la guerre ; sur leur tête on dirait des couronnes d'or, et leur face rappelle des faces humaines ; 
###### 8
leurs cheveux, des chevelures de femmes, et leurs dents, des dents de lions ; 
###### 9
leur thorax, des cuirasses de fer, et le bruit de leurs ailes, le vacarme de chars aux multiples chevaux se ruant au combat ; 
###### 10
elles ont des queues pareilles à des scorpions, avec des dards ; et dans leurs queues se trouve leur pouvoir de torturer les hommes durant cinq mois. 
###### 11
A leur tête, comme roi, elles ont l'Ange de l'Abîme ; il s'appelle en hébreu : " Abaddôn ", et en grec : " Apollyôn ". 
###### 12
Le premier " Malheur " a passé, voici encore deux " Malheurs " qui le suivent... 
###### 13
Et le sixième Ange sonna... Alors j'entendis une voix venant des quatre cornes de l'autel d'or placé devant Dieu ; 
###### 14
elle dit au sixième Ange portant trompette : " Relâche les quatre Anges enchaînés sur le grand fleuve Euphrate. " 
###### 15
Et l'on relâcha les quatre Anges qui se tenaient prêts pour l'heure et le jour et le mois et l'année, afin d'exterminer le tiers des hommes. 
###### 16
Leur armée comptait deux cents millions de cavaliers : on m'en précisa le nombre. 
###### 17
Tels m'apparurent en vision les chevaux et leurs cavaliers : ceux-ci portent des cuirasses de feu, d'hyacinthe et de soufre ; quant aux chevaux, leur tête est comme celle du lion, et leur bouche crache feu et fumée et soufre. 
###### 18
Alors le tiers des hommes fut exterminé par ces trois fléaux : le feu, la fumée et le soufre vomis de la bouche des chevaux. 
###### 19
Car la puissance des chevaux réside en leur bouche ; elle réside aussi dans leur queue : ces queues, en effet, ainsi que des serpents, sont munies de têtes dont elles se servent pour nuire. 
###### 20
Or les hommes échappés à l'hécatombe de ces fléaux ne renoncèrent même pas aux œuvres de leurs mains : ils ne cessèrent d'adorer les démons, ces idoles d'or, d'argent, de bronze, de pierre et de bois, incapables de voir, d'entendre ou de marcher. 
###### 21
Ils n'abandonnèrent ni leurs meurtres, ni leurs sorcelleries, ni leurs débauches, ni leurs rapines. 
