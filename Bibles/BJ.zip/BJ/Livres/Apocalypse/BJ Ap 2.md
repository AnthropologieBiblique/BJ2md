---
aliases : 
- Apocalypse 2
- Apocalypse 2
- Ap 2
- Revelation 2
tags : 
- Bible/Ap/2
- français
cssclass : français
---

# Apocalypse 2

###### 1
" A l'Ange de l'Église d'Éphèse, écris : Ainsi parle celui qui tient les sept étoiles en sa droite et qui marche au milieu des sept candélabres d'or. 
###### 2
Je connais ta conduite, tes labeurs et ta constance ; je le sais, tu ne peux souffrir les méchants : tu as mis à l'épreuve ceux qui usurpent le titre d'apôtres, et tu les as trouvés menteurs. 
###### 3
Tu as de la constance : n'as-tu pas souffert pour mon nom, sans te lasser ? 
###### 4
Mais j'ai contre toi que tu as perdu ton amour d'antan. 
###### 5
Allons ! rappelle-toi d'où tu es tombé, repens-toi, reprends ta conduite première. Sinon, je vais venir à toi pour changer ton candélabre de son rang, si tu ne te repens. 
###### 6
Il y a cependant pour toi que tu détestes la conduite des Nicolaïtes, que je déteste moi-même. 
###### 7
Celui qui a des oreilles, qu'il entende ce que l'Esprit dit aux Églises : au vainqueur, je ferai manger de l'arbre de vie placé dans le Paradis de Dieu. 
###### 8
" A l'Ange de l'Église de Smyrne, écris : Ainsi parle le Premier et le Dernier, celui qui fut mort et qui a repris vie. 
###### 9
Je connais tes épreuves et ta pauvreté - tu es riche pourtant - et les diffamations de ceux qui usurpent le titre de Juifs - une synagogue de Satan plutôt ! - 
###### 10
Ne crains pas les souffrances qui t'attendent : voici, le Diable va jeter des vôtres en prison pour vous tenter, et vous aurez dix jours d'épreuve. Reste fidèle jusqu'à la mort, et je te donnerai la couronne de vie. 
###### 11
Celui qui a des oreilles, qu'il entende ce que l'Esprit dit aux Églises : le vainqueur n'a rien à craindre de la seconde mort. 
###### 12
" A l'Ange de l'Église de Pergame, écris : Ainsi parle celui qui possède l'épée acérée à double tranchant. 
###### 13
Je sais où tu demeures : là est le trône de Satan. Mais tu tiens ferme à mon nom et tu n'as pas renié ma foi, même aux jours d'Antipas, mon témoin fidèle, qui fut mis à mort chez vous, là où demeure Satan. 
###### 14
Mais j'ai contre toi quelque grief : tu en as là qui tiennent la doctrine de Balaam ; il incitait Balaq à tendre un piège aux fils d'Israël pour qu'ils mangent des viandes immolées aux idoles et se prostituent. 
###### 15
Ainsi, chez toi aussi, il en est qui tiennent la doctrine des Nicolaïtes. 
###### 16
Allons ! repens-toi, sinon je vais bientôt venir à toi pour combattre ces gens avec l'épée de ma bouche. 
###### 17
Celui qui a des oreilles, qu'il entende ce que l'Esprit dit aux Églises : au vainqueur, je donnerai de la manne cachée et je lui donnerai aussi un caillou blanc, un caillou portant gravé un nom nouveau que nul ne connaît, hormis celui qui le reçoit. 
###### 18
" A l'Ange de l'Église de Thyatire, écris : Ainsi parle le Fils de Dieu, dont les yeux sont comme une flamme ardente et les pieds pareils à de l'airain précieux. 
###### 19
Je connais ta conduite : ton amour, ta foi, ton dévouement, ta constance ; tes œuvres vont sans cesse en se multipliant. 
###### 20
Mais j'ai contre toi que tu tolères Jézabel, cette femme qui se dit prophétesse ; elle égare mes serviteurs, les incitant à se prostituer en mangeant des viandes immolées aux idoles. 
###### 21
Je lui ai laissé le temps de se repentir, mais elle refuse de se repentir de ses prostitutions. 
###### 22
Voici, je vais la jeter sur un lit de douleurs, et ses compagnons de prostitution dans une épreuve terrible, s'ils ne se repentent de leur conduite. 
###### 23
Et ses enfants, je vais les frapper de mort : ainsi, toutes les Églises sauront que c'est moi qui sonde les reins et les cœurs ; et je vous paierai chacun selon vos œuvres. 
###### 24
Quant à vous autres, à Thyatire, qui ne partagez pas cette doctrine, vous qui n'avez pas connu " les profondeurs de Satan ", comme ils disent, je vous déclare que je ne vous impose pas d'autre fardeau ; 
###### 25
du moins, ce que vous avez, tenez-le ferme jusqu'à mon retour. 
###### 26
Le vainqueur, celui qui restera fidèle à mon service jusqu'à la fin, je lui donnerai pouvoir sur les nations : 
###### 27
c'est avec un sceptre de fer qu'il les mènera comme on fracasse des vases d'argile ! 
###### 28
Ainsi moi-même j'ai reçu ce pouvoir de mon Père. Et je lui donnerai l'Étoile du matin. 
###### 29
Celui qui a des oreilles, qu'il entende ce que l'Esprit dit aux Églises. 
