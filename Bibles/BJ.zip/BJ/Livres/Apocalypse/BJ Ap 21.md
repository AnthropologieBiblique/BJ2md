---
aliases : 
- Apocalypse 21
- Apocalypse 21
- Ap 21
- Revelation 21
tags : 
- Bible/Ap/21
- français
cssclass : français
---

# Apocalypse 21

###### 1
Puis je vis un ciel nouveau, une terre nouvelle - car le premier ciel et la première terre ont disparu, et de mer, il n'y en a plus. 
###### 2
Je vis la Cité sainte, Jérusalem nouvelle, qui descendait du ciel, de chez Dieu ; elle s'est faite belle, comme une jeune mariée parée pour son époux. 
###### 3
J'entendis alors une voix clamer, du trône : " Voici la demeure de Dieu avec les hommes. Il aura sa demeure avec eux ; ils seront son peuple, et lui, Dieu-avec-eux, sera leur Dieu. 
###### 4
Il essuiera toute larme de leurs yeux : de mort, il n'y en aura plus ; de pleur, de cri et de peine, il n'y en aura plus, car l'ancien monde s'en est allé. " 
###### 5
Alors, Celui qui siège sur le trône déclara : " Voici, je fais l'univers nouveau. " Puis il ajouta : " Écris : Ces paroles sont certaines et vraies. " 
###### 6
" C'en est fait, me dit-il encore, je suis l'Alpha et l'Oméga, le Principe et la Fin ; celui qui a soif, moi, je lui donnerai de la source de vie, gratuitement. 
###### 7
Telle sera la part du vainqueur ; et je serai son Dieu, et lui sera mon fils. 
###### 8
Mais les lâches, les renégats, les dépravés, les assassins, les impurs, les sorciers, les idolâtres, bref, tous les hommes de mensonge, leur lot se trouve dans l'étang brûlant de feu et de soufre : c'est la seconde mort. " 
###### 9
Alors, l'un des sept Anges aux sept coupes remplies des sept derniers fléaux s'en vint me dire : " Viens, que je te montre la Fiancée, l'Épouse de l'Agneau. " 
###### 10
Il me transporta donc en esprit sur une montagne de grande hauteur, et me montra la Cité sainte, Jérusalem, qui descendait du ciel, de chez Dieu, 
###### 11
avec en elle la gloire de Dieu. Elle resplendit telle une pierre très précieuse, comme une pierre de jaspe cristallin. 
###### 12
Elle est munie d'un rempart de grande hauteur pourvu de douze portes près desquelles il y a douze Anges et des noms inscrits, ceux des douze tribus des Israélites ; 
###### 13
à l'orient, trois portes ; au nord, trois portes ; au midi, trois portes ; à l'occident, trois portes. 
###### 14
Le rempart de la ville repose sur douze assises portant chacune le nom de l'un des douze Apôtres de l'Agneau. 
###### 15
Celui qui me parlait tenait une mesure, un roseau d'or, pour mesurer la ville, ses portes et son rempart ; 
###### 16
cette ville dessine un carré : sa longueur égale sa largeur. Il la mesura donc à l'aide du roseau, soit douze mille stades ; longueur, largeur et hauteur y sont égales. 
###### 17
Puis il en mesura le rempart, soit cent quarante-quatre coudées. - L'Ange mesurait d'après une mesure humaine. - 
###### 18
Ce rempart est construit en jaspe, et la ville est de l'or pur, comme du cristal bien pur. 
###### 19
Les assises de son rempart sont rehaussées de pierreries de toute sorte : la première assise est de jaspe, la deuxième de saphir, la troisième de calcédoine, la quatrième d'émeraude, 
###### 20
la cinquième de sardoine, la sixième de cornaline, la septième de chrysolite, la huitième de béryl, la neuvième de topaze, la dixième de chrysoprase, la onzième d'hyacinthe, la douzième d'améthyste. 
###### 21
Et les douze portes sont douze perles, chaque porte formée d'une seule perle ; et la place de la ville est de l'or pur, transparent comme du cristal. 
###### 22
Du temple, je n'en vis point en elle ; c'est que le Seigneur, le Dieu Maître-de-tout, est son temple, ainsi que l'Agneau. 
###### 23
La ville peut se passer de l'éclat du soleil et de celui de la lune, car la gloire de Dieu l'a illuminée, et l'Agneau lui tient lieu de flambeau. 
###### 24
Les nations marcheront à sa lumière, et les rois de la terre viendront lui porter leurs trésors. 
###### 25
Ses portes resteront ouvertes le jour - car il n'y aura pas de nuit - 
###### 26
et l'on viendra lui porter les trésors et le faste des nations. 
###### 27
Rien de souillé n'y pourra pénétrer, ni ceux qui commettent l'abomination et le mal, mais seulement ceux qui sont inscrits dans le livre de vie de l'Agneau. 
