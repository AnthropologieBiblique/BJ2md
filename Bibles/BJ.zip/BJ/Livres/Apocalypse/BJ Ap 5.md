---
aliases : 
- Apocalypse 5
- Apocalypse 5
- Ap 5
- Revelation 5
tags : 
- Bible/Ap/5
- français
cssclass : français
---

# Apocalypse 5

###### 1
Et je vis dans la main droite de Celui qui siège sur le trône un livre roulé, écrit au recto et au verso, et scellé de sept sceaux. 
###### 2
Et je vis un Ange puissant proclamant à pleine voix : " Qui est digne d'ouvrir le livre et d'en briser les sceaux ? " 
###### 3
Mais nul n'était capable, ni dans le ciel, ni sur la terre, ni sous la terre, d'ouvrir le livre et de le lire. 
###### 4
Et je pleurais fort de ce que nul ne s'était trouvé digne d'ouvrir le livre et de le lire. 
###### 5
L'un des Vieillards me dit alors : " Ne pleure pas. Voici : il a remporté la victoire, le Lion de la tribu de Juda, le Rejeton de David ; il ouvrira donc le livre aux sept sceaux. " 
###### 6
Alors je vis, debout entre le trône aux quatre Vivants et les Vieillards, un Agneau, comme égorgé, portant sept cornes et sept yeux, qui sont les sept Esprits de Dieu en mission par toute la terre. 
###### 7
Il s'en vint prendre le livre dans la main droite de Celui qui siège sur le trône. 
###### 8
Quand il l'eut pris, les quatre Vivants et les vingt-quatre Vieillards se prosternèrent devant l'Agneau, tenant chacun une harpe et des coupes d'or pleines de parfums, les prières des saints ; 
###### 9
ils chantaient un cantique nouveau : " Tu es digne de prendre le livre et d'en ouvrir les sceaux, car tu fus égorgé et tu rachetas pour Dieu, au prix de ton sang, des hommes de toute race, langue, peuple et nation ; 
###### 10
tu as fait d'eux pour notre Dieu une Royauté de Prêtres régnant sur la terre. " 
###### 11
Et ma vision se poursuivit. J'entendis la voix d'une multitude d'Anges rassemblés autour du trône, des Vivants et des Vieillards - ils se comptaient par myriades de myriades et par milliers de milliers ! - 
###### 12
et criant à pleine voix : " Digne est l'Agneau égorgé de recevoir la puissance, la richesse, la sagesse, la force, l'honneur, la gloire et la louange. " 
###### 13
Et toute créature, dans le ciel, et sur la terre, et sous la terre, et sur la mer, l'univers entier, je l'entendis s'écrier : " A Celui qui siège sur le trône, ainsi qu'à l'Agneau, la louange, l'honneur, la gloire et la puissance dans les siècles des siècles ! " 
###### 14
Et les quatre Vivants disaient : " Amen ! " ; et les Vieillards se prosternèrent pour adorer. 
