---
aliases : 
- Apocalypse 7
- Apocalypse 7
- Ap 7
- Revelation 7
tags : 
- Bible/Ap/7
- français
cssclass : français
---

# Apocalypse 7

###### 1
Après quoi je vis quatre Anges, debout aux quatre coins de la terre, retenant les quatre vents de la terre pour qu'il ne soufflât point de vent, ni sur la terre, ni sur la mer, ni sur aucun arbre. 
###### 2
Puis je vis un autre Ange monter de l'orient, portant le sceau du Dieu vivant ; il cria d'une voix puissante aux quatre Anges auxquels il fut donné de malmener la terre et la mer : 
###### 3
" Attendez, pour malmener la terre et la mer et les arbres, que nous ayons marqué au front les serviteurs de notre Dieu. " 
###### 4
Et j'ai appris combien furent alors marqués du sceau : cent quarante-quatre mille, de toutes les tribus des fils d'Israël. 
###### 5
De la tribu de Juda, douze mille furent marqués ; de la tribu de Ruben, douze mille ; de la tribu de Gad, douze mille ; 
###### 6
de la tribu d'Aser, douze mille ; de la tribu de Nephtali, douze mille ; de la tribu de Manassé, douze mille ; 
###### 7
de la tribu de Siméon, douze mille; de la tribu de Lévi, douze mille ; de la tribu d'Issachar, douze mille ; 
###### 8
de la tribu de Zabulon, douze mille ; de la tribu de Joseph, douze mille ; de la tribu de Benjamin, douze mille furent marqués. Le triomphe des élus au ciel. 
###### 9
Après quoi, voici qu'apparut à mes yeux une foule immense, que nul ne pouvait dénombrer, de toute nation, race, peuple et langue ; debout devant le trône et devant l'Agneau, vêtus de robes blanches, de palmes à la main, 
###### 10
ils crient d'une voix puissante : " Le salut à notre Dieu, qui siège sur le trône, ainsi qu'à l'Agneau ! " 
###### 11
Et tous les Anges en cercle autour du trône, des Vieillards et des quatre Vivants, se prosternèrent devant le trône, la face contre terre, pour adorer Dieu ; 
###### 12
ils disaient : " Amen ! Louange, gloire, sagesse, action de grâces, honneur, puissance et force à notre Dieu pour les siècles des siècles ! Amen ! " 
###### 13
L'un des Vieillards prit alors la parole et me dit : " Ces gens vêtus de robes blanches, qui sont-ils et d'où viennent-ils ? " 
###### 14
Et moi de répondre : " Monseigneur, c'est toi qui le sais. " Il reprit : " Ce sont ceux qui viennent de la grande épreuve : ils ont lavé leurs robes et les ont blanchies dans le sang de l'Agneau. 
###### 15
C'est pourquoi ils sont devant le trône de Dieu, le servant jour et nuit dans son temple ; et Celui qui siège sur le trône étendra sur eux sa tente. 
###### 16
Jamais plus ils ne souffriront de la faim ni de la soif ; jamais plus ils ne seront accablés ni par le soleil, ni par aucun vent brûlant. 
###### 17
Car l'Agneau qui se tient au milieu du trône sera leur pasteur et les conduira aux sources des eaux de la vie. Et Dieu essuiera toute larme de leurs yeux. 
