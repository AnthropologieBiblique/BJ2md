---
aliases : 
- Apocalypse 17
- Apocalypse 17
- Ap 17
- Revelation 17
tags : 
- Bible/Ap/17
- français
cssclass : français
---

# Apocalypse 17

###### 1
Alors l'un des sept Anges aux sept coupes s'en vint me dire : " Viens, que je te montre le jugement de la Prostituée fameuse, assise au bord des grandes eaux ; 
###### 2
c'est avec elle qu'ont forniqué les rois de la terre, et les habitants de la terre se sont saoulés du vin de sa prostitution. " 
###### 3
Il me transporta au désert, en esprit. Et je vis une femme, assise sur une Bête écarlate couverte de titres blasphématoires et portant sept têtes et dix cornes. 
###### 4
La femme, vêtue de pourpre et d'écarlate, étincelait d'or, de pierres précieuses et de perles ; elle tenait à la main une coupe en or, remplie d'abominations et des souillures de sa prostitution. 
###### 5
Sur son front, un nom était inscrit - un mystère ! - " Babylone la Grande, la mère des prostituées et des abominations de la terre. " 
###### 6
Et sous mes yeux, la femme se saoulait du sang des saints et du sang des martyrs de Jésus. A sa vue, je fus bien stupéfait ; 
###### 7
mais l'Ange me dit : " Pourquoi t'étonner ? je vais te dire, moi, le mystère de la femme et de la Bête qui la porte, aux sept têtes et aux dix cornes. 
###### 8
" Cette Bête-là, elle était et elle n'est plus ; elle va remonter de l'Abîme, mais pour s'en aller à sa perte ; et les habitants de la terre, dont le nom ne fut pas inscrit dès l'origine du monde dans le livre de vie, s'émerveilleront au spectacle de la Bête, de ce qu'elle était, n'est plus, et reparaîtra. 
###### 9
C'est ici qu'il faut un esprit doué de finesse ! Les sept têtes, ce sont sept collines sur lesquelles la femme est assise. " Ce sont aussi sept rois, 
###### 10
dont cinq ont passé, l'un vit, et le dernier n'est pas encore venu ; une fois là, il faut qu'il demeure un peu. 
###### 11
Quant à la Bête qui était et n'est plus, elle-même fait le huitième, l'un des sept cependant ; il s'en va à sa perte. 
###### 12
Et ces dix cornes-là, ce sont dix rois ; ils n'ont pas encore reçu de royauté, ils recevront un pouvoir royal, pour une heure seulement, avec la Bête. 
###### 13
Ils sont tous d'accord pour remettre à la Bête leur puissance et leur pouvoir. 
###### 14
Ils mèneront campagne contre l'Agneau, et l'Agneau les vaincra, car il est Seigneur des seigneurs et Roi des rois, avec les siens : les appelés, les choisis, les fidèles. 
###### 15
" Et ces eaux-là, poursuivit l'Ange, où la Prostituée est assise, ce sont des peuples, des foules, des nations et des langues. 
###### 16
Mais ces dix cornes-là et la Bête, ils vont prendre en haine la Prostituée, ils la dépouilleront de ses vêtements, toute nue, ils en mangeront la chair, ils la consumeront par le feu ; 
###### 17
car Dieu leur a inspiré la résolution de réaliser son propre dessein, de se mettre d'accord pour remettre leur pouvoir royal à la Bête, jusqu'à l'accomplissement des paroles de Dieu. 
###### 18
Et cette femme-là, c'est la Grande Cité, celle qui règne sur les rois de la terre. " 
