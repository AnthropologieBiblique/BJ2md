---
aliases : 
- Osée 7
- Osée 7
- Os 7
- Hosea 7
tags : 
- Bible/Os/7
- français
cssclass : français
---

# Osée 7

###### 1
Alors que je veux guérir Israël, se dévoilent la faute d'Éphraïm et les méchancetés de Samarie; car ils pratiquent le mensonge, le voleur entre dans la maison, une bande sévit au dehors. 
###### 2
Et ils ne disent pas en leur cœur que je me souviens de toute leur méchanceté! Maintenant leurs œuvres les enserrent, elles sont devant ma face. 
###### 3
Par leur méchanceté ils égaient le roi, et par leurs mensonges, les chefs. 
###### 4
Tous sont adultères, ils sont comme un four brûlant que le boulanger cesse d'attiser depuis qu'il a pétri la pâte jusqu'à ce qu'elle ait levé. 
###### 5
Au jour de notre roi, les chefs se rendent malades par la chaleur du vin, et lui tend la main aux moqueurs 
###### 6
quand ils s'approchent. Dans leur complot, leur cœur est semblable à un four; toute la nuit leur colère sommeille, au matin elle brûle comme un feu flamboyant; 
###### 7
tous sont échauffés comme un four, ils dévorent leurs juges. Tous leurs rois sont tombés. Pas un d'entre eux qui crie vers moi! 
###### 8
Éphraïm se mêle aux peuples, Éphraïm est une galette qu'on n'a pas retournée. 
###### 9
Des étrangers dévorent sa vigueur, et lui ne le sait pas! Même des cheveux blancs parsèment sa tête, et lui ne le sait pas! 
###### 10
L'orgueil d'Israël témoigne contre lui; et ils ne reviennent pas vers Yahvé leur Dieu, avec tout cela, ils ne le cherchent pas! 
###### 11
Éphraïm est une colombe naïve, sans cervelle; ils appellent l'Égypte, ils vont en Assur, 
###### 12
où qu'ils aillent, je déploierai sur eux mon filet, comme l'oiseau du ciel je les ferai tomber, je les punirai à cause de leur méchanceté. 
###### 13
Malheur à eux, parce qu'ils ont fui loin de moi! Ruine sur eux, parce qu'ils m'ont été infidèles! Et moi, je devrais les libérer, quand eux profèrent contre moi des mensonges ? 
###### 14
Ils ne crient pas vers moi du fond du cœur quand ils se lamentent sur leurs couches; pour du blé et du vin nouveau, ils se lacèrent, mais ils se rebellent contre moi. 
###### 15
Et moi, j'avais fortifié leur bras, mais contre moi ils méditent le mal. 
###### 16
Ils se tournent vers ce qui n'est rien, ils sont comme un arc trompeur. Leurs chefs tomberont sous l'épée à cause de la fureur de leur langue, et l'on se moquera bien d'eux au pays d'Égypte... 
