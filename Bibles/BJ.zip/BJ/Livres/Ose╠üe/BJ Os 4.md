---
aliases : 
- Osée 4
- Osée 4
- Os 4
- Hosea 4
tags : 
- Bible/Os/4
- français
cssclass : français
---

# Osée 4

###### 1
Écoutez la parole de Yahvé, enfants d'Israël, car Yahvé est en procès avec les habitants du pays : il n'y a ni fidélité ni amour, ni connaissance de Dieu dans le pays, 
###### 2
mais parjure et mensonge, assassinat et vol, adultère et violence, et le sang versé succède au sang versé. 
###### 3
Voilà pourquoi le pays est en deuil et tous ses habitants dépérissent, jusqu'aux bêtes des champs et aux oiseaux du ciel, et même les poissons de la mer disparaîtront. 
###### 4
Pourtant que nul n'intente procès, que nul ne réprimande! C'est avec toi, prêtre, que je suis en procès. 
###### 5
Tu trébucheras en plein jour, le prophète aussi trébuchera, la nuit, avec toi, et je ferai périr ta mère. 
###### 6
Mon peuple périt, faute de connaissance. Puisque toi, tu as rejeté la connaissance, je te rejetterai de mon sacerdoce; puisque tu as oublié l'enseignement de ton Dieu, à mon tour, j'oublierai tes fils. 
###### 7
Tous tant qu'ils sont, ils ont péché contre moi, ils ont échangé leur Gloire contre l'Ignominie. 
###### 8
Du péché de mon peuple, ils se nourrissent, de sa faute, ils sont avides. 
###### 9
Mais il en sera du prêtre comme du peuple : je lui ferai expier sa conduite, je lui revaudrai ses œuvres. 
###### 10
Ils mangeront, mais sans se rassasier, ils se prostitueront, mais sans s'accroître, car ils ont abandonné Yahvé pour se livrer 
###### 11
à la prostitution. Le vin et le moût font perdre le sens. 
###### 12
Mon peuple consulte son morceau de bois, c'est son bâton qui le renseigne; car un esprit de prostitution les égare, et ils se prostituent, s'éloignant de leur Dieu. 
###### 13
Sur le sommet des montagnes, ils sacrifient, sur les collines, ils brûlent de l'encens, sous le chêne, le peuplier et le térébinthe, car leur ombrage est bon. Voilà pourquoi, si vos filles se prostituent, si vos brus commettent l'adultère, 
###### 14
je ne châtierai pas vos filles pour leurs prostitutions, ni vos brus pour leurs adultères; car eux-mêmes vont à l'écart avec les prostituées, ils sacrifient avec les hiérodules, et le peuple, sans discernement, va à sa perte! 
###### 15
Si toi, tu te prostitues, Israël, que Juda ne se rende pas coupable! N'allez pas à Gilgal, ne montez pas à Bet-Aven, et ne jurez pas " par la vie de Yahvé ". 
###### 16
Car telle une vache rétive, Israël a été rétif; et maintenant Yahvé le ferait paître comme un agneau dans un vaste pacage ? 
###### 17
Éphraïm est l'allié des idoles, laisse-le! 
###### 18
Leur beuverie terminée, ils ne font que se prostituer; ils préfèrent l'Ignominie à leur Orgueil. 
###### 19
Le vent les emportera de ses ailes, et ils auront honte de leurs sacrifices. 
