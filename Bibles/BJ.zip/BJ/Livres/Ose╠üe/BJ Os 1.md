---
aliases : 
- Osée 1
- Osée 1
- Os 1
- Hosea 1
tags : 
- Bible/Os/1
- français
cssclass : français
---

# Osée 1

###### 1
Parole de Yahvé qui fut adressée à Osée, fils de Beéri, au temps d'Ozias, de Yotam, d'Achaz et d'Ézéchias, rois de Juda, et au temps de Jéroboam, fils de Joas, roi d'Israël. 
###### 2
Commencement de ce que Yahvé a dit par Osée. Yahvé dit à Osée : " Va, prends une femme se livrant à la prostitution et des enfants de prostitution, car le pays ne fait que se prostituer en se détournant de Yahvé. " 
###### 3
Il alla donc prendre Gomer, fille de Diblayim, qui conçut et lui enfanta un fils. 
###### 4
Yahvé lui dit : " Appelle-le du nom de Yizréel, car encore un peu de temps, et je châtierai la maison de Jéhu pour le sang versé à Yizréel, et je mettrai fin à la royauté de la maison d'Israël. 
###### 5
Il adviendra, en ce jour-là, que je briserai l'arc d'Israël dans la vallée de Yizréel. " 
###### 6
Elle conçut encore et enfanta une fille. Yahvé lui dit : " Appelle-la du nom de Lo-Ruhamah, car désormais je n'aurai plus pitié de la maison d'Israël pour lui pardonner encore. 
###### 7
Mais de la maison de Juda j'aurai pitié et je les sauverai par Yahvé leur Dieu. Je ne les sauverai ni par l'arc, ni par l'épée, ni par la guerre, ni par les chevaux, ni par les cavaliers. " 
###### 8
Elle sevra Lo-Ruhamah, conçut encore et enfanta un fils. 
###### 9
Yahvé dit : " Appelle-le du nom de Lo-Ammi, car vous n'êtes pas mon peuple, et moi je n'existe pas pour vous. " 
