---
aliases : 
- Osée 5
- Osée 5
- Os 5
- Hosea 5
tags : 
- Bible/Os/5
- français
cssclass : français
---

# Osée 5

###### 1
Écoutez ceci, prêtres, sois attentive, maison d'Israël, maison du roi, prête l'oreille! Car c'est vous que concerne le droit, mais vous avez été un piège à Miçpa, et un filet tendu sur le Tabor. 
###### 2
Ils ont approfondi la fosse de Shittim, eh bien, moi, je vais les punir tous. 
###### 3
Moi, je connais Éphraïm, Israël ne m'est point caché. Oui, tu t'es prostitué, Éphraïm, Israël s'est souillé. 
###### 4
Leurs œuvres ne leur permettent pas de revenir vers leur Dieu, car un esprit de prostitution est en leur sein et ils ne connaissent pas Yahvé. 
###### 5
L'orgueil d'Israël témoigne contre lui; Israël et Éphraïm trébuchent à cause de leur faute, Juda aussi trébuche avec eux. 
###### 6
Avec leurs brebis et leurs bœufs, ils iront chercher Yahvé, mais ils ne le trouveront pas : il s'est retiré d'eux! 
###### 7
Ils ont trahi Yahvé, ils ont engendré des bâtards; maintenant la néoménie va les dévorer, eux et leurs champs. 
###### 8
Sonnez du cor à Gibéa, de la trompette à Rama, donnez l'alarme à Bet-Aven, on te talonne Benjamin. 
###### 9
Éphraïm deviendra une désolation, au jour du châtiment, sur les tribus d'Israël, j'annonce une chose certaine. 
###### 10
Les chefs de Juda sont comme des déplaceurs de bornes; sur eux je répandrai ma fureur comme de l'eau. 
###### 11
Éphraïm est opprimé, écrasé par le jugement, car il s'est plu à courir après le Mensonge. 
###### 12
Eh bien, moi, je serai comme la teigne pour Éphraïm, comme la carie pour la maison de Juda. 
###### 13
Éphraïm a vu sa maladie et Juda son ulcère; Éphraïm alors est allé vers Assur, il a envoyé des messagers au grand roi; mais lui ne pourra vous guérir ni porter remède à votre ulcère. 
###### 14
Car moi, je suis comme un lion pour Éphraïm, comme un lionceau pour la maison de Juda; moi, moi, je déchirerai et je m'en irai, j'emporterai ma proie, et personne pour délivrer. 
###### 15
Oui, je vais regagner ma demeure, jusqu'à ce qu'ils s'avouent coupables et cherchent ma face; dans leur détresse, ils me rechercheront. 
