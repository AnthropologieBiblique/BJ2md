---
aliases : 
- Osée 11
- Osée 11
- Os 11
- Hosea 11
tags : 
- Bible/Os/11
- français
cssclass : français
---

# Osée 11

###### 1
Quand Israël était jeune, je l'aimai, et d'Égypte j'appelai mon fils. 
###### 2
Mais plus je les appelais, plus ils s'écartaient de moi; aux Baals ils sacrifiaient, aux idoles ils brûlaient de l'encens. 
###### 3
Et moi j'avais appris à marcher à Éphraïm, je le prenais par les bras, et ils n'ont pas compris que je prenais soin d'eux! 
###### 4
Je les menais avec des attaches humaines, avec des liens d'amour; j'étais pour eux comme ceux qui soulèvent un nourrisson tout contre leur joue, je m'inclinais vers lui et le faisais manger. 
###### 5
Il ne reviendra pas au pays d'Égypte, mais Assur sera son roi. Puisqu'il a refusé de revenir à moi, 
###### 6
l'épée sévira dans ses villes, elle anéantira ses verrous, elle dévorera à cause de leurs desseins. 
###### 7
Mon peuple est cramponné à son infidélité. On les appelle en haut, pas un qui se relève! 
###### 8
Comment t'abandonnerais-je, Éphraïm, te livrerais-je, Israël ? Comment te traiterais-je comme Adma, te rendrais-je semblable à Çeboyim ? Mon cœur en moi est bouleversé, toutes mes entrailles frémissent. 
###### 9
Je ne donnerai pas cours à l'ardeur de ma colère, je ne détruirai pas à nouveau Éphraïm, car je suis Dieu et non pas homme, au milieu de toi je suis le Saint, et je ne viendrai pas avec fureur. 
###### 10
Derrière Yahvé ils marcheront, comme un lion il rugira; et quand il rugira, les fils viendront, tremblants, de l'Occident; 
###### 11
comme un passereau ils viendront en tremblant de l'Égypte, comme une colombe, du pays d'Assur, et je les ferai habiter dans leurs maisons, oracle de Yahvé. 
