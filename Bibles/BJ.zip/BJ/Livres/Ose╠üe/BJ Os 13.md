---
aliases : 
- Osée 13
- Osée 13
- Os 13
- Hosea 13
tags : 
- Bible/Os/13
- français
cssclass : français
---

# Osée 13

###### 1
Quand Éphraïm parlait, c'était la terreur, il était grand en Israël, mais il se rendit coupable avec Baal et mourut. 
###### 2
Et maintenant ils continuent à pécher, ils se font des images de métal fondu, avec leur argent, des idoles de leur invention; œuvre d'artisan que tout cela! Ils disent : " Offrez-leur des sacrifices ". A des veaux, des hommes donnent des baisers! 
###### 3
C'est pourquoi ils seront comme la nuée du matin, comme la rosée qui tôt se dissipe, comme la balle emportée loin de l'aire, comme la fumée qui s'échappe de la fenêtre. 
###### 4
Pourtant moi je suis Yahvé, ton Dieu, depuis le pays d'Égypte, de Dieu, excepté moi, tu n'en connais pas, et de sauveur, il n'en est pas en dehors de moi. 
###### 5
Moi, je t'ai connu au désert, au pays de l'aridité. 
###### 6
Je les ai fait paître, ils se sont rassasiés; rassasiés, leur cœur s'est élevé; voilà pourquoi ils m'ont oublié. 
###### 7
J'ai donc été pour eux comme un lion, comme un léopard, près du chemin, je me tenais aux aguets; 
###### 8
j'ai fondu sur eux comme une ourse privée de ses petits, j'ai déchiré l'enveloppe de leur cœur; là, je les ai dévorés comme une lionne, la bête sauvage les a déchirés. 
###### 9
Te voilà détruit, Israël, c'est en moi qu'est ton secours. 
###### 10
Où donc est-il ton roi, pour qu'il te sauve ? et dans toutes tes villes, tes juges ? ceux-là dont tu disais : " Donne-moi un roi et des chefs. " 
###### 11
Un roi, je te le donne dans ma colère, et je le reprends dans ma fureur. 
###### 12
La faute d'Éphraïm est mise en réserve, son péché tenu en lieu sûr. 
###### 13
Les douleurs de l'enfantement surviennent pour lui, mais c'est un enfant stupide; il est à terme et ne quitte pas le sein maternel! 
###### 14
Et je les libérerais du pouvoir du Shéol ? De la mort je les rachèterais ? Où est ta peste, ô Mort ? Où est ta contagion, ô Shéol ? La compassion se dérobe à mes yeux. 
###### 15
Éphraïm a beau fructifier parmi ses frères, le vent d'est viendra, le souffle de Yahvé montera du désert, et sa source sera tarie, sa fontaine desséchée. C'est lui qui pillera le trésor de tous les objets précieux. 
