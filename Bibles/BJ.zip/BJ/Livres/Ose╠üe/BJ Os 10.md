---
aliases : 
- Osée 10
- Osée 10
- Os 10
- Hosea 10
tags : 
- Bible/Os/10
- français
cssclass : français
---

# Osée 10

###### 1
Israël était une vigne luxuriante, qui donnait bien son fruit. Plus son fruit se multipliait, plus il a multiplié les autels; plus son pays devenait riche, plus riches il a fait les stèles. 
###### 2
Leur cœur est double, maintenant ils vont expier; lui-même renversera leurs autels, il dévastera leurs stèles. 
###### 3
Alors ils diront : " Nous n'avons pas de roi, car nous n'avons pas craint Yahvé, mais le roi, que pourrait-il faire pour nous ? " 
###### 4
On tient des discours, on jure en vain, on conclut des alliances; et le droit prospère comme la plante vénéneuse sur le sillon des champs! 
###### 5
Pour le veau de Bet-Aven les habitants de Samarie tremblent; oui, sur lui son peuple mène le deuil, ainsi que sa prêtraille : Qu'ils exultent sur sa gloire maintenant qu'elle est déportée loin de nous! 
###### 6
Lui-même, on le transportera en Assur comme tribut pour le grand roi. Éphraïm recueillera la honte, et Israël rougira de son dessein. 
###### 7
C'en est fait de Samarie! Son roi est comme un fétu à la surface de l'eau. 
###### 8
Ils seront détruits, les hauts lieux d'Aven, ce péché d'Israël; épines et chardons grimperont sur leurs autels. Ils diront alors aux montagnes : " Couvrez-nous! " et aux collines : " Tombez sur nous! " 
###### 9
Depuis les jours de Gibéa, tu as péché, Israël! ils s'en sont tenus là, et la guerre n'atteindrait pas les criminels à Gibéa ? 
###### 10
Je vais venir les punir! Des peuples s'assembleront contre eux quand ils seront punis pour leurs deux fautes. 
###### 11
Éphraïm est une génisse bien dressée, aimant à fouler l'aire; et moi j'ai fait passer le joug sur son cou superbe! j'attellerai Éphraïm, Juda labourera, Jacob traînera la herse. 
###### 12
Faites-vous des semailles selon la justice, moissonnez à proportion de l'amour; défrichez-vous des terres en friche : il est temps de rechercher Yahvé, jusqu'à ce qu'il vienne faire pleuvoir sur vous la justice. 
###### 13
Vous avez labouré la méchanceté, vous avez moissonné l'injustice, vous avez mangé le fruit du mensonge. Parce que tu t'es confié dans tes chars, dans la multitude de tes guerriers, 
###### 14
un grondement s'élèvera parmi ton peuple et toutes tes forteresses seront dévastées, comme Shalmân dévasta Bet-Arbel, au jour du combat, quand la mère était écrasée sur ses enfants. 
###### 15
Voilà ce que vous a fait Béthel, pour votre méchanceté sans nom; à l'aurore, oui, c'en sera fait du roi d'Israël! 
