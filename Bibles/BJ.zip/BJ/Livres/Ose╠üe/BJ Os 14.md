---
aliases : 
- Osée 14
- Osée 14
- Os 14
- Hosea 14
tags : 
- Bible/Os/14
- français
cssclass : français
---

# Osée 14

###### 1
Samarie expiera car elle s'est rebellée contre son Dieu. Ils tomberont sous l'épée, leurs petits enfants seront écrasés, leurs femmes enceintes éventrées. Retour sincère d'Israël à Yahvé. 
###### 2
Reviens, Israël, à Yahvé ton Dieu, car c'est ta faute qui t'a fait trébucher. 
###### 3
Munissez-vous de paroles et revenez à Yahvé. Dites-lui : " Enlève toute faute et prends ce qui est bon. Au lieu de taureaux nous te vouerons nos lèvres. 
###### 4
Assur ne nous sauvera pas, nous ne monterons plus sur des chevaux, et nous ne dirons plus "Notre Dieu! " à l'œuvre de nos mains, car c'est auprès de toi que l'orphelin trouve compassion. " 
###### 5
- Je les guérirai de leur infidélité, je les aimerai de bon cœur; puisque ma colère s'est détournée de lui, 
###### 6
je serai comme la rosée pour Israël, il fleurira comme le lis, il enfoncera ses racines comme le chêne du Liban; 
###### 7
ses rejetons s'étendront, il aura la splendeur de l'olivier et le parfum du Liban. 
###### 8
Ils reviendront s'asseoir à mon ombre; ils feront revivre le froment, ils feront fleurir la vigne qui aura la renommée du vin du Liban. 
###### 9
Éphraïm, qu'a-t-il encore à faire avec les idoles ? Moi je l'exauce et le regarde. Je suis comme un cyprès verdoyant, c'est de moi que vient ton fruit. 
###### 10
Qui est sage pour comprendre ces choses, intelligent pour les connaître ? Droites sont les voies de Yahvé, les justes y marcheront, mais les infidèles y trébucheront. 
