---
aliases : 
- Osée 9
- Osée 9
- Os 9
- Hosea 9
tags : 
- Bible/Os/9
- français
cssclass : français
---

# Osée 9

###### 1
Ne te réjouis pas, Israël; ne jubile pas comme les peuples; car tu as abandonné ton Dieu pour la prostitution, dont tu as aimé le salaire sur toutes les aires à blé. 
###### 2
L'aire et la cuve ne les nourriront pas, le vin nouveau les décevra. 
###### 3
Ils n'habiteront pas au pays de Yahvé, Éphraïm retournera en Égypte, et en Assur, ils mangeront des mets impurs. 
###### 4
Ils ne feront pas à Yahvé de libations de vin et leurs sacrifices ne lui seront pas agréables : ce sera pour eux comme un pain de deuil, tous ceux qui en mangeront deviendront impurs; car leur pain sera pour eux-mêmes, mais il n'entrera pas dans la Maison de Yahvé. 
###### 5
Que ferez-vous au jour de solennité, au jour de la fête de Yahvé ? 
###### 6
Car voilà qu'ils sont partis devant la dévastation; l'Égypte les rassemblera, Memphis les ensevelira, leurs objets précieux, l'ortie en héritera, et l'épine envahira leurs tentes. 
###### 7
Ils sont venus, les jours du châtiment, ils sont venus, les jours de la rétribution, qu'Israël le sache! - " Le prophète est fou, l'inspiré délire! " - A cause de la grandeur de ta faute, grande sera l'hostilité. 
###### 8
Le guetteur d'Éphraïm est avec mon Dieu - c'est le prophète, à qui on tend un piège sur tous les chemins et dans la maison de son Dieu, c'est l'hostilité. 
###### 9
Ils se sont profondément corrompus, comme aux jours de Gibéa : il se souviendra de leur faute, il châtiera leurs péchés. 
###### 10
Comme des raisins dans le désert, je trouvai Israël, comme un fruit sur un figuier en la prime saison, je vis vos pères; mais arrivés à Baal-Péor, ils se vouèrent à la Honte et devinrent des horreurs, comme l'objet de leur amour. 
###### 11
Éphraïm, comme l'oiseau s'envolera sa gloire : plus d'enfantement, plus de grossesse, plus de conception. 
###### 12
Même s'ils élèvent leurs fils, je les en priverai avant qu'ils soient hommes; oui, malheur à eux quand je m'éloignerai d'eux! 
###### 13
Éphraïm, je le voyais comme Tyr, plantée dans une prairie, mais Éphraïm devra mener ses fils à l'égorgeur. 
###### 14
Donne-leur, Yahvé... Que donneras-tu ? Donne-leur des entrailles stériles et des seins desséchés. 
###### 15
Toute leur méchanceté a paru à Gilgal, c'est là que je les ai pris en haine. A cause de la méchanceté de leurs actions, je les chasserai de ma maison, je ne les aimerai plus, tous leurs chefs sont des rebelles. 
###### 16
Éphraïm est frappé, leur racine est desséchée, ils ne donneront pas de fruit. Même s'il leur naît des enfants, je ferai mourir les délices de leur sein. 
###### 17
Mon Dieu les rejettera parce qu'ils ne l'ont pas écouté, et ils seront errants parmi les nations. 
