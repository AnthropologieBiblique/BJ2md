---
aliases : 
- Osée 3
- Osée 3
- Os 3
- Hosea 3
tags : 
- Bible/Os/3
- français
cssclass : français
---

# Osée 3

###### 1
Yahvé me dit : " Va de nouveau, aime une femme qui en aime un autre et commet l'adultère, comme Yahvé aime les enfants d'Israël, alors qu'ils se tournent vers d'autres dieux et qu'ils aiment les gâteaux de raisin. " 
###### 2
Je l'achetai donc pour quinze sicles d'argent et un muid et demi d'orge, 
###### 3
et je lui dis : " Pendant de longs jours tu me resteras là, sans te prostituer et sans appartenir à un homme, et j'agirai de même à ton égard. " 
###### 4
Car, pendant de longs jours les enfants d'Israël resteront sans roi et sans chef, sans sacrifice et sans stèle, sans éphod et sans téraphim. 
###### 5
Ensuite les enfants d'Israël reviendront; ils chercheront Yahvé leur Dieu, et David leur roi; ils accourront en tremblant vers Yahvé et vers ses biens, dans la suite des jours. 
