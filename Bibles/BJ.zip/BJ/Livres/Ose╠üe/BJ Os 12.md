---
aliases : 
- Osée 12
- Osée 12
- Os 12
- Hosea 12
tags : 
- Bible/Os/12
- français
cssclass : français
---

# Osée 12

###### 1
Éphraïm m'entoure de mensonge et la maison d'Israël de tromperie. Mais Juda est encore auprès de Dieu, au Saint il reste fidèle. 
###### 2
Éphraïm se repaît de vent, tout le jour il poursuit le vent d'est; il multiplie mensonge et fausseté : on conclut alliance avec Assur, on porte de l'huile à l'Égypte. 
###### 3
Yahvé est en procès avec Juda, il va sévir contre Jacob selon sa conduite, et lui rendre selon ses actions. 
###### 4
Dès le sein maternel il supplanta son frère, dans sa vigueur il fut fort contre Dieu. 
###### 5
Il fut fort contre l'Ange et l'emporta, il pleura et l'implora. A Béthel il le rencontra. C'est là qu'il parla avec nous. 
###### 6
Oui, Yahvé, le Dieu Sabaot, Yahvé est son titre. 
###### 7
Pour toi, grâce à ton Dieu, tu reviendras. Garde l'amour et le droit et espère en ton Dieu toujours. 
###### 8
Canaan a en main des balances trompeuses, il aime à exploiter. 
###### 9
Éphraïm a dit : " Oui, je me suis enrichi, je me suis acquis une fortune "; mais de tous ses gains, rien ne lui restera, à cause de la faute dont il s'est rendu coupable. 
###### 10
Je suis Yahvé, ton Dieu, depuis le pays d'Égypte. Je te ferai encore habiter sous les tentes comme aux jours du Rendez-vous. 
###### 11
Je parlerai aux prophètes, moi, je multiplierai les visions et par le ministère des prophètes je parlerai en paraboles. 
###### 12
Si Galaad n'est qu'iniquité, eux ne sont que fausseté; à Gilgal ils sacrifient aux taureaux, c'est pourquoi leurs autels seront comme des monceaux de pierres sur les sillons des champs. 
###### 13
Jacob s'enfuit aux campagnes d'Aram, Israël servit pour une femme, pour une femme, il garda les troupeaux. 
###### 14
Mais par un prophète, Yahvé fit monter Israël d'Égypte, et par un prophète il fut gardé. 
###### 15
Éphraïm l'a offensé amèrement : Yahvé rejettera sur lui le sang versé, son Seigneur lui revaudra ses outrages. 
