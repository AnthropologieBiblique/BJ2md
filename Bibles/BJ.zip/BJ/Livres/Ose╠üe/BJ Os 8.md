---
aliases : 
- Osée 8
- Osée 8
- Os 8
- Hosea 8
tags : 
- Bible/Os/8
- français
cssclass : français
---

# Osée 8

###### 1
Embouche la trompette! Comme un aigle, le malheur fond sur la maison de Yahvé. Car ils ont transgressé mon alliance et ont été infidèles à ma Loi. 
###### 2
Ils ont beau me crier : " Mon Dieu, nous te connaissons, nous Israël. " 
###### 3
Israël a rejeté le bien, l'ennemi le poursuivra. 
###### 4
Ils ont fait des rois, mais sans mon aveu, ils ont fait des chefs, mais à mon insu. De leur argent et de leur or ils se sont fait des idoles, afin qu'elles soient supprimées. 
###### 5
Ton veau, Samarie, je le repousse! - ma colère s'est enflammée contre eux. Jusques à quand ne pourront-ils recouvrer l'innocence ? - 
###### 6
Car il vient d'Israël, c'est un artisan qui l'a fabriqué, lui, il n'est pas Dieu, lui. Oui, le veau de Samarie tombera en miettes. 
###### 7
Puisqu'ils sèment le vent, ils moissonneront la tempête : tige qui n'a pas d'épi, qui ne donne pas de farine; et si elle en donne, des étrangers l'engloutiront. 
###### 8
Israël est englouti. Maintenant ils sont parmi les nations comme un objet dont personne ne veut; 
###### 9
car ils sont montés vers Assur, onagre qui vit à l'écart; Éphraïm s'est acheté des amants. 
###### 10
Qu'il s'en achète parmi les nations, maintenant je vais les rassembler et ils souffriront bientôt sous le fardeau du roi des princes. 
###### 11
Quand Éphraïm a multiplié les autels, ces autels ne lui ont servi qu'à pécher. 
###### 12
Que pour lui j'écrive les mille préceptes de ma loi, on les tient pour une chose étrangère. 
###### 13
Les sacrifices qu'ils m'offrent, ils les sacrifient, ils en mangent la viande, mais Yahvé ne les agrée pas. Maintenant, il va se souvenir de leur faute et châtier leurs péchés : ils retourneront, eux, en Égypte. 
###### 14
Israël a oublié son auteur et il a bâti des palais; Juda a multiplié les villes fortes. Mais j'enverrai le feu dans ses villes, et il en dévorera les citadelles. 
