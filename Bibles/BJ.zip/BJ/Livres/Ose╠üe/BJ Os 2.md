---
aliases : 
- Osée 2
- Osée 2
- Os 2
- Hosea 2
tags : 
- Bible/Os/2
- français
cssclass : français
---

# Osée 2

###### 1
Le nombre des enfants d'Israël sera comme le sable de la mer, qu'on ne peut ni mesurer ni compter; au lieu même où on leur disait : " Vous n'êtes pas mon peuple ", on leur dira : " Fils du Dieu vivant. " 
###### 2
Les enfants de Juda et les enfants d'Israël se réuniront, ils se donneront un chef unique et ils déborderont hors du pays; car il sera grand le jour de Yizréel. 
###### 3
Dites à vos frères : " Mon Peuple ", et à vos sœurs : " Celle dont on a pitié ". 
###### 4
Intentez procès à votre mère, intentez-lui procès! Car elle n'est pas ma femme, et moi je ne suis pas son mari. Qu'elle écarte de sa face ses prostitutions, et d'entre ses seins ses adultères. 
###### 5
Sinon je la déshabillerai toute nue et la mettrai comme au jour de sa naissance; je la rendrai pareille au désert, je la réduirai en terre aride, je la ferai mourir de soif, 
###### 6
et de ses enfants je n'aurai pas pitié, car ce sont des enfants de prostitution. 
###### 7
Oui, leur mère s'est prostituée, celle qui les conçut s'est déshonorée; car elle a dit : Je veux courir après mes amants, qui me donnent mon pain et mon eau, ma laine et mon lin, mon huile et ma boisson. 
###### 8
C'est pourquoi je vais obstruer son chemin avec des ronces, je l'entourerai d'une barrière pour qu'elle ne trouve plus ses sentiers; 
###### 9
elle poursuivra ses amants et ne les atteindra pas, elle les cherchera et ne les trouvera pas. Alors elle dira : Je veux retourner vers mon premier mari, car j'étais plus heureuse alors que maintenant. 
###### 10
Elle n'a pas reconnu que c'est moi qui lui donnais le froment, le vin nouveau et l'huile fraîche, qui lui prodiguais cet argent et cet or qu'ils ont employés pour Baal! 
###### 11
C'est pourquoi je reprendrai mon froment en son temps et mon vin nouveau en sa saison; je retirerai ma laine et mon lin qui devaient couvrir sa nudité. 
###### 12
Puis je dévoilerai son infamie aux yeux de ses amants et personne ne la délivrera de ma main. 
###### 13
Je ferai cesser toutes ses réjouissances, ses fêtes, ses néoménies, ses sabbats et toutes ses solennités. 
###### 14
Je dévasterai sa vigne et son figuier, dont elle disait : Ils sont le salaire que m'ont donné mes amants; j'en ferai un hallier et la bête sauvage les dévorera. 
###### 15
Je la châtierai pour les jours des Baals auxquels elle brûlait de l'encens, quand elle se parait de son anneau et de son collier et qu'elle courait après ses amants; et moi, elle m'oubliait! Oracle de Yahvé. 
###### 16
C'est pourquoi je vais la séduire, je la conduirai au désert et je parlerai à son cœur. 
###### 17
Là, je lui rendrai ses vignobles, et je ferai du val d'Akor une porte d'espérance. Là, elle répondra comme aux jours de sa jeunesse, comme au jour où elle montait du pays d'Égypte. 
###### 18
Il adviendra, en ce jour-là - oracle de Yahvé - que tu m'appelleras " Mon mari ", et tu ne m'appelleras plus " Mon Baal ". 
###### 19
J'écarterai de sa bouche les noms des Baals, et ils ne seront plus mentionnés par leur nom. 
###### 20
Je conclurai pour eux une alliance, en ce jour-là, avec les bêtes des champs, avec les oiseaux du ciel et les reptiles du sol; l'arc, l'épée, la guerre, je les briserai et les bannirai du pays, et eux, je les ferai reposer en sécurité. 
###### 21
Je te fiancerai à moi pour toujours; je te fiancerai dans la justice et dans le droit, dans la tendresse et la miséricorde; 
###### 22
je te fiancerai à moi dans la fidélité, et tu connaîtras Yahvé. 
###### 23
Il adviendra, en ce jour-là, que je répondrai - oracle de Yahvé - je répondrai aux cieux et eux répondront à la terre; 
###### 24
la terre répondra au froment, au vin nouveau et à l'huile fraîche, et eux répondront à Yizréel. 
###### 25
Je la sèmerai dans le pays, j'aurai pitié de Lo-Ruhamah, je dirai à Lo-Ammi : " Tu es mon peuple " et lui dira : " Mon Dieu! " 
