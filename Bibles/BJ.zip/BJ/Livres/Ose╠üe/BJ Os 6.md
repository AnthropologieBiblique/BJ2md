---
aliases : 
- Osée 6
- Osée 6
- Os 6
- Hosea 6
tags : 
- Bible/Os/6
- français
cssclass : français
---

# Osée 6

###### 1
" Venez, retournons vers Yahvé. Il a déchiré, il nous guérira; il a frappé, il pansera nos plaies; 
###### 2
après deux jours il nous fera revivre, le troisième jour il nous relèvera et nous vivrons en sa présence. 
###### 3
Connaissons, appliquons-nous à connaître Yahvé; sa venue est certaine comme l'aurore; il viendra pour nous comme l'ondée, comme la pluie de printemps qui arrose la terre. " 
###### 4
- Que te ferai-je, Éphraïm ? Que te ferai-je, Juda ? Car votre amour est comme la nuée du matin, comme la rosée qui tôt se dissipe. 
###### 5
C'est pourquoi je les ai taillés en pièces par les prophètes, je les ai tués par les paroles de ma bouche, et mon jugement surgira comme la lumière. 
###### 6
Car c'est l'amour qui me plaît et non les sacrifices, la connaissance de Dieu plutôt que les holocaustes. 
###### 7
Mais eux, à Adam, ont transgressé l'alliance, là, ils m'ont trahi. 
###### 8
Galaad est une cité de malfaiteurs qui porte des traces de sang. 
###### 9
Comme des brigands en embuscade, une bande de prêtres assassine sur la route de Sichem; oui, ils commettent l'infamie! 
###### 10
A Béthel j'ai vu une chose horrible; c'est là que se prostitue Éphraïm, que se souille Israël. 
###### 11
A toi aussi, Juda, est destinée une moisson, quand je rétablirai mon peuple. 
