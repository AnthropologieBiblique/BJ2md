---
aliases : 
- Éphésiens
- Éphésiens
- Ep
- Ephesians
tags : 
- Bible/Ep
- français
cssclass : français
---

# Éphésiens

[[BJ Ep 1|Éphésiens 1]]
[[BJ Ep 2|Éphésiens 2]]
[[BJ Ep 3|Éphésiens 3]]
[[BJ Ep 4|Éphésiens 4]]
[[BJ Ep 5|Éphésiens 5]]
[[BJ Ep 6|Éphésiens 6]]
