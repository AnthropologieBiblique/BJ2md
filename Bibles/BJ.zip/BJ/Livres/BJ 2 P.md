---
aliases : 
- 2 Pierre
- 2 Pierre
- 2 P
- 2 Peter
tags : 
- Bible/2P
- français
cssclass : français
---

# 2 Pierre

[[BJ 2 P 1|2 Pierre 1]]
[[BJ 2 P 2|2 Pierre 2]]
[[BJ 2 P 3|2 Pierre 3]]
