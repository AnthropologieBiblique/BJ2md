---
aliases : 
- 2 Chroniques 25
- 2 Chroniques 25
- 2 Ch 25
- 2 Chronicles 25
tags : 
- Bible/2Ch/25
- français
cssclass : français
---

# 2 Chroniques 25

###### 1
Amasias devint roi à l'âge de vingt-cinq ans et régna vingt-neuf ans à Jérusalem. Sa mère s'appelait Yehoaddân, et était de Jérusalem. 
###### 2
Il fit ce qui est agréable à Yahvé, non pas pourtant d'un cœur sans défaillance. 
###### 3
Lorsque le royaume se fut affermi sous son gouvernement, il mit à mort ceux de ses officiers qui avaient tué le roi son père. 
###### 4
Mais il ne fit pas mourir leurs fils, car il est écrit dans la Loi, dans le livre de Moïse, que Yahvé a prescrit : Les pères ne seront pas mis à mort pour les fils et les fils ne seront pas mis à mort pour les pères, mais chacun sera mis à mort pour son propre crime. 
###### 5
Amasias réunit les Judéens et les constitua en familles avec officiers de milliers et de centaines pour tout Juda et Benjamin. Il recensa ceux qui avaient vingt ans et plus et il en trouva trois cent mille, hommes d'élite aptes à faire campagne, la lance et le bouclier au poing. 
###### 6
Il enrôla ensuite comme mercenaires, pour cent talents d'argent, cent mille preux vaillants d'Israël. 
###### 7
Un homme de Dieu vint alors le trouver et lui dit : " O Roi, il ne faut pas que les troupes d'Israël viennent se joindre à toi, car Yahvé n'est ni avec Israël ni avec aucun des Éphraïmites. 
###### 8
Car s'ils viennent, tu auras beau agir et combattre vaillamment, Dieu ne t'en fera pas moins trébucher devant tes ennemis, car c'est en Dieu qu'est le pouvoir de soutenir et d'abattre. " 
###### 9
Amasias répondit à l'homme de Dieu : " Quoi! Et les cent talents que j'ai donnés à la troupe d'Israélites! " - " Yahvé a de quoi te donner beaucoup plus que cela ", dit l'homme de Dieu. 
###### 10
Amasias détacha alors de la sienne la troupe qui lui était venue d'Éphraïm et la renvoya chez elle; ces gens furent très excités contre Juda et retournèrent chez eux fort en colère. 
###### 11
Amasias se décida à partir à la tête de ses troupes, il gagna la vallée du Sel et battit dix mille fils de Séïr. 
###### 12
Les Judéens emmenèrent vivants dix mille captifs qu'ils conduisirent au sommet de la Roche, d'où ils les précipitèrent; tous s'écrasèrent. 
###### 13
Quant à la troupe qu'avait congédiée Amasias au lieu de l'emmener combattre avec lui, elle envahit les villes de Juda, de Samarie à Bet-Horôn, battit une troupe de trois milliers et fit un grand pillage. 
###### 14
Une fois rentré de sa campagne victorieuse contre les Édomites, Amasias introduisit les dieux des fils de Séïr, en fit ses dieux, se prosterna devant eux et les encensa. 
###### 15
La colère de Yahvé s'enflamma contre Amasias, il lui envoya un prophète qui lui dit : " Pourquoi recherches-tu les dieux de ce peuple, qui n'ont pu le sauver de ta main ? " 
###### 16
Il lui parlait encore qu'Amasias l'interrompit : " T'avons-nous nommé conseiller du roi ? Arrête-toi, si tu ne veux pas qu'on te frappe. " Le prophète s'arrêta, puis il dit : " Je sais que Dieu a tenu conseil pour ta perte, puisque tu as agi ainsi et que tu n'as pas écouté mon conseil. " 
###### 17
Après avoir tenu conseil, Amasias, roi de Juda, envoya dire à Joas, fils de Joachaz, fils de Jéhu, roi d'Israël : " Viens et mesurons-nous! " 
###### 18
Joas, roi d'Israël, retourna ce message à Amasias, roi de Juda : " Le chardon du Liban manda ceci au cèdre du Liban : "Donne ta fille pour femme à mon fils", mais les bêtes sauvages du Liban passèrent et foulèrent le chardon. 
###### 19
"Me voici vainqueur d'Édom", as-tu dit, et tu te montes la tête! Sois glorieux et reste maintenant chez toi. Pourquoi provoquer le malheur et amener ta chute et celle de Juda avec toi ? " 
###### 20
Mais Amasias n'écouta pas; c'était le fait de Dieu qui voulait livrer ces gens-là pour avoir recherché les dieux d'Édom. 
###### 21
Joas, roi d'Israël, se mit en campagne. Ils se mesurèrent, lui et Amasias, roi de Juda, à Bet-Shémesh qui appartient à Juda. 
###### 22
Juda fut battu devant Israël et chacun s'enfuit à sa tente. 
###### 23
Quant au roi de Juda, Amasias, fils de Joas, fils d'Ochozias, le roi d'Israël Joas le fit prisonnier à Bet-Shémesh et l'emmena à Jérusalem. Il fit une brèche au rempart de Jérusalem, depuis la porte d'Éphraïm jusqu'à la porte de l'Angle, sur quatre cents coudées. 
###### 24
Il prit tout l'or et l'argent, tout le mobilier qui se trouvait dans le Temple de Dieu chez Obed-Édom, les trésors du palais royal, des otages, et retourna à Samarie. 
###### 25
Amasias, fils de Joas, roi de Juda, vécut encore quinze ans après la mort de Joas, fils de Joachaz, roi d'Israël. 
###### 26
Le reste de l'histoire d'Amasias, du début à la fin, n'est-il pas écrit au livre des Rois de Juda et d'Israël ? 
###### 27
Après l'époque où Amasias se détourna de Yahvé, on trama contre lui un complot à Jérusalem; il s'enfuit vers Lakish, mais on le fit poursuivre à Lakish et mettre à mort là-bas. 
###### 28
On le transporta avec des chevaux et on l'enterra auprès de ses pères dans la Cité de David. 
