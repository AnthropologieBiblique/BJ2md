---
aliases : 
- 2 Chroniques 6
- 2 Chroniques 6
- 2 Ch 6
- 2 Chronicles 6
tags : 
- Bible/2Ch/6
- français
cssclass : français
---

# 2 Chroniques 6

###### 1
Alors Salomon dit : " Yahvé a décidé d'habiter la nuée obscure. 
###### 2
Moi, je t'ai construit une demeure princière, une résidence où tu habites à jamais. " 
###### 3
Puis le roi se retourna et bénit toute l'assemblée d'Israël. Toute l'assemblée d'Israël se tenait debout; 
###### 4
il dit : " Béni soit Yahvé, Dieu d'Israël, qui a accompli de sa main ce qu'il avait promis de sa bouche à mon père David en ces termes : 
###### 5
"Depuis le jour où j'ai fait sortir mon peuple du pays d'Égypte, je n'ai pas choisi de ville, dans toutes les tribus d'Israël, pour qu'on y bâtit une maison où serait mon Nom, ni choisi d'homme pour qu'il fût chef de mon peuple Israël. 
###### 6
Mais j'ai choisi Jérusalem pour qu'y fût mon Nom et j'ai choisi David pour qu'il commandât à mon peuple Israël. " 
###### 7
Mon père David eut dans l'esprit de bâtir une maison pour le Nom de Yahvé, Dieu d'Israël, 
###### 8
mais Yahvé dit à mon père David : "Tu as eu dans l'esprit de bâtir une maison pour mon Nom, et tu as bien fait. 
###### 9
Seulement, ce n'est pas toi qui bâtiras cette maison, c'est ton fils, issu de tes reins, qui bâtira la maison pour mon Nom. " 
###### 10
Yahvé a réalisé la parole qu'il avait dite : j'ai succédé à mon père David et je me suis assis sur le trône d'Israël comme avait dit Yahvé, j'ai construit la maison pour le Nom de Yahvé, Dieu d'Israël, 
###### 11
et j'y ai placé l'arche où est l'alliance que Yahvé a conclue avec les Israélites. " 
###### 12
Puis il se tint devant l'autel de Yahvé, en présence de toute l'assemblée d'Israël et il étendit les mains. 
###### 13
Or Salomon avait fait un socle de bronze qu'il avait mis au milieu de la cour; il avait cinq coudées de long, cinq de large et trois de haut. Salomon y monta, s'y tint et s'y agenouilla en présence de toute l'assemblée d'Israël. Il étendit les mains vers le ciel 
###### 14
et dit : " Yahvé, Dieu d'Israël! Il n'y a aucun Dieu pareil à toi dans les cieux ni sur la terre, toi qui es fidèle à l'alliance et gardes la bienveillance à l'égard de tes serviteurs, quand ils marchent de tout leur cœur devant toi. 
###### 15
Tu as tenu à ton serviteur David, mon père, la promesse que tu lui avais faite, et ce que tu avais dit de ta bouche, tu l'as accompli aujourd'hui de ta main. 
###### 16
Et maintenant, Yahvé, Dieu d'Israël, tiens à ton serviteur David, mon père, la promesse que tu lui as faite, quand tu as dit : "Tu ne seras jamais dépourvu d'un descendant qui soit devant moi, assis sur le trône d'Israël, à condition que tes fils veillent à leur conduite et suivent ma loi comme toi-même tu as marché devant moi. " 
###### 17
Maintenant donc, Yahvé, Dieu d'Israël, que se vérifie la parole que tu as dite à ton serviteur David! 
###### 18
Mais Dieu habiterait-il vraiment avec les hommes sur la terre ? Voici que les cieux et les cieux des cieux ne le peuvent contenir, moins encore cette maison que j'ai construite! 
###### 19
Sois attentif à la prière et à la supplication de ton serviteur, Yahvé, mon Dieu, écoute l'appel et la prière que ton serviteur fait devant toi! 
###### 20
Que tes yeux soient ouverts jour et nuit sur cette maison, sur ce lieu où tu as dit mettre ton Nom. Écoute la prière que ton serviteur fera en ce lieu. 
###### 21
" Écoute les supplications de ton serviteur et de ton peuple Israël, lorsqu'ils prieront en ce lieu. Toi, écoute du lieu où tu résides, du ciel, écoute et pardonne. 
###### 22
Si un homme pèche contre son prochain, et que celui-ci prononce sur lui un serment imprécatoire et le fasse jurer devant ton autel dans ce Temple, 
###### 23
toi, écoute du ciel et agis; juge entre tes serviteurs : rends au méchant son dû en faisant retomber sa conduite sur sa tête, et justifie l'innocent en lui rendant selon sa justice. 
###### 24
Si ton peuple Israël est battu devant l'ennemi parce qu'il aura péché contre toi, s'il se convertit, loue ton Nom, prie et supplie devant toi dans ce Temple, 
###### 25
toi, écoute du ciel, pardonne le péché de ton peuple Israël, et ramène-le dans le pays que tu lui as donné comme à ses pères. 
###### 26
Quand le ciel sera fermé et qu'il n'y aura pas de pluie parce qu'ils auront péché contre toi, s'ils prient en ce lieu, louent ton Nom, se repentent de leur péché, parce que tu les auras humiliés, 
###### 27
toi, écoute du ciel, pardonne le péché de tes serviteurs et de ton peuple Israël - tu leur indiqueras la bonne voie qu'ils doivent suivre -, et arrose de pluie ta terre, que tu as donnée en héritage à ton peuple. 
###### 28
Quand le pays subira la famine, la peste, la rouille ou la nielle, quand surviendront les sauterelles ou les criquets, quand l'ennemi de ce peuple assiégera l'une de ses portes, quand il y aura n'importe quel fléau ou quelle épidémie, 
###### 29
quelle que soit la prière ou la supplication, qu'elle soit d'un homme quelconque ou de tout Israël ton peuple, si l'on éprouve peine ou douleur et si l'on tend les mains vers ce Temple, 
###### 30
toi, écoute du ciel où tu résides, pardonne et rends à chaque homme selon sa conduite, puisque tu connais son cœur - tu es le seul à connaître le cœur des hommes -, 
###### 31
en sorte qu'ils te craindront et suivront tes voies tous les jours qu'ils vivront sur la terre que tu as donnée à nos pères. 
###### 32
Même l'étranger qui n'est pas d'Israël ton peuple, s'il vient d'un pays lointain à cause de la grandeur de ton Nom, de ta main forte et de ton bras étendu, s'il vient et prie dans ce Temple, 
###### 33
toi, écoute du ciel où tu résides, exauce toutes les demandes de l'étranger afin que tous les peuples de la terre reconnaissent ton Nom et te craignent comme le fait ton peuple Israël, et qu'ils sachent que ce Temple que j'ai bâti porte ton Nom. 
###### 34
Si ton peuple part en guerre contre ses ennemis par le chemin où tu l'auras envoyé, s'il te prie, tourné vers la ville que tu as choisie et vers le Temple que j'ai construit pour ton Nom, 
###### 35
écoute du ciel sa prière et sa supplication et fais-lui justice. 
###### 36
Quand ils pécheront contre toi - car il n'y a aucun homme qui ne pèche -, quand tu seras irrité contre eux, quand tu les livreras à l'ennemi et que leurs conquérants les emmèneront captifs dans un pays lointain ou proche, 
###### 37
s'ils rentrent en eux-mêmes, dans le pays où ils auront été déportés, s'ils se repentent et te supplient dans le pays de leur captivité en disant : "Nous avons péché, nous avons mal agi, nous nous sommes pervertis", 
###### 38
s'ils reviennent à toi de tout leur cœur et de toute leur âme dans le pays de leur captivité où ils ont été déportés et s'ils prient, tournés vers le pays que tu as donné à leurs pères, vers la ville que tu as choisie et le Temple que j'ai bâti pour ton Nom, 
###### 39
écoute du ciel où tu résides, écoute leur prière et leur supplication, fais-leur justice et pardonne à ton peuple les péchés commis envers toi. 
###### 40
" Maintenant, ô mon Dieu, que tes yeux soient ouverts et tes oreilles attentives aux prières faites en ce lieu! 
###### 41
Et maintenant Dresse-toi, Yahvé Dieu, fixe-toi, toi et l'arche de ta force! Que tes prêtres, Yahvé Dieu, se revêtent de salut et que tes fidèles jubilent dans le bonheur! 
###### 42
Yahvé Dieu, n'écarte pas la face de ton oint, souviens-toi des grâces faites à David ton serviteur! " 
