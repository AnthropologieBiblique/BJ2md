---
aliases : 
- 2 Chroniques 17
- 2 Chroniques 17
- 2 Ch 17
- 2 Chronicles 17
tags : 
- Bible/2Ch/17
- français
cssclass : français
---

# 2 Chroniques 17

###### 1
Son fils Josaphat régna à sa place et affermit son pouvoir sur Israël. 
###### 2
Il mit des troupes dans toutes les villes fortifiées de Juda et établit des préfets dans le pays de Juda et dans les villes d'Éphraïm qu'avait conquises Asa, son père. 
###### 3
Yahvé fut avec Josaphat, car sa conduite fut celle qu'avait d'abord suivie son père et il ne rechercha pas les Baals. 
###### 4
C'est bien le Dieu de son père qu'il rechercha, et il marcha selon ses commandements sans imiter les actions d'Israël. 
###### 5
Yahvé maintint le royaume entre ses mains; tous les Judéens payaient tribut à Josaphat, si bien qu'il eut beaucoup de richesses et d'honneur. 
###### 6
Son cœur progressa dans les voies de Yahvé et il supprima de nouveau en Juda les hauts lieux et les ashéras. 
###### 7
La troisième année de son règne, il envoya ses officiers : Ben-Hayil, Obadya, Zekarya, Netanéel, Mikayahu, instruire les cités judéennes. 
###### 8
Des lévites les accompagnaient : Shemayahu, Netanyahu, Zebadyahu, Asahel, Shemiramot, Yehonatân, Adoniyyahu, Tobiyyahu, lévites, ainsi que les prêtres Élishama et Yehoram. 
###### 9
Ils se mirent à enseigner en Juda, munis du livre de la Loi de Yahvé, et firent le tour des cités judéennes, en instruisant le peuple. 
###### 10
La terreur de Yahvé s'étendit sur tous les royaumes des pays qui entouraient Juda; ils ne firent pas la guerre à Josaphat. 
###### 11
Des Philistins lui apportèrent en tribut des présents et de l'argent; les Arabes eux-mêmes lui amenèrent du petit bétail : sept mille sept cents béliers et sept mille sept cents boucs. 
###### 12
Josaphat grandissant allait au plus haut; il édifia en Juda des citadelles et des villes-entrepôts. 
###### 13
Il eut d'importants services dans les cités judéennes et des guerriers, des vaillants preux, à Jérusalem. 
###### 14
En voici la répartition par familles : Pour Juda : officiers de milliers : Adna l'officier, avec 300 milliers de vaillants preux; 
###### 15
à ses ordres, Yehohanân l'officier, avec 280 milliers; 
###### 16
à ses ordres, Amasya, fils de Zikri, engagé volontaire au service de Yahvé, avec 200 milliers de vaillants preux. 
###### 17
De Benjamin : le vaillant preux Élyada avec 200 milliers armés de l'arc et de la rondache; 
###### 18
à ses ordres, Yehozabad, avec 180 milliers équipés pour la guerre. 
###### 19
Tels étaient ceux qui servaient le roi, sans compter les hommes qu'il avait mis dans les places fortes de tout Juda. 
