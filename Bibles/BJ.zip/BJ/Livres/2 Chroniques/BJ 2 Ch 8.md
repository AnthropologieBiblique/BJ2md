---
aliases : 
- 2 Chroniques 8
- 2 Chroniques 8
- 2 Ch 8
- 2 Chronicles 8
tags : 
- Bible/2Ch/8
- français
cssclass : français
---

# 2 Chroniques 8

###### 1
Au bout des vingt années pendant lesquelles Salomon construisit le Temple de Yahvé et son propre palais, 
###### 2
il restaura les villes que lui avait données Huram et y établit les Israélites. 
###### 3
Puis il alla à Hamat de Çoba, dont il se rendit maître; 
###### 4
il restaura Tadmor dans le désert et toutes les villes-entrepôts qu'il avait édifiées dans le pays de Hamat. 
###### 5
Il restaura Bet-Horôn-le-Haut et Bet-Horôn-le-Bas, villes fortifiées, munies de murs, de portes et de barres, 
###### 6
ainsi que Baalat, toutes les villes-entrepôts qu'avait Salomon, toutes les villes de chars et les villes de chevaux, et ce qu'il plut à Salomon de construire à Jérusalem, au Liban et dans tous les pays qui lui étaient soumis. 
###### 7
Tout ce qui restait des Hittites, des Amorites, des Perizzites, des Hivvites et des Jébuséens, qui n'étaient pas des Israélites 
###### 8
et dont les descendants étaient restés après eux dans le pays sans être exterminés par les Israélites, Salomon les leva comme hommes de corvée; ils le sont encore. 
###### 9
Mais Salomon ne fit point des Israélites des esclaves travaillant pour lui, car ils servaient comme soldats : ils étaient les officiers de ses écuyers, les officiers de sa charrerie et de sa cavalerie. 
###### 10
Voici les officiers des préfets dont disposait le roi Salomon : deux cent cinquante qui commandaient au peuple. 
###### 11
Salomon fit monter de la Cité de David la fille de Pharaon jusqu'à la maison qu'il lui avait construite. Il disait en effet : " Une femme ne saurait demeurer à cause de moi dans le palais de David, roi d'Israël; ce sont des lieux sacrés où vint l'arche de Yahvé. " 
###### 12
Salomon offrit alors des holocaustes à Yahvé sur l'autel de Yahvé qu'il avait bâti devant le Vestibule. 
###### 13
Selon le rituel quotidien des holocaustes, conformément à l'ordre de Moïse sur les sabbats, les néoménies et les trois solennités annuelles : la fête des Azymes, la fête des Semaines et la fête des Tentes, 
###### 14
il établit, selon la règle de David son père, les classes des prêtres dans leur service, les lévites dans leur fonction pour louer et officier près des prêtres selon le rituel quotidien, et les portiers, selon leur classe respective, à chaque porte, car tels avaient été les ordres de David, homme de Dieu. 
###### 15
Sur aucun autre point, même au sujet des réserves, ils ne s'écartèrent des ordres du roi relatifs aux prêtres et aux lévites. 
###### 16
Et toute l'œuvre de Salomon, qui n'avait été que préparée jusqu'au jour de la fondation du Temple de Yahvé, fut parfaite lorsqu'il eut achevé le Temple de Yahvé. 
###### 17
Alors Salomon gagna Éçyon-Géber et Élat, au bord de la mer, au pays d'Édom. 
###### 18
Huram lui envoya des navires montés par ses serviteurs ainsi que des serviteurs qui connaissaient la mer. Avec les serviteurs de Salomon ils allèrent à Ophir et en rapportèrent quatre cent cinquante talents d'or qu'ils remirent au roi Salomon. 
