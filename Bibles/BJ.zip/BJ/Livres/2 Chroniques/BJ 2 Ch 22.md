---
aliases : 
- 2 Chroniques 22
- 2 Chroniques 22
- 2 Ch 22
- 2 Chronicles 22
tags : 
- Bible/2Ch/22
- français
cssclass : français
---

# 2 Chroniques 22

###### 1
Les habitants de Jérusalem firent roi à sa place Ochozias, son plus jeune fils, car la troupe qui, avec les Arabes, avait fait incursion dans le camp, avait assassiné les aînés. Ainsi Ochozias, fils de Joram, devint roi de Juda. 
###### 2
Il avait quarante-deux ans à son avènement et il régna un an à Jérusalem. Le nom de sa mère était Athalie, fille de Omri. 
###### 3
Lui aussi imita la conduite de la maison d'Achab, car sa mère lui donnait de mauvais conseils. 
###### 4
Il fit ce qui déplaît à Yahvé, comme la famille d'Achab, car ce sont ces gens qui, pour sa perte, devinrent ses conseillers après la mort de son père. 
###### 5
Il suivit en outre leur politique et alla avec Joram, fils d'Achab, roi d'Israël, pour combattre Hazaèl, roi d'Aram, à Ramot de Galaad. Mais les Araméens blessèrent Joram; 
###### 6
il revint à Yizréel pour faire soigner les blessures reçues à Ramot en combattant Hazaèl, roi d'Aram. Ochozias, fils de Joram, roi de Juda, descendit à Yizréel, pour visiter Joram, fils d'Achab, parce qu'il était souffrant. 
###### 7
Dieu fit de cette visite à Joram la perte d'Ochozias. A son arrivée, il sortit avec Joram à la rencontre de Jéhu, fils de Nimshi, oint par Yahvé pour en finir avec la maison d'Achab. 
###### 8
Alors qu'il s'employait à faire justice de la maison d'Achab, Jéhu rencontra les officiers de Juda et les neveux d'Ochozias, ses serviteurs; il les tua, 
###### 9
puis se mit à la recherche d'Ochozias. On se saisit de lui tandis qu'il essayait de se cacher dans Samarie et on l'amena à Jéhu, qui l'exécuta. Mais on l'ensevelit parce qu'on disait : " C'est le fils de Josaphat qui recherchait Yahvé de tout son cœur. " Il n'y avait personne dans la maison d'Ochozias qui fût en mesure de régner. 
###### 10
Lorsque la mère d'Ochozias, Athalie, eut appris que son fils était mort, elle entreprit d'exterminer toute la descendance royale de la maison de Juda. 
###### 11
Mais Yehoshéba, fille du roi, retira furtivement Joas, fils d'Ochozias, du groupe des fils du roi qu'on massacrait et elle le mit, avec sa nourrice, dans la chambre des lits. Ainsi Yehoshéba, fille du roi Joram et femme du prêtre Yehoyada et elle était sœur d'Ochozias , put le soustraire à Athalie et éviter qu'elle ne le tuât. 
###### 12
Il resta six ans avec eux, caché dans le Temple de Dieu, pendant qu'Athalie régnait sur le pays. 
