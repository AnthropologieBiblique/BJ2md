---
aliases : 
- 2 Chroniques 34
- 2 Chroniques 34
- 2 Ch 34
- 2 Chronicles 34
tags : 
- Bible/2Ch/34
- français
cssclass : français
---

# 2 Chroniques 34

###### 1
Josias avait huit ans à son avènement et il régna trente et un ans à Jérusalem. 
###### 2
Il fit ce qui est agréable à Yahvé et suivit la conduite de son ancêtre David sans en dévier ni à droite ni à gauche. 
###### 3
La huitième année de son règne, n'étant encore qu'un jeune homme, il commença à rechercher le Dieu de David son ancêtre. La douzième année de son règne, il commença à purifier Juda et Jérusalem des hauts lieux, des pieux sacrés, des idoles sculptées et fondues. 
###### 4
On démolit devant lui les autels des Baals, il arracha les autels à encens qui étaient placés sur eux, il brisa les pieux sacrés, les idoles sculptées et fondues, et les réduisit en une poussière qu'il répandit sur les tombeaux de ceux qui leur avaient offert des sacrifices. 
###### 5
Il brûla les ossements des prêtres sur leurs autels et purifia ainsi Juda et Jérusalem. 
###### 6
Dans les villes de Manassé, d'Éphraïm, de Siméon, et même de Nephtali, et dans les territoires saccagés qui les entouraient, 
###### 7
il démolit les autels, les pieux sacrés, brisa et pulvérisa les idoles, il abattit les autels à encens dans tout le pays d'Israël, puis il revint à Jérusalem. 
###### 8
La dix-huitième année de son règne, dans le but de purifier le pays et le Temple, il envoya Shaphân, fils d'Açalyahu, Maaséyahu, gouverneur de la ville, et Yoah, fils de Yoahaz le héraut, pour réparer le Temple de Yahvé son Dieu. 
###### 9
Ils allèrent remettre à Hilqiyyahu, le grand prêtre, l'argent qui avait été apporté au Temple de Dieu et que les lévites gardiens du seuil avaient recueilli : l'argent provenait de Manassé, d'Éphraïm, de tout le reste d'Israël, ainsi que de tous les Judéens et Benjaminites qui habitaient Jérusalem. 
###### 10
Ils le remirent aux maîtres d'œuvre attachés au Temple de Yahvé et ceux-ci l'utilisèrent pour les travaux de restauration et de réparation du Temple. 
###### 11
Ils le donnèrent aux charpentiers et aux ouvriers du bâtiment pour acheter les pierres de taille et le bois nécessaire au chaînage et aux charpentes des bâtiments qu'avaient endommagés les rois de Juda. 
###### 12
Ces hommes travaillèrent avec fidélité à cette œuvre; ils étaient sous la surveillance de Yahat et de Obadyahu, lévites des fils de Merari, de Zekarya et de Meshullam, Qehatites contremaîtres, des lévites experts dans les instruments d'accompagnement du chant, 
###### 13
de ceux qui étaient à la tête des transporteurs et de ceux qui dirigeaient tous les maîtres d'œuvre de chaque service, et enfin de quelques lévites, scribes, greffiers et portiers. 
###### 14
Quand on retira l'argent déposé au Temple de Yahvé, le prêtre Hilqiyyahu trouva le livre de la Loi de Yahvé transmise par Moïse. 
###### 15
Hilqiyyahu prit la parole et dit au secrétaire Shaphân : " J'ai trouvé le livre de la Loi dans le Temple de Yahvé. " Et Hilqiyyahu donna le livre à Shaphân. 
###### 16
Shaphân remit le livre au roi et lui rapporta encore ceci : " Tout ce qui a été confié à tes serviteurs, ils l'exécutent, 
###### 17
ils ont fondu l'argent qui se trouvait dans le Temple de Yahvé et l'ont remis aux mains des subordonnés et des maîtres d'œuvre. " 
###### 18
Puis le secrétaire Shaphân annonça au roi : " Le prêtre Hilqiyyahu m'a donné un livre "; et Shaphân y fit une lecture devant le roi. 
###### 19
En entendant les paroles de la Loi, le roi déchira ses vêtements. 
###### 20
Il donna cet ordre à Hilqiyyahu, à Ahiqam fils de Shaphân, à Abdôn fils de Mika, au secrétaire Shaphân et à Asaya, ministre du roi : 
###### 21
" Allez consulter Yahvé pour moi et pour ce qui reste d'Israël et de Juda, à propos des paroles du livre qui vient d'être trouvé. Grande doit être la colère de Yahvé qui s'est répandue sur nous parce que nos pères n'ont pas observé la parole de Yahvé en pratiquant tout ce qui est écrit dans ce livre. " 
###### 22
Hilqiyyahu et les gens du roi se rendirent auprès de la prophétesse Hulda, femme de Shallum, fils de Toqhat, fils de Hasra, la gardien des vêtements; elle habitait à Jérusalem dans la ville neuve. Ils lui parlèrent en ce sens 
###### 23
et elle répondit : " Ainsi parle Yahvé, Dieu d'Israël. Dites à l'homme qui vous a envoyés vers moi : 
###### 24
Ainsi parle Yahvé. Je vais amener le malheur sur ce lieu et sur ses habitants, toutes les malédictions écrites dans le livre qu'on a lu devant le roi de Juda, 
###### 25
parce qu'ils m'ont abandonné et qu'ils ont sacrifié à d'autres dieux pour m'irriter par toutes leurs actions. Ma colère s'est enflammée contre ce lieu, elle ne s'éteindra pas. 
###### 26
Et vous direz au roi de Juda qui vous a envoyés pour consulter Yahvé : Ainsi parle Yahvé, Dieu d'Israël : les paroles que tu as entendues... 
###### 27
Mais parce que ton cœur a été touché et que tu t'es humilié devant Dieu en entendant les paroles qu'il a prononcées contre ce lieu et ses habitants, parce que tu t'es humilié, que tu as déchiré tes vêtements et que tu as pleuré devant moi, moi aussi je t'ai entendu, oracle de Yahvé. 
###### 28
Voici que je te réunirai à tes pères, tu seras recueilli en paix dans ton sépulcre, tes yeux ne verront pas tous les malheurs que je fais venir sur ce lieu et sur ses habitants. " Ils portèrent la réponse au roi. 
###### 29
Alors le roi fit convoquer tous les anciens de Juda et de Jérusalem, 
###### 30
et le roi monta au Temple de Yahvé avec tous les hommes de Juda, les habitants de Jérusalem, les prêtres, les lévites et tout le peuple, du plus grand au plus petit. Il lut devant eux tout le contenu du livre de l'alliance trouvé dans le Temple de Yahvé. 
###### 31
Le roi était debout sur l'estrade, et il conclut devant Yahvé l'alliance qui l'obligeait à suivre Yahvé, à garder ses commandements, ses instructions et ses lois, de tout son cœur et de toute son âme, et à mettre en pratique les clauses de l'alliance écrites dans ce livre. 
###### 32
Il y fit adhérer quiconque se trouvait à Jérusalem ou dans Benjamin, et les habitants de Jérusalem se conformèrent à l'alliance de Dieu, le Dieu de leurs pères. 
###### 33
Josias enleva toute chose abominable de tous les territoires appartenant aux Israélites. Pendant toute sa vie, il mit au service de Yahvé leur Dieu quiconque se trouvait en Israël. Ils ne s'écartèrent pas de Yahvé, le Dieu de leurs pères. 
