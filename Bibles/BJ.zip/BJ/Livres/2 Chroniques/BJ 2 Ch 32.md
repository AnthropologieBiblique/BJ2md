---
aliases : 
- 2 Chroniques 32
- 2 Chroniques 32
- 2 Ch 32
- 2 Chronicles 32
tags : 
- Bible/2Ch/32
- français
cssclass : français
---

# 2 Chroniques 32

###### 1
Après ces actes de loyauté eut lieu l'invasion de Sennachérib, roi d'Assyrie. Il envahit Juda, campa devant les villes fortes et ordonna de lui en forcer les murs. 
###### 2
Ézéchias, observant que Sennachérib, en arrivant, se proposait d'attaquer Jérusalem, 
###### 3
décida avec ses officiers et ses preux d'obstruer les eaux des sources qui se trouvaient à l'extérieur de la ville. Ceux-ci lui prêtèrent leur concours 
###### 4
et beaucoup de gens se groupèrent pour obstruer toutes les sources ainsi que le cours d'eau qui coulait dans les terres : " Pourquoi, disaient-ils, les rois d'Assyrie trouveraient-ils à leur arrivée des eaux abondantes ? " 
###### 5
Ézéchias se fortifia : il fit maçonner toutes les brèches de la muraille qu'il surmonta de tours et pourvut d'un second mur à l'extérieur, répara le Millo de la Cité de David, et fabriqua quantité d'armes de jet et de boucliers. 
###### 6
Puis il mit des généraux à la tête du peuple, les réunit près de lui sur la place de la porte de la cité et les encouragea en ces termes : 
###### 7
" Soyez fermes et tenez bon; ne craignez pas, ne tremblez pas devant le roi d'Assur et devant toute la foule qui l'accompagne, car Ce qui est avec nous est plus puissant que ce qui est avec lui. 
###### 8
Avec lui il n'y a qu'un bras de chair, mais avec nous il y a Yahvé, notre Dieu, qui nous secourt et combat nos combats. " Le peuple fut réconforté par les paroles d'Ézéchias, roi de Juda. 
###### 9
Après cela Sennachérib, roi d'Assyrie, tandis qu'il se trouvait lui-même devant Lakish avec toutes ses forces, envoya ses serviteurs à Jérusalem, à Ézéchias, roi de Juda, et à tous les Judéens qui se trouvaient à Jérusalem. Ils dirent : 
###### 10
" Ainsi parle Sennachérib, roi d'Assyrie : Sur quoi repose votre confiance pour demeurer ainsi dans Jérusalem assiégée ? 
###### 11
Ézéchias ne vous abuse-t-il pas, ne vous livre-t-il pas à la mort, par la faim et par la soif, quand il dit : "Yahvé notre Dieu nous délivrera de la main du roi d'Assyrie" ? 
###### 12
N'est-ce pas cet Ézéchias qui a supprimé ses hauts lieux et ses autels et qui a déclaré à Juda et à Jérusalem : "C'est devant un seul autel que vous vous prosternerez et sur lui que vous ferez monter l'encens" ? 
###### 13
Ne savez-vous pas ce que moi-même et mes pères nous avons fait à tous les peuples des pays ? Les dieux des nations de ces pays ont-ils pu les délivrer de ma main ? 
###### 14
Parmi tous les dieux des nations que mes pères ont vouées à l'anathème, quel est celui qui a pu délivrer son peuple de ma main ? Votre dieu pourrait-il alors vous délivrer de ma main ? 
###### 15
Et maintenant, qu'Ézéchias ne vous leurre pas! Qu'il ne vous abuse pas ainsi! Ne le croyez pas, car aucun dieu d'aucune nation ni d'aucun royaume ne peut délivrer son peuple de ma main pas plus que de celle de mes pères; votre dieu ne vous délivrera pas davantage de ma main. " 
###### 16
Ses serviteurs parlaient encore contre Yahvé Dieu et son serviteur Ézéchias, 
###### 17
quand Sennachérib écrivit une lettre pour insulter Yahvé, Dieu d'Israël; il en parlait ainsi : " Pas plus que les dieux des nations des pays n'ont délivré leurs peuples de ma main, le dieu d'Ézéchias n'en délivrera son peuple. " 
###### 18
Ils s'adressaient en criant, en judéen, au peuple de Jérusalem qui se trouvait sur les murs, pour l'effrayer et le bouleverser et par suite capturer la ville; 
###### 19
ils parlaient du Dieu de Jérusalem comme de l'un des dieux des peuples de la terre, œuvre de mains humaines. 
###### 20
Dans cette situation, le roi Ézéchias et le prophète Isaïe, fils d'Amoç, prièrent et implorèrent le ciel. 
###### 21
Yahvé envoya un ange qui extermina tous les vaillants preux, les capitaines et les officiers, dans le camp du roi d'Assyrie; celui-ci s'en retourna, le visage couvert de honte, dans son pays; puis il entra dans le temple de son dieu où quelques-uns de ses enfants le frappèrent de l'épée. 
###### 22
Ainsi Yahvé sauva Ézéchias et les habitants de Jérusalem de la main de Sennachérib, roi d'Assyrie, et de la main de tous les autres. Il leur donna la tranquillité sur toutes leurs frontières. 
###### 23
Beaucoup apportèrent à Jérusalem une oblation à Yahvé et des présents à Ézéchias roi de Juda qui, à la suite de ces événements, acquit du prestige aux yeux de toutes les nations. 
###### 24
En ces jours-là, Ézéchias tomba malade et fut sur le point de mourir. Il pria Dieu qui l'exauça et lui accorda un miracle. 
###### 25
Mais Ézéchias ne répondit pas au bienfait reçu, son cœur s'enorgueillit et la Colère s'appesantit sur lui, sur Juda et sur Jérusalem. 
###### 26
Toutefois Ézéchias s'humilia de l'orgueil de son cœur, ainsi que les habitants de Jérusalem : la colère de Yahvé cessa de s'appesantir sur eux du vivant d'Ézéchias. 
###### 27
Ézéchias eut pléthore de richesses et de gloire. Il se constitua des trésors en or, argent, pierres précieuses, onguents, joyaux et toutes sortes d'objets précieux. 
###### 28
Il eut des entrepôts pour ses rentrées de blé, de vin et d'huile, des étables pour les différentes espèces de son bétail, et des parcs pour ses troupeaux. 
###### 29
Il se procura des ânes et un cheptel abondant en gros et en petit bétail. Dieu lui avait vraiment donné pléthore de biens. 
###### 30
C'est Ézéchias qui obstrua l'issue supérieure des eaux du Gihôn et les dirigea vers le bas de la Cité de David, à l'ouest. Ézéchias réussit dans toutes ses entreprises. 
###### 31
Et même avec les interprètes des officiers babyloniens envoyés près de lui pour enquêter sur le miracle qui avait eu lieu dans le pays, c'est pour l'éprouver que Dieu l'abandonna, et pour connaître le fond de son cœur. 
###### 32
Le reste de l'histoire d'Ézéchias, les témoignages de sa piété se trouvent écrits dans la vision du prophète Isaïe, fils d'Amoç, au livre des rois de Juda et d'Israël. 
###### 33
Ézéchias se coucha avec ses pères et on l'enterra sur la montée des tombeaux des fils de David. A sa mort, tous les Judéens et les habitants de Jérusalem lui rendirent honneur. Son fils Manassé régna à sa place. 
