---
aliases : 
- 2 Chroniques 13
- 2 Chroniques 13
- 2 Ch 13
- 2 Chronicles 13
tags : 
- Bible/2Ch/13
- français
cssclass : français
---

# 2 Chroniques 13

###### 1
La dix-huitième année du règne de Jéroboam, Abiyya devint roi de Juda 
###### 2
et régna trois ans à Jérusalem. Sa mère s'appelait Mikayahu, fille d'Uriel, de Gibéa. Il y eut guerre entre Abiyya et Jéroboam. 
###### 3
Abiyya engagea le combat avec une armée de guerriers vaillants - quatre cent mille hommes d'élite - et Jéroboam se rangea en bataille contre lui avec huit cent mille hommes d'élite, preux vaillants. 
###### 4
Abiyya se posta sur le mont Çemarayim, situé dans la montagne d'Éphraïm, et s'écria : " Jéroboam et vous tous, Israélites, écoutez-moi! 
###### 5
Ne savez-vous pas que Yahvé, le Dieu d'Israël, a donné pour toujours à David la royauté sur Israël ? C'est une alliance infrangible pour lui et pour ses fils. 
###### 6
Jéroboam, fils de Nebat, serviteur de Salomon, fils de David, s'est dressé et révolté contre son seigneur; 
###### 7
des gens de rien, des vauriens, se sont unis à lui et se sont imposés à Roboam, fils de Salomon; Roboam n'était encore qu'un jeune homme, timide de caractère, et n'a pas pu leur résister. 
###### 8
Or vous parlez maintenant de tenir tête à la royauté de Yahvé qu'exercent les fils de David, et vous voilà en foule immense, accompagnés des veaux d'or que vous a faits pour dieux Jéroboam! 
###### 9
N'avez-vous pas expulsé les prêtres de Yahvé, fils d'Aaron, et les lévites, pour vous faire des prêtres comme s'en font les peuples des pays : quiconque vient avec un taureau et sept béliers pour se faire donner l'investiture, peut devenir prêtre de ce qui n'est point Dieu! 
###### 10
Notre Dieu à nous, c'est Yahvé, et nous ne l'avons pas abandonné : les fils d'Aaron sont prêtres au service de Yahvé et les lévites officient. 
###### 11
Chaque matin et chaque soir nous faisons fumer les holocaustes pour Yahvé, nous avons l'encens aromatique, les pains rangés sur la table pure, le candélabre d'or avec ses lampes qui brûlent chaque soir. Car nous gardons les ordonnances de Yahvé notre Dieu que vous, vous avez abandonnées. 
###### 12
Voici que Dieu est en tête avec nous, voici ses prêtres et les trompettes dont ils vont sonner pour que l'on pousse le cri de guerre contre vous! Israélites, ne luttez pas avec Yahvé, le Dieu de vos pères, car vous n'aboutirez à rien. " 
###### 13
Jéroboam fit faire un mouvement tournant à l'embuscade qui atteignit leurs arrières; l'armée était face à Juda, et l'embuscade par-derrière. 
###### 14
Faisant volte-face, les Judéens se virent combattus de front et de dos. Ils firent appel à Yahvé, les prêtres sonnèrent de la trompette, 
###### 15
les hommes de Juda poussèrent le cri de guerre, et, tandis qu'ils poussaient ce cri, Dieu frappa Jéroboam et tout Israël devant Abiyya et Juda. 
###### 16
Les Israélites s'enfuirent devant Juda et Dieu les livra aux mains des Judéens. 
###### 17
Abiyya et son armée leur infligèrent une cuisante défaite : cinq cent mille hommes d'élite tombèrent morts parmi les Israélites. 
###### 18
En ce temps-là, les Israélites furent humiliés, les fils de Juda raffermis pour s'être appuyés sur Yahvé, Dieu de leurs pères. 
###### 19
Abiyya poursuivit Jéroboam et lui conquit des villes : Béthel et ses dépendances, Yeshana et ses dépendances, Éphrôn et ses dépendances. 
###### 20
Jéroboam perdit alors sa puissance durant la vie d'Abiyyahu; Yahvé le frappa et il mourut. 
###### 21
Abiyyahu s'affermit; il épousa quatorze femmes et engendra vingt-deux fils et seize filles. 
###### 22
Le reste de l'histoire d'Abiyya, sa conduite et ses actions sont écrits dans le Midrash du prophète Iddo. 
###### 23
Puis Abiyya se coucha avec ses pères et on l'enterra dans la Cité de David; son fils Asa régna à sa place. La paix d'Asa. Le pays, de son temps, fut tranquille pendant dix ans. 
