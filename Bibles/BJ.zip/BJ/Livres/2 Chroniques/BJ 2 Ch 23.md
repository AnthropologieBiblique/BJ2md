---
aliases : 
- 2 Chroniques 23
- 2 Chroniques 23
- 2 Ch 23
- 2 Chronicles 23
tags : 
- Bible/2Ch/23
- français
cssclass : français
---

# 2 Chroniques 23

###### 1
La septième année, Yehoyada se décida. Il envoya chercher les officiers de centaines, Azarya fils de Yeroham, Yishmaèl fils de Yehohanân, Azaryahu fils d'Obed, Maaséyahu fils d'Adayahu, Élishaphat fils de Zikri, qui étaient liés à lui par un pacte. 
###### 2
Ils parcoururent Juda, rassemblèrent les lévites de toutes les cités judéennes et les chefs de famille israélites. Ils vinrent à Jérusalem 
###### 3
et toute cette Assemblée conclut un pacte avec le roi dans le Temple de Dieu. " Voici le fils du roi, leur dit Yehoyada. Qu'il règne, comme l'a déclaré Yahvé des fils de David! 
###### 4
Voici ce que vous allez faire : tandis que le tiers d'entre vous, prêtres, lévites et portiers des seuils, entrera pour le sabbat, 
###### 5
un tiers se trouvera au palais royal, un tiers à la porte du Fondement et tout le peuple dans les parvis du Temple de Yahvé. 
###### 6
Que personne n'entre dans le Temple de Yahvé, sinon les prêtres et les lévites de service, car ils sont consacrés. Tout le peuple observera les ordonnances de Yahvé. 
###### 7
Les lévites feront cercle autour du roi, chacun ses armes à la main, et ils accompagneront le roi partout où il ira; mais quiconque entrera dans le Temple sera mis à mort. " 
###### 8
Les lévites et tous les Judéens exécutèrent tout ce que leur avait ordonné le prêtre Yehoyada. Ils prirent chacun leurs hommes, ceux qui commençaient la semaine et ceux qui la terminaient, le prêtre Yehoyada n'ayant exempté aucune des classes. 
###### 9
Puis le prêtre donna aux centeniers les lances, les rondaches et les boucliers du roi David, qui étaient dans le Temple de Dieu. 
###### 10
Il rangea tout le peuple, chacun son arme à la main, depuis l'angle sud jusqu'à l'angle nord du Temple, entourant l'autel et le Temple pour faire cercle autour du roi. 
###### 11
On fit alors sortir le fils du roi, on lui imposa le diadème et on lui donna le document d'alliance. Puis Yehoyada et ses fils lui donnèrent l'onction royale et s'écrièrent : " Vive le roi! " 
###### 12
Entendant les cris du peuple qui se précipitait vers le roi et l'acclamait, Athalie se rendit auprès du peuple au Temple de Yahvé. 
###### 13
Quand elle vit le roi debout sur l'estrade, à l'entrée, les chefs et les trompettes auprès du roi, tout le peuple du pays exultant de joie et sonnant de la trompette, les chantres avec les instruments de musique dirigeant le chant des hymnes, Athalie déchira ses vêtements et s'écria : " Trahison! Trahison! " 
###### 14
Mais Yehoyada fit sortir les officiers de centaines, qui commandaient la troupe, et leur dit : " Faites-la sortir entre les rangs, et si quelqu'un la suit, qu'on le passe au fil de l'épée "; car le prêtre avait dit : " Ne la tuez pas dans le Temple de Yahvé. " 
###### 15
Ils mirent la main sur elle et, quand elle arriva au palais royal, à l'entrée de la porte des Chevaux, là ils la mirent à mort. 
###### 16
Yehoyada conclut entre tout le peuple et le roi une alliance par laquelle le peuple s'obligeait à être le peuple de Yahvé. 
###### 17
Tout le peuple se rendit ensuite au temple de Baal et le démolit; on brisa ses autels et ses images et on tua Mattân, prêtre de Baal, devant les autels. 
###### 18
Yehoyada établit des postes de surveillance du Temple de Yahvé, confiés aux prêtres lévites. C'est à eux que David avait donné pour part le Temple de Yahvé afin d'offrir les holocaustes de Yahvé, comme il est écrit dans la Loi de Moïse, dans la joie et avec des chants, selon les ordres de David. 
###### 19
Il installa des portiers aux entrées du Temple de Yahvé pour qu'en aucun cas un homme impur n'y pénétrât. 
###### 20
Puis il prit les centeniers, les notables, ceux qui avaient une autorité publique et tout le peuple du pays; et il fit descendre le roi du Temple de Yahvé. Ils entrèrent au palais royal par la voûte centrale de la porte supérieure, et ils firent asseoir le roi sur le trône royal. 
###### 21
Tout le peuple du pays était en joie, mais la ville ne bougea pas. Quant à Athalie, on la fit périr par l'épée. 
