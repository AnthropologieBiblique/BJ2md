---
aliases : 
- 2 Chroniques 31
- 2 Chroniques 31
- 2 Ch 31
- 2 Chronicles 31
tags : 
- Bible/2Ch/31
- français
cssclass : français
---

# 2 Chroniques 31

###### 1
Quand tout cela fut terminé, tous les Israélites qui se trouvaient là allèrent dans les villes de Juda briser les stèles, couper les pieux sacrés, saccager les hauts lieux et les autels pour en débarrasser entièrement tout Juda, Benjamin, Éphraïm et Manassé. Puis tous les Israélites retournèrent dans leurs villes, chacun dans son patrimoine. 
###### 2
Ézéchias rétablit les classes sacerdotales et lévitiques, chacun dans sa classe, selon son service, qu'il fût prêtre ou lévite, qu'il s'agît d'holocaustes, de sacrifices de communion, de service liturgique, d'action de grâces ou d'hymne, - dans les portes du camp de Yahvé. 
###### 3
Le roi prit une part sur ses biens pour les holocaustes, holocaustes du matin et du soir, holocaustes des sabbats, des néoménies et des solennités, comme il est écrit dans la loi de Yahvé. 
###### 4
Puis il dit au peuple, aux habitants de Jérusalem, de livrer la part des prêtres et des lévites afin qu'ils puissent observer la Loi de Yahvé. 
###### 5
Dès qu'on eut répandu cette parole, les Israélites accumulèrent les prémices du froment, du vin, de l'huile, du miel et de tous les produits agricoles, et ils apportèrent une large dîme de tout. 
###### 6
Les Israélites et les Judéens, qui habitaient les cités judéennes, apportèrent eux aussi la dîme du gros et du petit bétail et la dîme des choses saintes consacrées à Yahvé; ils les apportèrent, tas après tas. 
###### 7
C'est au troisième mois qu'ils commencèrent à faire ces tas et ils les achevèrent le septième. 
###### 8
Ézéchias et les officiers vinrent voir les tas et bénirent Yahvé et Israël, son peuple. 
###### 9
Ézéchias interrogea à ce sujet les prêtres et les lévites. 
###### 10
C'est Azarya, de la maison de Sadoq, et premier prêtre, qui lui répondit : " Dès les premiers prélèvements apportés au Temple de Yahvé, dit-il, on a pu manger, se rassasier, et avoir même de larges excédents, car Yahvé a béni son peuple; ce qui reste, c'est pour cette masse-ci. " 
###### 11
Ézéchias ordonna de mettre en état des pièces dans le Temple de Yahvé. On le fit 
###### 12
et l'on apporta fidèlement les prélèvements, les dîmes et les choses consacrées. Le lévite Konanyahu en fut le chef responsable avec son frère Shiméï pour second. 
###### 13
Yehiel, Azazyahu, Nahat, Asahel, Yerimot, Yozabad, Éliel, Yismakyahu, Mahat et Benayahu en étaient les surveillants sous les ordres de Konanyahu et de son frère Shiméï, sous le gouvernement du roi Ézéchias et d'Azaryahu, chef du Temple de Dieu. 
###### 14
Qoré, fils de Yimna le lévite, gardien de la porte orientale, avait la charge des offrandes volontaires faites à Dieu; il fournissait le prélèvement de Yahvé et les choses très saintes. 
###### 15
Éden, Minyamîn, Yéshua, Shemayahu, Amaryahu et Shekanyahu l'assistaient fidèlement dans les villes sacerdotales pour faire les distributions à leurs frères répartis en classes, autant au grand qu'au petit, 
###### 16
et, sans tenir compte de leur enregistrement, aux hommes âgés de trente ans et plus, à tous ceux qui allaient au Temple de Yahvé selon le rituel quotidien, assurer le service de leurs fonctions, selon leurs classes. 
###### 17
Les prêtres furent enregistrés par familles et les lévites, âgés de vingt ans et plus, selon leurs fonctions et leurs classes. 
###### 18
Ils furent enregistrés avec toutes les personnes à leur charge, femmes, fils et filles, toute l'Assemblée, car ils devaient se sanctifier avec fidélité. 
###### 19
Pour les prêtres, fils d'Aaron, qui se trouvaient dans les terrains de pâturage de leurs villes et dans chaque ville, il y eut des hommes inscrits nominativement pour faire les répartitions à tout mâle parmi les prêtres et à tous ceux qui étaient enregistrés parmi les lévites. 
###### 20
C'est ainsi qu'agit Ézéchias en tout Juda. Il fit ce qui était bon, juste et loyal devant Yahvé, son Dieu. 
###### 21
Tout ce qu'il entreprit au service du Temple de Dieu, au sujet de la Loi et des commandements, il le fit en cherchant Dieu de tout son cœur, et il réussit. 
