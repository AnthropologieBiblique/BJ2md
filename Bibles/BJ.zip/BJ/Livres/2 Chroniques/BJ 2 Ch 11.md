---
aliases : 
- 2 Chroniques 11
- 2 Chroniques 11
- 2 Ch 11
- 2 Chronicles 11
tags : 
- Bible/2Ch/11
- français
cssclass : français
---

# 2 Chroniques 11

###### 1
Roboam se rendit à Jérusalem; il convoqua la maison de Juda et de Benjamin, soit cent quatre-vingt mille guerriers d'élite, pour combattre Israël et rendre le royaume à Roboam. 
###### 2
Mais la parole de Yahvé fut adressée à Shemaya, l'homme de Dieu, en ces termes : 
###### 3
" Dis ceci à Roboam, fils de Salomon, roi de Juda, et à tous les Israélites qui sont en Juda et en Benjamin : 
###### 4
Ainsi parle Yahvé. N'allez pas vous battre contre vos frères; que chacun retourne chez soi, car cet événement vient de moi. " Ils écoutèrent les paroles de Yahvé et firent demi-tour au lieu de marcher contre Jéroboam. 
###### 5
Roboam habita Jérusalem et construisit des villes fortifiées en Juda. 
###### 6
Il restaura Bethléem, Étam et Teqoa, 
###### 7
Bet-Çur, Soko, Adullam, 
###### 8
Gat, Maresha, Ziph, 
###### 9
Adorayim, Lakish, Azéqa, 
###### 10
Çoréa, Ayyalôn, Hébron; c'étaient des villes fortifiées en Juda et en Benjamin. 
###### 11
Il les fortifia puissamment et y mit des commandants, ainsi que des réserves de vivres, d'huile et de vin. 
###### 12
Dans chacune de ces villes il y avait des boucliers et des lances. Il les rendit extrêmement fortes et fut maître de Juda et de Benjamin. 
###### 13
Les prêtres et les lévites qui se trouvaient dans tout Israël quittèrent leur territoire pour s'établir près de lui. 
###### 14
Les lévites, en effet, abandonnèrent leurs pâturages et leurs patrimoines et vinrent en Juda et à Jérusalem, Jéroboam et ses fils les ayant exclus du sacerdoce de Yahvé. 
###### 15
Jéroboam avait établi des prêtres pour les hauts lieux, pour les satyres et pour les veaux qu'il avait fabriqués. 
###### 16
Des membres de toutes les tribus d'Israël qui avaient à cœur de rechercher Yahvé, Dieu d'Israël, les suivirent et vinrent à Jérusalem afin de sacrifier à Yahvé, Dieu de leurs pères. 
###### 17
Ils renforcèrent le royaume de Juda et, pendant trois ans, soutinrent Roboam, fils de Salomon, car c'est pendant trois ans qu'il suivit la voie de David et de Salomon. 
###### 18
Roboam prit pour femme Mahalat, fille de Yerimot, fils de David, et d'Abihayil, fille d'Éliab, fils de Jessé. 
###### 19
Elle lui donna des fils : Yéush, Shemarya et Zaham. 
###### 20
Il épousa après elle Maaka, fille d'Absalom, qui lui enfanta Abiyya, Attaï, Ziza et Shelomit. 
###### 21
Roboam aima Maaka, fille d'Absalom, plus que toutes ses autres femmes et concubines. Il avait en effet pris dix-huit femmes et soixante concubines, et engendré vingt-huit fils et soixante filles. 
###### 22
Roboam fit d'Abiyya, fils de Maaka, le chef de famille, prince parmi ses frères, afin de le faire roi. 
###### 23
Roboam fut avisé et il répartit certains de ses fils dans toutes les régions de Juda et de Benjamin et dans toutes les villes fortifiées; il les pourvut de vivres en abondance et leur trouva des femmes. 
