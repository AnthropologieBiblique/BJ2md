---
aliases : 
- 2 Chroniques 12
- 2 Chroniques 12
- 2 Ch 12
- 2 Chronicles 12
tags : 
- Bible/2Ch/12
- français
cssclass : français
---

# 2 Chroniques 12

###### 1
Alors que sa royauté s'était établie et affermie, Roboam abandonna la Loi de Yahvé, et tout Israël avec lui. 
###### 2
La cinquième année du règne de Roboam, le roi d'Égypte, Sheshonq, marcha contre Jérusalem, car elle avait été infidèle à Yahvé. 
###### 3
Avec mille deux cents chars, soixante mille chevaux et une innombrable armée de Libyens, de Sukkiens et de Kushites, qui vint avec lui d'Égypte, 
###### 4
il prit les villes fortifiées de Juda et atteignit Jérusalem. 
###### 5
Shemaya, le prophète, vint trouver Roboam et les officiers judéens qui, devant Sheshonq, s'étaient regroupés près de Jérusalem, et il leur dit : " Ainsi parle Yahvé. Vous m'avez abandonné, aussi vous ai-je abandonnés moi-même aux mains de Sheshonq. " 
###### 6
Alors les officiers israélites et le roi s'humilièrent et dirent : " Yahvé est juste. " 
###### 7
Quand Yahvé vit qu'ils s'humiliaient, la parole de Yahvé fut adressée à Shemaya en ces termes : " Ils se sont humiliés, je ne les exterminerai pas; sous peu je leur permettrai d'échapper et ce n'est pas par les mains de Sheshonq que ma colère s'abattra sur Jérusalem. 
###### 8
Mais ils deviendront ses esclaves et ils apprécieront ce que c'est que de me servir et de servir les royaumes des pays! " 
###### 9
Le roi d'Égypte Sheshonq marcha contre Jérusalem. Il se fit livrer les trésors du Temple de Yahvé et ceux du palais royal, absolument tout, jusqu'aux boucliers d'or qu'avait faits Salomon; 
###### 10
à leur place le roi Roboam fit des boucliers de bronze et les confia aux chefs des gardes qui veillaient à la porte du palais royal : 
###### 11
chaque fois que le roi allait au Temple de Yahvé, les gardes venaient les prendre, puis il les rapportaient à la salle des gardes. 
###### 12
Mais parce qu'il s'était humilié la colère de Yahvé se détourna de lui et ne l'anéantit pas complètement. Qui plus est, d'heureux événements survinrent en Juda, 
###### 13
le roi Roboam put s'affermir dans Jérusalem et régner. Il avait en effet quarante et un ans à son avènement et il régna dix-sept ans à Jérusalem, la ville que Yahvé avait choisie entre toutes les tribus d'Israël pour y placer son Nom. Sa mère s'appelait Naama, l'Ammonite. 
###### 14
Il fit le mal, parce qu'il n'avait pas disposé son cœur à rechercher Yahvé. 
###### 15
L'histoire de Roboam, du début à la fin, cela n'est-il pas écrit dans l'histoire du prophète Shemaya et du voyant Iddo ? Il y eut tout le temps des combats entre Roboam et Jéroboam. 
###### 16
Roboam se coucha avec ses pères et fut enterré dans la Cité de David; son fils Abiyya régna à sa place. 
