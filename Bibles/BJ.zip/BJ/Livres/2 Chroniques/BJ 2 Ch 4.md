---
aliases : 
- 2 Chroniques 4
- 2 Chroniques 4
- 2 Ch 4
- 2 Chronicles 4
tags : 
- Bible/2Ch/4
- français
cssclass : français
---

# 2 Chroniques 4

###### 1
Il fit un autel de bronze, long de vingt coudées, large de vingt et haut de dix. 
###### 2
Puis il coula la Mer en métal fondu, de dix coudées de bord à bord, à pourtour circulaire, de cinq coudées de hauteur; un fil de trente coudées en mesurait le tour. 
###### 3
Il y avait sous le pourtour des animaux ressemblant à des bœufs, l'encerclant tout autour. Incurvées sur dix coudées du pourtour de la Mer, deux rangées de bœufs avaient été coulées avec la masse. 
###### 4
La Mer reposait sur douze bœufs, trois regardaient vers le nord, trois regardaient vers l'ouest, trois regardaient vers le sud, trois regardaient vers l'est : la Mer s'élevait au-dessus d'eux et tous leurs arrière-trains étaient tournés vers l'intérieur. 
###### 5
Son épaisseur était d'un palme et son bord avait la même forme que le bord d'une coupe, comme une fleur. Elle contenait trois mille mesures. 
###### 6
Il fit dix bassins et en plaça cinq à droite et cinq à gauche pour y laver la victime de l'holocauste que l'on y purifiait, mais c'est dans la Mer que les prêtres se lavaient. 
###### 7
Il fit les dix chandeliers d'or du modèle prescrit et les mit dans le Hékal, cinq à droite et cinq à gauche. 
###### 8
Il fit dix tables qu'il installa dans le Hékal, cinq à droite et cinq à gauche. Il fit cent coupes d'aspersion en or. 
###### 9
Il fit le parvis des prêtres, la grande cour et ses portes qu'il revêtit de bronze. 
###### 10
Quant à la Mer, il l'avait placée à distance du côté droit, au sud-est. 
###### 11
Huram fit les vases à cendres, les pelles, les bols à aspersion. Il acheva tout l'ouvrage dont l'avait chargé le roi Salomon pour le Temple de Dieu : 
###### 12
deux colonnes; les tores des chapiteaux qui étaient au sommet des colonnes; les deux treillis pour couvrir les deux tores des chapiteaux qui étaient au sommet des colonnes; 
###### 13
les quatre cents grenades pour les deux treillis : les grenades pour chaque treillis étaient en deux rangées; 
###### 14
les dix bases et les dix bassins sur les bases; 
###### 15
la Mer unique et les douze bœufs sous la Mer; 
###### 16
les vases à cendres, les pelles, les fourchettes, et tous leurs accessoires que fit en bronze poli Huram-Abi pour le roi Salomon, pour le Temple de Yahvé. 
###### 17
C'est dans le district du Jourdain que le roi les coula en pleine terre, entre Sukkot et Çeréda. 
###### 18
Salomon fit tous ces objets en grand nombre, car on ne calculait pas le poids du bronze. 
###### 19
Salomon fit tous les objets destinés au Temple de Dieu : l'autel d'or et les tables sur lesquelles étaient les pains d'oblation; 
###### 20
les chandeliers et leurs lampes qui devaient, selon la règle, briller devant le Debir, en or fin; 
###### 21
les fleurons, les lampes et les mouchettes, en or et c'était de l'or pur ; 
###### 22
les couteaux, les coupes d'aspersion, les coupes et les encensoirs, en or fin; l'entrée du Temple, les portes intérieures pour le Saint des Saints et les portes du Temple pour le Hékal , en or. 
