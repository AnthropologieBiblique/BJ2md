---
aliases : 
- 2 Chroniques 3
- 2 Chroniques 3
- 2 Ch 3
- 2 Chronicles 3
tags : 
- Bible/2Ch/3
- français
cssclass : français
---

# 2 Chroniques 3

###### 1
Salomon commença alors la construction de la maison de Yahvé. C'était à Jérusalem, sur le mont Moriyya, là où son père David avait eu une vision. C'était le lieu préparé par David, l'aire d'Ornân le Jébuséen. 
###### 2
Salomon commença les constructions au second mois de la quatrième année de son règne. 
###### 3
Voici que l'édifice de la maison de Dieu, fondée par Salomon, eut une longueur de soixante coudées - coudée d'ancienne mesure - et une largeur de vingt. 
###### 4
Le vestibule qui se trouvait par devant avait une longueur de vingt coudées couvrant la largeur de la maison et une hauteur de cent vingt coudées. Salomon en revêtit d'or pur l'intérieur. 
###### 5
Quant à la grande salle, il la plaqua en bois de genévrier qu'il recouvrit d'un bel or et y dressa des palmes et des guirlandes. 
###### 6
Il sertit alors la salle de pierres précieuses, éclatantes; l'or était de l'or de Parvayim, 
###### 7
il en recouvrit la salle, les poutres, les seuils, les parois et les portes, et grava ensuite des chérubins sur les parois. 
###### 8
Puis il bâtit la salle du Saint des Saints dont la longueur de vingt coudées couvrait la largeur de la grande salle, et dont la largeur était de vingt coudées. Il la plaqua pour six cents talents d'un bel or; 
###### 9
les clous d'or pesaient cinquante sicles. Il plaqua d'or les chambres hautes. 
###### 10
Dans la salle du Saint des Saints il fit deux chérubins, ouvrage en métal forgé qu'il plaqua d'or. 
###### 11
Les ailes des chérubins avaient vingt coudées de long, chacune d'elles ayant cinq coudées et touchant l'une à la paroi de la salle, l'autre à celle de l'autre chérubin. 
###### 12
L'une des ailes de cinq coudées d'un chérubin touchait à la paroi de la salle; la seconde, de cinq coudées, touchait à l'aile de l'autre chérubin. 
###### 13
Déployées, les ailes de ces chérubins mesuraient vingt coudées. Eux-mêmes se tenaient debout, face à la Salle. 
###### 14
Il fit le Rideau de pourpre violette et écarlate, de cramoisi et de byssus; il y appliqua des chérubins. 
###### 15
Devant la salle, il fit deux colonnes longues de trente-cinq coudées que surmontait un chapiteau de cinq coudées. 
###### 16
Dans le Debir, il fit des guirlandes qu'il disposa au haut des colonnes et fit cent grenades qu'il mit dans les guirlandes. 
###### 17
Il dressa les colonnes devant le Hékal, l'une à droite et l'autre à gauche, et il appela Yakîn celle de droite, Boaz celle de gauche. 
