---
aliases : 
- 2 Chroniques 2
- 2 Chroniques 2
- 2 Ch 2
- 2 Chronicles 2
tags : 
- Bible/2Ch/2
- français
cssclass : français
---

# 2 Chroniques 2

###### 1
Il enrôla 70000 hommes pour le transport, 80000 pour extraire les pierres de la montagne et 3600 contremaîtres. 
###### 2
Puis Salomon envoya ce message à Huram, roi de Tyr : " Agis comme tu l'as fait envers mon père David en lui envoyant des cèdres pour se bâtir une maison où il résiderait. 
###### 3
Or voici que je bâtis une maison au nom de Yahvé mon Dieu pour reconnaître sa sainteté, brûler devant lui de l'encens parfumé, avoir en permanence des pains rangés, offrir des holocaustes le matin, le soir, aux sabbats, aux néoménies et aux solennités de Yahvé notre Dieu; et cela pour toujours en Israël. 
###### 4
La maison que je bâtis sera grande, car notre Dieu est plus grand que tous les dieux. 
###### 5
Qui serait en mesure de lui bâtir une maison quand les cieux et les cieux des cieux ne le peuvent contenir ? Et moi, qui suis-je pour lui bâtir une maison, si ce n'est pour que les fumées montent devant lui ? 
###### 6
Envoie-moi maintenant un homme habile à travailler l'or, l'argent, le bronze, le fer, l'écarlate, le cramoisi et la pourpre violette, et connaissant l'art de la gravure; il travaillera avec les artisans qui sont près de moi dans Juda et à Jérusalem, eux que mon père David a mis à ma disposition. 
###### 7
Envoie-moi du Liban des troncs de cèdre, de genévrier et d'algummim, car je sais que tes serviteurs savent abattre les arbres du Liban. Mes serviteurs travailleront avec les tiens. 
###### 8
Ils me prépareront du bois en quantité, car la maison que je veux bâtir sera d'une grandeur étonnante. 
###### 9
Je livre pour les bûcherons qui abattront les arbres 20000 muids de froment, 20.000 muids d'orge, 20000
###### 10
Huram, roi de Tyr, répondit par une lettre qu'il envoya à Salomon : " C'est parce qu'il aime son peuple que Yahvé t'en a fait le roi. " 
###### 11
Puis il ajouta : " Béni soit Yahvé le Dieu d'Israël! Il a fait les cieux et la terre, il a donné au roi David un fils sage, sensé et intelligent qui va bâtir une maison pour Yahvé et une autre pour y régner lui-même. 
###### 12
J'envoie aussitôt un homme habile et intelligent, Huram-Abi, 
###### 13
fils d'une Danite, et de père tyrien. Il sait travailler l'or, l'argent, le bronze, le fer, la pierre, le bois, l'écarlate, la pourpre violette, le byssus, le cramoisi, graver n'importe quoi et concevoir des projets. C'est lui qu'on fera travailler avec tes artisans et ceux de Monseigneur David, ton père. 
###### 14
Que soient alors envoyés à ses serviteurs le froment, l'orge, l'huile et le vin dont a parlé Monseigneur. 
###### 15
Quant à nous, nous abattrons au Liban tout le bois dont tu auras besoin, nous l'amènerons à Joppé en radeaux par mer, et c'est toi qui le feras monter à Jérusalem. " 
###### 16
Salomon fit le compte de tous les étrangers en résidence en terre d'Israël, d'après le recensement qu'en avait fait David son père, et on en trouva 153 600. 
###### 17
Il en affecta 70000 aux transports, 80000 aux carrières de la montagne, 3600 à la direction du travail de ces gens. 
