---
aliases : 
- 2 Chroniques 7
- 2 Chroniques 7
- 2 Ch 7
- 2 Chronicles 7
tags : 
- Bible/2Ch/7
- français
cssclass : français
---

# 2 Chroniques 7

###### 1
Quand Salomon eut fini de prier, le feu descendit du ciel, consuma l'holocauste et les sacrifices, et la gloire de Yahvé remplit le Temple. 
###### 2
Les prêtres ne purent entrer dans la maison de Yahvé, car la gloire de Yahvé remplissait la maison de Yahvé. 
###### 3
Tous les Israélites, voyant le feu descendre et la gloire de Yahvé reposer sur le Temple, se prosternèrent face contre terre sur le pavé; ils adorèrent et célébrèrent Yahvé " car il est bon, car éternel est son amour. " 
###### 4
Le roi et tout le peuple sacrifièrent devant Yahvé. 
###### 5
Le roi Salomon immola en sacrifice 22000 bœufs et 120.000 moutons, et le roi et tout le peuple dédièrent le Temple de Dieu. 
###### 6
Les prêtres se tenaient à leur poste et les lévites célébraient Yahvé avec les instruments qu'avait faits le roi David pour accompagner les cantiques de Yahvé " car éternel est son amour ". C'étaient eux qui exécutaient les louanges composées par David. A leurs côtés, les prêtres sonnaient de la trompette et tout Israël se tenait debout. 
###### 7
Salomon consacra le milieu de la cour qui était devant le Temple de Yahvé, car c'est là qu'il offrit les holocaustes et les graisses des sacrifices de communion. L'autel de bronze qu'avait fait Salomon ne pouvait en effet contenir l'holocauste, l'oblation et les graisses. 
###### 8
En ce temps-là, Salomon célébra la fête pendant sept jours et tous les Israélites avec lui, un très grand rassemblement depuis l'Entrée de Hamat jusqu'au Torrent d'Égypte. 
###### 9
Le huitième jour eut lieu une réunion solennelle, car on avait célébré la dédicace de l'autel pendant sept jours et célébré la fête pendant sept jours. 
###### 10
Le vingt-troisième jour du septième mois, Salomon renvoya le peuple chacun chez soi, joyeux et le cœur content du bien que Yahvé avait fait à David, à Salomon et à son peuple Israël. 
###### 11
Salomon acheva le Temple de Yahvé et le palais royal et il mena à bien tout ce qu'il désirait faire dans la maison de Yahvé et la sienne. 
###### 12
Yahvé apparut alors de nuit à Salomon et lui dit : " J'ai entendu ta prière et je me suis choisi ce lieu pour qu'il soit la maison des sacrifices. 
###### 13
Quand je fermerai le ciel et que la pluie fera défaut, quand j'ordonnerai aux sauterelles de dévorer le pays, quand j'enverrai la peste sur mon peuple, 
###### 14
si mon peuple sur qui est invoqué mon Nom s'humilie, prie, recherche ma présence et se repent de sa mauvaise conduite, moi, du ciel, j'écouterai, je pardonnerai ses péchés et je restaurerai son pays. 
###### 15
Désormais mes yeux sont ouverts, et mes oreilles attentives à la prière faite en ce lieu. 
###### 16
J'ai désormais choisi et consacré cette maison afin que mon Nom y soit à jamais; mes yeux et mon cœur y seront toujours. 
###### 17
Pour toi, si tu marches devant moi comme a fait ton père David, si tu agis selon tout ce que je te commande et si tu observes mes lois et mes ordonnances, 
###### 18
je maintiendrai ton trône royal comme je m'y suis engagé envers ton père David quand j'ai dit : "Il ne te manquera jamais un descendant qui règne en Israël. " 
###### 19
Mais si vous m'abandonnez, si vous délaissez les lois et les commandements que je vous ai proposés, si vous allez servir d'autres dieux et leur rendez hommage, 
###### 20
j'arracherai les Israélites de ma terre que je leur avais donnée; ce Temple que j'ai consacré à mon Nom, je le rejetterai de ma présence et j'en ferai la fable et la risée de tous les peuples. 
###### 21
Ce Temple qui aura été sublime, tous ceux qui le longeront seront stupéfaits et diront : "Pourquoi Yahvé a-t-il fait cela à ce pays et à ce Temple ?" 
###### 22
Et l'on répondra : "Parce qu'ils ont abandonné Yahvé, le Dieu de leurs pères, qui les avait fait sortir du pays d'Égypte, qu'ils se sont attachés à d'autres dieux et qu'ils leur ont rendu hommage et culte, voilà pourquoi il leur a envoyé tous ces maux". " 
