---
aliases : 
- 2 Chroniques 26
- 2 Chroniques 26
- 2 Ch 26
- 2 Chronicles 26
tags : 
- Bible/2Ch/26
- français
cssclass : français
---

# 2 Chroniques 26

###### 1
Tout le peuple de Juda choisit Ozias, qui avait seize ans, et le fit roi à la place de son père Amasias. 
###### 2
C'est lui qui rebâtit Élat et la rendit à Juda, après que le roi se fut couché avec ses pères. 
###### 3
Ozias avait seize ans à son avènement et il régna cinquante-deux ans à Jérusalem; sa mère s'appelait Yekolyahu et était de Jérusalem. 
###### 4
Il fit ce qui est agréable à Yahvé, comme tout ce qu'avait fait son père Amasias; 
###### 5
il s'appliqua à rechercher Dieu tant que vécut Zekaryahu, celui qui l'instruisait dans la crainte de Dieu. Tant qu'il chercha Yahvé, celui-ci le fit réussir. 
###### 6
Il partit combattre les Philistins, démantela les murailles de Gat, celles de Yabné et d'Ashdod, puis restaura des villes dans la région d'Ashdod et chez les Philistins. 
###### 7
Dieu l'aida contre les Philistins, les Arabes, les habitants de Gur-Baal et les Méûnites. 
###### 8
Les Ammonites payèrent tribut à Ozias. Sa renommée s'étendit jusqu'au seuil de l'Égypte, car il était devenu extrêmement puissant. 
###### 9
Ozias construisit des tours à Jérusalem, à la porte de l'Angle, à la porte de la Vallée, à l'Encoignure, et il les fortifia. 
###### 10
Il construisit aussi des tours dans le désert et creusa de nombreuses citernes, car il disposait d'un cheptel abondant dans le Bas-Pays et sur le Plateau, de laboureurs et de vignerons dans les montagnes et les vergers; il avait en effet le goût de l'agriculture. 
###### 11
Ozias eut une armée entraînée, prête à entrer en campagne, répartie en groupes recensés sous la surveillance du scribe Yeïel et du greffier Maaséyahu; elle était sous les ordres de Hananyahu, l'un des officiers royaux. 
###### 12
Le nombre total des chefs de famille de ces preux vaillants était de deux mille six cents. 
###### 13
Ils avaient sous leurs ordres l'armée de campagne, soit trois cent sept mille cinq cents guerriers, d'une grande valeur militaire pour prêter main-forte au roi contre l'ennemi. 
###### 14
A chaque campagne Ozias leur distribuait boucliers, lances, casques, cuirasses, arcs et pierres de fronde. 
###### 15
Il fit faire à Jérusalem des engins inventés par les ingénieurs, à placer sur les tours et les saillants pour lancer des flèches et de grosses pierres. Son renom s'étendit au loin, et il dut sa puissance à un secours vraiment miraculeux. 
###### 16
Quand il fut devenu puissant, son cœur s'enorgueillit jusqu'à le perdre : il prévariqua envers Yahvé son Dieu. Il vint dans la grande salle du Temple de Yahvé pour faire l'encensement sur l'autel des parfums. 
###### 17
Le prêtre Azaryahu, ainsi que quatre-vingts vertueux prêtres de Yahvé, vinrent 
###### 18
s'opposer au roi Ozias et lui dirent : " Ce n'est pas à toi, Ozias, d'encenser Yahvé, mais aux prêtres descendants d'Aaron consacrés à cet effet. Quitte le sanctuaire, car tu as prévariqué et tu n'as plus droit à la gloire qui vient de Yahvé Dieu. " 
###### 19
Ozias, tenant dans ses mains l'encensoir à parfum, s'emporta. Mais alors qu'il s'emportait contre les prêtres, la lèpre bourgeonna sur son front, en présence des prêtres, dans le Temple de Yahvé, près de l'autel des parfums! 
###### 20
Azaryahu, premier prêtre, et tous les prêtres se tournèrent vers lui et lui virent la lèpre au front. Ils l'expulsèrent en hâte et il se hâta lui-même de sortir, car Yahvé l'avait frappé. 
###### 21
Le roi Ozias fut affligé de la lèpre jusqu'au jour de sa mort. Il demeura confiné à la chambre, lépreux, vraiment exclu du Temple de Yahvé. Son fils Yotam était maître du palais et administrait le peuple du pays. 
###### 22
Le reste de l'histoire d'Ozias, du début à la fin, a été écrit par le prophète Isaïe, fils d'Amoç. 
###### 23
Puis Ozias se coucha avec ses pères et on l'enterra avec eux dans le terrain des sépultures royales, car on disait : " C'est un lépreux. " Son fils Yotam devint roi à sa place. 
