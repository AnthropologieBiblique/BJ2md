---
aliases : 
- 2 Chroniques 5
- 2 Chroniques 5
- 2 Ch 5
- 2 Chronicles 5
tags : 
- Bible/2Ch/5
- français
cssclass : français
---

# 2 Chroniques 5

###### 1
Alors fut achevé tout le travail que fit Salomon pour le Temple de Yahvé; et Salomon apporta ce que son père David avait consacré, l'argent, l'or et tous les vases, qu'il mit dans le trésor du Temple de Dieu. 
###### 2
Alors Salomon convoqua à Jérusalem les anciens d'Israël, tous les chefs des tribus et les princes des familles israélites, pour faire monter de la Cité de David, qui est Sion, l'arche de l'alliance de Yahvé. 
###### 3
Tous les hommes d'Israël se rassemblèrent auprès du roi, au septième mois, pendant la fête. 
###### 4
Tous les anciens d'Israël vinrent, et ce furent les lévites qui portèrent l'arche. 
###### 5
Ils portèrent l'arche et la Tente du Rendez-vous avec tous les objets sacrés qui y étaient; ce sont les prêtres lévites qui les transportèrent. 
###### 6
Puis le roi Salomon et toute la communauté d'Israël, réunie près de lui devant l'arche, sacrifièrent moutons et bœufs en quantité innombrable et incalculable. 
###### 7
Les prêtres apportèrent l'arche de l'alliance de Yahvé à sa place, au Debir du Temple, c'est-à-dire au Saint des Saints, sous les ailes des chérubins. 
###### 8
Les chérubins étendaient leurs ailes au-dessus de l'emplacement de l'arche et abritaient l'arche et ses barres. 
###### 9
Celles-ci étaient assez longues pour qu'on vît leur extrémité depuis le Saint, devant le Debir, mais pas en dehors de là; elles y sont restées jusqu'à ce jour. 
###### 10
Il n'y avait rien dans l'arche, sauf les deux tables que Moïse y déposa à l'Horeb, lorsque Yahvé avait conclu une alliance avec les Israélites à leur sortie d'Égypte. 
###### 11
Or, quand les prêtres sortirent du sanctuaire, - en effet, tous les prêtres qui se trouvaient là s'étaient sanctifiés sans garder l'ordre des classes; 
###### 12
les chantres lévites au complet : Asaph, Hémân et Yedutûn avec leurs fils et leurs frères s'étaient revêtus de byssus et jouaient des cymbales, de la lyre et de la cithare en se tenant à l'orient de l'autel, et cent vingt prêtres les accompagnaient en sonnant des trompettes. 
###### 13
Chacun de ceux qui jouaient de la trompette ou qui chantaient, louaient et célébraient Yahvé d'une seule voix; élevant la voix au son des trompettes, des cymbales et des instruments d'accompagnement, ils louaient Yahvé " car il est bon, car éternel est son amour " - le sanctuaire fut rempli par la nuée de la gloire de Yahvé. 
###### 14
Les prêtres ne purent pas continuer leur fonction à cause de la nuée, car la gloire de Yahvé remplissait le Temple de Dieu. 
