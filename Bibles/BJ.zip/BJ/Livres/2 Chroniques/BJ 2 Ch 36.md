---
aliases : 
- 2 Chroniques 36
- 2 Chroniques 36
- 2 Ch 36
- 2 Chronicles 36
tags : 
- Bible/2Ch/36
- français
cssclass : français
---

# 2 Chroniques 36

###### 1
Le peuple du pays prit Joachaz, fils de Josias, et on le fit roi à la place de son père à Jérusalem. 
###### 2
Joachaz avait vingt-trois ans à son avènement et il régna trois mois à Jérusalem. 
###### 3
Le roi d'Égypte l'enleva de Jérusalem et imposa au pays une contribution de cent talents d'argent et d'un talent d'or. 
###### 4
Puis le roi d'Égypte établit son frère Élyaqim comme roi sur Juda et Jérusalem, et il changea son nom en celui de Joiaqim. Quant à Joachaz, son frère, Neko le prit et l'emmena en Égypte. 
###### 5
Joiaqim avait vingt-cinq ans à son avènement et il régna onze ans à Jérusalem; il fit ce qui déplaît à Yahvé, son Dieu. 
###### 6
Nabuchodonosor, roi de Babylone, fit campagne contre lui et le mit aux fers pour l'emmener à Babylone. 
###### 7
Nabuchodonosor emporta aussi à Babylone une partie du mobilier du Temple de Yahvé et le déposa dans son palais de Babylone. 
###### 8
Le reste de l'histoire de Joiaqim, les abominations qu'il commit et ce qui a été relevé contre lui, cela est écrit dans le livre des Rois d'Israël et de Juda. Joiakîn son fils régna à sa place. 
###### 9
Joiakîn avait dix-huit ans à son avènement et il régna trois mois et dix jours à Jérusalem; il fit ce qui déplaît à Yahvé. 
###### 10
Au retour de l'année, le roi Nabuchodonosor l'envoya chercher et le fit conduire à Babylone avec le mobilier précieux du Temple de Yahvé, et il établit Sédécias son frère comme roi sur Juda et Jérusalem. 
###### 11
Sédécias avait vingt et un ans à son avènement et il régna onze ans à Jérusalem. 
###### 12
Il fit ce qui déplaît à Yahvé, son Dieu. Il ne s'humilia pas devant le prophète Jérémie venu sur l'ordre de Yahvé. 
###### 13
Il se révolta en outre contre le roi Nabuchodonosor auquel il avait prêté serment par Dieu. Il raidit sa nuque et endurcit son cœur au lieu de revenir à Yahvé, le Dieu d'Israël. 
###### 14
De plus, tous les chefs des prêtres et le peuple multiplièrent les infidélités, imitant toutes les abominations des nations, et souillèrent le Temple que Yahvé s'était consacré à Jérusalem. 
###### 15
Yahvé, le Dieu de leurs pères, leur envoya sans se lasser des messagers, car il voulait épargner son peuple et sa Demeure. 
###### 16
Mais ils tournaient en dérision les envoyés de Dieu, ils méprisaient ses paroles, ils se moquaient de ses prophètes, tant qu'enfin la colère de Yahvé contre son peuple fut telle qu'il n'y eut plus de remède. 
###### 17
Il fit monter contre eux le roi des Chaldéens qui passa au fil de l'épée leurs jeunes guerriers dans leur sanctuaire et n'épargna ni le jeune homme, ni la jeune fille, ni le vieillard, ni l'homme à la tête chenue. Dieu les livra tous entre ses mains. 
###### 18
Tous les objets du Temple de Dieu, grands et petits, les trésors du Temple de Yahvé, les trésors du roi et de ses officiers, il emporta le tout à Babylone. 
###### 19
On brûla le Temple de Dieu, on abattit les murailles de Jérusalem, on incendia tous ses palais et l'on détruisit tous ses objets précieux. 
###### 20
Puis Nabuchodonosor déporta à Babylone le reste échappé à l'épée; ils durent le servir ainsi que ses fils jusqu'à l'établissement du royaume perse, 
###### 21
accomplissant ainsi ce que Yahvé avait dit par la bouche de Jérémie : " Jusqu'à ce que le pays ait acquitté ses sabbats, il chômera durant tous les jours de la désolation, jusqu'à ce que soixante-dix ans soient révolus. " 
###### 22
Et la première année de Cyrus, roi de Perse, pour accomplir la parole de Yahvé prononcée par Jérémie, Yahvé éveilla l'esprit de Cyrus, roi de Perse, qui fit proclamer - et même afficher - dans tout son royaume : 
###### 23
" Ainsi parle Cyrus, roi de Perse : Yahvé, le Dieu du ciel, m'a remis tous les royaumes de la terre; c'est lui qui m'a chargé de lui bâtir un Temple à Jérusalem, en Juda. Quiconque, parmi vous, fait partie de tout son peuple, que son Dieu soit avec lui et qu'il monte! " 
