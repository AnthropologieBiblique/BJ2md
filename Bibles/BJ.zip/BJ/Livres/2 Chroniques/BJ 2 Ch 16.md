---
aliases : 
- 2 Chroniques 16
- 2 Chroniques 16
- 2 Ch 16
- 2 Chronicles 16
tags : 
- Bible/2Ch/16
- français
cssclass : français
---

# 2 Chroniques 16

###### 1
La trente-sixième année du règne d'Asa, Basha, roi d'Israël, marcha contre Juda; il fortifia Rama pour bloquer les communications d'Asa, roi de Juda. 
###### 2
Alors Asa puisa de l'or et de l'argent dans les trésors du Temple de Yahvé et du palais royal pour en faire l'envoi à Ben-Hadad, le roi d'Aram, qui résidait à Damas, avec ce message : 
###### 3
" Alliance entre moi et toi, entre mon père et ton père! Je t'envoie de l'argent et de l'or; va, romps ton alliance avec Basha, roi d'Israël, pour qu'il s'éloigne de moi! " 
###### 4
Ben-Hadad exauça le roi Asa et envoya ses chefs d'armée contre les villes d'Israël; il conquit Iyyôn, Dan, Abel-Mayim et tous les entrepôts des villes de Nephtali. 
###### 5
Quand Basha l'apprit, il arrêta les travaux de Rama et fit cesser l'ouvrage. 
###### 6
Alors le roi Asa amena tout Juda; on enleva les pierres et le bois avec lesquels Basha fortifiait Rama, et on s'en servit pour fortifier Géba et Miçpa. 
###### 7
C'est alors que Hanani le voyant vint trouver Asa, roi de Juda. Il lui dit : " Parce que tu t'es appuyé sur le roi d'Aram et non sur Yahvé ton Dieu, les forces du roi d'Aram échapperont à tes mains. 
###### 8
Kushites et Libyens ne formaient-ils pas une armée nombreuse avec une grande multitude de chars et de chevaux ? Or n'ont-ils pas été livrés entre tes mains parce que tu t'étais appuyé sur Yahvé ? 
###### 9
Puisque Yahvé parcourt des yeux toute la terre pour affermir ceux dont le cœur est tout entier tourné vers lui, tu as cette fois-ci agi en insensé et tu auras désormais la guerre. " 
###### 10
S'emportant contre le voyant, Asa le mit aux ceps en prison, car cela l'avait irrité; il prit en ce temps-là de dures mesures contre une partie du peuple. 
###### 11
L'histoire d'Asa, du début à la fin, est écrite au livre des Rois de Juda et d'Israël. 
###### 12
Asa eut les pieds malades, d'une maladie très grave, dans la trente-neuvième année de son règne; même alors, il n'eut pas recours dans sa maladie à Yahvé mais aux médecins. 
###### 13
Asa se coucha avec ses pères et mourut dans la quarante et unième année de son règne. 
###### 14
On l'enterra dans le tombeau qu'il s'était fait creuser dans la Cité de David. On l'étendit sur un lit tout rempli d'aromates, d'essences et d'onguents préparés; l'on fit pour lui un feu tout à fait grandiose. 
