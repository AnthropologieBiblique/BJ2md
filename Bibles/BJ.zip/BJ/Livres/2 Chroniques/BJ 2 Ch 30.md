---
aliases : 
- 2 Chroniques 30
- 2 Chroniques 30
- 2 Ch 30
- 2 Chronicles 30
tags : 
- Bible/2Ch/30
- français
cssclass : français
---

# 2 Chroniques 30

###### 1
Ézéchias envoya des messagers à tout Israël et Juda, et écrivit même des lettres à Éphraïm et à Manassé, pour que l'on vienne au Temple de Yahvé à Jérusalem célébrer une Pâque pour Yahvé, le Dieu d'Israël. 
###### 2
Le roi, ses officiers et toute l'Assemblée de Jérusalem furent d'avis de la célébrer le second mois 
###### 3
puisqu'on ne pouvait plus la faire au moment même, les prêtres ne s'étant pas sanctifiés en nombre suffisant et le peuple ne s'étant pas rassemblé à Jérusalem. 
###### 4
La chose parut juste au roi et à toute l'Assemblée. 
###### 5
On décida de faire passer à travers tout Israël, de Bersabée à Dan, un appel à venir célébrer à Jérusalem une Pâque pour Yahvé, Dieu d'Israël; peu, en effet, s'étaient conformés à l'Écriture. 
###### 6
Des courriers partirent, avec des lettres de la main du roi et des officiers, dans tout Israël et Juda. Ils devaient dire, selon l'ordre du roi : " Israélites, revenez à Yahvé, le Dieu d'Abraham, d'Isaac et d'Israël, et il reviendra à ceux d'entre vous qui restent après avoir échappé à la poigne des rois d'Assyrie. 
###### 7
Ne soyez pas comme vos pères et vos frères qui ont prévariqué envers Yahvé, le Dieu de leurs pères, et ont été livrés par lui à la ruine comme vous le voyez. 
###### 8
Ne raidissez plus vos nuques comme l'ont fait vos pères. Soumettez-vous à Yahvé, venez à son sanctuaire qu'il a consacré pour toujours, servez Yahvé votre Dieu et il détournera de vous son ardente colère. 
###### 9
Si vous revenez vraiment à Yahvé, vos frères et vos fils trouveront grâce devant leurs conquérants, ils reviendront en ce pays, car Yahvé votre Dieu est plein de pitié et de tendresse. Si vous revenez à lui, il ne détournera pas de vous sa face. " 
###### 10
Les courriers parcoururent, de ville en ville, le pays d'Éphraïm et de Manassé, et même de Zabulon, mais on se moqua d'eux et on les tourna en dérision. 
###### 11
Toutefois, quelques hommes d'Asher, de Manassé et de Zabulon s'humilièrent et vinrent à Jérusalem. 
###### 12
C'est plutôt en Juda que la main de Dieu agit pour donner à tous un seul cœur, afin d'exécuter les prescriptions du roi et des officiers contenues dans la Parole de Yahvé. 
###### 13
Un peuple nombreux se rassembla à Jérusalem pour célébrer au deuxième mois la fête des Azymes. Une assemblée extrêmement nombreuse 
###### 14
se mit à enlever les autels qui étaient dans Jérusalem et tous les brûle-parfums, pour les jeter dans la vallée du Cédron. 
###### 15
On immola la Pâque le quatorze du second mois. Pleins de confusion, les prêtres et les lévites se sanctifièrent et purent porter les holocaustes au Temple de Yahvé. 
###### 16
Puis ils se tinrent à leur poste, conformément à leurs statuts selon la loi de Moïse, homme de Dieu. Les prêtres versaient le sang qu'ils prenaient de la main des lévites, 
###### 17
car il y avait beaucoup de gens dans l'Assemblée qui ne s'étaient pas sanctifiés et les lévites étaient chargés d'immoler les victimes pascales au profit de ceux qui n'avaient pas la pureté requise pour les consacrer à Yahvé. 
###### 18
En effet, la majorité du peuple, beaucoup d'Éphraïmites, de Manassites, de fils d'Issachar et de Zabulon, ne s'étaient pas purifiés; ils avaient mangé la Pâque sans se conformer à l'Écriture. Mais Ézéchias pria pour eux; il dit : " Que Yahvé dans sa bonté couvre la faute de 
###### 19
quiconque s'est disposé de cœur à chercher Dieu, Yahvé, le Dieu de leurs pères, même s'il n'a pas la pureté requise pour les choses saintes! " 
###### 20
Yahvé exauça Ézéchias et laissa le peuple sain et sauf. 
###### 21
Les Israélites qui se trouvaient à Jérusalem célébrèrent pendant sept jours, et en grande joie, la fête des Azymes, tandis que les lévites et les prêtres louaient chaque jour Yahvé de toutes leurs forces. 
###### 22
Ézéchias encouragea les lévites qui avaient tous l'intelligence des choses de Yahvé, et pendant sept jours ils prirent part au festin de la solennité, célébrant les sacrifices de communion et louant Yahvé, le Dieu de leurs pères. 
###### 23
Puis toute l'Assemblée fut d'avis de célébrer sept autres jours de fête et ils en firent sept jours de joie. 
###### 24
Car Ézéchias, roi de Juda, avait fait un prélèvement de mille taureaux et de sept mille moutons pour l'Assemblée, et les officiers un autre de mille taureaux et de dix mille moutons. Les prêtres se sanctifièrent en masse, 
###### 25
et toute l'Assemblée des Judéens se réjouit, ainsi que les prêtres, les lévites, toute l'Assemblée venue d'Israël; les réfugiés venus du pays d'Israël aussi bien que ceux qui habitaient en Juda. 
###### 26
Il y eut grande joie à Jérusalem, car depuis les jours de Salomon, fils de David, roi d'Israël, rien de semblable ne s'était produit à Jérusalem. 
###### 27
Les prêtres lévites se mirent à bénir le peuple. Leur voix fut entendue et leur prière reçue en Sa demeure sainte des cieux. 
