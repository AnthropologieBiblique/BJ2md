---
aliases : 
- 2 Chroniques 24
- 2 Chroniques 24
- 2 Ch 24
- 2 Chronicles 24
tags : 
- Bible/2Ch/24
- français
cssclass : français
---

# 2 Chroniques 24

###### 1
Joas avait sept ans à son avènement et il régna quarante ans à Jérusalem; sa mère s'appelait Çibya, elle était de Bersabée. 
###### 2
Joas fit ce qui est agréable à Yahvé tout le temps que vécut le prêtre Yehoyada, 
###### 3
qui lui avait fait épouser deux femmes dont il eut des fils et des filles. 
###### 4
Après quoi Joas désira restaurer le Temple de Yahvé. 
###### 5
Il réunit les prêtres et les lévites et leur dit : " Partez dans les cités judéennes et recueillez auprès de tous les Israélites de l'argent pour réparer le Temple de votre Dieu, autant qu'il en faudra chaque année. Hâtez cette affaire. " Mais les lévites ne se pressèrent pas. 
###### 6
Alors le roi appela Yehoyada, le premier d'entre eux, et lui dit : " Pourquoi n'as-tu pas exigé des lévites qu'ils fassent rentrer de Juda et de Jérusalem le tribut de Moïse, serviteur de Yahvé, et de l'assemblée d'Israël, pour la Tente du Témoignage ? 
###### 7
Athalie et ses fils qu'elle a pervertis ont endommagé le Temple de Dieu et ont même attribué aux Baals tous les revenus sacrés du Temple de Yahvé. " 
###### 8
Et le roi ordonna de faire un coffre, qu'ils mirent devant la porte du Temple de Yahvé. 
###### 9
On proclama en Juda et à Jérusalem qu'il fallait apporter à Yahvé le tribut que Moïse, le serviteur de Dieu, avait imposé à Israël dans le désert. 
###### 10
Tous les officiers et tout le peuple vinrent avec joie jeter leur dû dans le coffre jusqu'à paiement complet. 
###### 11
Or, au moment d'apporter le coffre à l'administration royale qui était aux mains des lévites, ceux-ci virent qu'il y avait beaucoup d'argent; le secrétaire royal vint avec le préposé du premier prêtre; ils soulevèrent le coffre, l'emportèrent, puis le remirent en place. Ils firent ainsi chaque jour et recueillirent beaucoup d'argent. 
###### 12
Le roi et Yehoyada le donnèrent au maître d'œuvre attaché au service du Temple de Yahvé. Les salariés, maçons et charpentiers, se mirent à restaurer le Temple de Yahvé; des forgerons et des bronziers travaillèrent aussi à le réparer. 
###### 13
Les maîtres d'œuvre s'étant donc mis au travail, les réparations progressèrent entre leurs mains, ils réédifièrent le Temple de Dieu dans ses dimensions propres et le consolidèrent. 
###### 14
Quand ils eurent terminé, ils apportèrent au roi et à Yehoyada le reste de l'argent; on en fabriqua du mobilier pour le Temple de Yahvé, vases pour le service et les holocaustes, coupes et objets d'or et d'argent. On put ainsi offrir l'holocauste perpétuel dans le Temple de Yahvé tout le temps que vécut Yehoyada. 
###### 15
Puis Yehoyada vieillit et mourut rassasié de jours. Il avait cent trente ans à sa mort 
###### 16
et on l'ensevelit avec les rois dans la Cité de David, car il avait bien agi en Israël envers Dieu et son Temple. 
###### 17
Après la mort de Yehoyada, les officiers de Juda vinrent se prosterner devant le roi, et cette fois le roi les écouta. 
###### 18
Les Judéens abandonnèrent le Temple de Yahvé, Dieu de leurs pères, pour rendre un culte aux pieux sacrés et aux idoles. A cause de cette faute, la colère de Dieu s'abattit sur Juda et sur Jérusalem. 
###### 19
Des prophètes leur furent envoyés pour les ramener à Yahvé; mais ils témoignèrent contre eux sans qu'ils prêtent l'oreille. 
###### 20
L'Esprit de Dieu revêtit Zacharie, le fils du prêtre Yehoyada, qui se tint debout devant le peuple et lui dit : " Ainsi parle Dieu. Pourquoi transgressez-vous les commandements de Yahvé sans aboutir à rien ? Parce que vous avez abandonné Yahvé, il vous abandonne. " 
###### 21
Ils se liguèrent alors contre lui et sur l'ordre du roi le lapidèrent sur le parvis du Temple de Yahvé. 
###### 22
Le roi Joas, oubliant la générosité que lui avait témoignée Yehoyada, père de Zacharie, tua Zacharie son fils, qui en mourant s'écria : " Yahvé verra et demandera compte! " 
###### 23
Or, au retour de l'année, l'armée araméenne partit en guerre contre Joas. Elle atteignit Juda et Jérusalem, extermina parmi la population tous les officiers et envoya toutes leurs dépouilles au roi de Damas. 
###### 24
Certes, l'armée araméenne n'était venue qu'avec peu d'hommes, mais c'est une armée considérable que Yahvé livra entre ses mains pour l'avoir abandonné, lui, le Dieu de leurs pères. Les Araméens firent justice de Joas, 
###### 25
et quand ils le quittèrent, le laissant gravement malade, ses serviteurs se conjurèrent contre lui pour venger le fils du prêtre Yehoyada et le tuèrent sur son lit. Il mourut et on l'ensevelit dans la Cité de David, mais non pas dans les sépultures royales. 
###### 26
Voici les conjurés : Zabad fils de Shiméat l'Ammonite, Yehozabad fils de Shimrit la Moabite. 
###### 27
Quant à ses fils, l'importance du tribut qui lui fut imposé et la restauration du Temple de Dieu, on trouvera cela consigné dans le Midrash du livre des Rois. Amasias, son fils, régna à sa place. 
