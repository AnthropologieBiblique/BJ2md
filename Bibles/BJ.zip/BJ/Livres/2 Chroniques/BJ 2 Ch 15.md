---
aliases : 
- 2 Chroniques 15
- 2 Chroniques 15
- 2 Ch 15
- 2 Chronicles 15
tags : 
- Bible/2Ch/15
- français
cssclass : français
---

# 2 Chroniques 15

###### 1
L'esprit de Dieu vint sur Azaryahu, fils d'Oded, 
###### 2
qui sortit au-devant d'Asa. Il lui dit : " Asa, et vous tous, de Juda et de Benjamin, écoutez-moi! Yahvé est avec vous quand vous êtes avec lui. Quand vous le recherchez il se laisse trouver par vous, quand vous l'abandonnez il vous abandonne. 
###### 3
Israël passera bien des jours sans Dieu fidèle, sans prêtre pour l'enseigner, et sans loi; 
###### 4
mais dans sa détresse il reviendra à Yahvé, Dieu d'Israël, il le recherchera et Yahvé se laissera trouver par lui. 
###### 5
En ce temps-là, aucun adulte ne connaîtra la paix, mais des tribulations multiples pèseront sur tous les habitants du pays. 
###### 6
Les nations s'écraseront l'une contre l'autre, les villes l'une contre l'autre, car Dieu les frappera par toutes sortes de détresses. 
###### 7
Mais vous, soyez fermes et que vos mains ne faiblissent point, car vos actions auront leur récompense. " 
###### 8
Quand Asa entendit ces paroles et cette prophétie, il se décida à faire disparaître les horribles idoles de tout le pays de Juda et de Benjamin et des villes qu'il avait conquises dans la montagne d'Éphraïm, puis il remit en état l'autel de Yahvé qui se trouvait devant le Vestibule de Yahvé. 
###### 9
Il réunit tout Juda et Benjamin, ainsi que les Éphraïmites, les Manassites et les Siméonites qui séjournaient avec eux, car beaucoup d'Israélites s'étaient ralliés à Asa en voyant que Yahvé, son Dieu, était avec lui. 
###### 10
Le troisième mois de la quinzième année du règne d'Asa, ils se réunirent à Jérusalem. 
###### 11
Ils offrirent en sacrifice à Yahvé, ce jour-là, une part du butin qu'ils rapportaient, sept cents bœufs et sept mille moutons. 
###### 12
Ils s'engagèrent par une alliance à chercher Yahvé, le Dieu de leurs pères, de tout leur cœur et de toute leur âme; 
###### 13
quiconque ne chercherait pas Yahvé, Dieu d'Israël, serait mis à mort, grand ou petit, homme ou femme. 
###### 14
Ils prêtèrent serment à Yahvé à voix haute et par acclamation, au son des trompettes et des cors; 
###### 15
tous les Judéens furent joyeux de ce serment qu'ils avaient prêté de tout leur cœur. C'est de plein gré qu'ils cherchèrent Yahvé. Aussi se laissa-t-il trouver par eux et leur donna-t-il la tranquillité sur toutes leurs frontières. 
###### 16
Même Maaka, grand-mère du roi Asa, se vit retirer par lui la dignité de Grande Dame, parce qu'elle avait fait une horreur pour Ashéra; Asa abattit son horreur, la réduisit en poudre et la brûla dans la vallée du Cédron. 
###### 17
Les hauts lieux ne disparurent pas d'Israël; pourtant le cœur d'Asa resta intègre toute sa vie. 
###### 18
Il déposa dans le Temple de Dieu les saintes offrandes de son père et ses propres offrandes, de l'argent, de l'or et du mobilier. 
###### 19
Il n'y eut point de guerre jusqu'à la trente-cinquième année du règne d'Asa. 
