---
aliases : 
- 2 Chroniques 19
- 2 Chroniques 19
- 2 Ch 19
- 2 Chronicles 19
tags : 
- Bible/2Ch/19
- français
cssclass : français
---

# 2 Chroniques 19

###### 1
Josaphat, roi de Juda, retourna sain et sauf chez lui, à Jérusalem. 
###### 2
Jéhu, fils de Hanani le voyant, sortit à sa rencontre et dit au roi Josaphat : " Porte-t-on secours au méchant ? Aimerais-tu ceux qui haïssent Yahvé, pour attirer ainsi sur toi sa colère ? 
###### 3
Néanmoins, on a trouvé en toi quelque chose de bon, car tu as extirpé du pays les ashéras et tu as disposé ton cœur à la recherche de Dieu. " 
###### 4
Josaphat, après un séjour à Jérusalem, repartit à travers son peuple depuis Bersabée jusqu'à la montagne d'Éphraïm, afin de le ramener à Yahvé, le Dieu de ses pères. 
###### 5
Il établit des juges dans le pays pour toutes les villes fortifiées de Juda, dans chaque ville. 
###### 6
Il dit à ces juges : " Soyez attentifs à ce que vous faites, car vous ne jugez pas au nom des hommes mais de Yahvé, lui qui est avec vous quand vous prononcez une sentence. 
###### 7
Que la crainte de Yahvé pèse maintenant sur vous! Prenez garde à ce que vous faites, car Yahvé notre Dieu ne consent ni aux fraudes, ni aux privilèges, ni aux cadeaux acceptés. " 
###### 8
En outre, Josaphat établit à Jérusalem des prêtres, des lévites et des chefs de famille israélites, pour promulguer les sentences de Yahvé et juger les procès. Ils habitaient Jérusalem 
###### 9
et Josaphat leur donna ainsi ses prescriptions : " Vous remplirez de telles fonctions dans la crainte de Yahvé, dans la fidélité et l'intégrité du cœur. 
###### 10
Quel que soit le procès qu'introduiront devant vous vos frères établis dans leurs villes : affaire de meurtre, de contestation sur la Loi, sur un commandement, sur des décrets ou des coutumes, vous les éclairerez pour qu'ils ne se rendent point coupables devant Yahvé et que sa colère n'éclate pas contre vous et vos frères; en agissant ainsi vous ne serez point coupables. 
###### 11
Voici qu'Amaryahu, le premier prêtre, vous contrôlera pour toute affaire de Yahvé et Zebadyahu, fils de Yishmaèl, chef de la maison de Juda, pour toute affaire royale. Les lévites vous serviront de scribes. Soyez fermes, mettez cela en pratique et Yahvé sera là avec le bonheur. " 
