---
aliases : 
- 2 Chroniques 10
- 2 Chroniques 10
- 2 Ch 10
- 2 Chronicles 10
tags : 
- Bible/2Ch/10
- français
cssclass : français
---

# 2 Chroniques 10

###### 1
Roboam se rendit à Sichem, car c'est à Sichem que tout Israël était venu pour le proclamer roi. 
###### 2
Dès que Jéroboam fils de Nebat en fut informé - il était en Égypte, où il avait fui le roi Salomon - il revint d'Égypte. 
###### 3
On le fit appeler et il vint avec tout Israël. Ils parlèrent ainsi à Roboam : 
###### 4
" Ton père a rendu pénible notre joug, allège maintenant le dur servage de ton père, la lourdeur du joug qu'il nous imposa, et nous te servirons. " 
###### 5
Il leur répondit : " Attendez trois jours, puis revenez vers moi. " Et le peuple s'en alla. 
###### 6
Le roi Roboam prit conseil des anciens, qui avaient servi son père Salomon de son vivant, et demanda : " Que conseillez-vous de répondre à ce peuple ? " 
###### 7
Ils lui répondirent : " Si tu te montres bon envers ces gens, si tu leur es bienveillant et leur donnes de bonnes paroles, alors ils resteront toujours tes serviteurs. " 
###### 8
Mais il repoussa le conseil que les anciens lui avaient donné et consulta des jeunes gens qui l'assistaient, ses compagnons d'enfance. 
###### 9
Il leur demanda : " Que conseillez-vous que nous répondions à ce peuple, qui m'a parlé ainsi : "Allège le joug que ton père nous a imposé" ? " 
###### 10
Les jeunes gens, ses compagnons d'enfance, lui répondirent : " Voici ce que tu diras au peuple qui t'a dit : "Ton père a rendu pesant notre joug, mais toi allège notre charge", voici ce que tu leur répondras : "Mon petit doigt est plus gros que les reins de mon père! 
###### 11
Ainsi mon père vous a fait porter un joug pesant, moi, j'ajouterai encore à votre joug; mon père vous a châtiés avec des lanières, je le ferai, moi, avec des fouets à pointes de fer! " " 
###### 12
Jéroboam, avec tout le peuple, vint à Roboam le troisième jour, selon cet ordre qu'il avait donné : " Revenez vers moi le troisième jour. " 
###### 13
Le roi leur répondit durement. Le roi Roboam rejeta le conseil des anciens 
###### 14
et, suivant le conseil des jeunes, il leur parla ainsi : " Mon père a rendu pesant votre joug, moi j'y ajouterai encore; mon père vous a châtiés avec des lanières, je le ferai, moi, avec des fouets à pointes de fer. " 
###### 15
Le roi n'écouta donc pas le peuple : c'était une intervention de Dieu, pour accomplir la parole que Yahvé avait dite à Jéroboam, fils de Nebat, par le ministère d'Ahiyya de Silo, 
###### 16
et à tous les Israélites, à savoir : que le roi ne les écouterait pas. Ils répliquèrent alors au roi : " Quelle part avons-nous sur David ? Nous n'avons pas d'héritage sur le fils de Jessé. Chacun à ses tentes, Israël! Et maintenant, pourvois à ta maison, David. " Tout Israël regagna ses tentes. 
###### 17
Quant aux Israélites qui habitaient les villes de Juda, Roboam régna sur eux. 
###### 18
Le roi Roboam dépêcha Adoram, le chef de la corvée, mais les Israélites le lapidèrent et il mourut; alors le roi Roboam se vit contraint de monter sur son char pour fuir à Jérusalem. 
###### 19
Et Israël fut séparé de la maison de David, jusqu'à ce jour. 
