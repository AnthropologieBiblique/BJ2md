---
aliases : 
- 2 Chroniques 21
- 2 Chroniques 21
- 2 Ch 21
- 2 Chronicles 21
tags : 
- Bible/2Ch/21
- français
cssclass : français
---

# 2 Chroniques 21

###### 1
Josaphat se coucha avec ses pères et on l'enterra avec eux dans la Cité de David; son fils Joram régna à sa place. 
###### 2
Joram avait des frères, fils de Josaphat : Azarya, Yehiel, Zekaryahu, Azaryahu, Mikaèl et Shephatyahu; ce sont là tous les fils de Josaphat, roi d'Israël. 
###### 3
Leur père leur avait fait de multiples dons en argent, en or, en joyaux et en villes fortifiées de Juda, mais il avait laissé la royauté à Joram, car c'était l'aîné. 
###### 4
Joram put s'établir à la tête du royaume de son père, puis, s'étant affermi, il fit passer au fil de l'épée tous ses frères, plus quelques officiers d'Israël. 
###### 5
Joram avait trente-deux ans à son avènement et il régna huit ans à Jérusalem. 
###### 6
Il imita la conduite des rois d'Israël, comme avait fait la maison d'Achab, car il avait épousé une fille d'Achab; et il fit ce qui déplaît à Yahvé. 
###### 7
Cependant Yahvé ne voulut pas détruire la maison de David à cause de l'alliance qu'il avait conclue avec lui et selon la promesse qu'il lui avait faite de lui laisser toujours une lampe ainsi qu'à ses fils. 
###### 8
De son temps, Édom s'affranchit de la domination de Juda et se donna un roi. 
###### 9
Joram passa la frontière, et avec lui ses officiers et tous ses chars. Il se leva de nuit, et força la ligne des Édomites qui l'encerclaient, et les commandants de chars avec lui. 
###### 10
Ainsi Édom s'affranchit de la domination de Juda, jusqu'à ce jour. C'est aussi l'époque où Libna s'affranchit de sa domination. Il avait en effet abandonné Yahvé, le Dieu de ses pères. 
###### 11
C'est aussi lui qui institua des hauts lieux sur les montagnes de Juda, qui fit se prostituer les habitants de Jérusalem et s'égarer les Judéens. 
###### 12
Un écrit du prophète Élie lui parvint alors, qui disait : " Ainsi parle Yahvé, le Dieu de ton père David. Parce que tu n'as pas suivi la conduite de Josaphat ton père, ni celle d'Asa, roi de Juda, 
###### 13
mais parce que tu as suivi la conduite des rois d'Israël et que tu es cause de la prostitution des Judéens et des habitants de Jérusalem, comme l'a été la maison d'Achab, et parce que tu as en outre assassiné tes frères, ta famille, qui étaient meilleurs que toi, 
###### 14
Yahvé va frapper d'un grand désastre ton peuple et tes fils, tes femmes et tous tes biens. 
###### 15
Toi-même tu seras frappé de graves maladies, d'un mal d'entrailles tel que par cette maladie, jour après jour, tu te videras de tes entrailles. " 
###### 16
Yahvé excita contre Joram l'animosité des Philistins et des Arabes voisins des Kushites. 
###### 17
Ils attaquèrent Juda, y pénétrèrent, et razzièrent tous les biens qui se trouvaient appartenir à la maison du roi, et même ses fils et ses femmes, et il ne lui resta plus d'autre fils qu'Ochozias, le plus petit d'entre eux. 
###### 18
Après tout cela, Yahvé le frappa d'une maladie d'entrailles incurable; 
###### 19
cela arriva jour après jour, et vers la fin de la deuxième année, il se vida de ses entrailles et mourut dans de cruelles souffrances. Le peuple ne lui fit pas de feux comme il en avait fait pour ses pères. 
###### 20
Il avait trente-deux ans à son avènement et régna huit ans à Jérusalem. Il s'en alla sans laisser de regrets et on l'enterra dans la Cité de David, mais non dans les sépultures royales. 
