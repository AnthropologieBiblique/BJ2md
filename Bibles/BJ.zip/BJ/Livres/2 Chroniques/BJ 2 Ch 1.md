---
aliases : 
- 2 Chroniques 1
- 2 Chroniques 1
- 2 Ch 1
- 2 Chronicles 1
tags : 
- Bible/2Ch/1
- français
cssclass : français
---

# 2 Chroniques 1

###### 1
Salomon, fils de David, s'affermit sur son trône. Yahvé son Dieu était avec lui et porta au faîte sa grandeur. 
###### 2
Salomon parla alors à tout Israël, aux officiers de milliers et de centaines, aux juges et à tous les princes de tout Israël, chefs de famille. 
###### 3
Puis, avec toute l'assemblée, Salomon se rendit au haut lieu de Gabaôn où se trouvait en effet la Tente du Rendez-vous de Dieu, faite dans le désert par Moïse, serviteur de Yahvé; 
###### 4
mais David avait fait monter l'arche de Dieu de Qiryat-Yéarim jusqu'à l'endroit qu'il avait préparé pour elle : il lui avait en effet dressé une tente à Jérusalem. 
###### 5
L'autel de bronze qu'avait fait Beçaléel, fils de Uri, fils de Hur, était là devant la Demeure de Yahvé où Salomon et l'assemblée venaient le consulter. 
###### 6
C'est là que Salomon, en présence de Dieu, monta à l'autel de bronze qui était attenant à la Tente du Rendez-vous et il y offrit mille holocaustes. 
###### 7
La nuit même, Dieu se montra à Salomon et lui dit : " Demande ce que je dois te donner. " 
###### 8
Salomon répondit à Dieu : " Tu as témoigné une grande bienveillance à David mon père et tu m'as établi roi à sa place. 
###### 9
Yahvé Dieu, la promesse que tu as faite à mon père David s'accomplit maintenant puisque tu m'as établi roi sur un peuple aussi nombreux que la poussière de la terre. 
###### 10
Donne-moi donc à présent sagesse et savoir pour agir en chef à la tête de ce peuple, car qui pourrait gouverner un peuple aussi grand que le tien ? " 
###### 11
Dieu dit à Salomon : " Puisque tel est ton désir, puisque tu n'as demandé ni richesse, ni trésors, ni gloire, ni la vie de tes ennemis, puisque tu n'as pas même demandé de longs jours, mais sagesse et savoir pour gouverner mon peuple dont je t'ai établi roi, 
###### 12
la sagesse et le savoir te sont donnés. Je te donne aussi richesse, trésors et gloire comme n'en eut aucun des rois qui t'ont précédé et comme n'en auront point ceux qui viendront après toi. " 
###### 13
Salomon quitta le haut lieu de Gabaôn pour Jérusalem, loin de la Tente du Rendez-vous; il régna sur Israël. 
###### 14
Il rassembla des chars et des chevaux; il eut mille quatre cents chars et mille deux cents chevaux, et il les cantonna dans les villes des chars et près du roi à Jérusalem. 
###### 15
Le roi fit que l'argent et l'or étaient aussi communs à Jérusalem que les cailloux, et les cèdres aussi nombreux que les sycomores du Bas-Pays. 
###### 16
Les chevaux de Salomon étaient importés de Muçur et de Cilicie; les courtiers du roi en prenaient livraison en Cilicie à prix d'argent. 
###### 17
Ils s'en allaient aussi importer d'Égypte des chars à six cents sicles l'unité; un cheval en valait cent cinquante; il en était de même pour tous les rois des Hittites et les rois d'Aram qui les importaient par leur entremise. 
###### 18
Salomon ordonna de bâtir une maison au nom de Yahvé et une autre pour y régner lui-même. 
