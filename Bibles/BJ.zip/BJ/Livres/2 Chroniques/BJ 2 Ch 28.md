---
aliases : 
- 2 Chroniques 28
- 2 Chroniques 28
- 2 Ch 28
- 2 Chronicles 28
tags : 
- Bible/2Ch/28
- français
cssclass : français
---

# 2 Chroniques 28

###### 1
Achaz avait vingt ans à son avènement et il régna seize ans à Jérusalem. Il ne fit pas ce qui est agréable à Yahvé comme avait fait David son ancêtre. 
###### 2
Il imita la conduite des rois d'Israël et même il fit fondre des idoles pour les Baals, 
###### 3
il fit fumer des offrandes dans le val des fils de Hinnom et fit passer ses fils par le feu, selon les coutumes abominables des nations que Yahvé avait chassées devant les Israélites. 
###### 4
Il offrit des sacrifices et de l'encens sur les hauts lieux, sur les collines et sous tout arbre verdoyant. 
###### 5
Yahvé son Dieu le livra aux mains du roi des Araméens. Ceux-ci le battirent et lui enlevèrent de nombreux captifs qu'ils emmenèrent à Damas. Il fut livré aussi aux mains du roi d'Israël, qui lui infligea une lourde défaite. 
###### 6
Péqah, fils de Remalyahu, tua en un seul jour cent vingt mille hommes en Juda, tous vaillants, pour avoir abandonné Yahvé, le Dieu de leurs pères. 
###### 7
Zikri, héros éphraïmite, tua Maaséyahu, fils du roi, Azriqam, chef du palais, et Elqana le lieutenant du roi. 
###### 8
Les Israélites firent à leurs frères deux cent mille prisonniers, femmes, fils et filles; ils razzièrent de plus un important butin et emmenèrent le tout à Samarie. 
###### 9
Il y avait là un prophète de Yahvé nommé Oded. Il sortit au-devant des troupes qui arrivaient à Samarie et leur dit : " Voici que Yahvé, le Dieu de vos pères, a livré les Judéens entre vos mains parce qu'il était irrité contre eux, mais vous les avez massacrés avec une telle fureur que le ciel en est atteint. 
###### 10
Et vous parlez maintenant de réduire les enfants de Juda et de Jérusalem à devenir vos serviteurs et vos servantes! Mais vous-mêmes, n'êtes-vous pas coupables envers Yahvé votre Dieu ? 
###### 11
Écoutez-moi maintenant, rendez les prisonniers faits à vos frères, car l'ardente colère de Yahvé vous menace. " 
###### 12
Certains des chefs éphraïmites, Azaryahu fils de Yehohanân, Bérékyahu fils de Meshillemot, Yehizqiyyahu fils de Shallum, Amasa fils de Hadlaï, s'élevèrent alors contre ceux qui revenaient de l'expédition. 
###### 13
Ils leurs dirent : " Vous ne ferez pas entrer ici ces prisonniers, car c'est de nous rendre coupables envers Yahvé que vous parlez, c'est d'ajouter à nos péchés et à nos fautes, alors que notre culpabilité est énorme et qu'une ardente colère menace Israël. " 
###### 14
L'armée abandonna alors les prisonniers et le butin en présence des officiers et de toute l'assemblée. 
###### 15
Des hommes, qui avaient été nominativement désignés, se mirent à réconforter les prisonniers. Prélevant sur le butin, ils habillèrent tous ceux qui étaient nus; ils les vêtirent, les chaussèrent, les nourrirent, les désaltérèrent et les abritèrent. Puis ils les reconduisirent, les éclopés montés sur des ânes, et les amenèrent auprès de leurs frères à Jéricho, la ville des palmiers. Puis ils rentrèrent à Samarie. 
###### 16
C'est alors que le roi Achaz envoya demander au roi d'Assyrie de lui porter secours. 
###### 17
Les Édomites envahirent de nouveau Juda, le battirent et emmenèrent des prisonniers. 
###### 18
Les Philistins se répandirent dans les villes du Bas-Pays et du Négeb de Juda. Ils prirent Bet-Shémesh, Ayyalôn, Gedérot, Soko et ses dépendances, Timna et ses dépendances, Gimzo et ses dépendances, et s'y établirent. 
###### 19
Yahvé abaissa en effet Juda à cause d'Achaz, roi d'Israël, qui laissait aller Juda et était infidèle à Yahvé. 
###### 20
Téglat-Phalasar, roi d'Assyrie, l'attaqua et l'assiégea sans pouvoir l'emporter; 
###### 21
mais Achaz dut prélever une part des biens du Temple de Yahvé et des maisons royale et princières, pour les envoyer au roi d'Assyrie, sans recevoir secours de lui. 
###### 22
Tandis qu'il était assiégé, il accrut son infidélité envers Yahvé, lui, le roi Achaz, 
###### 23
en offrant des sacrifices aux dieux de Damas dont il était la victime : " Puisque les dieux des rois d'Aram leur prêtent main-forte, disait-il, je leur sacrifierai pour qu'ils m'aident. " Mais ce furent eux qui causèrent sa chute, et celle de tout Israël. 
###### 24
Achaz rassembla le mobilier du Temple de Dieu, il le mit en pièces, ferma les portes du Temple de Yahvé et se fit des autels à tous les coins de rue de Jérusalem; 
###### 25
il institua des hauts lieux dans toutes les cités judéennes pour y encenser d'autres dieux, et provoqua l'irritation de Yahvé, le Dieu de ses pères. 
###### 26
Le reste de son histoire et de toute sa politique, du début à la fin, est écrit dans le livre des Rois de Juda et d'Israël. 
###### 27
Achaz se coucha avec ses pères, on l'enterra dans la Cité, à Jérusalem, sans le transporter dans les tombeaux des rois d'Israël. Son fils Ézéchias régna à sa place. 
