---
aliases : 
- 2 Chroniques 27
- 2 Chroniques 27
- 2 Ch 27
- 2 Chronicles 27
tags : 
- Bible/2Ch/27
- français
cssclass : français
---

# 2 Chroniques 27

###### 1
Yotam avait vint-cinq ans à son avènement et il régna seize ans à Jérusalem; sa mère s'appelait Yerusha, fille de Sadoq. 
###### 2
Il fit ce qui est agréable à Yahvé, imitant en tout la conduite de son père Ozias. Seulement il n'entra pas dans le sanctuaire de Yahvé. Mais le peuple continua à se perdre. 
###### 3
C'est lui qui construisit la Porte Supérieure du Temple de Yahvé, et fit de nombreux travaux au mur de l'Ophel. 
###### 4
Il construisit des villes dans la montagne de Juda ainsi que des citadelles et des tours dans les terres labourables. 
###### 5
Il combattit le roi des Ammonites. Il l'emporta sur eux et les Ammonites lui livrèrent cette année-là cent talents d'argent, dix mille muids de froment et dix mille d'orge. C'est cela que les Ammonites durent lui rendre; il en fut de même la seconde et la troisième année. 
###### 6
Yotam devint puissant, car il se conduisait avec fermeté en présence de Yahvé son Dieu. 
###### 7
Le reste de l'histoire de Yotam, toutes ses guerres et sa politique, est écrit dans le livre des rois d'Israël et de Juda. 
###### 8
Il avait vingt-cinq ans à son avènement et il régna seize ans à Jérusalem. 
###### 9
Puis Yotam se coucha avec ses pères, on l'enterra dans la Cité de David, et son fils Achaz devint roi à sa place. 
