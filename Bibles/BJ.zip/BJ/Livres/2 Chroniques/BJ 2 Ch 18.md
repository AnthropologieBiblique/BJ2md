---
aliases : 
- 2 Chroniques 18
- 2 Chroniques 18
- 2 Ch 18
- 2 Chronicles 18
tags : 
- Bible/2Ch/18
- français
cssclass : français
---

# 2 Chroniques 18

###### 1
Josaphat eut donc beaucoup de richesses et d'honneur et il s'allia par mariage avec Achab. 
###### 2
Au bout de quelques années, il vint visiter Achab à Samarie. Achab immola quantité de moutons et de bœufs pour lui et sa suite afin de l'inciter à attaquer Ramot de Galaad. 
###### 3
Achab, roi d'Israël, dit à Josaphat, roi de Juda : " Viendras-tu avec moi à Ramot de Galaad ? " Il lui répondit : " Il en sera de la bataille pour moi comme pour toi, pour mes gens comme pour tes gens. " 
###### 4
Cependant Josaphat dit au roi d'Israël : " Je te prie, consulte d'abord la parole de Yahvé. " 
###### 5
Le roi d'Israël rassembla les prophètes, au nombre de quatre cents, et leur demanda : " Devons-nous aller attaquer Ramot de Galaad, ou dois-je y renoncer ? " Ils répondirent : " Monte, Dieu la livrera aux mains du roi. " 
###### 6
Mais Josaphat dit : " N'y a-t-il donc ici aucun autre prophète de Yahvé, par qui nous puissions le consulter ? " 
###### 7
Le roi d'Israël répondit à Josaphat : " Il y a encore un homme par qui on peut consulter Yahvé, mais je le hais, car il ne prophétise jamais le bien à mon sujet, mais toujours du mal : c'est Michée, fils de Yimla. " Josaphat dit : " Que le roi ne parle pas ainsi! " 
###### 8
Le roi d'Israël appela un eunuque et dit : " Fais vite venir Michée, fils de Yimla. " 
###### 9
Le roi d'Israël et Josaphat, roi de Juda, étaient assis, chacun sur son trône, en grand costume; ils siégeaient sur l'aire devant la porte de Samarie et tous les prophètes se livraient à leurs transports devant eux. 
###### 10
Sédécias, fils de Kenaana, se fit des cornes de fer et dit : " Ainsi parle Yahvé. Avec cela tu encorneras les Araméens jusqu'au dernier. " 
###### 11
Et tous les prophètes faisaient la même prédiction, disant : " Monte à Ramot de Galaad! Tu réussiras, Yahvé la livrera aux mains du roi. " 
###### 12
Le messager qui était allé chercher Michée lui dit : " Voici que les prophètes n'ont qu'une seule bouche pour parler en faveur du roi. Tâche de parler comme l'un d'eux et prédis le succès. " 
###### 13
Mais Michée répondit : " Par Yahvé vivant! Ce que mon Dieu dira, c'est cela que j'énoncerai. " 
###### 14
Il arriva près du roi, et le roi lui demanda : " Michée, devons-nous aller combattre à Ramot de Galaad, ou dois-je y renoncer ? " Il répondit : " Montez! Vous réussirez, ses habitants seront livrés entre vos mains. " 
###### 15
Mais le roi lui dit : " Combien de fois me faudra-t-il t'adjurer de ne me dire que la vérité au nom de Yahvé ? " 
###### 16
Alors il prononça : " J'ai vu tout Israël dispersé sur les montagnes comme un troupeau sans pasteur. Et Yahvé a dit : ils n'ont plus de maître, que chacun retourne en paix chez soi! " 
###### 17
Le roi d'Israël dit alors à Josaphat : " Ne t'avais-je pas dit qu'il prophétisait pour moi non le bien mais le mal ? " 
###### 18
Michée reprit : " Écoutez plutôt la parole de Yahvé : J'ai vu Yahvé assis sur son trône; toute l'armée du ciel se tenait à sa droite et à sa gauche. 
###### 19
Yahvé demanda : "Qui trompera Achab, le roi d'Israël, pour qu'il marche contre Ramot de Galaad et qu'il y succombe ?" Ils répondirent, celui-ci d'une manière et celui-là d'une autre. 
###### 20
Alors l'Esprit s'avança et se tint devant Yahvé : "C'est moi, dit-il, qui le tromperai. " Yahvé lui demanda : "Comment ?" 
###### 21
Il répondit : "J'irai et je me ferai esprit de mensonge dans la bouche de tous ses prophètes. " Yahvé dit : "Tu le tromperas, tu réussiras. Va et fais ainsi. " 
###### 22
Voici donc que Yahvé a mis un esprit de mensonge dans la bouche de tes prophètes qui sont là, mais Yahvé a prononcé contre toi le malheur. " 
###### 23
Alors Sédécias, fils de Kenaana, s'approcha et frappa Michée à la mâchoire, en disant : " Par quelle voie l'esprit de Yahvé m'a-t-il quitté pour te parler ? " 
###### 24
Michée repartit : " C'est ce que tu verras le jour où tu fuiras dans une chambre retirée pour te cacher. " 
###### 25
Le roi d'Israël ordonna : " Saisissez Michée, et remettez-le à Amon, gouverneur de la ville, et au fils du roi, Yoas. 
###### 26
Vous leur direz : "Ainsi parle le roi. Mettez cet homme en prison et nourrissez-le strictement de pain et d'eau jusqu'à ce que je revienne sain et sauf". " 
###### 27
Michée dit : " Si tu reviens sain et sauf, c'est que Yahvé n'a pas parlé par ma bouche. " 
###### 28
Le roi d'Israël et Josaphat, roi de Juda, marchèrent contre Ramot de Galaad. 
###### 29
Le roi d'Israël dit à Josaphat : " Je me déguiserai pour marcher au combat, mais toi, revêts ton costume! " Le roi d'Israël se déguisa et il marchèrent au combat. 
###### 30
Le roi d'Aram avait donné cet ordre à ses commandants de chars : " Vous n'attaquerez ni petit ni grand, mais seulement le roi d'Israël. " 
###### 31
Lorsque les commandants de chars virent Josaphat, ils dirent : " C'est le roi d'Israël ", et ils concentrèrent sur lui le combat; mais Josaphat poussa son cri de guerre, Yahvé lui vint en aide et Dieu les entraîna loin de lui. 
###### 32
Lorsque les commandants de chars virent que ce n'était pas le roi d'Israël, ils s'éloignèrent de lui. 
###### 33
Or un homme banda son arc sans savoir qui il visait et atteignit le roi d'Israël entre le corselet et les appliques de la cuirasse. Celui-ci dit au charrier : " Tourne bride et fais-moi sortir de la mêlée, car je me sens mal. " 
###### 34
Mais le combat se fit plus violent ce jour-là; le roi d'Israël, jusqu'au soir, resta debout sur son char en face des Araméens et, au coucher du soleil, il mourut. 
