---
aliases : 
- 2 Chroniques 33
- 2 Chroniques 33
- 2 Ch 33
- 2 Chronicles 33
tags : 
- Bible/2Ch/33
- français
cssclass : français
---

# 2 Chroniques 33

###### 1
Manassé avait douze ans à son avènement et il régna cinquante-cinq ans à Jérusalem. 
###### 2
Il fit ce qui déplaît à Yahvé, imitant les abominations des nations que Yahvé avait chassées devant les Israélites. 
###### 3
Il rebâtit les hauts lieux qu'avait détruits Ézéchias son père, il éleva des autels aux Baals et fabriqua des pieux sacrés, il se prosterna devant toute l'armée du ciel et lui rendit un culte. 
###### 4
Il construisit des autels dans le Temple de Yahvé, dont Yahvé avait dit : " C'est à Jérusalem que mon Nom sera à jamais. " 
###### 5
Il construisit des autels à toute l'armée du ciel dans les deux cours du Temple de Yahvé. 
###### 6
C'est lui qui fit passer ses enfants par le feu dans la vallée des fils de Hinnom. Il pratiqua les incantations, la divination et la magie, installa des nécromants et des devins, et multiplia les actions que Yahvé regarde comme mauvaises, provoquant ainsi sa colère. 
###### 7
Il plaça l'idole, qu'il avait fait sculpter, dans le Temple de Dieu, dont Dieu avait dit à David et à son fils Salomon : " Dans ce Temple et dans Jérusalem, la ville que j'ai choisie entre toutes les tribus d'Israël, je placerai mon Nom à jamais. 
###### 8
Je ne détournerai plus les pas des Israélites de la terre où j'ai établi vos pères, pourvu qu'ils veillent à pratiquer tout ce que je leur ai commandé selon toute la Loi, les prescriptions et les coutumes transmises par Moïse. " 
###### 9
Mais Manassé égara les Judéens et les habitants de Jérusalem, au point qu'ils agirent encore plus mal que les nations que Yahvé avait exterminées devant les Israélites. 
###### 10
Yahvé parla à Manassé et à son peuple, mais ils ne prêtèrent pas l'oreille. 
###### 11
Alors Yahvé fit venir contre eux les généraux du roi d'Assyrie qui capturèrent Manassé avec des crocs, le mirent aux fers et l'emmenèrent à Babylone. 
###### 12
A l'occasion de cette épreuve, il chercha à apaiser Yahvé, son Dieu, il s'humilia profondément devant le Dieu de ses pères; 
###### 13
il le pria et lui se laissa fléchir. Il entendit sa supplication et le réintégra dans sa royauté, à Jérusalem. Manassé reconnut que c'est Yahvé qui est Dieu. 
###### 14
Après quoi, il restaura la muraille extérieure de la Cité de David, à l'ouest du Gihôn situé dans le ravin, jusqu'à la porte des Poissons; elle entoura l'Ophel et il la suréleva beaucoup. Il mit des généraux dans toutes les villes fortifiées de Juda. 
###### 15
Il écarta alors du Temple de Yahvé les dieux de l'étranger et la statue, ainsi que tous les autels qu'il avait construits sur la montagne du Temple et dans Jérusalem; il les jeta hors de la ville. 
###### 16
Il rétablit l'autel de Yahvé, y offrit des sacrifices de communion et de louange, et ordonna aux Judéens de servir Yahvé, Dieu d'Israël; 
###### 17
mais le peuple continuait de sacrifier sur les hauts lieux, bien qu'à Yahvé son Dieu. 
###### 18
Le reste de l'histoire de Manassé, la prière qu'il fit à son Dieu et les paroles des voyants qui s'adressèrent à lui au nom de Yahvé, Dieu d'Israël, se trouvent dans les Actes des rois d'Israël. 
###### 19
Sa prière et son exaucement, tous ses péchés et son impiété, les endroits où il avait construit des hauts lieux et dressé des pieux sacrés et des idoles avant de s'être humilié, sont consignés dans l'histoire de Hozaï. 
###### 20
Manassé se coucha avec ses pères et on l'enterra dans le jardin de son palais. Son fils Amon régna à sa place. 
###### 21
Amon avait vingt-deux ans à son avènement et il régna deux ans à Jérusalem. 
###### 22
Il fit ce qui déplaît à Yahvé, comme avait fait son père Manassé. Amon sacrifia et rendit un culte à toutes les idoles qu'avait faites son père Manassé. 
###### 23
Il ne s'humilia pas devant Yahvé comme s'était humilié son père Manassé; au contraire, lui, Amon, se rendit gravement coupable. 
###### 24
Ses serviteurs complotèrent contre lui et ils le tuèrent dans son palais; 
###### 25
mais le peuple du pays frappa tous ceux qui avaient conspiré contre Amon et proclama roi à sa place son fils Josias. 
