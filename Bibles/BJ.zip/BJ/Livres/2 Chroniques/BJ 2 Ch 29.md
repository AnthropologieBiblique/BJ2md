---
aliases : 
- 2 Chroniques 29
- 2 Chroniques 29
- 2 Ch 29
- 2 Chronicles 29
tags : 
- Bible/2Ch/29
- français
cssclass : français
---

# 2 Chroniques 29

###### 1
Ézéchias devint roi à l'âge de vingt-cinq ans et il régna vingt-neuf ans à Jérusalem; sa mère s'appelait Abiyya, fille de Zekaryahu. 
###### 2
Il fit ce qui est agréable à Yahvé, imitant tout ce qu'avait fait David son ancêtre. 
###### 3
C'est lui qui ouvrit les portes du Temple de Yahvé, le premier mois de la première année de son règne, et qui les restaura. 
###### 4
Puis il fit venir les prêtres et les lévites, les réunit sur la place orientale 
###### 5
et leur dit : " Écoutez-moi, lévites! Sanctifiez-vous maintenant, consacrez le Temple de Yahvé, Dieu de nos pères, et éliminez du sanctuaire la souillure. 
###### 6
Nos pères ont prévariqué et fait ce qui déplaît à Yahvé notre Dieu. Ils l'ont abandonné; ils ont détourné leurs faces de la Demeure de Yahvé, et lui ont tourné le dos. 
###### 7
Ils ont même fermé les portes du Vestibule, ils ont éteint les lampes et n'ont plus fait fumer d'encens, ils n'ont plus offert d'holocaustes au Dieu d'Israël dans le sanctuaire. 
###### 8
La colère de Yahvé s'est appesantie sur Juda et sur Jérusalem; il en a fait un objet d'épouvante, de stupeur et de dérision, comme vous le voyez de vos propres yeux. 
###### 9
Aussi nos pères sont-ils tombés sous l'épée, nos fils, nos filles et nos femmes sont-ils partis prisonniers. 
###### 10
Je veux maintenant conclure une alliance avec Yahvé, Dieu d'Israël, pour qu'il détourne de nous l'ardeur de sa colère. 
###### 11
O mes fils, ne soyez plus négligents, car c'est vous que Yahvé a choisis pour vous tenir en sa présence, pour le servir, pour vaquer à son culte et à ses encensements. " 
###### 12
Les lévites se levèrent : Mahat fils de Amasaï; Yoèl fils de Azaryahu, des fils de Qehat; des Merarites : Qish fils d'Abdi et Azaryahu fils de Yehalléléel; des Gershonites : Yoah fils de Zimma et Éden fils de Yoah; 
###### 13
des fils d'Éliçaphân : Shimri et Yeïel; des fils d'Asaph : Zekaryahu et Mattanyahu; 
###### 14
des fils de Hémân : Yehiel et Shiméï; des fils de Yedutûn : Shemaya et Uzziel. 
###### 15
Ils réunirent leurs frères, se sanctifièrent et, conformément à l'ordre du roi, selon les paroles de Yahvé, vinrent purifier le Temple de Yahvé. 
###### 16
Les prêtres entrèrent dans le Temple de Yahvé pour le purifier. Ils emportèrent sur le parvis du Temple de Yahvé toutes les choses impures qu'ils trouvèrent dans le sanctuaire de Yahvé, et les lévites en firent des tas qu'ils allèrent déposer à l'extérieur, dans la vallée du Cédron. 
###### 17
Ayant commencé cette consécration le premier jour du premier mois, ils purent entrer dans le Vestibule de Yahvé le huit du mois; ils mirent huit jours à consacrer le Temple de Yahvé et terminèrent le seizième jour du premier mois. 
###### 18
Ils se rendirent alors dans les appartements du rois Ézéchias et lui dirent : " Nous avons entièrement purifié le Temple de Yahvé, l'autel des holocaustes et tous ses accessoires, la table des rangées de pains et tous ses accessoires. 
###### 19
Tous les objets qu'avait rejetés le roi Achaz durant son règne impie, nous les avons réinstallés et consacrés; les voici devant l'autel de Yahvé. " 
###### 20
Le roi Ézéchias se leva aussitôt, il réunit les officiers de la ville et monta au Temple de Yahvé. 
###### 21
On fit venir sept taureaux, sept béliers et sept agneaux, plus sept boucs en vue du sacrifice pour le péché, à l'intention de la monarchie, du sanctuaire et de Juda. Le roi dit alors aux prêtres, fils d'Aaron, d'offrir les holocaustes sur l'autel de Yahvé. 
###### 22
Ils immolèrent les taureaux; les prêtres recueillirent le sang qu'ils versèrent sur l'autel. Puis ils immolèrent les béliers, dont ils versèrent le sang sur l'autel, et les agneaux, dont ils versèrent le sang sur l'autel. 
###### 23
Ils firent alors approcher les boucs, destinés au sacrifice pour le péché, devant le roi et l'Assemblée qui leur imposèrent les mains. 
###### 24
Les prêtres les immolèrent et de leur sang versé sur l'autel firent un sacrifice pour le péché afin d'accomplir le rite d'expiation sur tout Israël; c'était en effet pour tout Israël que le roi avait ordonné les holocaustes et le sacrifice pour le péché. 
###### 25
Il plaça ensuite les lévites dans le Temple de Yahvé avec des cymbales, des lyres et des cithares selon les prescriptions de David, de Gad le voyant du roi, et de Natân le prophète; l'ordre venait en effet de Dieu par l'intermédiaire de ses prophètes. 
###### 26
Quand on eut placé les lévites avec les instruments de David et les prêtres avec les trompettes, 
###### 27
Ézéchias ordonna d'offrir les holocaustes sur l'autel; l'holocauste commençait quand on entonna les chants de Yahvé et quand les trompettes sonnèrent, accompagnées des instruments de David, roi d'Israël. 
###### 28
Toute l'Assemblée se prosterna, chacun chantant les hymnes ou faisant retentir les trompettes jusqu'à l'achèvement de l'holocauste. 
###### 29
Quand l'holocauste fut terminé, le roi et tous ceux qui l'accompagnaient à ce moment fléchirent le genou et se prosternèrent. 
###### 30
Puis le roi Ézéchias et les officiers dirent aux lévites de louer Yahvé avec les paroles de David et d'Asaph le voyant; ils le firent jusqu'à exaltation, puis tombèrent et se prosternèrent. 
###### 31
Ézéchias prit alors la parole et dit : " Vous voici maintenant consacrés à Yahvé. Approchez-vous, apportez dans le Temple de Yahvé les victimes et les sacrifices de louange. " L'Assemblée apporta les victimes et les sacrifices de louange et toutes sortes d'holocaustes en dons votifs. 
###### 32
Le nombre des victimes de ces holocaustes fut de soixante-dix bœufs, cent béliers, deux cents agneaux, tous en holocaustes pour Yahvé; 
###### 33
six cents bœufs et trois mille moutons furent consacrés. 
###### 34
Les prêtres furent toutefois trop peu nombreux pour pouvoir dépecer tous ces holocaustes, et leurs frères les lévites leur prêtèrent main-forte jusqu'à ce que cette opération fût terminée et les prêtres sanctifiés; les lévites avaient été en effet mieux disposés que les prêtres à se sanctifier. 
###### 35
Il y eut de plus un abondant holocauste des graisses des sacrifices de communion, et des libations conjointes à l'holocauste. Ainsi fut rétabli le culte dans le Temple de Yahvé. 
###### 36
Ézéchias et tout le peuple se réjouirent de ce que Dieu eût disposé le peuple à agir sur-le-champ. 
