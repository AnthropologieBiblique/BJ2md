---
aliases : 
- 2 Chroniques 14
- 2 Chroniques 14
- 2 Ch 14
- 2 Chronicles 14
tags : 
- Bible/2Ch/14
- français
cssclass : français
---

# 2 Chroniques 14

###### 1
Asa fit ce qui est bien et juste aux yeux de Yahvé, son Dieu. 
###### 2
Il supprima les autels de l'étranger et les hauts lieux, il brisa les stèles, mit en pièces les ashéras 
###### 3
et dit aux Judéens de rechercher Yahvé, le Dieu de leurs pères, et de pratiquer loi et commandement. 
###### 4
Il supprima de toutes les villes de Juda les hauts lieux et les autels à encens. Aussi le royaume fut-il calme sous son règne; 
###### 5
il restaura les villes fortifiées de Juda, car le pays était calme et ne participa à aucune guerre en ces années-là, Yahvé lui ayant donné la tranquillité. 
###### 6
" Restaurons ces villes, dit-il à Juda, entourons-les d'un mur, de tours, de portes et de barres; le pays est encore à notre disposition car nous avons cherché Yahvé, notre Dieu; aussi nous a-t-il recherchés et nous a-t-il donné la tranquillité sur toutes nos frontières. " Ils restaurèrent et prospérèrent. 
###### 7
Asa disposa d'une armée de trois cent mille Judéens, portant le bouclier et la lance, et de deux cent quatre-vingt mille Benjaminites portant la rondache et tirant de l'arc, tous preux valeureux. 
###### 8
Zérah le Kushite fit une incursion avec une armée de mille milliers et de trois cents chars, et il atteignit Maresha. 
###### 9
Asa sortit à sa rencontre et se rangea en bataille dans la vallée de Çephata, à Maresha. 
###### 10
Asa invoqua Yahvé son Dieu et dit : " Il n'en est point comme toi, Yahvé, pour secourir le puissant aussi bien que celui qui est sans force. Porte-nous secours, Yahvé notre Dieu! C'est sur toi que nous nous appuyons et c'est en ton nom que nous nous heurtons à cette foule. Yahvé, tu es notre Dieu. Que le mortel ne te résiste pas! " 
###### 11
Yahvé battit les Kushites devant Asa et les Judéens : les Kushites s'enfuirent 
###### 12
et Asa les poursuivit avec son armée jusqu'à Gérar. Il tomba tant de Kushites qu'ils ne purent subsister, car ils s'étaient brisés devant Yahvé et son camp. On ramassa une grande quantité de butin, 
###### 13
on conquit toutes les villes aux alentours de Gérar, car la Terreur de Yahvé s'était appesantie sur elles, et on les pilla toutes car il s'y trouvait beaucoup de butin. 
###### 14
On s'en prit même aux tentes des troupeaux et l'on razzia nombre de moutons et de chameaux, puis l'on revint à Jérusalem. 
