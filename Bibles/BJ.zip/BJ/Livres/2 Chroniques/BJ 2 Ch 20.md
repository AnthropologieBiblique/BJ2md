---
aliases : 
- 2 Chroniques 20
- 2 Chroniques 20
- 2 Ch 20
- 2 Chronicles 20
tags : 
- Bible/2Ch/20
- français
cssclass : français
---

# 2 Chroniques 20

###### 1
Après cela les Moabites et les Ammonites, accompagnés de Méûnites, s'en vinrent combattre Josaphat. 
###### 2
On vint en informer Josaphat en ces termes : " Une foule immense s'avance contre toi d'au-delà de la mer, d'Édom; la voici à Haçaçôn Tamar, c'est-à-dire En-Gaddi. " 
###### 3
Josaphat prit peur et se tourna vers Yahvé. Il s'adressa à lui et proclama un jeûne pour tout Juda. 
###### 4
Les Judéens se rassemblèrent pour chercher secours auprès de Yahvé; ce sont même toutes les cités judéennes qui vinrent chercher secours auprès de Yahvé. 
###### 5
Lors de cette Assemblée des Judéens et des Hiérosolymites dans le Temple de Yahvé, Josaphat se tint debout devant le nouveau parvis 
###### 6
et s'écria : " Yahvé, Dieu de nos pères, n'est-ce pas toi le Dieu qui est dans les cieux ? N'est-ce pas toi qui domines sur tous les royaumes des nations ? Dans ta main sont la force et la puissance, et nul ne peut tenir contre toi. 
###### 7
N'est-ce pas toi qui es notre Dieu, toi qui, devant Israël ton peuple, as dépossédé les habitants de ce pays ? Ne l'as-tu pas donné à la race d'Abraham que tu aimeras éternellement ? 
###### 8
Ils s'y sont établis et y ont construit un sanctuaire à ton Nom en disant : 
###### 9
"Si le malheur s'abat sur nous, guerre, punition, peste ou famine, nous nous tiendrons devant ce Temple et devant toi, car ton Nom est dans ce Temple. Du fond de notre détresse nous crierons vers toi, tu nous entendras et tu nous sauveras. " 
###### 10
Vois à cette heure les Ammonites, Moab et les montagnards de Séïr; tu n'as pas laissé Israël les envahir lorsqu'il venait du pays d'Égypte, il s'est au contraire écarté d'eux sans les détruire; 
###### 11
or voici qu'ils nous récompensent en venant nous chasser des possessions que tu nous as léguées. 
###### 12
O notre Dieu, n'en feras-tu pas justice, car nous sommes sans force devant cette foule immense qui nous attaque. Nous, nous ne savons que faire, aussi est-ce sur toi que se portent nos regards. " 
###### 13
Tous les Judéens se tenaient debout en présence de Yahvé, et même leurs familles, leurs femmes et leurs fils. 
###### 14
Au milieu de l'Assemblée, l'Esprit de Yahvé fut sur Yahaziel, fils de Zekaryahu, fils de Benaya, fils de Yeïel, fils de Mattanya le lévite, l'un des fils d'Asaph. 
###### 15
Il s'écria : " Prêtez l'oreille, vous tous Judéens et habitants de Jérusalem, et toi, roi Josaphat! Ainsi vous parle Yahvé : Ne craignez pas, ne vous effrayez pas devant cette foule immense; ce combat n'est pas le vôtre mais celui de Dieu. 
###### 16
Descendez demain contre eux : voici qu'ils empruntent la montée de Çiç et vous les rencontrerez à l'extrémité de la vallée, près du désert de Yeruel. 
###### 17
Vous n'aurez pas à y combattre. Tenez-vous là, prenez position, vous verrez le salut que Yahvé vous réserve. Juda et Jérusalem, ne craignez pas, ne vous effrayez pas, partez demain à leur rencontre et Yahvé sera avec vous. " 
###### 18
Josaphat s'inclina, la face contre terre, tous les Judéens et les habitants de Jérusalem se prosternèrent devant Yahvé pour l'adorer. 
###### 19
Les lévites - des Qehatites et des Coréites - se mirent alors à louer Yahvé, Dieu d'Israël, à pleine voix. 
###### 20
De grand matin, ils se levèrent et partirent pour le désert de Téqoa. A leur départ, Josaphat, debout, s'écria : " Écoutez-moi, Judéens et habitants de Jérusalem! Croyez en Yahvé votre Dieu et vous vous maintiendrez, croyez en ses prophètes et vous réussirez. " 
###### 21
Puis, après avoir tenu conseil avec le peuple, il plaça au départ, devant les guerriers, les chantres de Yahvé qui le louaient, vêtus d'ornements sacrés, en disant : " Louez Yahvé, car éternel est son amour. " 
###### 22
Au moment où ils entonnaient l'exaltation et la louange, Yahvé tendit une embuscade contre les Ammonites, Moab et les montagnards de Séïr qui attaquaient Juda, et qui se virent alors battus. 
###### 23
Les Ammonites et les Moabites se dressèrent contre les habitants de la montagne de Séïr pour les vouer à l'anathème et les anéantir, mais en exterminant les habitants de Séïr ils ne s'entraidaient que pour leur propre perte. 
###### 24
Les Judéens atteignaient le point d'où l'on a vue sur le désert et allaient faire face à la foule, quand il n'y avait déjà plus que cadavres à terre et aucun rescapé. 
###### 25
Josaphat vint avec son armée razzier du butin; l'on y trouva en abondance du bétail, des biens, des vêtements et des objets précieux; ils en ramassèrent plus qu'ils n'en pouvaient porter et ils passèrent trois jours à razzier ce butin tant il était abondant. 
###### 26
Le quatrième jour, ils se rassemblèrent dans la vallée de Beraka; ils y bénirent en effet Yahvé, d'où le nom de vallée de Beraka donné à ce lieu jusqu'à nos jours. 
###### 27
Puis tous les hommes de Juda et de Jérusalem revinrent tout joyeux à Jérusalem, avec Josaphat à leur tête, car Yahvé les avait réjouis aux dépens de leurs ennemis. 
###### 28
Ils entrèrent à Jérusalem, dans le Temple de Yahvé, au son des lyres, des cithares et des trompettes, 
###### 29
et la terreur de Dieu s'abattit sur tous les royaumes des pays quand ils apprirent que Yahvé avait combattu les ennemis d'Israël. 
###### 30
Le règne de Josaphat fut calme et Dieu lui donna la tranquillité sur toutes ses frontières. 
###### 31
Josaphat régna sur Juda; il avait trente-cinq ans à son avènement et il régna vingt-cinq ans à Jérusalem; sa mère s'appelait Azuba, fille de Shilhi. 
###### 32
Il suivit la conduite de son père Asa sans dévier, faisant ce qui est juste au regard de Yahvé. 
###### 33
Cependant les hauts lieux ne disparurent pas et le peuple continua à ne pas fixer son cœur dans le Dieu de ses pères. 
###### 34
Le reste de l'histoire de Josaphat, du début à la fin, se trouve écrit dans les Actes de Jéhu, fils de Hanani, qui ont été portés sur le livre des Rois d'Israël. 
###### 35
Après quoi, Josaphat, roi de Juda, se lia à Ochozias, roi d'Israël. C'est celui-ci qui le poussa à mal faire. 
###### 36
Il s'associa avec lui pour construire des navires à destination de Tarsis; c'est à Éçyôn-Géber qu'ils les construisirent. 
###### 37
Éliézer, fils de Dodavahu de Maresha, prophétisa alors contre Josaphat : " Parce que tu t'es associé à Ochozias, dit-il, Yahvé a fait une brèche dans tes œuvres. " Les navires se brisèrent et ne furent pas en mesure de partir pour Tarsis. 
