---
aliases : 
- 1 Samuel 8
- 1 Samuel 8
- 1 S 8
tags : 
- Bible/1S/8
- français
cssclass : français
---

# 1 Samuel 8

###### 1
Lorsque Samuel fut devenu vieux, il établit ses fils comme juges en Israël. 
###### 2
Son fils aîné s'appelait Yoèl et son cadet Abiyya; ils étaient juges à Bersabée. 
###### 3
Mais ses fils ne suivirent pas son exemple : ils furent attirés par le gain, acceptèrent des présents et firent fléchir le droit. 
###### 4
Tous les anciens d'Israël se réunirent et vinrent trouver Samuel à Rama. 
###### 5
Ils lui dirent : " Tu es devenu vieux et tes fils ne suivent pas ton exemple. Eh bien! établis-nous un roi pour qu'il nous juge, comme toutes les nations. " 
###### 6
Cela déplut à Samuel qu'ils aient dit : " Donne-nous un roi, pour qu'il nous juge ", et il invoqua Yahvé. 
###### 7
Mais Yahvé dit à Samuel : " Satisfais à tout ce que te dit le peuple, car ce n'est pas toi qu'ils ont rejeté, c'est moi qu'ils ont rejeté, ne voulant plus que je règne sur eux. 
###### 8
Tout ce qu'ils m'ont fait depuis le jour où je les ai fait monter d'Égypte jusqu'à maintenant - ils m'ont abandonné et ont servi des dieux étrangers -ils te le font aussi. 
###### 9
Eh bien, satisfais à leur demande. Seulement, tu les avertiras solennellement et tu leur apprendras le droit du roi qui va régner sur eux. " 
###### 10
Samuel répéta toutes les paroles de Yahvé au peuple qui lui demandait un roi. 
###### 11
Il dit : " Voici le droit du roi qui va régner sur vous. Il prendra vos fils et les affectera à sa charrerie et à ses chevaux et ils courront devant son char. 
###### 12
Il les emploiera comme chefs de mille et comme chefs de cinquante; il leur fera labourer son labour, moissonner sa moisson, fabriquer ses armes de guerre et les harnais de ses chars. 
###### 13
Il prendra vos filles comme parfumeuses, cuisinières et boulangères. 
###### 14
Il prendra vos champs, vos vignes et vos oliveraies les meilleures et les donnera à ses officiers. 
###### 15
Sur vos cultures et vos vignes, il prélèvera la dîme et la donnera à ses eunuques et à ses officiers. 
###### 16
Les meilleurs de vos serviteurs, de vos servantes et de vos bœufs, et vos ânes, il les prendra et les fera travailler pour lui. 
###### 17
Il prélèvera la dîme sur vos troupeaux et vous-mêmes deviendrez ses esclaves. 
###### 18
Ce jour-là, vous pousserez des cris à cause du roi que vous vous serez choisi, mais Yahvé ne vous répondra pas, ce jour-là! " 
###### 19
Le peuple refusa d'écouter Samuel et dit : " Non! Nous aurons un roi 
###### 20
et nous serons, nous aussi, comme toutes les nations : notre roi nous jugera, il sortira à notre tête et combattra nos combats. " 
###### 21
Samuel entendit toutes les paroles du peuple et les redit à l'oreille de Yahvé. 
###### 22
Mais Yahvé lui dit : " Satisfais à leur demande et intronise-leur un roi. " Alors Samuel dit aux hommes d'Israël : " Retournez chacun dans sa ville. " 
