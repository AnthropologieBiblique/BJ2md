---
aliases : 
- 1 Samuel 5
- 1 Samuel 5
- 1 S 5
tags : 
- Bible/1S/5
- français
cssclass : français
---

# 1 Samuel 5

###### 1
Lorsque les Philistins se furent emparés de l'arche de Dieu, ils la conduisirent d'Ében-ha-Ézèr à Ashod. 
###### 2
Les Philistins prirent l'arche de Dieu, l'introduisirent dans le temple de Dagôn et la déposèrent à côté de Dagôn. 
###### 3
Quand les Ashdodites se levèrent le lendemain matin et vinrent au temple de Dagôn, voilà que Dagôn était tombé sur sa face, par terre, devant l'arche de Yahvé. Ils relevèrent Dagôn et le remirent à sa place. 
###### 4
Mais, quand ils se levèrent le lendemain de bon matin, voilà que Dagôn était tombé sur sa face, par terre, devant l'arche de Yahvé, et la tête de Dagôn et ses deux mains gisaient coupées sur le seuil : il ne restait à sa place que le tronc de Dagôn. 
###### 5
C'est pourquoi les prêtres de Dagôn et tous ceux qui entrent dans le temple de Dagôn ne foulent pas du pied le seuil de Dagôn à Ashdod, encore aujourd'hui. 
###### 6
La main de Yahvé s'appesantit sur les Ashdodites : il les ravagea et les affligea de tumeurs, Ashdod et son territoire. 
###### 7
Quand les gens d'Ashdod virent ce qui arrivait, ils dirent : " Que l'arche du Dieu d'Israël ne reste pas chez nous, car sa main s'est raidie contre nous et contre notre dieu Dagôn. " 
###### 8
Ils firent donc convoquer tous les princes des Philistins auprès d'eux et dirent : " Que devons-nous faire de l'arche du Dieu d'Israël ? " Ils décidèrent : " C'est à Gat que s'en ira l'arche du Dieu d'Israël ", et on emmena l'arche du Dieu d'Israël. 
###### 9
Mais après qu'ils l'eurent amenée, la main de Yahvé fut sur la ville et il y eut une très grande panique : les gens de la ville furent frappés, du plus petit au plus grand, et il leur sortit des tumeurs. 
###### 10
Ils envoyèrent alors l'arche de Dieu à Éqrôn, mais lorsque l'arche de Dieu arriva à Éqrôn, les Éqronites s'écrièrent : " Ils m'ont amené l'arche du Dieu d'Israël pour me faire périr moi et mon peuple! " 
###### 11
Ils firent convoquer tous les princes des Philistins et dirent : " Renvoyez l'arche du Dieu d'Israël, et qu'elle retourne à son lieu et ne me fasse pas mourir, moi et mon peuple. " Il y avait en effet une panique mortelle dans toute la ville, tant s'y était appesantie la main de Dieu. 
###### 12
Les gens qui ne mouraient pas étaient affligés de tumeurs et le cri de détresse de la ville montait jusqu'au ciel. 
