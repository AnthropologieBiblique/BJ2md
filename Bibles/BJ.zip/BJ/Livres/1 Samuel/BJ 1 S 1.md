---
aliases : 
- 1 Samuel 1
- 1 Samuel 1
- 1 S 1
tags : 
- Bible/1S/1
- français
cssclass : français
---

# 1 Samuel 1

###### 1
Il y avait un homme de Ramatayim, un Çuphite de la montagne d'Éphraïm, qui s'appelait Elqana, fils de Yeroham, fils d'Élihu, fils de Tohu, fils de Çuph, un Éphraïmite. 
###### 2
Il avait deux femmes : l'une s'appelait Anne, l'autre Peninna; mais alors que Peninna avait des enfants, Anne n'en n'avait point. 
###### 3
Chaque année, cet homme montait de sa ville pour adorer et pour sacrifier à Yahvé Sabaot à Silo là se trouvaient les deux fils d'Éli, Hophni et Pinhas, comme prêtres de Yahvé . 
###### 4
Un jour Elqana offrit un sacrifice. - Il avait coutume de donner des portions à sa femme Peninna et à tous ses fils et filles, 
###### 5
et il n'en donnait qu'une à Anne bien qu'il préférât Anne, mais Yahvé l'avait rendue stérile. 
###### 6
Sa rivale lui faisait aussi des affronts pour la mettre en colère, parce que Yahvé avait rendu son sein stérile. 
###### 7
C'est ce qui arrivait annuellement, chaque fois qu'ils montaient au temple de Yahvé : elle lui faisait des affronts. - Or donc, Anne pleura et resta sans manger. 
###### 8
Alors son mari Elqana lui dit : " Anne, pourquoi pleures-tu et ne manges-tu pas ? Pourquoi es-tu malheureuse ? Est-ce que je ne vaux pas pour toi mieux que dix fils ? " 
###### 9
Anne se leva après qu'ils eurent mangé dans la chambre et elle se tint devant Yahvé - le prêtre Éli était assis sur son siège, contre le montant de la porte, au sanctuaire de Yahvé. 
###### 10
Dans l'amertume de son âme, elle pria Yahvé et elle pleura beaucoup. 
###### 11
Elle fit ce vœu : " O Yahvé Sabaot! Si tu voulais considérer la misère de ta servante, te souvenir de moi, ne pas oublier ta servante et lui donner un petit d'homme, alors je le donnerai à Yahvé pour toute sa vie et le rasoir ne passera pas sur sa tête. " 
###### 12
Comme elle prolongeait sa prière devant Yahvé, Éli observait sa bouche. 
###### 13
Anne parlait tout bas : ses lèvres remuaient mais on n'entendait pas sa voix, et Éli pensa qu'elle était ivre. 
###### 14
Alors Éli lui dit : " Jusques à quand seras-tu dans l'ivresse ? Fais passer ton vin! " 
###### 15
Mais Anne répondit ainsi : " Non, Monseigneur, je ne suis qu'une femme affligée, je n'ai bu ni vin ni boisson fermentée, j'épanche mon âme devant Yahvé. 
###### 16
Ne juge pas ta servante comme une vaurienne : c'est par excès de peine et de dépit que j'ai parlé jusqu'à maintenant. " 
###### 17
Alors Éli lui répondit : " Va en paix et que le Dieu d'Israël t'accorde ce que tu lui as demandé. " 
###### 18
Elle dit : " Puisse ta servante trouver grâce à tes yeux ", et la femme alla son chemin; elle mangea et son visage ne fut plus le même. 
###### 19
Ils se levèrent de bon matin et, après s'être prosternés devant Yahvé, ils s'en retournèrent et arrivèrent chez eux, à Rama. Elqana s'unit à sa femme Anne, et Yahvé se souvint d'elle. 
###### 20
Anne conçut et, au temps révolu, elle mit au monde un fils qu'elle nomma Samuel " car, dit-elle, je l'ai demandé à Yahvé ". 
###### 21
Le mari Elqana monta, avec toute sa famille, pour offrir à Yahvé le sacrifice annuel et accomplir son vœu. 
###### 22
Mais Anne ne monta pas car elle dit à son mari : " Pas avant que l'enfant ne soit sevré! Alors je le conduirai; il sera présenté devant Yahvé et il restera là pour toujours. " 
###### 23
Elqana, son mari, lui répondit : " Fais comme il te plaît et attends de l'avoir sevré. Que seulement Yahvé réalise sa parole! " La femme resta donc et allaita l'enfant jusqu'à son sevrage. 
###### 24
Lorsqu'elle l'eut sevré, elle l'emmena avec elle, en même temps qu'un taureau de trois ans, une mesure de farine et une outre de vin, et elle le fit entrer dans le temple de Yahvé à Silo; l'enfant était tout jeune. 
###### 25
Ils immolèrent le taureau et ils conduisirent l'enfant à Éli. 
###### 26
Elle dit : " S'il te plaît, Monseigneur! Aussi vrai que tu vis, Monseigneur, je suis la femme qui se tenait près de toi ici, priant Yahvé. 
###### 27
C'est pour cet enfant que je priais et Yahvé m'a accordé la demande que je lui ai faite. 
###### 28
A mon tour, je le cède à Yahvé tous les jours de sa vie : il est cédé à Yahvé. " Et, là, ils se prosternèrent devant Yahvé. 
