---
aliases : 
- 1 Samuel 2
- 1 Samuel 2
- 1 S 2
tags : 
- Bible/1S/2
- français
cssclass : français
---

# 1 Samuel 2

###### 1
Alors Anne fit cette prière : " Mon cœur exulte en Yahvé, ma corne s'élève en mon Dieu, ma bouche est large ouverte contre mes ennemis, car je me réjouis en ton secours. 
###### 2
Point de Saint comme Yahvé car il n'y a personne excepté toi , point de Rocher comme notre Dieu. 
###### 3
Ne multipliez pas les paroles hautaines, que l'arrogance ne sorte pas de votre bouche. Un Dieu plein de savoir, voilà Yahvé, à lui de peser les actions. 
###### 4
L'arc des puissants est brisé, mais les défaillants sont ceinturés de force. 
###### 5
Les rassasiés s'embauchent pour du pain, mais les affamés cessent de travailler. La femme stérile enfante sept fois, mais la mère de nombreux enfants se flétrit. 
###### 6
C'est Yahvé qui fait mourir et vivre, qui fait descendre au shéol et en remonter. 
###### 7
C'est Yahvé qui appauvrit et qui enrichit, qui abaisse et aussi qui élève. 
###### 8
Il retire de la poussière le faible, du fumier il relève le pauvre, pour les faire asseoir avec les nobles et leur assigner un siège d'honneur; car à Yahvé sont les piliers de la terre, sur eux il a posé le monde. 
###### 9
Il garde les pas de ses fidèles, mais les méchants disparaissent dans les ténèbres car ce n'est pas par la force que l'homme triomphe . 
###### 10
Yahvé, ses ennemis sont brisés, le Très Haut tonne dans les cieux. Yahvé juge les confins de la terre, il donne la force à son Roi, il exalte la vigueur de son Oint. " 
###### 11
Elqana partit pour Rama dans sa maison mais l'enfant restait à servir Yahvé, en présence du prêtre Éli. 
###### 12
Or les fils d'Éli étaient des vauriens, qui ne se souciaient pas de Yahvé 
###### 13
ni du droit des prêtres vis-à-vis du peuple : si quelqu'un offrait un sacrifice, le serviteur du prêtre venait pendant qu'on cuisait la viande, tenant une fourchette à trois dents, 
###### 14
il piquait dans le chaudron ou dans la marmite ou dans la terrine ou dans le pot, et le prêtre s'attribuait tout ce que ramenait la fourchette; on agissait ainsi avec tous les Israélites qui venaient là, à Silo. 
###### 15
Et même, on n'avait pas encore fait fumer la graisse que le serviteur du prêtre venait et disait à celui qui sacrifiait : " Donne de la viande à rôtir pour le prêtre, il n'acceptera pas de toi de la viande bouillie, seulement de la viande crue. " 
###### 16
Et si cet homme lui disait : " Qu'on fasse d'abord fumer la graisse, puis prends pour toi à ta guise ", il répondait : " Non, tu vas me donner tout de suite, sinon je prends de force. " 
###### 17
Le péché des jeunes gens était très grand devant Yahvé, car ils traitaient avec mépris l'offrande faite à Yahvé. 
###### 18
Samuel était au service de Yahvé, un enfant vêtu du pagne de lin. 
###### 19
Sa mère lui faisait un petit manteau qu'elle lui apportait chaque année, lorsqu'elle montait avec son mari pour offrir le sacrifice annuel. 
###### 20
Éli bénissait Elqana et sa femme et disait : " Que Yahvé te rende une progéniture de cette femme, en échange du prêt qu'elle a cédé à Yahvé ", et ils s'en allaient chez eux. 
###### 21
Yahvé visita Anne, elle conçut et elle mit au monde trois fils et deux filles; le jeune Samuel grandissait auprès de Yahvé. 
###### 22
Bien qu'Éli fût très âgé, il était informé de tout ce que ses fils faisaient à tout Israël. 
###### 23
Il leur dit : " Pourquoi agissez-vous de la manière que j'entends dire par tout le peuple ? 
###### 24
Non, mes fils, elle n'est pas belle la rumeur que j'entends le peuple de Yahvé colporter. 
###### 25
Si un homme pèche contre un autre homme, Dieu sera l'arbitre, mais si c'est contre Yahvé que pèche un homme, qui intercédera pour lui ? " Cependant ils n'écoutèrent pas la voix de leur père. C'est qu'il avait plu à Yahvé de les faire mourir. 
###### 26
Quant au jeune Samuel, il continuait de croître en taille et en grâce tant auprès de Yahvé qu'auprès des hommes. 
###### 27
Un homme de Dieu vint chez Éli et lui dit : " Ainsi parle Yahvé. Voilà donc que je me suis révélé à la maison de ton père quand ils étaient en Égypte, esclaves de la maison de Pharaon. 
###### 28
Je l'ai distinguée de toutes les tribus d'Israël pour exercer mon sacerdoce, pour monter à mon autel, pour faire fumer l'offrande, pour porter l'éphod en ma présence, et j'ai concédé à la maison de ton père toutes les viandes offertes par les Israélites. 
###### 29
Pourquoi piétinez-vous l'offrande et le sacrifice que j'ai ordonnés pour ma Demeure, et honores-tu tes fils plus que moi, en vous engraissant du meilleur de toutes les offrandes d'Israël, mon peuple ? 
###### 30
C'est pourquoi - oracle de Yahvé, Dieu d'Israël - j'avais bien dit que ta maison et la maison de ton père marcheraient en ma présence pour toujours, mais maintenant - oracle de Yahvé - je m'en garderai! Car j'honore ceux qui m'honorent et ceux qui me méprisent sont traités comme rien. 
###### 31
Voici que des jours viennent où j'abattrai ton bras et le bras de la maison de ton père, en sorte qu'il n'y ait pas de vieillard dans ta maison. 
###### 32
Tu regarderas, à côté de la Demeure, tout le bien que je ferai à Israël, et il n'y aura pas de vieillard dans ta maison, à jamais. 
###### 33
Je maintiendrai quelqu'un des tiens près de mon autel, pour que ses yeux se consument et que son âme s'étiole, mais tout l'ensemble de ta maison périra par l'épée des hommes. 
###### 34
Le présage sera pour toi ce qui va arriver à tes deux fils, Hophni et Pinhas : le même jour, ils mourront tous deux. 
###### 35
Je me susciterai un prêtre fidèle, qui agira selon mon cœur et mon désir, je lui assurerai une maison qui dure et il marchera toujours en présence de mon oint. 
###### 36
Quiconque subsistera de ta famille viendra se prosterner devant lui pour avoir une piécette d'argent et une galette de pain, et dira : "Je t'en prie, attache-moi à n'importe quelle fonction sacerdotale, pour que j'aie un morceau de pain à manger. " " 
