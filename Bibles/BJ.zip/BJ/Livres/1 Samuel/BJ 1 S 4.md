---
aliases : 
- 1 Samuel 4
- 1 Samuel 4
- 1 S 4
tags : 
- Bible/1S/4
- français
cssclass : français
---

# 1 Samuel 4

###### 1
et la parole de Samuel fut pour tout Israël comme la parole de Yahvé. Éli était très âgé et ses fils persévéraient dans leur mauvaise conduite à l'égard de Yahvé. Il advint en ce temps-là que les Philistins se rassemblèrent pour combattre Israël, et les Israélites sortirent à leur rencontre pour le combat. Ils campèrent près d'Ében-ha-Ézer, tandis que les Philistins étaient campés à Apheq. 
###### 2
Les Philistins s'étant mis en ligne contre Israël, il y eut un rude combat et Israël fut battu devant les Philistins : environ quatre mille hommes furent tués dans les lignes, en rase campagne. 
###### 3
L'armée revint au camp et les anciens d'Israël dirent : " Pourquoi Yahvé nous a-t-il fait battre aujourd'hui par les Philistins ? Allons chercher à Silo l'arche de notre Dieu, qu'elle vienne au milieu de nous et qu'elle nous sauve de l'emprise de nos ennemis. " 
###### 4
L'armée envoya à Silo et on enleva de là l'arche de Yahvé Sabaot, qui siège sur les chérubins; les deux fils d'Éli, Hophni et Pinhas, accompagnaient l'arche. 
###### 5
Quand l'arche de Yahvé arriva au camp, tous les Israélites poussèrent une grande acclamation, qui fit résonner la terre. 
###### 6
Les Philistins entendirent le bruit de l'acclamation et dirent : " Que signifie cette grande acclamation au camp des Hébreux ? ", et ils connurent que l'arche de Yahvé était arrivée au camp. 
###### 7
Alors les Philistins eurent peur, car ils se disaient : " Dieu est venu au camp! " Ils dirent : " Malheur à nous! Car une chose pareille n'est pas arrivée auparavant. 
###### 8
Malheur à nous! Qui nous délivrera de la main de ce Dieu puissant ? C'est lui qui a frappé l'Égypte de toutes sortes de plaies au désert. 
###### 9
Prenez courage et soyez virils, Philistins, pour n'être pas asservis aux Hébreux comme ils vous ont été asservis; soyez virils et combattez! " 
###### 10
Les Philistins livrèrent bataille, les Israélites furent battus et chacun s'enfuit à ses tentes; ce fut un très grand massacre et trente mille hommes de pied tombèrent du côté d'Israël. 
###### 11
L'arche de Dieu fut prise et les deux fils d'Éli moururent, Hophni et Pinhas. 
###### 12
Un homme de Benjamin courut hors des lignes et atteignit Silo le même jour, les vêtements déchirés et la tête couverte de poussière. 
###### 13
Lorsqu'il arriva, Éli était assis sur son siège, à côté de la porte, surveillant la route, car son cœur tremblait pour l'arche de Dieu. Cet homme donc vint apporter la nouvelle à la ville, et ce furent des cris dans toute la ville. 
###### 14
Éli entendit les cris et demanda : " Quelle est cette grande rumeur ? " L'homme se hâta et vint avertir Éli. - 
###### 15
Celui-ci avait quatre-vingt-dix-huit ans, il avait le regard fixe et ne pouvait plus voir. - 
###### 16
L'homme dit à Éli : " J'arrive du camp, je me suis enfui des lignes aujourd'hui ", et celui-ci demanda : " Que s'est-il passé, mon fils ? " 
###### 17
Le messager répondit : " Israël a fui devant les Philistins, ce fut même une grande défaite pour l'armée, et encore tes deux fils sont morts, et l'arche de Dieu a été prise! " 
###### 18
A cette mention de l'arche de Dieu, Éli tomba de son siège à la renverse, en travers de la porte, sa nuque se brisa et il mourut, car l'homme était âgé et pesant. Il avait jugé Israël pendant quarante ans. 
###### 19
Or sa bru, la femme de Pinhas, était enceinte et sur le point d'accoucher. Dès qu'elle eut appris la nouvelle relative à la prise de l'arche de Dieu et à la mort de son beau-père et de son mari, elle s'accroupit et elle accoucha, car ses douleurs l'avaient assaillie. 
###### 20
Comme elle était à la mort, celles qui l'assistaient lui dirent : " Aie confiance, c'est un fils que tu as enfanté! " mais elle ne répondit pas et n'y fit pas attention. 
###### 21
Elle appela l'enfant Ikabod, disant : " La gloire a été bannie d'Israël ", par allusion à la prise de l'arche de Dieu, et à son beau-père et son mari. 
###### 22
Elle dit : " La gloire a été bannie d'Israël, parce que l'arche de Dieu a été prise. " 
