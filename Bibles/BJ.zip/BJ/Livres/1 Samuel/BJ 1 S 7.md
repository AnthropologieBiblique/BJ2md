---
aliases : 
- 1 Samuel 7
- 1 Samuel 7
- 1 S 7
tags : 
- Bible/1S/7
- français
cssclass : français
---

# 1 Samuel 7

###### 1
Les gens de Qiryat-Yéarim vinrent et firent monter l'arche de Yahvé. Ils la conduisirent dans la maison d'Abinadab, sur la hauteur, et ils consacrèrent son fils Éléazar pour garder l'arche de Yahvé. 
###### 2
Depuis le jour où l'arche fut installée à Qiryat-Yéarim un long temps s'écoula - vingt ans - et toute la maison d'Israël soupira après Yahvé. 
###### 3
Alors Samuel parla ainsi à toute la maison d'Israël : " Si c'est de tout votre cœur que vous revenez à Yahvé, écartez les dieux étrangers du milieu de vous, et les Astartés, fixez votre cœur en Yahvé et ne servez que lui : alors il vous délivrera de la main des Philistins. " 
###### 4
Les Israélites écartèrent donc les Baals et les Astartés et ne servirent que Yahvé. 
###### 5
Samuel dit : " Rassemblez tout Israël à Miçpa et je supplierai Yahvé pour vous. " 
###### 6
Ils se rassemblèrent donc à Miçpa, ils puisèrent de l'eau qu'ils répandirent devant Yahvé, ils jeûnèrent ce jour-là et ils dirent : " Nous avons péché contre Yahvé. " Et Samuel jugea les Israélites à Miçpa. 
###### 7
Lorsque les Philistins surent que les Israélites s'étaient rassemblés à Miçpa, les princes des Philistins montèrent à l'attaque d'Israël. Les Israélites l'apprirent et ils eurent peur des Philistins. 
###### 8
Ils dirent à Samuel : " Ne cesse pas d'invoquer Yahvé notre Dieu, pour qu'il nous délivre de la main des Philistins. " 
###### 9
Samuel prit un agneau de lait et l'offrit en holocauste complet à Yahvé, il invoqua Yahvé pour Israël et Yahvé l'exauça. 
###### 10
Pendant que Samuel offrait l'holocauste, les Philistins engagèrent le combat contre Israël, mais Yahvé, ce jour-là, tonna à grand fracas sur les Philistins, il les frappa de panique et ils furent battus devant Israël. 
###### 11
Les gens d'Israël sortirent de Miçpa et poursuivirent les Philistins, et ils les battirent jusqu'en dessous de Bet-Kar. 
###### 12
Alors Samuel prit une pierre et la dressa entre Miçpa et La Dent, et il lui donna le nom d'Ében-ha-Ézèr, en disant : " C'est jusqu'ici que Yahvé nous a secourus. " 
###### 13
Les Philistins furent abaissés. Ils ne revinrent plus sur le territoire d'Israël et la main de Yahvé pesa sur les Philistins pendant toute la vie de Samuel. 
###### 14
Les villes que les Philistins avaient prises à Israël lui firent retour depuis Éqrôn jusqu'à Gat, et Israël délivra leur territoire de la main des Philistins. Il y eut paix entre Israël et les Amorites. 
###### 15
Samuel jugea Israël pendant toute sa vie. 
###### 16
Il allait chaque année faire une tournée par Béthel, Gilgal, Miçpa, et il jugeait Israël en tous ces endroits. 
###### 17
Puis il revenait à Rama, car c'est là qu'il avait sa maison et qu'il jugeait Israël. Il y construisit un autel à Yahvé. 
