---
aliases : 
- 1 Samuel 6
- 1 Samuel 6
- 1 S 6
tags : 
- Bible/1S/6
- français
cssclass : français
---

# 1 Samuel 6

###### 1
L'arche de Yahvé fut sept mois dans le territoire des Philistins. 
###### 2
Les Philistins en appelèrent aux prêtres et aux devins et demandèrent : " Que devons-nous faire de l'arche de Yahvé ? Indiquez-nous comment nous la renverrons en son lieu. " 
###### 3
Ils répondirent : " Si vous voulez renvoyer l'arche du Dieu d'Israël, ne la renvoyez pas sans rien, mais payez-lui une réparation. Alors vous guérirez et vous saurez pourquoi sa main ne s'était pas détournée de vous. " 
###### 4
Ils demandèrent : " Quelle doit être la réparation que nous lui paierons ? " Ils répondirent : " D'après le nombre des princes des Philistins, cinq tumeurs d'or et cinq rats d'or, car ce fut la même plaie pour vous et pour vos princes. 
###### 5
Faites des images de vos tumeurs et des images de vos rats, qui ravagent le pays, et rendez gloire au Dieu d'Israël. Peut-être sa main se fera-t-elle plus légère sur vous, vos dieux et votre pays. 
###### 6
Pourquoi endurciriez-vous votre cœur comme l'ont endurci les Égyptiens et Pharaon ? Lorsque Dieu les eut malmenés, ne les ont-ils pas laissés partir ? 
###### 7
Maintenant, prenez et préparez un chariot neuf et deux vaches qui allaitent et n'ont pas porté le joug : vous attellerez les vaches au chariot et vous ramènerez leurs petits en arrière à l'étable. 
###### 8
Vous prendrez l'arche de Yahvé et vous la placerez sur le chariot. Quant aux objets d'or que vous lui payez comme réparation, vous les mettrez dans un coffre, à côté d'elle, et vous la laisserez partir. 
###### 9
Puis regardez : s'il prend le chemin de son territoire, vers Bet-Shémesh, c'est lui qui nous a causé ce grand mal, sinon nous saurons que ce n'est pas sa main qui nous a frappés et que cela nous est arrivé par accident. " 
###### 10
Ainsi firent les gens : ils prirent deux vaches qui allaitaient et ils les attelèrent au chariot, mais ils retinrent les petits à l'étable. 
###### 11
Ils placèrent l'arche de Yahvé sur le chariot, ainsi que le coffre avec les rats d'or et les images de leurs tumeurs. 
###### 12
Les vaches prirent tout droit la route de Bet-Shémesh et gardèrent le même chemin, elles meuglaient en marchant, sans dévier ni à droite ni à gauche. Les princes des Philistins les suivirent jusqu'aux confins de Bet-Shémesh. 
###### 13
Les gens de Bet-Shémesh faisaient la moisson des blés dans la plaine. Levant les yeux, ils virent l'arche et ils allèrent avec joie à sa rencontre. 
###### 14
Lorsque le chariot fut arrivé au champ de Josué de Bet-Shémesh, il s'y arrêta. Il y avait là une grande pierre. On fendit le bois du chariot et on offrit les vaches en holocauste à Yahvé. 
###### 15
Les lévites avaient descendu l'arche de Yahvé et le coffre qui était près d'elle et qui contenait les objets d'or, et ils avaient déposé le tout sur la grande pierre. Les gens de Bet-Shémesh offrirent ce jour-là des holocaustes et firent des sacrifices à Yahvé. 
###### 16
Quand les cinq princes des Philistins eurent vu cela, ils revinrent à Éqrôn, le même jour. 
###### 17
Voici les tumeurs d'or que les Philistins payèrent en réparation à Yahvé : pour Ashdod une, pour Gaza une, pour Ashqelôn une, pour Gat une, pour Éqrôn une. 
###### 18
Et des rats d'or, autant que toutes les villes des Philistins, celles des cinq princes, depuis les villes fortes jusqu'aux villages ouverts. Témoin la grande pierre sur laquelle on déposa l'arche de Yahvé, et qui est encore aujourd'hui dans le champ de Josué de Bet-Shémesh. 
###### 19
Les fils de Yekonya, parmi les gens de Bet-Shémesh, ne s'étaient pas réjouis lorsqu'ils avaient vu l'arche de Yahvé, et Yahvé frappa soixante-dix hommes d'entre eux. Et le peuple fut en deuil, parce que Yahvé l'avait durement frappé. 
###### 20
Alors les gens de Bet-Shémesh dirent : " Qui pourrait tenir en face de Yahvé, le Dieu Saint ? Chez qui montera-t-il loin de nous ? " 
###### 21
Ils envoyèrent des messagers aux habitants de Qiryat-Yéarim, avec ces mots : " Les Philistins ont rendu l'arche de Yahvé. Descendez et faites-la monter chez vous. " 
