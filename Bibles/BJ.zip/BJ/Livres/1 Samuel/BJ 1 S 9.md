---
aliases : 
- 1 Samuel 9
- 1 Samuel 9
- 1 S 9
tags : 
- Bible/1S/9
- français
cssclass : français
---

# 1 Samuel 9

###### 1
Il y avait, parmi les Benjaminites, un homme qui s'appelait Qish, fils d'Abiel, fils de Çeror, fils de Bekorat, fils d'Aphiah; c'était un Benjaminite, homme de condition. 
###### 2
Il avait un fils nommé Saül, qui était dans la fleur de l'âge et beau. Nul parmi les Israélites n'était plus beau que lui : de l'épaule et au-dessus, il dépassait tout le monde. 
###### 3
Les ânesses appartenant à Qish, père de Saül, s'étant égarées, Qish dit à son fils Saül : " Prends avec toi l'un des serviteurs et va, pars à la recherche des ânesses. " 
###### 4
Ils traversèrent la montagne d'Éphraïm, ils traversèrent le pays de Shalisha sans rien trouver; ils traversèrent le pays de Shaalim : elles n'y étaient pas; ils traversèrent le pays de Benjamin sans rien trouver. 
###### 5
Lorsqu'ils furent arrivés au pays de Çuph, Saül dit au serviteur qui l'accompagnait : " Allons! Retournons, de peur que mon père ne laisse les ânesses pour s'inquiéter de nous. " 
###### 6
Mais celui-ci lui répondit : " Voici qu'un homme de Dieu habite cette ville-là. C'est un homme réputé : tout ce qu'il dit arrive sûrement. Allons-y donc, peut-être nous éclairera-t-il sur le voyage que nous avons entrepris. " 
###### 7
Saül dit à son serviteur : " A supposer que nous y allions, qu'offrirons-nous à l'homme ? Le pain a disparu de nos sacs et nous n'avons pas de rétribution à offrir à l'homme de Dieu. Qu'avons-nous d'autre ? " 
###### 8
Le serviteur reprit la parole et dit à Saül : " Il se trouve que j'ai en main un quart de sicle d'argent, je le donnerai à l'homme de Dieu et il nous éclairera sur notre voyage. " 
###### 9
Autrefois en Israël, voici ce qu'on disait en allant consulter Dieu : " Allons donc chez le voyant ", car au lieu de " prophète " comme aujourd'hui on disait autrefois " voyant ". - 
###### 10
Saül dit à son serviteur : " Tu as bien parlé, allons donc! " Et ils allèrent à la ville où se trouvait l'homme de Dieu. 
###### 11
Comme ils gravissaient la montée de la ville, ils rencontrèrent des jeunes filles qui sortaient pour puiser l'eau et ils leur demandèrent : " Le voyant est-il là ? " - 
###### 12
Elles leur répondirent en ces termes : " Il est là, il t'a juste précédé. Hâte-toi maintenant : il est venu aujourd'hui en ville, car il y a aujourd'hui un sacrifice pour le peuple sur le haut lieu. 
###### 13
Dès que vous entrerez en ville, vous le trouverez avant qu'il ne monte au haut lieu pour le repas. Le peuple ne mangera pas avant son arrivée, car c'est lui qui doit bénir le sacrifice; après quoi, les invités mangeront. Maintenant, montez : vous le trouverez sur l'heure. " 
###### 14
Ils montèrent donc à la ville. Comme ils entraient dans la porte, Samuel sortait à leur rencontre pour monter au haut lieu. 
###### 15
Or, un jour avant que Saül ne vînt, Yahvé avait fait cette révélation à Samuel : 
###### 16
" Demain à pareille heure, avait-il dit, je t'enverrai un homme du pays de Benjamin, tu lui donneras l'onction comme chef de mon peuple Israël, et il délivrera mon peuple de la main des Philistins, car j'ai vu la misère de mon peuple et son cri est venu jusqu'à moi. " 
###### 17
Et quand Samuel aperçut Saül, Yahvé lui signifia : " Voilà l'homme dont je t'ai dit : C'est lui qui jugera mon peuple. ". 
###### 18
Saül aborda Samuel au milieu de la porte et dit : " Indique-moi, je te prie, où est la maison du voyant. " 
###### 19
Samuel répondit à Saül : " Je suis le voyant. Monte devant moi au haut lieu. Vous mangerez aujourd'hui avec moi. Je te dirai adieu demain matin et je t'expliquerai tout ce qui occupe ton cœur. 
###### 20
Quant aux ânesses que tu as perdues il y a trois jours, ne t'en inquiète pas : elles sont retrouvées. D'ailleurs, à qui revient toute la richesse d'Israël ? N'est-ce pas à toi et à toute la maison de ton père ? " 
###### 21
Saül répondit ainsi : " Ne suis-je pas un Benjaminite, la plus petite des tribus d'Israël, et ma famille n'est-elle pas la moindre de toutes celles de la tribu de Benjamin ? Pourquoi me dire de telles paroles ? " 
###### 22
Samuel emmena Saül et son serviteur. Il les introduisit dans la salle et leur donna une place en tête des invités, qui étaient une trentaine. 
###### 23
Puis Samuel dit au cuisinier : " Sers la part que je t'ai donnée en te disant de la mettre de côté. " 
###### 24
Le cuisinier préleva le gigot et la queue, qu'il mit devant Saül, et il dit : " Voilà posé devant toi ce qu'on a laissé. Mange! ... " Ce jour-là, Saül mangea avec Samuel. 
###### 25
Ils descendirent du haut lieu à la ville. On prépara un lit sur la terrasse pour Saül 
###### 26
et il se coucha. Dès que parut l'aurore, Samuel appela Saül sur la terrasse : " Lève-toi, dit-il, je vais te dire adieu. " Saül se leva, et Samuel et lui sortirent tous deux au-dehors. 
###### 27
Ils étaient descendus à la limite de la ville quand Samuel dit à Saül : " Ordonne au serviteur qu'il passe devant nous, mais toi, reste maintenant, que je te fasse entendre la parole de Dieu. " 
