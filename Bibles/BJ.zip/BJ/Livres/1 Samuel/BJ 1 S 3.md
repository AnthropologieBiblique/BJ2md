---
aliases : 
- 1 Samuel 3
- 1 Samuel 3
- 1 S 3
tags : 
- Bible/1S/3
- français
cssclass : français
---

# 1 Samuel 3

###### 1
Le jeune Samuel servait donc Yahvé en présence d'Éli; en ce temps-là, il était rare que Yahvé parlât, les visions n'étaient pas fréquentes. 
###### 2
Or, un jour, Éli était couché dans sa chambre - ses yeux commençaient de faiblir et il ne pouvait plus voir - 
###### 3
la lampe de Dieu n'était pas encore éteinte et Samuel était couché dans le sanctuaire de Yahvé, là où se trouvait l'arche de Dieu. 
###### 4
Yahvé appela : " Samuel, Samuel! " Il répondit : " Me voici! " 
###### 5
et il courut près d'Éli et dit : " Me voici, puisque tu m'as appelé. " - " Je ne t'ai pas appelé, dit Éli; retourne te coucher. " Il alla se coucher. 
###### 6
Yahvé recommença d'appeler : " Samuel, Samuel! " Il se leva et alla près d'Éli et dit : " Me voici, puisque tu m'as appelé. " - " Je ne t'ai pas appelé, mon fils, dit Éli; retourne te coucher. " 
###### 7
Samuel ne connaissait pas encore Yahvé et la parole de Yahvé ne lui avait pas encore été révélée. 
###### 8
Yahvé recommença d'appeler Samuel pour la troisième fois. Il se leva et alla près d'Éli et dit : " Me voici, puisque tu m'as appelé. " Alors Éli comprit que c'était Yahvé qui appelait l'enfant 
###### 9
et il dit à Samuel : " Va te coucher et, si on t'appelle, tu diras : Parle, Yahvé, car ton serviteur écoute ", et Samuel alla se coucher à sa place. 
###### 10
Yahvé vint et se tint présent. Il appela comme les autres fois : " Samuel, Samuel! ", et Samuel répondit : " Parle, car ton serviteur écoute. " 
###### 11
Yahvé dit à Samuel : " Je m'en vais faire en Israël une chose telle que les deux oreilles en tinteront à quiconque l'apprendra. 
###### 12
En ce jour-là, j'accomplirai contre Éli tout ce que j'ai dit sur sa maison, du commencement à la fin. 
###### 13
Tu lui annonceras que je condamne sa maison pour toujours; parce qu'il a su que ses fils maudissaient Dieu et qu'il ne les a pas corrigés. 
###### 14
C'est pourquoi - je le jure à la maison d'Éli - ni sacrifice ni offrande n'effaceront jamais la faute de la maison d'Éli. " 
###### 15
Samuel reposa jusqu'au matin, puis il ouvrit les portes du temple de Yahvé. Samuel craignait de raconter la vision à Éli, 
###### 16
mais Éli l'appela en disant : " Samuel, mon fils! ", et il répondit : " Me voici! " 
###### 17
Il demanda : " Quelle est la parole qu'il t'a dite ? Ne me cache rien! Que Dieu te fasse ce mal et qu'il ajoute encore cet autre si tu me caches un mot de ce qu'il t'a dit. " 
###### 18
Alors Samuel lui rapporta tout, il ne lui cacha rien. Éli dit : " Il est Yahvé; qu'il fasse ce qui lui semble bon! " 
###### 19
Samuel grandit. Yahvé était avec lui et ne laissa rien tomber à terre de tout ce qu'il lui avait dit. 
###### 20
Tout Israël sut, depuis Dan jusqu'à Bersabée, que Samuel était accrédité comme prophète de Yahvé. 
###### 21
Yahvé continua de se manifester à Silo, car il se révélait à Samuel, à Silo, 
