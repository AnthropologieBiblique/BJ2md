---
aliases : 
- Philémon 1
- Philémon 1
- Phm 1
- Philemon 1
tags : 
- Bible/Phm/1
- français
cssclass : français
---

# Philémon 1

###### 
Paul, prisonnier du Christ Jésus, et le frère Timothée, à Philémon, notre cher collaborateur, 
###### 
avec Apphia notre sœur, Archippe notre frère d'armes, et l'Église qui s'assemble dans ta maison. 
###### 
A vous grâce et paix de par Dieu notre Père et le Seigneur Jésus Christ ! 
###### 
Je rends sans cesse grâces à mon Dieu en faisant mémoire de toi dans mes prières, 
###### 
car j'entends louer ta charité et la foi qui t'anime, tant à l'égard du Seigneur Jésus qu'au bénéfice de tous les saints. 
###### 
Puisse cette foi rendre agissant son esprit d'entraide en t'éclairant pleinement sur tout le bien qu'il est en notre pouvoir d'accomplir pour le Christ. 
###### 
De fait, j'ai eu grande joie et consolation en apprenant ta charité : on me dit, frère, que tu as soulagé le cœur des saints ! 
###### 
C'est pourquoi, bien que j'aie dans le Christ tout le franc-parler nécessaire pour te prescrire ton devoir, 
###### 
je préfère invoquer la charité et te présenter une requête. Celui qui va parler, c'est Paul, le vieux Paul et, qui plus est, maintenant le prisonnier du Christ Jésus. 
###### 
La requête est pour mon enfant, que j'ai engendré dans les chaînes, cet Onésime, 
###### 
qui jadis ne te fut guère utile, mais qui désormais te sera bien utile, comme il l'est devenu pour moi. 
###### 
Je te le renvoie, et lui, c'est comme mon propre cœur. 
###### 
Je désirais le retenir près de moi, pour qu'il me servît en ton nom dans ces chaînes que me vaut l'Évangile ; 
###### 
cependant je n'ai rien voulu faire sans ton assentiment, pour que ce bienfait ne parût pas t'être imposé, mais qu'il vînt de ton bon gré. 
###### 
Peut-être aussi Onésime ne t'a-t-il été retiré pour un temps qu'afin de t'être rendu pour l'éternité, 
###### 
non plus comme un esclave, mais bien mieux qu'un esclave, comme un frère très cher : il l'est grandement pour moi, combien plus va-t-il l'être pour toi, et selon le monde et selon le Seigneur ! 
###### 
Si donc tu as égard aux liens qui nous unissent, reçois-le comme si c'était moi. 
###### 
Et s'il t'a fait du tort ou te doit quelque chose, mets cela sur mon compte. 
###### 
Moi, Paul, je m'y engage de ma propre écriture : c'est moi qui réglerai... Pour ne rien dire de la dette qui t'oblige toujours à mon endroit, et qui est toi-même ! 
###### 
Allons, frère, j'attends de toi ce service dans le Seigneur ; soulage mon cœur dans le Christ. 
###### 
Je t'écris avec pleine confiance en ta docilité : je sais bien que tu feras plus encore que je ne demande. 
###### 
Avec cela, prépare-moi un gîte ; j'espère en effet que, grâce à vos prières, je vais vous être rendu. 
###### 
Tu as les salutations d'Épaphras, mon compagnon de captivité dans le Christ Jésus, 
###### 
ainsi que de Marc, Aristarque, Démas et Luc, mes collaborateurs. 
###### 
Que la grâce du Seigneur Jésus Christ soit avec votre esprit ! 
