---
aliases : 
- Amos 6
- Amos 6
- Am 6
tags : 
- Bible/Am/6
- français
cssclass : français
---

# Amos 6

###### 1
Malheur à ceux qui sont tranquilles en Sion, à ceux qui sont confiants sur la montagne de Samarie, ces notables des prémices des nations, à qui va la maison d'Israël. 
###### 2
Passez à Kalné et voyez, de là, allez à Hamat la grande, puis descendez à Gat des Philistins : valent-elles mieux que ces royaumes-ci ? leur territoire est-il plus grand que le vôtre ? 
###### 3
Vous pensez reculer le jour du malheur et vous hâtez le règne de la violence ! 
###### 4
Couchés sur des lits d'ivoire, vautrés sur leurs divans, ils mangent les agneaux du troupeau et les veaux pris à l'étable. 
###### 5
Ils braillent au son de la harpe, comme David, ils inventent des instruments de musique; 
###### 6
ils boivent le vin dans de larges coupes, ils se frottent des meilleures huiles, mais ils ne s'affligent pas de la ruine de Joseph ! 
###### 7
C'est pourquoi ils seront maintenant déportés, en tête des déportés, c'en est fait de l'orgie des vautrés ! Le châtiment sera terrible. 
###### 8
Le Seigneur Yahvé l'a juré par lui-même : - oracle de Yahvé, Dieu Sabaot - J'abhorre l'orgueil de Jacob, je hais ses palais, et je livrerai la ville et tout ce qui la remplit. 
###### 9
S'il reste dix hommes dans une seule maison, ils mourront. 
###### 10
Il n'y aura qu'un petit nombre de rescapés pour sortir les ossements de la maison; et si l'on dit à celui qui est au fond de la maison : " En reste-t-il avec toi ? " il dira : " Plus personne " et il dira : " Silence ! il ne faut pas prononcer le nom de Yahvé ! " 
###### 11
Car voici que Yahvé commande, sous ses coups la grande maison se crevasse et la petite se lézarde. 
###### 12
Les chevaux courent-ils sur le roc, laboure-t-on la mer avec des bœufs, que vous changiez le droit en poison et le fruit de la justice en absinthe ? 
###### 13
Vous vous réjouissez à propos de Lo-Debar, vous dites : " N'est-ce point par notre force que nous avons pris Qarnayim ? " 
###### 14
Or voici que je suscite contre vous, maison d'Israël - oracle de Yahvé, Dieu Sabaot - une nation qui vous opprimera depuis l'Entrée de Hamat jusqu'au torrent de la Araba. 
