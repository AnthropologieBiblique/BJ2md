---
aliases : 
- Amos 3
- Amos 3
- Am 3
tags : 
- Bible/Am/3
- français
cssclass : français
---

# Amos 3

###### 1
Écoutez cette parole que Yahvé prononce contre vous, enfants d'Israël, contre toute la famille que j'ai fait monter du pays d'Égypte : 
###### 2
Je n'ai connu que vous de toutes les familles de la terre, c'est pourquoi je vous châtierai pour toutes vos fautes. La vocation prophétique est irrésistible. 
###### 3
Deux hommes vont-ils ensemble sans s'être concertés ? 
###### 4
Le lion rugit-il dans la forêt sans avoir une proie ? Le lionceau donne-t-il de la voix, de sa tanière, sans qu'il ait rien pris ? 
###### 5
Le passereau tombe-t-il dans le filet, à terre, sans qu'il y ait de piège ? Le filet se soulève-t-il du sol sans rien attraper ? 
###### 6
Sonne-t-on du cor dans une ville sans que le peuple soit effrayé ? Arrive-t-il un malheur dans une ville sans que Yahvé en soit l'auteur ? 
###### 7
Mais le Seigneur Yahvé ne fait rien qu'il n'en ait révélé le secret à ses serviteurs les prophètes. 
###### 8
Le lion a rugi : qui ne craindrait ? Le Seigneur Yahvé a parlé : qui ne prophétiserait ? Samarie, corrompue, périra. 
###### 9
Proclamez-le sur les palais d'Assur et sur les palais du pays d'Égypte; dites : rassemblez-vous sur les monts de Samarie, et voyez, que de désordres au milieu d'elle et que d'oppression en son sein ! 
###### 10
Ils ne savent pas agir avec droiture, - oracle de Yahvé - eux qui entassent violence et rapine en leurs palais. 
###### 11
C'est pourquoi, ainsi parle le Seigneur Yahvé : L'ennemi investira le pays, il abattra ta puissance et tes palais seront pillés. 
###### 12
Ainsi parle Yahvé : Comme le berger sauve de la gueule du lion deux pattes ou un bout d'oreille, ainsi seront sauvés les enfants d'Israël qui sont assis dans Samarie, au coin d'un lit et sur un divan de Damas. Contre Béthel et les demeures luxueuses. 
###### 13
Écoutez et témoignez contre la maison de Jacob : - oracle du Seigneur Yahvé, Dieu Sabaot - 
###### 14
le jour où je châtierai Israël pour ses crimes, je sévirai contre les autels de Béthel; les cornes de l'autel seront abattues et tomberont à terre. 
###### 15
Je frapperai la maison d'hiver avec la maison d'été, les maisons d'ivoire seront détruites, bien des maisons disparaîtront, oracle de Yahvé. 
