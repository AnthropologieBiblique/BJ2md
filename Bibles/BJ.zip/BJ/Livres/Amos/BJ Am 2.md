---
aliases : 
- Amos 2
- Amos 2
- Am 2
tags : 
- Bible/Am/2
- français
cssclass : français
---

# Amos 2

###### 1
Ainsi parle Yahvé : Pour trois crimes de Moab et pour quatre, je l'ai décidé sans retour ! Parce qu'il a brûlé les os du roi d'Édom jusqu'à les calciner, 
###### 2
j'enverrai le feu dans Moab, il dévorera les palais de Qeriyyot, et Moab mourra dans le tumulte, dans la clameur, au son du cor; 
###### 3
je supprimerai le juge de chez lui, et tous ses princes, je les tuerai avec lui, dit Yahvé. 
###### 4
Ainsi parle Yahvé : Pour trois crimes de Juda et pour quatre, je l'ai décidé sans retour ! Parce qu'ils ont rejeté la loi de Yahvé et n'ont pas observé ses décrets, parce que leurs Mensonges les ont égarés, ceux que leurs pères avaient suivis, 
###### 5
J'enverrai le feu dans Juda, et il dévorera les palais de Jérusalem. Israël. 
###### 6
Ainsi parle Yahvé : Pour trois crimes d'Israël et pour quatre, je l'ai décidé sans retour ! Parce qu'ils vendent le juste à prix d'argent et le pauvre pour une paire de sandales; 
###### 7
parce qu'ils écrasent la tête des faibles sur la poussière de la terre et qu'ils font dévier la route des humbles; parce que fils et père vont à la même fille afin de profaner mon saint nom; 
###### 8
parce qu'ils s'étendent sur des vêtements pris en gage, à côté de tous les autels, et qu'ils boivent dans la maison de leur dieu le vin de ceux qui sont frappés d'amende. 
###### 9
Et moi, j'avais anéanti devant eux l'Amorite, lui dont la taille égalait celle des cèdres, lui qui était fort comme les chênes ! J'avais anéanti son fruit, en haut, et ses racines, en bas ! 
###### 10
Et moi, je vous avais fait monter du pays d'Égypte, et pendant quarante ans, menés dans le désert, pour que vous possédiez le pays de l'Amorite ! 
###### 11
J'avais suscité parmi vos fils des prophètes, et parmi vos jeunes gens des nazirs ! N'en est-il pas ainsi, enfants d'Israël ? Oracle de Yahvé. 
###### 12
Mais vous avez fait boire du vin aux nazirs, aux prophètes, vous avez donné cet ordre : " Ne prophétisez pas ! " 
###### 13
Eh bien ! moi, je vais vous broyer sur place comme broie le chariot plein de gerbes; 
###### 14
la fuite manquera à l'homme agile, l'homme fort ne déploiera pas sa vigueur et le brave ne sauvera pas sa vie; 
###### 15
celui qui manie l'arc ne tiendra pas, l'homme aux pieds agiles n'échappera pas, celui qui monte à cheval ne sauvera pas sa vie, 
###### 16
et le plus courageux d'entre les braves s'enfuira nu, en ce jour-là, oracle de Yahvé. 
