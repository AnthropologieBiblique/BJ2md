---
aliases : 
- Amos 9
- Amos 9
- Am 9
tags : 
- Bible/Am/9
- français
cssclass : français
---

# Amos 9

###### 1
Je vis le Seigneur debout près de l'autel, et il dit : " Frappe le chapiteau et que les seuils s'ébranlent; brise-les sur leur tête à tous, et ce qui restera d'eux, je les tuerai par l'épée; ils ne s'enfuira point parmi eux de fuyard, il ne se sauvera point parmi eux de rescapé. 
###### 2
S'ils forcent l'entrée du Shéol, de là ma main les prendra; et s'ils montent aux cieux, de là je les ferai descendre; 
###### 3
s'ils se cachent au sommet du Carmel, là j'irai les chercher et les prendre; s'ils se dérobent à mes yeux au fond de la mer, là je commanderai au Serpent de les mordre; 
###### 4
s'ils s'en vont captifs devant leurs ennemis, là je commanderai à l'épée de les tuer, je fixerai les yeux sur eux, pour leur malheur et non pour leur bonheur. 
###### 5
Et le Seigneur Yahvé Sabaot... Il touche la terre et elle se dissout, et tous ses habitants sont en deuil; elle monte comme le Nil, tout entière, et puis retombe comme le Nil d'Égypte. 
###### 6
Il bâtit dans le ciel ses chambres hautes, il a fondé sa voûte sur la terre; il appelle les eaux de la mer et les répand sur la face de la terre; Yahvé est son nom. Tous les pécheurs périront. 
###### 7
N'êtes-vous pas pour moi comme des Kushites, enfants d'Israël ? - oracle de Yahvé - N'ai-je pas fait monter Israël du pays d'Égypte, et les Philistins de Kaphtor et les Araméens de Qir ? 
###### 8
Voici, les yeux du Seigneur Yahvé sont sur le royaume pécheur. Je vais l'exterminer de la surface du sol, toutefois je n'exterminerai pas complètement la maison de Jacob - oracle de Yahvé. 
###### 9
Car voici que je vais commander et je secouerai la maison d'Israël parmi toutes les nations, comme on secoue avec le crible, et pas un grain ne tombe à terre. 
###### 10
Tous les pécheurs de mon peuple périront par l'épée, eux qui disent : " Le malheur n'avancera pas, il ne nous atteindra pas. " 
###### 11
En ces jours-là, je relèverai la hutte branlante de David, je réparerai ses brèches, je relèverai ses ruines, je la rebâtirai comme aux jours d'autrefois, 
###### 12
afin qu'ils possèdent le reste d'Édom et toutes les nations qui furent appelées de mon nom, oracle de Yahvé qui a fait cela. 
###### 13
Voici venir des jours - oracle de Yahvé - où se suivront de près laboureur et moissonneur, celui qui foule les raisins et celui qui répand la semence. Les montagnes suinteront de jus de raisin, toutes les collines deviendront liquides. 
###### 14
Je rétablirai mon peuple Israël; ils rebâtiront les villes dévastées et les habiteront, ils planteront des vignes et en boiront le vin, ils cultiveront des jardins et en mangeront les fruits. 
###### 15
Je les planterai sur leur terre et ils ne seront plus arrachés de dessus la terre que je leur ai donnée, dit Yahvé ton Dieu. 
