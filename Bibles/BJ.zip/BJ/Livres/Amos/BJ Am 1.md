---
aliases : 
- Amos 1
- Amos 1
- Am 1
tags : 
- Bible/Am/1
- français
cssclass : français
---

# Amos 1

###### 1
Paroles d'Amos, qui fut l'un des bergers de Téqoa. Ce qu'il vit sur Israël au temps d'Ozias, roi de Juda, et au temps de Jéroboam, fils de Joas, roi d'Israël, deux ans avant le tremblement de terre. 
###### 2
Il dit : De Sion, Yahvé rugit, et de Jérusalem, il donne de la voix; les pacages des bergers sont en deuil et le sommet du Carmel se dessèche. 
###### 3
Ainsi parle Yahvé : Pour trois crimes de Damas et pour quatre, je l'ai décidé sans retour ! Parce qu'ils ont foulé Galaad avec des traîneaux de fer, 
###### 4
j'enverrai le feu dans la maison d'Hazaèl et il dévorera les palais de Ben-Hadad; 
###### 5
je briserai le verrou de Damas, de Biqeat-Aven je supprimerai l'habitant, de Bet-Éden, celui qui tient le sceptre, et le peuple d'Aram sera déporté à Qir, dit Yahvé. 
###### 6
Ainsi parle Yahvé : Pour trois crimes de Gaza et pour quatre, je l'ai décidé sans retour ! Parce qu'ils ont déporté des populations entières pour les livrer à Édom, 
###### 7
j'enverrai le feu dans le rempart de Gaza et il dévorera ses palais; 
###### 8
d'Ashdod je supprimerai l'habitant, et d'Ashqelôn, celui qui tient le sceptre; je tournerai ma main contre Eqrôn et ce qui reste des Philistins périra, dit le Seigneur Yahvé. 
###### 9
Ainsi parle Yahvé : Pour trois crimes de Tyr et pour quatre, je l'ai décidé sans retour ! Parce qu'ils ont livré à Édom des populations entières de captifs, sans se souvenir d'une alliance entre frères, 
###### 10
j'enverrai le feu dans le rempart de Tyr et il dévorera ses palais. 
###### 11
Ainsi parle Yahvé : Pour trois crimes d'Édom et pour quatre, je l'ai décidé sans retour ! Parce qu'il a poursuivi son frère avec l'épée, étouffant toute pitié, parce qu'il garde à jamais sa colère et conserve sans fin sa fureur, 
###### 12
j'enverrai le feu dans Témân et il dévorera les palais de Boçra. 
###### 13
Ainsi parle Yahvé : Pour trois crimes des fils d'Ammon et pour quatre, je l'ai décidé sans retour ! Parce qu'ils ont éventré les femmes enceintes du Galaad afin d'élargir leur territoire, 
###### 14
je mettrai le feu au rempart de Rabba et il dévorera ses palais, dans la clameur, en un jour de bataille, dans la tempête, en un jour d'ouragan; 
###### 15
et leur roi s'en ira en déportation, lui, et ses princes avec lui, dit Yahvé. 
