---
aliases : 
- Amos 4
- Amos 4
- Am 4
tags : 
- Bible/Am/4
- français
cssclass : français
---

# Amos 4

###### 1
Écoutez cette parole, vaches du Bashân qui êtes sur la montagne de Samarie, qui exploitez les faibles, qui maltraitez les pauvres, qui dites à vos maris : " Apporte et buvons ! " 
###### 2
Le Seigneur l'a juré par sa sainteté : voici que des jours viennent sur vous où l'on vous enlèvera avec des crocs, et jusqu'aux dernières, avec des harpons de pêche; 
###### 3
vous sortirez par des brèches, chacune droit devant soi, et vous serez repoussées vers l'Hermon, oracle de Yahvé. Illusions, impénitence, châtiment d'Israël. 
###### 4
Allez à Béthel et péchez ! A Gilgal, péchez de plus belle ! Apportez le matin vos sacrifices, tous les trois jours vos dîmes; 
###### 5
faites brûler du levain en sacrifice de louange, criez vos offrandes volontaires, annoncez-les, puisque c'est cela que vous aimez, enfants d'Israël ! Oracle du Seigneur Yahvé. 
###### 6
Aussi, moi je vous ai fait les dents nettes en toutes vos villes, je vous ai privés de pain dans tous vos villages; et vous n'êtes pas revenus à moi ! Oracle de Yahvé. 
###### 7
Aussi, moi je vous ai refusé la pluie, juste trois mois avant la moisson; j'ai fait pleuvoir sur une ville et sur une autre ville je ne faisais pas pleuvoir; un champ recevait de la pluie, et un champ, faute de pluie, se desséchait; 
###### 8
deux, trois villes allaient en titubant vers une autre pour boire de l'eau sans pouvoir se désaltérer; et vous n'êtes pas revenus à moi ! Oracle de Yahvé. 
###### 9
Je vous ai frappés par la rouille et la nielle, j'ai desséché vos jardins et vos vignes; vos figuiers et vos oliviers, la sauterelle les a dévorés; et vous n'êtes pas revenus à moi ! Oracle de Yahvé. 
###### 10
J'ai envoyé parmi vous une peste, comme la peste d'Égypte; j'ai tué vos jeunes gens par l'épée, tandis que vos chevaux étaient capturés; j'ai fait monter à vos narines la puanteur de vos camps; et vous n'êtes pas revenus à moi ! Oracle de Yahvé. 
###### 11
Je vous ai bouleversés comme Dieu bouleversa Sodome et Gomorrhe, et vous avez été comme un tison sauvé de l'incendie; et vous n'êtes pas revenus à moi ! Oracle de Yahvé. 
###### 12
C'est pourquoi, voici comment je vais te traiter, Israël ! Parce que je vais te traiter ainsi, prépare-toi à rencontrer ton Dieu, Israël ! 
###### 13
Car c'est lui qui forme les montagnes et qui crée le vent, qui révèle à l'homme ses pensées, qui change l'aurore en ténèbres, et qui marche sur les hauteurs de la terre : Yahvé, Dieu Sabaot, est son nom. 
