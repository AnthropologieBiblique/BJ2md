---
aliases : 
- Amos 7
- Amos 7
- Am 7
tags : 
- Bible/Am/7
- français
cssclass : français
---

# Amos 7

###### 1
Voici ce que me fit voir le Seigneur Yahvé : C'était une éclosion de sauterelles, au temps où le regain commence à monter, de sauterelles adultes, après la coupe du roi. 
###### 2
Et comme elles achevaient de dévorer l'herbe du pays, je dis : " Seigneur Yahvé, pardonne, je t'en prie ! Comment Jacob tiendra-t-il ? Il est si petit ! " 
###### 3
Yahvé en eut du repentir : " Cela ne sera pas ", dit Yahvé. 
###### 4
Voici ce que me fit voir le Seigneur Yahvé : Le Seigneur Yahvé appelait le feu pour châtier : celui-ci dévora le grand Abîme, puis il dévora la campagne. 
###### 5
Je dis : " Seigneur Yahvé, cesse, je t'en prie ! Comment Jacob tiendra-t-il ? Il est si petit ! " 
###### 6
Yahvé en eut du repentir : " Cela non plus ne sera pas ", dit le Seigneur Yahvé. 
###### 7
Voici ce qu'il me fit voir : Le Seigneur se tenait près d'un mur, un fil à plomb dans la main. 
###### 8
Yahvé me dit : " Que vois-tu, Amos ? " Je dis : " Un fil à plomb. " Le Seigneur dit : " Voici que je vais mettre un fil à plomb au milieu de mon peuple, Israël, désormais je ne lui pardonnerai plus. 
###### 9
Les hauts lieux d'Isaac seront dévastés, les sanctuaires d'Israël détruits, et je me lèverai contre la maison de Jéroboam avec l'épée. 
###### 10
Alors Amasias, le prêtre de Béthel, envoya dire à Jéroboam, roi d'Israël : " Amos conspire contre toi, au sein de la maison d'Israël; le pays ne peut tolérer ses discours. 
###### 11
Car ainsi parle Amos : "Jéroboam périra par l'épée et Israël sera déporté loin de sa terre". " 
###### 12
Et Amasias dit à Amos : " Voyant, va-t-en; fuis au pays de Juda; mange ton pain là-bas, et là-bas prophétise. 
###### 13
Mais à Béthel, cesse désormais de prophétiser, car c'est un sanctuaire royal, un temple du royaume. " 
###### 14
Amos répondit et dit à Amasias : " Je ne suis pas prophète, je ne suis pas frère prophète; je suis bouvier et pinceur de sycomores. 
###### 15
Mais Yahvé m'a pris de derrière le troupeau et Yahvé m'a dit : "Va, prophétise à mon peuple Israël. " 
###### 16
Et maintenant, écoute la parole de Yahvé : Tu dis : "Tu ne prophétiseras pas contre Israël, tu ne vaticineras pas contre la maison d'Isaac. " 
###### 17
C'est pourquoi, ainsi parle Yahvé : "Ta femme se prostituera dans la ville, tes fils et tes filles tomberont sous l'épée, ta terre sera partagée au cordeau, et toi, tu mourras sur une terre impure, et Israël sera déporté loin de sa terre". 
