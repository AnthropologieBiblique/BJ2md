---
aliases : 
- Amos 5
- Amos 5
- Am 5
tags : 
- Bible/Am/5
- français
cssclass : français
---

# Amos 5

###### 1
Écoutez cette parole que je profère contre vous, une lamentation, maison d'Israël : 
###### 2
Elle est tombée, elle ne se relèvera plus, la vierge d'Israël ! Elle est étendue sur son sol, personne pour la relever ! 
###### 3
Car ainsi parle le Seigneur Yahvé : la ville qui mettait en campagne mille hommes n'en aura plus que cent, et celle qui en mettait cent n'en aura plus que dix, pour la maison d'Israël. Sans conversion, point de salut. 
###### 4
Car ainsi parle Yahvé à la maison d'Israël : Cherchez-moi et vous vivrez ! 
###### 5
Mais ne cherchez pas Béthel, n'allez pas à Gilgal, ne passez pas à Bersabée; car Gilgal ira en déportation et Béthel deviendra néant. 
###### 6
Cherchez Yahvé et vous vivrez, de peur qu'il ne fonde comme le feu sur la maison de Joseph, qu'il ne dévore, et personne à Béthel pour éteindre ! 
###### 7
Ils changent le droit en absinthe et jettent à terre la justice. 
###### 8
C'est lui qui fait les Pléiades et Orion, qui change en matin les ténèbres épaisses et obscurcit le jour comme la nuit; lui qui appelle les eaux de la mer et les répand sur la face de la terre; Yahvé est son nom. 
###### 9
Il déchaîne la dévastation sur celui qui est fort, et la dévastation arrive sur la citadelle. 
###### 10
Ils haïssent quiconque réprimande à la Porte, ils abhorrent celui qui parle avec intégrité. 
###### 11
Eh bien ! puisque vous piétinez le faible et que vous prélevez sur lui un tribut de froment, ces maisons en pierres de taille que vous avez bâties, vous n'y habiterez pas; ces vignes délicieuses que vous avez plantées, vous n'en boirez pas le vin. 
###### 12
Car je sais combien nombreux sont vos crimes, énormes vos péchés, oppresseurs du juste, extorqueurs de rançons, vous qui, à la Porte, déboutez les pauvres. 
###### 13
Voilà pourquoi l'homme avisé se tait en ce temps-ci, car c'est un temps de malheur. 
###### 14
Recherchez le bien et non le mal, afin que vous viviez, et qu'ainsi Yahvé, Dieu Sabaot, soit avec vous, comme vous le dites. 
###### 15
Haïssez le mal, aimez le bien, et faites régner le droit à la Porte; peut-être Yahvé, Dieu Sabaot, prendra-t-il en pitié le reste de Joseph ? 
###### 16
C'est pourquoi, ainsi parle Yahvé, le Dieu Sabaot, le Seigneur : Sur toutes les places il y aura des lamentations, et dans toutes les rues, on dira " Hélas ! Hélas ! " On convoquera le laboureur au deuil et aux lamentations ceux qui savent gémir; 
###### 17
dans toutes les vignes il y aura des lamentations, car je vais passer au milieu de toi, dit Yahvé. 
###### 18
Malheur à ceux qui soupirent après le jour de Yahvé ! Que sera-t-il pour vous, le jour de Yahvé ? Il sera ténèbres, et non lumière. 
###### 19
Tel l'homme qui fuit devant un lion et tombe sur un ours ! Il entre à la maison, appuie sa main au mur, et un serpent le mord ! 
###### 20
N'est-il pas ténèbres, le jour de Yahvé, et non lumière ? Il est obscur et sans clarté ! 
###### 21
Je hais, je méprise vos fêtes et je ne puis sentir vos réunions solennelles. 
###### 22
Quand vous m'offrez des holocaustes... vos oblations, je ne les agrée pas, le sacrifice de vos bêtes grasses, je ne le regarde pas. 
###### 23
Écarte de moi le bruit de tes cantiques, que je n'entende pas la musique de tes harpes ! 
###### 24
Mais que le droit coule comme de l'eau, et la justice, comme un torrent qui ne tarit pas. 
###### 25
Des sacrifices et des oblations, m'en avez-vous présentés au désert, pendant quarante ans, maison d'Israël ? 
###### 26
Vous emporterez Sakkut, votre roi, et l'étoile de votre dieu, Kevân, ces images que vous vous êtes fabriquées; 
###### 27
et je vous déporterai par-delà Damas, dit Yahvé - Dieu Sabaot est son nom. 
