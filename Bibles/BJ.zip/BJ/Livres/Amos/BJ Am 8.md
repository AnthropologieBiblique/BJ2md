---
aliases : 
- Amos 8
- Amos 8
- Am 8
tags : 
- Bible/Am/8
- français
cssclass : français
---

# Amos 8

###### 1
Voici ce que me fit voir le Seigneur Yahvé : C'était une corbeille de fruits mûrs. 
###### 2
Il dit : " Que vois-tu, Amos ? " Je dis : " Une corbeille de fruits mûrs. " Yahvé me dit : " Mon peuple Israël est mûr pour sa fin, désormais je ne lui pardonnerai plus. 
###### 3
Les chants du palais seront des hurlements en ce jour-là - oracle du Seigneur Yahvé - Nombreux seront les cadavres, on le jettera en tous lieux. Silence ! 
###### 4
Écoutez ceci, vous qui écrasez le pauvre et voudriez faire disparaître les humbles du pays, 
###### 5
vous qui dites : " Quand donc sera passée la néoménie pour que nous vendions du grain, et le sabbat, que nous écoulions le froment ? Nous diminuerons la mesure, nous augmenterons le sicle, nous fausserons les balances pour tromper. 
###### 6
Nous achèterons les faibles à prix d'argent et le pauvre pour une paire de sandales; et nous vendrons les déchets du froment. " 
###### 7
Yahvé l'a juré par l'orgueil de Jacob : Jamais je n'oublierai aucune de leurs actions. 
###### 8
A cause de cela la terre ne tremble-t-elle pas ? Tous ceux qui l'habitent ne sont-ils pas en deuil ? Elle monte, comme le Nil, tout entière, elle gonfle et puis retombe, comme le Nil d'Égypte. 
###### 9
Il adviendra en ce jour-là - oracle du Seigneur Yahvé - que je ferai coucher le soleil en plein midi et que j'obscurcirai la terre en un jour de lumière. 
###### 10
Je changerai vos fêtes en deuil et tous vos chants en lamentations; je mettrai le sac sur tous les reins et la tonsure sur toutes les têtes. J'en ferai comme un deuil de fils unique, sa fin sera comme un jour d'amertume. 
###### 11
Voici venir des jours - oracle de Yahvé - où j'enverrai la faim dans le pays, non pas une faim de pain, non pas une soif d'eau, mais d'entendre la parole de Yahvé. 
###### 12
On ira titubant d'une mer à l'autre mer, du nord au levant, on errera pour chercher la parole de Yahvé et on ne la trouvera pas ! 
###### 13
En ce jour-là s'étioleront de soif les belles jeunes filles et les jeunes gens. 
###### 14
Ceux qui jurent par le péché de Samarie, ceux qui disent : " Vive ton dieu, Dan ! " et : " Vive le chemin de Bersabée ! " ceux-là tomberont pour ne plus se relever. 
