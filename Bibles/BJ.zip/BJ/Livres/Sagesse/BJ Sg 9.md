---
aliases : 
- Sagesse 9
- Sagesse 9
- Sg 9
- Wisdom of Solomon 9
tags : 
- Bible/Sg/9
- français
cssclass : français
---

# Sagesse 9

###### 1
"Dieu des Pères et Seigneur de miséricorde, toi qui, par ta parole, as fait l'univers,
###### 2
toi qui, par ta Sagesse, as formé l'homme pour dominer sur les créatures que tu as faites,
###### 3
pour régir le monde en sainteté et justice et exercer le jugement en droiture d'âme,
###### 4
donne-moi celle qui partage ton trône, la Sagesse, et ne me rejette pas du nombre de tes enfants.
###### 5
Car je suis ton serviteur et le fils de ta servante, un homme faible et de vie éphémère, peu apte à comprendre la justice et les lois.
###### 6
Quelqu'un, en effet, serait-il parfait parmi les fils des hommes, s'il lui manque la sagesse qui vient de toi, on le comptera pour rien.
###### 7
C'est toi qui m'as choisi pour roi de ton peuple et pour juge de tes fils et de tes filles.
###### 8
Tu m'as ordonné de bâtir un Temple sur ta montagne sainte, et un autel dans la ville où tu as fixé ta tente, imitation de la Tente sainte que tu as préparée dès l'origine.
###### 9
Avec toi est la Sagesse, qui connaît tes œuvres et qui était présente quand tu faisais le monde; elle sait ce qui est agréable à tes yeux et ce qui est conforme à tes commandements.
###### 10
Mande-la des cieux saints, de ton trône de gloire envoie-la, pour qu'elle me seconde et peine avec moi, et que je sache ce qui te plaît;
###### 11
car elle sait et comprend tout. Elle me guidera prudemment dans mes actions et me protégera par sa gloire.
###### 12
Alors mes œuvres seront agréées, je jugerai ton peuple avec justice et je serai digne du trône de mon père.
###### 13
Quel homme en effet peut connaître le dessein de Dieu, et qui peut concevoir ce que veut le Seigneur?
###### 14
Car les pensées des mortels sont timides, et instables nos réflexions;
###### 15
un corps corruptible, en effet, appesantit l'âme, et cette tente d'argile alourdit l'esprit aux multiples soucis.
###### 16
Nous avons peine à conjecturer ce qui est sur la terre, et ce qui est à notre portée nous ne le trouvons qu'avec effort, mais ce qui est dans les cieux, qui l'a découvert?
###### 17
Et ta volonté, qui l'a connue, sans que tu aies donné la Sagesse et envoyé d'en haut ton esprit saint?
###### 18
Ainsi ont été rendus droits les sentiers de ceux qui sont sur la terre, ainsi les hommes ont été instruits de ce qui te plaît et, par la Sagesse, ont été sauvés."
