---
aliases : 
- Sagesse 3
- Sagesse 3
- Sg 3
- Wisdom of Solomon 3
tags : 
- Bible/Sg/3
- français
cssclass : français
---

# Sagesse 3

###### 1
Les âmes des justes sont dans la main de Dieu. Et nul tourment ne les atteindra.
###### 2
Aux yeux des insensés ils ont paru mourir, leur départ a été tenu pour un malheur
###### 3
et leur voyage loin de nous pour un anéantissement, mais eux sont en paix.
###### 4
S'ils ont, aux yeux des hommes, subi des châtiments, leur espérance était pleine d'immortalité;
###### 5
pour une légère correction ils recevront de grands bienfaits. Dieu en effet les a mis à l'épreuve et il les a trouvés dignes de lui;
###### 6
comme l'or au creuset, il les a éprouvés, comme un parfait holocauste, il les a agréés.
###### 7
Au temps de leur visite, ils resplendiront, et comme des étincelles à travers le chaume ils courront.
###### 8
Ils jugeront les nations et domineront sur les peuples, et le Seigneur régnera sur eux à jamais.
###### 9
Ceux qui mettent en lui leur confiance comprendront la vérité et ceux qui sont fidèles demeureront auprès de lui dans l'amour, car la grâce et la miséricorde sont pour ses saints et sa visite est pour ses élus.
###### 10
Mais les impies auront un châtiment conforme à leurs pensées, eux qui ont négligé le juste et se sont écartés du Seigneur.
###### 11
Car malheur à qui méprise sagesse et discipline vaine est leur espérance, sans utilité leurs fatigues, sans profit leurs œuvres;
###### 12
leurs femmes sont insensées, pervers leurs enfants, maudite leur postérité!
###### 13
Heureuse la femme stérile qui est sans tache, celle qui n'a pas connu d'union coupable; car elle aura du fruit à la visite des âmes.
###### 14
Heureux encore l'eunuque dont la main ne commet pas de forfait et qui ne nourrit pas de pensées perverses contre le Seigneur il lui sera donné pour sa fidélité une grâce de choix, un lot très délicieux dans le Temple du Seigneur.
###### 15
Car le fruit de labeurs honnêtes est plein de gloire, impérissable est la racine de l'intelligence.
###### 16
Mais les enfants d'adultères n'atteindront pas leur maturité, la postérité issue d'une union illégitime disparaîtra.
###### 17
Même si leur vie se prolonge, ils seront comptés pour rien et, à la fin, leur vieillesse sera sans honneur,
###### 18
s'ils meurent tôt, ils n'auront pas d'espérance ni de consolation au jour de la Décision,
###### 19
car la fin d'une race injuste est cruelle!
