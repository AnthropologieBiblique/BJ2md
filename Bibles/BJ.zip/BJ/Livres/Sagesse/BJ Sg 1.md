---
aliases : 
- Sagesse 1
- Sagesse 1
- Sg 1
- Wisdom of Solomon 1
tags : 
- Bible/Sg/1
- français
cssclass : français
---

# Sagesse 1

###### 1
Aimez la justice, vous qui jugez la terre, ayez sur le Seigneur de droites pensées et cherchez-le en simplicité de cœur,
###### 2
parce qu'il se laisse trouver par ceux qui ne le tentent pas, il se révèle à ceux qui ne lui refusent pas leur foi.
###### 3
Car les pensées tortueuses éloignent de Dieu, et, mise à l'épreuve, la Puissance confond les insensés.
###### 4
Non, la Sagesse n'entre pas dans une âme malfaisante, elle n'habite pas dans un corps tributaire du péché.
###### 5
Car l'esprit saint, l'éducateur, fuit la fourberie, il se retire devant des pensées sans intelligence, il s'offusque quand survient l'injustice.
###### 6
La Sagesse est un esprit ami des hommes, mais elle ne laisse pas impuni le blasphémateur pour ses propos; car Dieu est le témoin de ses reins, le surveillant véridique de son cœur, et ce que dit sa langue, il l'entend.
###### 7
L'esprit du Seigneur en effet remplit le monde, et lui, qui tient unies toutes choses, a connaissance de chaque mot.
###### 8
Nul ne saurait donc se dérober, qui profère des méchancetés, la Justice vengeresse ne le laissera pas échapper.
###### 9
Sur les desseins de l'impie il sera fait enquête, le bruit de ses paroles ira jusqu'au Seigneur, pour que soient châtiés ses forfaits.
###### 10
Une oreille jalouse écoute tout, la rumeur même des murmures ne lui échappe pas.
###### 11
Gardez-vous donc des vains murmures, épargnez à votre langue les mauvais propos; car un mot furtif ne demeure pas sans effet, une bouche mensongère donne la mort à l'âme.
###### 12
Ne recherchez pas la mort par les égarements de votre vie et n'attirez pas sur vous la ruine par les œuvres de vos mains.
###### 13
Car Dieu n'a pas fait la mort, il ne prend pas plaisir à la perte des vivants.
###### 14
Il a tout créé pour l'être; les créatures du monde sont salutaires, en elles il n'est aucun poison de mort, et l'Hadès ne règne pas sur la terre;
###### 15
car la justice est immortelle.
###### 16
Mais les impies appellent la mort du geste et de la voix; la tenant pour amie, pour elle ils se consument, avec elle ils font un pacte, dignes qu'ils sont de lui appartenir.
