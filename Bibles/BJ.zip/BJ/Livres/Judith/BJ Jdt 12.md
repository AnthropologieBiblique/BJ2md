---
aliases : 
- Judith 12
- Judith 12
- Jdt 12
tags : 
- Bible/Jdt/12
- français
cssclass : français
---

# Judith 12

###### 1
Il la fit ensuite introduire là où était disposée sa vaisselle d'argent, lui fit servir de ses mets et lui donna à boire de son vin.
###### 2
Mais Judith : "Je me garderai bien d'en manger de peur que, pour moi, il n'y ait là une occasion de faute. Ce que j'ai apporté avec moi me suffira"
###### 3
"Et si tes provisions viennent à manquer, comment pourrons-nous t'en procurer de semblables? Reprit Holopherne. Parmi nous il n'y a personne de ta race"
###### 4
"Vis en paix, Monseigneur! Moi, ta servante, je n'aurai pas consommé toutes mes provisions que le Seigneur n'ait accompli par moi ses desseins!"
###### 5
Les aides de camp d'Holopherne la conduisirent alors à sa tente où elle dormit jusqu'au milieu de la nuit. Quand approcha la veille de l'aurore, elle se leva.
###### 6
Elle avait fait dire à Holopherne : "Que Monseigneur veuille bien ordonner de laisser sortir sa servante pour la prière",
###### 7
de sorte qu'Holopherne avait prescrit à ses gardes de ne pas l'en empêcher. Elle demeura trois jours dans le camp. Elle sortait de nuit vers le ravin de Béthulie et se lavait à la source où se trouvait le poste de garde.
###### 8
En remontant elle priait le Seigneur Dieu d'Israël de diriger son entreprise en vue du relèvement des fils de son peuple.
###### 9
Une fois purifiée, elle revenait et se tenait dans sa tente jusqu'au moment où, le soir, on lui apportait sa nourriture.
###### 10
Le quatrième jour, Holopherne donna un banquet auquel il invita seulement ses officiers, non compris ceux des services.
###### 11
Il dit à Bagoas, l'eunuque préposé à ses affaires : "Va donc persuader cette fille des Hébreux qui est chez toi de venir avec nous pour manger et boire en notre compagnie.
###### 12
Ce serait une honte pour nous de laisser partir une telle femme sans avoir eu commerce avec elle. Si nous ne réussissons pas à la décider, on rira bien de nous."
###### 13
Bagoas sortit donc de chez Holopherne et entra chez Judith. "Cette jeune beauté daignerait-elle venir sans tarder en présence de mon maître? Dit-il. Elle sera à la place d'honneur en face de lui, boira avec nous un vin joyeux, et deviendra aujourd'hui même comme l'une des filles des Assyriens qui se tiennent dans le palais de Nabuchodonosor"
###### 14
"Qui suis-je donc, répondit Judith, pour m'opposer à Monseigneur? Tout ce qui sera agréable à ses yeux je le ferai avec empressement, et ce sera pour moi un sujet de joie jusqu'au jour de ma mort!"
###### 15
Elle se leva, se para de ses vêtements et de tous ses atours féminins. Sa servante la précéda et étendit par terre vis-à-vis d'Holopherne la toison que Bagoas avait donnée à Judith pour son usage journalier, afin qu'elle pût s'y étendre pour manger.
###### 16
Judith entra et s'installa. Le cœur d'Holopherne en fut tout ravi et son esprit troublé. Il était saisi d'un désir intense de s'unir à elle, car depuis le jour où il l'avait vue il guettait un moment favorable pour la séduire.
###### 17
Il lui dit : "Bois donc! Partage notre joie"
###### 18
"Je bois volontiers, seigneur, car depuis ma naissance je n'ai jamais tant apprécié la vie qu'aujourd'hui!"
###### 19
Elle prit ce que lui avait préparé sa servante, puis mangea et but en face de lui.
###### 20
Holopherne était sous son charme, aussi but-il une telle quantité de vin qu'en aucun jour de sa vie il n'en avait tant absorbé.
