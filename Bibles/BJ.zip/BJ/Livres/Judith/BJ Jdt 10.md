---
aliases : 
- Judith 10
- Judith 10
- Jdt 10
tags : 
- Bible/Jdt/10
- français
cssclass : français
---

# Judith 10

###### 1
Ainsi criait Judith vers le Dieu d'Israël. Au terme de sa prière,
###### 2
elle se releva de sa prostration, appela sa servante, descendit dans l'appartement où elle se tenait aux jours de sabbat et de fête.
###### 3
Là, ôtant le sac qui l'enveloppait et quittant ses habits de deuil, elle se baigna, s'oignit d'un généreux parfum, peigna sa chevelure, ceignit un turban et revêtit le costume de joie qu'elle mettait du vivant de son mari Manassé.
###### 4
Elle chaussa ses sandales, mit ses colliers, ses anneaux, ses bagues, ses pendants d'oreilles, tous ses bijoux, elle se fit aussi belle que possible pour séduire les regards de tous les hommes qui la verraient.
###### 5
Puis elle donna à sa servante une outre de vin et une cruche d'huile, remplit une besace de galettes de farine d'orge, de gâteaux de fruits secs et de pains purs, et lui remit toutes ces provisions empaquetées.
###### 6
Elles sortirent alors dans la direction de la porte de Béthulie. Elles y trouvèrent posté Ozias, avec deux anciens de la ville, Chabris et Charmis.
###### 7
Quand ils virent Judith le visage transformé et les vêtements changés, sa beauté les jeta dans la plus grande stupéfaction. Alors ils lui dirent
###### 8
"Que le Dieu de nos pères te tienne en sa bienveillance! Qu'il donne accomplissement à tes desseins pour la glorification des enfants d'Israël et pour l'exaltation de Jérusalem!"
###### 9
Judith adora Dieu et leur dit : "Faites-moi ouvrir la porte de la ville, que je puisse sortir et réaliser tous les souhaits que vous venez de m'exprimer." Ils ordonnèrent donc aux jeunes gardes de lui ouvrir comme elle l'avait demandé.
###### 10
Ils obéirent et Judith sortit avec sa servante, suivie du regard par les gens de la ville pendant toute la descente de la montagne jusqu'à la traversée du vallon. Puis ils ne la virent plus.
###### 11
Comme elles marchaient droit devant elles dans le vallon, un poste avancé d'Assyriens se porta à leur rencontre
###### 12
et, se saisissant de Judith, ils l'interrogèrent. "De quel parti es-tu? D'où viens-tu? Où vas-tu" ? "Je suis, répondit-elle, une fille des Hébreux et je m'enfuis de chez eux, car ils ne seront pas longs à vous servir de pâture.
###### 13
Et je viens voir Holopherne, le général de votre armée, pour lui donner des renseignements sûrs. Je lui montrerai le chemin par où passer pour se rendre maître de toute la montagne sans perdre un homme ni un vie."
###### 14
En l'entendant parler les hommes la regardaient et n'en revenaient pas de la trouver si belle
###### 15
"C'aura été ton salut, lui dirent-ils, que d'avoir pris les devants et d'être descendue voir notre maître! Va donc le trouver dans sa tente, voici des nôtres pour t'accompagner et te remettre entre ses mains.
###### 16
Une fois devant lui, ne crains rien. Répète-lui ce que tu viens de nous dire, et il te traitera bien."
###### 17
Ils détachèrent alors cent de leurs hommes qui se joignirent à elle et à sa servante et les conduisirent auprès de la tente d'Holopherne.
###### 18
La nouvelle de son arrivée s'étant répandue parmi les tentes, il en résulta dans le camp une agitation générale. Elle était encore à l'extérieur de la tente d'Holopherne, attendant d'être annoncée, que déjà autour d'elle on faisait cercle.
###### 19
On ne se lassait pas d'admirer son étonnante beauté, et d'admirer par contrecoup les Israélites. "Qui donc pourrait encore mépriser un peuple qui a des femmes pareilles? Se disait-on à l'envi. Ce ne serait pas bien avisé d'en laisser debout un seul homme! Les survivants seraient capables de séduire la terre entière!"
###### 20
Les gardes du corps d'Holopherne et ses aides de camp sortirent et introduisirent Judith dans la tente.
###### 21
Holopherne reposait sur un lit placé sous une draperie de pourpre et d'or, rehaussée d'émeraudes et de pierres précieuses.
###### 22
On la lui annonça et il sortit sous l'auvent de la tente, précédé de porteurs de flambeaux d'argent.
###### 23
Quand Judith se trouva en présence du général et de ses aides de camp, la beauté de son visage les stupéfia tous. Elle se prosterna devant lui, la face contre terre. Mais les serviteurs la relevèrent.
