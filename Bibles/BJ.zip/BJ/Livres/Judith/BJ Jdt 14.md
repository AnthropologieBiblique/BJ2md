---
aliases : 
- Judith 14
- Judith 14
- Jdt 14
tags : 
- Bible/Jdt/14
- français
cssclass : français
---

# Judith 14

###### 1
Judith leur dit : "Ecoutez-moi, frères. Prenez cette tête, suspendez-la au faîte de vos remparts.
###### 2
Puis, quand l'aube aura paru et que le soleil sera levé sur la terre, prenez chacun vos armes et que tout homme valide sorte de la ville. Sur cette troupe établissez un chef, tout comme si vous vouliez descendre dans la plaine vers le poste avancé des Assyriens. Mais ne descendez pas.
###### 3
Les Assyriens prendront leur équipement, gagneront leur camp et éveilleront les chefs de leur armée. On se précipitera alors vers la tente d'Holopherne et on ne le trouvera pas. La frayeur s'emparera d'eux et ils fuiront devant vous.
###### 4
Vous, et tous ceux qui habitent dans le territoire d'Israël, vous n'aurez plus qu'à les poursuivre et à les abattre dans leur retraite.
###### 5
"Mais avant d'agir ainsi, appelez-moi Achior l'Ammonite, pour qu'il voie et reconnaisse le contempteur de la maison d'Israël, celui qui l'avait envoyé parmi nous comme un homme voué d'avance à la mort."
###### 6
On fit donc venir Achior de chez Ozias. Sitôt arrivé, à la vue de la tête d'Holopherne que tenait un des hommes de l'assemblée du peuple, il tomba la face contre terre et s'évanouit.
###### 7
On le releva. Il se jeta alors aux pieds de Judith et, se prosternant devant elle, s'écria "Bénie sois-tu dans toutes les tentes de Juda et parmi tous les peuples; ceux qui entendront prononcer ton nom seront saisis d'effroi!
###### 8
Et maintenant dis-moi ce que tu as fait durant ces jours." Et Judith lui raconta, au milieu de tout le peuple, tout ce qu'elle avait fait depuis le jour de sa sortie de Béthulie jusqu'au moment où elle parlait.
###### 9
Quand elle se fut tue, le peuple poussa de puissantes acclamations et emplit la ville de cris d'allégresse.
###### 10
Achior, voyant tout ce qu'avait fait le Dieu d'Israël, crut fermement en lui, se fit circoncire et fut admis définitivement dans la maison d'Israël.
###### 11
Quand l'aube parut, les gens de Béthulie pendirent la tête d'Holopherne au rempart. Chacun prit ses armes et tous sortirent par bandes sur les pentes de la montagne.
###### 12
Ce que voyant, les Assyriens dépêchèrent des messagers vers leurs chefs qui, à leur tour, se rendirent chez les stratèges, les chiliarques et tous leurs officiers.
###### 13
On parvint ainsi jusqu'à la tente d'Holopherne. "Eveille notre maître, dit-on à son intendant. Ces esclaves ont osé descendre vers nous et nous attaquer pour se faire complètement massacrer."
###### 14
Bagoas entra donc. Il frappa des mains devant le rideau de la tente, pensant qu'Holopherne dormait avec Judith.
###### 15
Mais comme personne ne semblait rien entendre, il ouvrit et pénétra dans la chambre à coucher et le trouva jeté sur le seuil, mort, la tête coupée.
###### 16
Il poussa alors un grand cri, pleura, sanglota, hurla et déchira ses vêtements,
###### 17
puis pénétra dans la tente où logeait Judith et ne la trouva pas. Alors, s'élançant dans la foule, il cria
###### 18
"Ah! les esclaves se sont rebellés! Une femme des Hébreux a couvert de honte la maison de Nabuchodonosor. Holopherne gît à terre, décapité!"
###### 19
A ces mots les chefs de l'armée d'Assur, l'esprit complètement bouleversé, déchirèrent leurs tuniques et firent retentir le camp de leurs cris et de leurs clameurs.
