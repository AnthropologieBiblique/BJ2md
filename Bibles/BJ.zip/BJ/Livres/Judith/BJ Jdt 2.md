---
aliases : 
- Judith 2
- Judith 2
- Jdt 2
tags : 
- Bible/Jdt/2
- français
cssclass : français
---

# Judith 2

###### 1
La dix-huitième année, le vingt-deuxième jour du premier mois, le bruit courut au palais que Nabuchodonosor, roi des Assyriens, allait tirer vengeance de toute la terre, comme il l'avait dit.
###### 2
Tous ses aides de camp et notables convoqués, il tint avec eux un conseil secret, et décida de sa propre bouche la destruction totale de toute la contrée.
###### 3
Alors on décréta de faire périr quiconque n'avait pas répondu à l'appel du roi.
###### 4
Le conseil terminé, Nabuchodonosor, roi des Assyriens, fit appeler Holopherne, général en chef de ses armées et son second. Il lui dit
###### 5
"Ainsi parle le grand roi, maître de toute la terre : Pars, prends avec toi des gens d'une valeur éprouvée, à peu près 20.000 fantassins et un fort contingent de chevaux avec 12.000 cavaliers,
###### 6
puis marche contre toute la région occidentale, puisque ces gens ont résisté à mon appel.
###### 7
Mande-leur de préparer la terre et l'eau, car, dans ma fureur, je vais marcher contre eux. Des pieds de mes soldats je couvrirai toute la surface du pays et je le livrerai au pillage.
###### 8
Leurs blessés rempliront les ravins et, comblés de leurs cadavres, torrents et fleuves déborderont.
###### 9
Je les emmènerai en captivité jusqu'au bout du monde.
###### 10
Va donc! Commence par me conquérir toute cette région. S'ils se livrent à toi, tu me les réserveras pour le jour de leur châtiment.
###### 11
Quant aux insoumis, que ton œil n'en épargne aucun. Voue-les à la tuerie et au pillage dans tout le territoire qui t'est confié.
###### 12
Car je suis vivant, moi, et vivante est la puissance de ma royauté! J'ai dit. Tout cela, je l'accomplirai de ma main!
###### 13
Et toi, ne néglige rien des ordres de ton maître, mais agis strictement selon ce que je t'ai prescrit, sans plus tarder!"
###### 14
Sorti de chez son souverain, Holopherne convoqua tous les princes, les généraux, les officiers de l'armée d'Assur,
###### 15
puis dénombra des guerriers d'élite, conformément aux ordres de son maître : environ 120.000 hommes plus 12.000 archers montés.
###### 16
Il les disposa en formation normale de combat.
###### 17
Il prit ensuite des chameaux, des ânes, des mulets en immense quantité pour porter les bagages, des brebis, des bœufs, des chèvres sans nombre pour le ravitaillement.
###### 18
Chaque homme reçut d'amples provisions ainsi que beaucoup d'or et d'argent comptés par la maison du roi.
###### 19
Puis, avec toute son armée, il partit en expédition devant le roi Nabuchodonosor afin de submerger toute la contrée occidentale de ses chars, de ses cavaliers, de ses fantassins d'élite.
###### 20
Une foule composite marchait à sa suite, aussi nombreuse que les sauterelles, que les grains de sable de la terre. Aucun chiffre n'en pourrait évaluer la multitude.
###### 21
Ils quittèrent donc Ninive et marchèrent trois jours durant dans la direction de la plaine de Bektileth. De Bektileth ils s'en vinrent camper près des montagnes situées à gauche de la Haute-Cilicie.
###### 22
De là, avec toute son armée, fantassins, cavaliers et chars, Holopherne s'engagea dans la région montagneuse.
###### 23
Il pourfendit Put et Lud, rançonna tous les fils de Rassis et ceux d'Ismaèl cantonnés à l'orée du désert au sud de Chéléôn,
###### 24
longea l'Euphrate, traversa la Mésopotamie, détruisit de fond en comble toutes les villes fortifiées qui dominent le torrent d'Abrona et parvint jusqu'à la mer.
###### 25
Puis il s'empara des territoires de la Cilicie, taillant en pièces quiconque lui résistait, arriva jusqu'aux limites méridionales de Japhet, en face de l'Arabie,
###### 26
encercla tous les Madianites, brûla leurs campements et pilla leurs bergeries,
###### 27
descendit ensuite dans la plaine de Damas à l'époque de la moisson des blés, mit le feu aux champs, fit disparaître menu et gros bétail, pilla les villes, dévasta les campagnes et passa au fil de l'épée tous les jeunes gens.
###### 28
Crainte et tremblement s'emparèrent de tous les habitants de la côte : ceux de Sidon et de Tyr, ceux de Sour, d'Okina et de Jamnia. La terreur régnait parmi les populations d'Azot et d'Ascalon.
