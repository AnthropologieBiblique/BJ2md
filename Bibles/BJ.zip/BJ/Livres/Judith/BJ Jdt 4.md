---
aliases : 
- Judith 4
- Judith 4
- Jdt 4
tags : 
- Bible/Jdt/4
- français
cssclass : français
---

# Judith 4

###### 1
Les Israélites établis en Judée, apprenant ce qu'Holopherne, général en chef de Nabuchodonosor roi des Assyriens, avait fait aux différents peuples et comment, après avoir dépouillé leurs temples, il les avait livrés à la destruction,
###### 2
furent saisis d'une extrême frayeur à son approche et tremblèrent pour Jérusalem et le Temple du Seigneur leur Dieu.
###### 3
A peine venaient-ils de remonter de captivité, et le regroupement du peuple en Judée, la purification du mobilier sacré, de l'autel et du Temple profanés étaient choses récentes.
###### 4
Ils alertèrent donc toute la Samarie, Kona, Bethorôn, Belmaïn, Jéricho, Choba, Esora et la vallée de Salem.
###### 5
Les sommets des plus hautes montagnes furent occupés, les bourgs qui s'y trouvaient, fortifiés. On prépara des approvisionnements en vue de la guerre, car les champs venaient d'être moissonnés.
###### 6
Le grand prêtre Ioakim, alors en résidence à Jérusalem, écrivit aux habitants de Béthulie et de Bétomestaïm, villes situées en face d'Esdrelon et vers la plaine de Dotaïn,
###### 7
pour leur dire d'occuper les hautes passes de la montagne, seule voie d'accès vers la Judée. Il leur serait d'ailleurs aisé d'arrêter les assaillants, l'étroitesse du passage ne permettant d'y avancer que deux de front.
###### 8
Les Israélites exécutèrent les ordres du grand prêtre Ioakim et du Conseil des anciens du peuple d'Israël siégeant à Jérusalem.
###### 9
Avec une ardeur soutenue, tous les hommes d'Israël crièrent vers Dieu et s'humilièrent devant lui.
###### 10
Eux, leurs femmes, leurs enfants, leurs troupeaux, tous ceux qui vivaient avec eux, mercenaires ou esclaves, ceignirent leurs reins de sacs.
###### 11
Tous les Israélites de Jérusalem, femmes et enfants compris, se prosternèrent devant le sanctuaire et, la tête couverte de cendres, étendirent les mains devant le Seigneur
###### 12
Ils entourèrent d'un sac l'autel lui-même. A grands cris ils suppliaient unanimement et avec ardeur le Dieu d'Israël de ne pas livrer leurs enfants au pillage, leurs femmes au rapt, les villes de leur héritage à la destruction, le Temple à la profanation et à l'ironie outrageante des païens.
###### 13
Attentif à leur voix, le Seigneur prit en considération leur détresse. Dans toute la Judée et à Jérusalem devant le sanctuaire du Seigneur Tout-Puissant le peuple jeûnait de longs jours.
###### 14
Le grand prêtre Ioakim et tous ceux qui se tenaient devant le Seigneur, prêtres et ministres du Seigneur, le sac sur les reins, offraient l'holocauste perpétuel, les oblations votives et les dons volontaires du peuple,
###### 15
et, le turban couvert de cendres, ils suppliaient intensément le Seigneur de visiter la maison d'Israël.
