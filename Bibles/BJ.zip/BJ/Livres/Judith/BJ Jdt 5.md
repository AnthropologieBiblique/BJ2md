---
aliases : 
- Judith 5
- Judith 5
- Jdt 5
tags : 
- Bible/Jdt/5
- français
cssclass : français
---

# Judith 5

###### 1
On annonça à Holopherne, général en chef de l'armée assyrienne, que les Israélites se préparaient au combat : ils avaient, disait-on, fermé les passes de la montagne, fortifié les hautes cimes et, dans les plaines, disposés des obstacles.
###### 2
Il entra alors dans une très violente colère, convoqua tous les princes de Moab, tous les généraux d'Ammon tous les satrapes du littoral.
###### 3
Hommes de Canaan, leur dit-il, renseignez-moi : quel est ce peuple qui demeure dans la région montagneuse? Quelles sont les villes qu'il habite? Quelle est l'importance de son armée? En quoi résident sa puissance et sa force? Quel est le roi qui est à sa tête et dirige son armée?
###### 4
Pourquoi a-t-il dédaigné de venir au-devant de moi, contrairement à ce qu'ont fait tous les habitants de la région occidentale?"
###### 5
Achior, chef de tous les Ammonites, lui répondit : "Que Monseigneur écoute, je t'en prie, les paroles prononcées par ton serviteur. Je vais te dire la vérité sur ce peuple de montagnards qui demeure tout près de toi. De la bouche de ton serviteur aucun mensonge ne sortira.
###### 6
Les gens de ce peuple sont des descendants des Chaldéens.
###### 7
Anciennement ils vinrent habiter en Mésopotamie parce qu'ils n'avaient pas voulu suivre les dieux de leurs pères établis en Chaldée.
###### 8
Ils s'écartèrent donc de la voie de leurs ancêtres et adorèrent le Dieu du ciel, Dieu qu'ils avaient reconnu. Bannis alors de la face de leurs dieux, ils s'enfuirent en Mésopotamie où ils habitèrent longtemps.
###### 9
Leur Dieu leur ayant signifié de sortir de leur résidence et de s'en aller au pays de Canaan, ils s'y installèrent et y furent surabondamment comblés d'or, d'argent et de nombreux troupeaux.
###### 10
Ils descendirent ensuite en Egypte, car une famine s'était abattue sur la terre de Canaan, et ils y demeurèrent tant qu'ils y trouvèrent de la nourriture. Là ils devinrent une grande multitude et une race innombrable.
###### 11
Mais le roi d'Egypte se dressa contre eux et se joua d'eux en les astreignant au travail des briques. On les humilia, on les assujettit à l'esclavage.
###### 12
Ils crièrent vers leur Dieu, qui frappa la terre d'Egypte tout entière de plaies sans remède. Les Egyptiens les chassèrent alors loin d'eux.
###### 13
Devant eux Dieu dessécha la mer Rouge
###### 14
et les conduisit par le chemin du Sinaï et de Cadès-Barné. Après avoir repoussé tous les habitants du désert,
###### 15
ils s'établirent dans le pays des Amorites et, vigoureusement, exterminèrent tous les habitants de Heshbôn. Puis, traversant le Jourdain, ils prirent possession de toute la montagne,
###### 16
expulsant devant eux les Cananéens, les Perizzites, les Jébuséens, les Sichémites ainsi que tous les Girgashites, et ils y habitèrent de longs jours.
###### 17
Tant qu'ils ne péchèrent pas en présence de leur Dieu, la prospérité fut avec eux, car ils ont un Dieu qui hait l'iniquité.
###### 18
Quand au contraire ils s'écartèrent de la voie qu'il leur avait assignée, une partie fut complètement détruite en de multiples guerres, l'autre fut conduite en captivité dans une terre étrangère. Le Temple de leur Dieu fut rasé et leurs villes tombèrent au pouvoir de leurs adversaires.
###### 19
Alors ils se retournèrent de nouveau vers leur Dieu, remontèrent de leur dispersion, des lieux où ils avaient été disséminés, reprirent possession de Jérusalem où se trouve leur Temple et repeuplèrent la montagne demeurée déserte.
###### 20
Et maintenant, maître et seigneur, s'il y a dans ce peuple quelque égarement, s'ils ont péché contre leur Dieu, alors assurons-nous qu'il y a bien en eux cette cause de chute. Puis montons, attaquons-les.
###### 21
Mais s'il n'y a pas d'injustice dans leur nation, que Monseigneur s'abstienne, de peur que leur Seigneur et Dieu ne les protège. Nous serions alors la risée de toute la terre!"
###### 22
Quand Achior eut cessé de parler, toute la foule massée autour de la tente se prit à murmurer. Les notables d'Holopherne, tous les habitants de la côte comme ceux de Moab parlaient de le mettre en pièces.
###### 23
"Qu'avons-nous donc à craindre des Israélites? C'est un peuple sans force ni puissance, incapable de tenir dans un combat un peu rude.
###### 24
Allons donc! Montons et ton armée n'en fera qu'une bouchée, ô notre maître, Holopherne!"
