---
aliases : 
- Judith 15
- Judith 15
- Jdt 15
tags : 
- Bible/Jdt/15
- français
cssclass : français
---

# Judith 15

###### 1
Lorsque ceux qui étaient encore dans leurs tentes apprirent la nouvelle, ils en furent frappés de stupeur.
###### 2
Pris de crainte et de tremblement ils ne purent rester deux ensemble : ce fut la débandade. Chacun s'enfuit par les sentiers de la plaine ou de la montagne.
###### 3
Ceux qui étaient campés dans la région montagneuse autour de Béthulie se mirent à fuir eux aussi. Alors les hommes de guerre d'Israël foncèrent sur eux.
###### 4
Ozias dépêcha des messagers à Bétomestaïm, à Bèbé, à Chobé, à Kola, dans le territoire d'Israël tout entier, afin d'y faire connaître tout ce qui venait de se passer et d'inviter toutes les populations à se jeter sur les ennemis et à les anéantir.
###### 5
A peine les Israélites furent-ils avertis que d'un seul élan ils tombèrent tous sur eux et les frappèrent jusqu'à Choba. Ceux de Jérusalem et de toute la montagne se joignirent également à eux, car ils avaient aussi été mis au courant de ce qui s'était passé dans le camp ennemi. Puis ce furent les gens de Galaad et de Galilée qui les prirent de flanc et les frappèrent durement jusqu'à proximité de Damas et de sa région.
###### 6
Quant aux autres, demeurés à Béthulie, ils se jetèrent sur le camp d'Assur, le pillèrent et s'enrichirent extrêmement.
###### 7
Les Israélites, de retour du carnage, se rendirent maîtres du reste. Les gens des bourgs et des villages de la montagne et de la plaine s'emparèrent aussi d'un immense butin, car il y en avait en quantité.
###### 8
Le grand prêtre Ioakim et tout le Conseil des anciens d'Israël qui étaient à Jérusalem vinrent contempler les bienfaits dont le Seigneur avait comblé Israël, pour voir Judith et la saluer.
###### 9
En entrant chez elle, tous la bénirent ainsi d'une seule voix "Tu es la gloire de Jérusalem! Tu es le suprême orgueil d'Israël! Tu es le grand honneur de notre race!
###### 10
En accomplissant tout cela de ta main, tu as bien mérité d'Israël, et Dieu a ratifié ce que tu as fait. Bénie sois-tu par le Seigneur Tout-Puissant dans la suite des temps!" Et tout le peuple reprit : "Amen!"
###### 11
La population pilla le camp 30 jours durant. On donna à Judith la tente d'Holopherne, toute son argenterie, sa literie, ses bassins et tout son mobilier. Elle le prit, en chargea sa mule, attela ses chariots et y amoncela le tout.
###### 12
Toutes les femmes d'Israël, accourues pour la voir, s'organisèrent en chœur de danse pour la fêter. Judith prit en main des thyrses et en donna aux femmes qui l'accompagnaient.
###### 13
Judith et ses compagnes se couronnèrent d'olivier. Puis elle se mit en tête du peuple et conduisit le chœur des femmes. Tous les hommes d'Israël, en armes et couronnés, l'accompagnaient au chant des hymnes.
###### 14
Au milieu de tout Israël, Judith entonna ce chant d'action de grâces et tout le peuple clama l'hymne
