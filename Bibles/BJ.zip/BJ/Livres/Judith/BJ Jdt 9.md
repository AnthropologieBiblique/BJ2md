---
aliases : 
- Judith 9
- Judith 9
- Jdt 9
tags : 
- Bible/Jdt/9
- français
cssclass : français
---

# Judith 9

###### 1
Judith tomba le visage contre terre, répandit de la cendre sur sa tête, se dépouilla jusqu'au sac dont elle était revêtue et, à haute voix, cria vers le Seigneur. C'était l'heure où, à Jérusalem, au Temple de Dieu, on offrait l'encens du soir. Elle dit
###### 2
"Seigneur, Dieu de mon père Siméon, tu l'armas d'un glaive vengeur contre les étrangers qui défirent la ceinture d'une vierge, à sa honte, mirent son flanc à nu, à sa confusion, et profanèrent son sein, à son déshonneur; car tu as dit : "Cela ne sera pas", et ils le firent.
###### 3
C'est pourquoi tu as livré leurs chefs au meurtre, et leur couche, avilie par leur duperie, fut dupée jusqu'au sang. Tu as frappé les esclaves avec les princes et les princes avec leurs serviteurs.
###### 4
Tu as livré leurs femmes au rapt et leurs filles à la captivité, et toutes leurs dépouilles au partage, au profit de tes fils préférés qui avaient brûlé de zèle pour toi, avaient eu horreur de la souillure infligée à leur sang et t'avaient appelé à leur secours. O Dieu, ô mon Dieu, exauce la pauvre veuve que je suis,
###### 5
puisque c'est toi qui as fait le passé et ce qui arrive maintenant et ce qui arrivera plus tard. Le présent et l'avenir, tu les as conçus, et ce qui est arrivé, c'est ce que tu avais dans l'esprit.
###### 6
Tes desseins se présentèrent et dirent : "Nous sommes là!" Car toutes tes voies sont préparées et tes jugements portés avec prévoyance.
###### 7
Voici les Assyriens : ils se prévalent de leur armée, se glorifient de leurs chevaux et de leurs cavaliers, se targuent de la valeur de leurs fantassins. Ils ont compté sur la lance et le bouclier, sur l'arc et sur la fronde; et ils n'ont pas reconnu en toi le Seigneur briseur de guerres.
###### 8
A toi le nom de Seigneur! Et toi, brise leur violence par ta puissance, fracasse leur force dans ta colère! Car ils ont projeté de profaner tes lieux saints, de souiller la tente où siège ton Nom glorieux et de renverser par le fer la corne de ton autel.
###### 9
Regarde leur outrecuidance, envoie ta colère sur leurs têtes, donne à ma main de veuve la vaillance escomptée.
###### 10
Par la ruse de mes lèvres, frappe l'esclave avec le chef et le chef avec son serviteur. Brise leur arrogance par une main de femme.
###### 11
Ta force ne réside pas dans le nombre, ni ton autorité dans les violents, mais tu es le Dieu des humbles, le secours des opprimés, le soutien des faibles, l'abri des délaissés, le sauveur des désespérés.
###### 12
Oui, oui, Dieu de mon père, Dieu de l'héritage d'Israël, Maître du ciel et de la terre, Créateur des eaux, Roi de tout ce que tu as créé, toi, exauce ma prière.
###### 13
Donne-moi un langage séducteur, pour blesser et pour meurtrir ceux qui ont formé de si noirs desseins contre ton alliance et ta sainte demeure et la montagne de Sion et la maison qui appartient à tes fils.
###### 14
Et fais connaître à tout peuple et à toute tribu que tu es le Seigneur, Dieu de toute puissance et de toute force, et que le peuple d'Israël n'a d'autre protecteur que toi."
