---
aliases : 
- Judith 6
- Judith 6
- Jdt 6
tags : 
- Bible/Jdt/6
- français
cssclass : français
---

# Judith 6

###### 1
Quand se fut apaisé le tumulte des gens attroupés autour du Conseil, Holopherne, général en chef de l'armée d'Assur, invectiva Achior devant toute la foule des étrangers et les Ammonites
###### 2
"Qui es-tu donc, Achior, toi avec les mercenaires d'Ephraïm, pour vaticiner chez nous comme tu le fais aujourd'hui et pour nous dissuader de partir en guerre contre la race d'Israël? Tu prétends que leur Dieu les protégera? Qui donc est dieu hormis Nabuchodonosor? C'est lui qui va envoyer sa puissance et les faire disparaître de la face de la terre, et ce n'est pas leur Dieu qui les sauvera!
###### 3
Mais nous, ses serviteurs, nous les broierons comme un seul homme! Ils ne pourront contenir la puissance de nos chevaux.
###### 4
Nous les brûlerons pêle-mêle. Leurs monts s'enivreront de leur sang et leurs plaines seront remplies de leurs cadavres. Loin de pouvoir tenir pied devant nous, ils périront du premier au dernier, dit le roi Nabuchodonosor, le maître de toute la terre. Car il a parlé et ses paroles ne seront pas vaines.
###### 5
Toi donc, Achior, mercenaire ammonite, toi qui as proféré ce discours en un moment d'emportement, à partir d'aujourd'hui tu ne verras plus mon visage jusqu'au jour où je me serai vengé de cette engeance évadée d'Egypte.
###### 6
Alors l'épée de mes soldats et la lance de mes serviteurs te transperceront le flanc. Tu tomberas parmi les blessés quand je me tournerai contre Israël.
###### 7
Mes serviteurs vont maintenant te mener dans la montagne et te laisser près d'une des villes situées dans les défilés.
###### 8
Tu ne périras pas sans partager leur ruine.
###### 9
Ne prends pas cet air abattu si tu nourris le secret espoir qu'elles ne seront pas capturées! J'ai dit; aucune de mes paroles ne restera sans effet."
###### 10
Holopherne ordonna aux gens de service dans sa tente de saisir Achior, de le mener à Béthulie et de le remettre aux mains des Israélites.
###### 11
Les serviteurs le prirent donc, le conduisirent hors du camp à travers la plaine et de là, prenant la direction de la montagne, ils parvinrent aux sources situées en contrebas de Béthulie.
###### 12
Quand les hommes de la ville les virent, ils prirent leurs armes, sortirent de la cité et gagnèrent la crête de la montagne, tandis que, pour les empêcher de monter, les frondeurs les criblaient de pierres.
###### 13
Aussi purent-ils tout juste se glisser au bas des pentes, ligoter Achior et le laisser étendu au pied de la montagne avant de s'en retourner vers leur maître.
###### 14
Les Israélites descendirent alors de leur ville, s'arrêtèrent près de lui, le délièrent, le conduisirent à Béthulie et le présentèrent aux chefs de la cité,
###### 15
qui étaient alors Ozias, fils de Michée, de la tribu de Siméon, Chabris, fils de Gothoniel, et Charmis, fils de Melchiel.
###### 16
Ceux-ci convoquèrent les anciens de la ville. Les jeunes gens et les femmes accoururent aussi à l'assemblée. Ozias interrogea Achior, debout au milieu du peuple, sur ce qui était arrivé.
###### 17
Prenant la parole, il leur fit connaître les délibérations du conseil d'Holopherne, tout ce qu'il avait lui-même dit parmi les chefs assyriens, ainsi que les rodomontades d'Holopherne à l'adresse de la maison d'Israël.
###### 18
Alors le peuple se prosterna, adora Dieu et cria
###### 19
"Seigneur, Dieu du ciel, considère leur orgueil démesuré et prends en pitié l'humiliation de notre race. En ce jour tourne un visage favorable vers ceux qui te sont consacrés."
###### 20
Puis on rassura Achior, vivement félicité.
###### 21
Au sortir de la réunion, Ozias le prit chez lui et offrit un banquet aux anciens. Durant toute cette nuit-là on implora le secours du Dieu d'Israël.
