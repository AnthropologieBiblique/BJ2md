---
aliases : 
- Judith 11
- Judith 11
- Jdt 11
tags : 
- Bible/Jdt/11
- français
cssclass : français
---

# Judith 11

###### 1
"Confiance, femme, lui dit Holopherne. Ne crains rien. Je n'ai jamais fait de mal à personne qui ait choisi de servir Nabuchodonosor, roi de toute la terre.
###### 2
Maintenant même, si ton peuple de montagnards ne m'avait pas méprisé, je n'aurais pas levé la lance contre lui. Ce sont eux qui l'ont voulu.
###### 3
Mais, dis-moi, pourquoi t'es-tu enfuie de chez eux pour venir chez nous? ... En tout cas ç'aura été ton salut! Courage! Cette nuit-ci te verra encore en vie, et les autres aussi!
###### 4
Personne ne te fera de mal, va! mais on te traitera bien, comme cela se pratique avec les serviteurs de mon seigneur le roi Nabuchodonosor."
###### 5
Et Judith : "Daigne accueillir favorablement les paroles de ton esclave et que ta servante puisse parler devant toi. Cette nuit je ne proférerai aucun mensonge devant Monseigneur.
###### 6
Suis seulement les avis de ta servante, et Dieu mènera ton affaire à bonne fin, mon Seigneur n'échouera pas dans ses entreprises.
###### 7
Vive Nabuchodonosor, roi de toute la terre, lui qui t'a envoyé remettre toute âme vivante dans le droit chemin, et vive sa puissance! car, grâce à toi, ce ne sont pas seulement les hommes qui le servent, mais par l'effet de ta force, les bêtes sauvages elles-mêmes, les troupeaux et les oiseaux du ciel vivront pour Nabuchodonosor et pour toute sa maison!
###### 8
Nous avons, en effet, entendu parler de ton talent et des ressources de ton esprit. C'est chose connue de toute la terre que, dans tout l'empire, tu es singulièrement capable, riche en expérience, étonnant dans la conduite de la guerre.
###### 9
Et puis, nous connaissons le discours prononcé par Achior dans ton conseil. Les gens de Béthulie l'ayant épargné, il leur a communiqué tout ce qu'il t'avait dit.
###### 10
Eh bien, maître et seigneur, ne néglige pas ses paroles, mais garde-les présentes à ton esprit, car elles sont vraies. Certes, notre race ne sera pas châtiée, l'épée ne pourra rien contre ses fils à moins qu'ils ne pèchent contre leur Dieu.
###### 11
Or, juste maintenant, afin que Monseigneur ne connaisse ni rebut ni échec, la mort va fondre sur leurs têtes. Car le péché s'est emparé d'eux, ce péché par lequel ils excitent la colère de leur Dieu chaque fois qu'ils se livrent au désordre.
###### 12
Depuis que les vivres leur manquent et que l'eau se fait rare, ils ont résolu de se battre sur leurs troupeaux et décidé de prendre pour eux tout ce que, par ses lois, Dieu leur a défendu de manger.
###### 13
Il n'est pas jusqu'aux prémices du blé, aux dîmes du vin et de l'huile choses pourtant consacrées et réservées par eux aux prêtres qui, à Jérusalem, se tiennent devant la face de notre Dieu qu'ils n'aient décidé de consommer. Pourtant personne du peuple n'a le droit d'y toucher, même de la main.
###### 14
Bien plus, ils ont envoyé à Jérusalem, où tout le monde en fait autant, des gens chargés de leur apporter du Conseil des anciens la permission nécessaire.
###### 15
Voici donc ce qui va leur arriver : sitôt la permission parvenue et dès qu'ils en auront usé, ce jour-là même ils te seront livrés pour leur ruine.
###### 16
Lorsque moi, ta servante, j'eus appris tout cela, je m'enfuis de chez eux. Dieu m'a envoyée pour réaliser avec toi des entreprises dont la terre entière sera stupéfaite quand on les apprendra.
###### 17
Car ta servante est une femme pieuse. Nuit et jour elle honore le Dieu du ciel. Alors moi, je me propose de rester près de toi, Monseigneur. Moi, ta servante, je sortirai de nuit dans le ravin et j'y prierai Dieu afin qu'il me fasse savoir quand ils auront consommé leur faute.
###### 18
Je reviendrai alors t'en informer pour que tu sortes avec toute ton armée, et nul d'entre eux ne pourra te résister.
###### 19
Je te conduirai à travers toute la Judée jusqu'à ce que tu parviennes devant Jérusalem. Je te ferai siéger au beau milieu de la cité. Alors tu les mèneras comme des brebis sans pasteur et il ne se trouvera même pas un chien pour gronder devant toi. De tout cela j'ai eu le pressentiment, cela m'a été annoncé et j'ai été envoyée pour te le révéler."
###### 20
Les paroles de cette femme plurent à Holopherne et à tous ses aides de camp. Etonnés de sa sagesse, ils s'écrièrent
###### 21
"D'un bout du monde à l'autre il n'y a pas de femme pareille, à la fois si belle et si bien-disante!"
###### 22
Et Holopherne lui dit : "Dieu a bien fait de t'envoyer en avant du peuple! Entre nos mains sera la puissance, et chez ceux qui ont méprisé mon seigneur, la ruine.
###### 23
Quant à toi, tu es aussi jolie qu'habile en tes discours. Si tu fais comme tu l'as dit, ton Dieu sera mon Dieu, et toi tu résideras dans le palais du roi Nabuchodonosor et tu seras célèbre par toute la terre!"
