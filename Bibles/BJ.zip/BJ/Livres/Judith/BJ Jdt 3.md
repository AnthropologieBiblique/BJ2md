---
aliases : 
- Judith 3
- Judith 3
- Jdt 3
tags : 
- Bible/Jdt/3
- français
cssclass : français
---

# Judith 3

###### 1
Des envoyés, porteurs de messages de paix, furent alors dépêchés vers lui.
###### 2
"Nous sommes, dirent-ils, les serviteurs du grand roi Nabuchodonosor et nous nous prosternons devant toi. Fais de nous ce qu'il te plaira.
###### 3
Nos parcs à bestiaux, notre territoire tout entier, tous nos champs de blé, notre menu et gros bétail, tous les enclos de nos campements sont à ta disposition. Uses-en comme bon te semblera.
###### 4
Nos villes mêmes et leurs habitants sont à ton service. Viens, avance-toi vers elles selon ton bon plaisir."
###### 5
Ces hommes se présentèrent donc devant Holopherne et lui transmirent en ces termes leur message.
###### 6
Avec son armée il descendit ensuite vers la côte, établit des garnisons dans toutes les villes fortifiées et y préleva des hommes d'élite comme troupes auxiliaires.
###### 7
Les habitants de ces cités et de toutes celles d'alentour l'accueillirent parés de couronnes et dansant au son des tambourins.
###### 8
Mais il n'en dévasta pas moins leurs sanctuaires et coupa leurs arbres sacrés, conformément à la mission reçue d'exterminer tous les dieux indigènes pour obliger les peuples à ne plus adorer que le seul Nabuchodonosor et forcer toute langue et toute race à l'invoquer comme dieu.
###### 9
Il arriva ainsi en face d'Esdrelon, près de Dôtaia, bourgade sise en avant de la grande chaîne de Judée,
###### 10
campa entre Géba et Scythopolis et y demeura tout un mois pour réapprovisionner ses forces.
