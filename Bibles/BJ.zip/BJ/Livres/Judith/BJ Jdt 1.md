---
aliases : 
- Judith 1
- Judith 1
- Jdt 1
tags : 
- Bible/Jdt/1
- français
cssclass : français
---

# Judith 1

###### 1
C'était en la douzième année de Nabuchodonosor, qui régna sur les Assyriens à Ninive la grande ville. Arphaxad régnait alors sur les Mèdes à Ecbatane.
###### 2
Il entoura cette ville d'un mur d'enceinte en pierres de taille larges de trois coudées et longues de six, donnant au rempart une hauteur de 70 coudées et une largeur de 50.
###### 3
Aux portes il dressa des tours de cent coudées de haut sur 60 de large à leurs fondations,
###### 4
les portes elles-mêmes s'élevant à 70 coudées avec une largeur de 40, ce qui permettait la sortie du gros de ses forces et le défilé de ses fantassins.
###### 5
Or, vers cette époque, le roi Nabuchodonosor livra bataille au roi Arphaxad dans la grande plaine située sur le territoire de Ragau.
###### 6
A ses côtés s'étaient rangés tous les peuples des montagnes, tous ceux de l'Euphrate, du Tigre, de l'Hydaspe, et ceux des plaines soumises au roi des Elyméens Arioch. Ainsi de nombreux peuples se rassemblèrent pour prendre part à la bataille des fils de Chéléoud.
###### 7
Nabuchodonosor, roi des Assyriens, envoya un message à tous les habitants de la Perse, à tous ceux de la région occidentale, de la Cilicie, de Damas, du Liban, de l'Anti-Liban, à tous ceux de la côte,
###### 8
aux peuplades du Carmel, de Galaad, de la Haute-Galilée, de la grande plaine d'Esdrelon,
###### 9
aux gens de Samarie et des villes de sa dépendance, à ceux d'au-delà du Jourdain, jusqu'à Jérusalem, Batanée, Chélous, Cadès, le fleuve d'Egypte, Taphnès, Ramsès, tout le territoire de Goshèn,
###### 10
au-delà de Tanis et de Memphis, et à tous les habitants de l'Egypte jusqu'aux confins de l'Ethiopie.
###### 11
Mais les habitants de ces contrées ne firent pas cas de l'appel de Nabuchodonosor, roi des Assyriens, et ne se joignirent pas à lui pour faire campagne. Ils ne le craignaient pas car, à leurs yeux, il paraissait un isolé. Ils renvoyèrent donc ses messagers les mains vides et déshonorés.
###### 12
Nabuchodonosor en éprouva une violente colère contre tous ces pays. Il jura par son trône et son royaume de se venger et de dévaster par l'épée tous les territoires de Cilicie, de Damascène, de Syrie, ainsi que ceux de Moab, ceux des Ammonites, de Judée et d'Egypte, jusqu'aux frontières des deux mers.
###### 13
Avec ses propres forces, il livra bataille au roi Arphaxad en la dix-septième année et, dans ce combat, le vainquit. Il culbuta toute son armée, sa cavalerie, ses chars,
###### 14
se soumit ses villes et parvint jusqu'à Ecbatane. Là il s'empara des tours, ravagea les places, faisant un objet de honte de tout ce qui constituait sa parure.
###### 15
Puis il prit Arphaxad dans les montagnes de Ragau, le perça de ses javelots et l'extermina définitivement.
###### 16
Il s'en retourna ensuite avec ses troupes et l'immense foule qui s'était jointe à eux, incommensurable cohue d'hommes armés. Alors, dans l'insouciance, ils s'adonnèrent à la bonne chère, lui et son armée, 120 jours durant.
