---
aliases : 
- Judith 13
- Judith 13
- Jdt 13
tags : 
- Bible/Jdt/13
- français
cssclass : français
---

# Judith 13

###### 1
Quand il se fit tard, ses officiers se hâtèrent de partir. Bagoas ferma la tente de l'extérieur, après avoir éconduit d'auprès de son maître ceux qui s'y trouvaient encore. Ils allèrent se coucher, fatigués par l'excès de boisson,
###### 2
et Judith fut laissée seule dans la tente avec Holopherne effondré sur son lit, noyé dans le vin.
###### 3
Judith dit alors à sa servante de se tenir dehors, près de la chambre à coucher, et d'attendre sa sortie comme elle le faisait chaque jour. Elle avait d'ailleurs eu soin de dire qu'elle sortirait pour sa prière et avait parlé dans le même sens à Bagoas.
###### 4
Tous s'en étaient allés de chez Holopherne et nul, petit ou grand, n'avait été laissé dans la chambre à coucher. Debout près du lit Judith dit en elle-même "Seigneur, Dieu de toute force, en cette heure, favorise l'œuvre de mes mains pour l'exaltation de Jérusalem.
###### 5
C'est maintenant le moment de ressaisir ton héritage et de réaliser mes plans pour écraser les ennemis levés contre nous."
###### 6
Elle s'avança alors vers la traverse du lit proche de la tête d'Holopherne, en détacha son cimeterre,
###### 7
puis s'approchant de la couche elle saisit la chevelure de l'homme et dit : "Rends-moi forte en ce jour, Seigneur, Dieu d'Israël!"
###### 8
Par deux fois elle le frappa au cou, de toute sa force, et détacha sa tête.
###### 9
Elle fit ensuite rouler le corps loin du lit et enleva la draperie des colonnes. Peu après elle sortit et donna la tête d'Holopherne à sa servante,
###### 10
qui la mit dans la besace à vivres, et toutes deux sortirent du camp comme elles avaient coutume de le faire pour aller prier. Une fois le camp traversé elles contournèrent le ravin, gravirent la pente de Béthulie et parvinrent aux portes.
###### 11
De loin Judith cria aux gardiens des portes : "Ouvrez, ouvrez la porte! Car le Seigneur notre Dieu est encore avec nous pour accomplir des prouesses en Israël et déployer sa force contre nos ennemis comme il l'a fait aujourd'hui!"
###### 12
Quand les hommes de la ville eurent entendu sa voix, ils se hâtèrent de descendre à la porte de leur cité et appelèrent les anciens.
###### 13
Du plus petit jusqu'au plus grand tout le monde accourut, car on ne s'attendait pas à son arrivée. Les gens ouvrirent la porte, accueillirent les deux femmes, firent du feu pour y voir et les entourèrent.
###### 14
D'une voix forte Judith leur dit : "Louez Dieu! Louez-le! Louez le Dieu qui n'a pas détourné sa miséricorde de la maison d'Israël, mais qui, cette nuit, a par ma main brisé nos ennemis."
###### 15
Elle tire alors la tête de sa besace et la leur montre : "Voici la tête d'Holopherne, le général en chef de l'armée d'Assur, et voici la draperie sous laquelle il gisait dans son ivresse! Le Seigneur l'a frappé par la main d'une femme!
###### 16
Vive le Seigneur qui m'a gardée dans mon entreprise! Car mon visage n'a séduit cet homme que pour sa perte. Il n'a pas péché avec moi pour ma honte et mon déshonneur."
###### 17
En proie à une grande émotion tout le peuple se prosterna pour adorer Dieu et cria d'une seule voix : "Béni sois-tu, ô notre Dieu, toi qui, en ce jour, as anéanti les ennemis de ton peuple!"
###### 18
Ozias, à son tour, dit à Judith "Sois bénie, ma fille, par le Dieu Très-Haut, plus que toutes les femmes de la terre; et béni soit le Seigneur Dieu, Créateur du ciel et de la terre, lui qui t'a conduite pour trancher la tête du chef de nos ennemis!
###### 19
Jamais la confiance dont tu as fait preuve ne s'effacera de l'esprit des hommes; mais ils se souviendront éternellement de la puissance de Dieu.
###### 20
Fasse Dieu que tu sois éternellement exaltée et récompensée de mille biens, puisque tu n'as pas ménagé ta vie quand notre race était humiliée, mais que tu as conjuré notre ruine en marchant droit devant notre Dieu." Tout le peuple répondit : "Amen! Amen!"
