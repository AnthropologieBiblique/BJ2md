---
aliases : 
- Judith 16
- Judith 16
- Jdt 16
tags : 
- Bible/Jdt/16
- français
cssclass : français
---

# Judith 16

###### 1
Entonnez un chant à mon Dieu sur les tambourins, chantez le Seigneur avec les cymbales, mêlez pour lui le psaume au cantique, exaltez et invoquez son nom!
###### 2
Car le Seigneur est un Dieu briseur de guerres; il a établi son camp au milieu de son peuple, pour m'arracher de la main de mes adversaires.
###### 3
Assur descendit des montagnes du septentrion, il vint avec les myriades de son armée. Leur multitude obstruait les torrents, leurs chevaux couvraient les collines.
###### 4
Ils parlaient d'embraser mon pays, de passer mes adolescents au fil de l'épée, de jeter à terre mes nourrissons, de livrer au butin mes enfants et mes jeunes filles au rapt.
###### 5
Mais le Seigneur Tout-Puissant le leur interdit par la main d'une femme.
###### 6
Car leur héros n'est pas tombé devant des jeunes gens, ce ne sont pas des fils de titans qui l'ont frappé, ni de fiers géants qui l'ont attaqué, mais c'est Judith, fille de Merari, qui l'a désarmé par la beauté de son visage.
###### 7
Elle avait déposé son vêtement de deuil pour le réconfort des affligés d'Israël, elle avait oint son visage de parfums,
###### 8
elle avait emprisonné sa chevelure sous un turban, elle avait mis une robe de lin pour le séduire.
###### 9
Sa sandale ravit son regard, sa beauté captiva son âme... et le cimeterre lui trancha le cou!
###### 10
Les Perses frémirent de son audace et les Mèdes furent confondus de sa hardiesse.
###### 11
Alors mes humbles crièrent, et eux prirent peur, mes faibles hurlèrent, et eux furent saisis d'effroi; ils enflèrent leur voix, et eux reculèrent.
###### 12
Des enfants de femmelettes les tuèrent, ils les transpercèrent comme des fils de déserteurs. Ils périrent dans la bataille de mon Seigneur!
###### 13
Je veux chanter à mon Dieu un cantique nouveau. Seigneur, tu es grand, tu es glorieux, admirable dans ta force, invincible.
###### 14
Que toute ta création te serve! Car tu as dit et les êtres furent, tu envoyas ton souffle et ils furent construits, et personne ne peut résister à ta voix.
###### 15
Les montagnes crouleraient-elles pour se mêler aux flots, les rochers fondraient-ils comme la cire devant ta face, qu'à ceux qui te craignent tu serais encore propice.
###### 16
Certes, c'est peu de chose qu'un sacrifice d'agréable odeur, et moins encore la graisse qui t'est brûlée en holocauste; mais qui craint le Seigneur est grand toujours.
###### 17
Malheur aux nations qui se dressent contre ma race! Le Seigneur Tout-Puissant les châtiera au jour du jugement. Il enverra le feu et les vers dans leurs chairs et ils pleureront de douleur éternellement.
###### 18
Quand ils furent arrivés à Jérusalem, tous se prosternèrent devant Dieu et, une fois le peuple purifié, ils offrirent leurs holocaustes, leurs oblations volontaires et leurs dons.
###### 19
Judith voua à Dieu, en anathème, tout le mobilier d'Holopherne donné par le peuple et la draperie qu'elle avait elle-même enlevée de son lit.
###### 20
La population se livra à l'allégresse devant le Temple, à Jérusalem, trois mois durant, et Judith resta avec eux.
###### 21
Ce temps écoulé, chacun revint chez soi. Judith regagna Béthulie et y demeura dans son domaine. De son vivant elle devint célèbre dans tout le pays.
###### 22
Beaucoup la demandèrent en mariage, mais elle ne connut point d'homme tous les jours de sa vie depuis que son mari Manassé était mort et avait été réuni à son peuple.
###### 23
Son renom croissait de plus en plus tandis qu'elle avançait en âge dans la maison de son mari. Elle atteignit 105 ans. Elle affranchit sa servante, puis mourut à Béthulie et fut ensevelie dans la caverne où reposait son mari Manassé.
###### 24
La maison d'Israël célébra son deuil durant sept jours. Avant de mourir elle avait réparti ses biens dans la parenté de son mari Manassé et dans la sienne propre.
###### 25
Plus personne n'inquiéta les Israélites du temps de Judith ni longtemps encore après sa mort.
