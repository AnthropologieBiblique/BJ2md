---
aliases : 
- Jude 1
- Jude 1
- Jude 1
tags : 
- Bible/Jude/1
- français
cssclass : français
---

# Jude 1

###### 
Jude, serviteur de Jésus Christ, frère de Jacques, aux appelés, aimés de Dieu le Père et gardés pour Jésus Christ. 
###### 
A vous miséricorde et paix et charité en abondance. 
###### 
Très chers, j'avais un grand désir de vous écrire au sujet de notre salut commun, et j'ai été contraint de le faire, afin de vous exhorter à combattre pour la foi transmise aux saints une fois pour toutes. 
###### 
Car il s'est glissé parmi vous certains hommes qui depuis longtemps ont été marqués d'avance pour cette sentence : ces impies travestissent en débauche la grâce de notre Dieu et renient notre seul Maître et Seigneur Jésus Christ. 
###### 
Je veux vous rappeler, à vous qui connaissez tout cela une fois pour toutes, que le Seigneur, après avoir sauvé le peuple de la terre d'Égypte, a fait périr ensuite les incrédules. 
###### 
Quant aux anges, qui n'ont pas conservé leur primauté, mais ont quitté leur propre demeure, c'est pour le jugement du grand Jour qu'il les a gardés dans des liens éternels, au fond des ténèbres. 
###### 
Ainsi Sodome, Gomorrhe et les villes voisines qui se sont prostituées de la même manière et ont couru après une chair différente, sont-elles proposées en exemple, subissant la peine d'un feu éternel. 
###### 
Pourtant, ceux-là aussi, en délire, souillent la chair, méprisent la Seigneurie, blasphèment les Gloires. 
###### 
Pourtant, l'archange Michel, lorsqu'il plaidait contre le diable et discutait au sujet du corps de Moïse, n'osa pas porter contre lui un jugement outrageant, mais dit : " Que le Seigneur te réprime ! " 
###### 
Quant à eux, ils blasphèment ce qu'ils ignorent ; et ce qu'ils connaissent par nature, comme les bêtes sans raison, ne sert qu'à les perdre. 
###### 
Malheur à eux ! car c'est dans la voie de Caïn qu'ils sont allés, c'est dans l'égarement de Balaam qu'ils se sont jetés pour un salaire, c'est par la révolte de Coré qu'ils ont péri. 
###### 
Ce sont eux les écueils de vos agapes. Ils font bonne chère sans vergogne, ils se repaissent : nuées sans eau que les vents emportent, arbres de fin de saison, sans fruits, deux fois morts, déracinés, 
###### 
houle sauvage de la mer écumant sa propre honte, astres errants auxquels les ténèbres épaisses sont gardées pour l'éternité. 
###### 
C'est aussi pour eux qu'a prophétisé en ces termes Hénoch, le septième patriarche depuis Adam : " Voici : le Seigneur est venu avec ses saintes myriades, 
###### 
afin d'exercer le jugement contre tous et de confondre tous les impies pour toutes les œuvres d'impiété qu'ils ont commises, pour toutes les paroles dures qu'ont proférées contre lui les pécheurs impies. " 
###### 
Ce sont eux qui murmurent, se plaignent, marchent selon leurs convoitises, leur bouche dit des choses orgueilleuses, ils flattent par intérêt. 
###### 
Mais vous, très chers, rappelez-vous ce qui a été prédit par les apôtres de notre Seigneur Jésus Christ. 
###### 
Ils vous disaient : " A la fin du temps, il y aura des moqueurs, marchant selon leurs convoitises impies. " 
###### 
Ce sont eux qui créent des divisions, ces êtres " psychiques " qui n'ont pas d'esprit. 
###### 
Mais vous, très chers, vous édifiant sur votre foi très sainte, priant dans l'Esprit Saint, 
###### 
gardez-vous dans la charité de Dieu, prêts à recevoir la miséricorde de notre Seigneur Jésus Christ pour la vie éternelle. 
###### 
Les uns, ceux qui hésitent, cherchez à les convaincre ; 
###### 
les autres, sauvez-les en les arrachant au feu ; les autres enfin, portez-leur une pitié craintive, en haïssant jusqu'à la tunique contaminée par leur chair. 
###### 
A celui qui peut vous garder de la chute et vous présenter devant sa gloire, sans reproche, dans l'allégresse, 
###### 
à l'unique Dieu, notre Sauveur par Jésus Christ notre Seigneur, gloire, majesté, force et puissance avant tout temps, maintenant et dans tous les temps ! Amen. 
