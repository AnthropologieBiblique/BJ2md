---
aliases : 
- 1 Thessaloniciens 2
- 1 Thessaloniciens 2
- 1 Th 2
- 1 Thessalonians 2
tags : 
- Bible/1Th/2
- français
cssclass : français
---

# 1 Thessaloniciens 2

###### 1
Vous-mêmes savez, frères, comment nous sommes venus chez vous, que ce ne fut pas en vain. 
###### 2
Nous avions, vous le savez, enduré à Philippes des souffrances et des insultes, mais notre Dieu nous a accordé de prêcher en toute hardiesse devant vous l'Évangile de Dieu, au milieu d'une lutte pénible. 
###### 3
En vous exhortant, nous ne nous inspirons ni de l'erreur ni de l'impureté, et nous ne tentons pas de ruser avec vous. 
###### 4
Seulement, Dieu nous ayant confié l'Évangile après nous avoir éprouvés, nous prêchons en conséquence, cherchant à plaire non pas aux hommes mais à Dieu qui éprouve nos cœurs. 
###### 5
Jamais non plus nous n'avons eu un mot de flatterie, vous le savez, ni une arrière-pensée de cupidité, Dieu en est témoin ; 
###### 6
ni recherché la gloire humaine, pas plus chez vous que chez d'autres, 
###### 7
alors que nous pouvions, étant apôtres du Christ, vous faire sentir tout notre poids. Au contraire, nous nous sommes faits tout aimables au milieu de vous. Comme une mère nourrit ses enfants et les entoure de soins, 
###### 8
telle était notre tendresse pour vous que nous aurions voulu vous livrer, en même temps que l'Évangile de Dieu, notre propre vie, tant vous nous étiez devenus chers. 
###### 9
Vous vous souvenez, frères, de nos labeurs et fatigues : de nuit comme de jour, nous travaillions, pour n'être à la charge d'aucun de vous, tandis que nous vous annoncions l'Évangile de Dieu ! 
###### 10
Vous êtes témoins, et Dieu l'est aussi, combien notre attitude envers vous, les croyants, a été sainte, juste, sans reproche. 
###### 11
Comme un père pour ses enfants, vous le savez, nous vous avons, chacun de vous, 
###### 12
exhortés, encouragés, adjurés de mener une vie digne de Dieu qui vous appelle à son Royaume et à sa gloire. 
###### 13
Voilà pourquoi, de notre côté, nous ne cessons de rendre grâces à Dieu de ce que, une fois reçue la parole de Dieu que nous vous faisions entendre, vous l'avez accueillie, non comme une parole d'hommes, mais comme ce qu'elle est réellement, la Parole de Dieu. Et cette parole reste active en vous, les croyants. 
###### 14
Car vous vous êtes mis, frères, à imiter les Églises de Dieu dans le Christ Jésus qui sont en Judée : vous avez souffert de la part de vos compatriotes les mêmes traitements qu'ils ont soufferts de la part des Juifs : 
###### 15
ces gens-là ont mis à mort Jésus le Seigneur et les prophètes, ils nous ont persécutés, ils ne plaisent pas à Dieu, ils sont ennemis de tous les hommes 
###### 16
quand ils nous empêchent de prêcher aux païens pour leur salut, mettant ainsi en tout temps le comble à leur péché ; et elle est tombée sur eux, la colère, pour en finir. 
###### 17
Et nous, frères, privés de votre compagnie pour un moment, de visage mais non de cœur, nous nous sommes sentis extrêmement pressés de revoir votre visage, tant notre désir était vif. 
###### 18
Nous avons donc voulu venir jusqu'à vous - moi-même, Paul, à plusieurs reprises -, mais Satan nous en a empêchés. 
###### 19
Quelle est en effet notre espérance, notre joie, la couronne dont nous serons fiers, si ce n'est vous, en présence de notre Seigneur Jésus lors de son Avènement ? 
###### 20
Oui, c'est bien vous qui êtes notre gloire et notre joie. 
