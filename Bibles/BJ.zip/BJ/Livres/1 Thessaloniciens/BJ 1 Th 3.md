---
aliases : 
- 1 Thessaloniciens 3
- 1 Thessaloniciens 3
- 1 Th 3
- 1 Thessalonians 3
tags : 
- Bible/1Th/3
- français
cssclass : français
---

# 1 Thessaloniciens 3

###### 1
Aussi, n'y tenant plus, nous avons pris le parti de demeurer seuls à Athènes, 
###### 2
et nous avons envoyé Timothée, notre frère et le collaborateur de Dieu dans l'Évangile du Christ, pour vous affermir et réconforter dans votre foi, 
###### 3
afin que personne ne se laisse ébranler par ces tribulations. Car vous savez bien que c'est là notre partage : 
###### 4
quand nous étions près de vous, nous vous prédisions que nous aurions à subir des tribulations, et c'est ce qui est arrivé, vous le savez. 
###### 5
C'est pour cela que, n'y tenant plus, je l'ai envoyé s'informer de votre foi. Pourvu que déjà le Tentateur ne vous ait pas tentés et que notre labeur n'ait pas été rendu vain ! 
###### 6
Maintenant Timothée vient de nous revenir de chez vous et il nous a donné de bonnes nouvelles de votre foi et de votre charité : il dit que vous conservez toujours de nous un bon souvenir, que vous aspirez à nous revoir autant que nous à vous revoir. 
###### 7
Nous avons trouvé là, frères, en raison de votre foi, un réconfort au milieu de toutes nos angoisses et tribulations. 
###### 8
Maintenant nous revivons, puisque vous tenez bon dans le Seigneur. 
###### 9
Comment pourrions-nous remercier Dieu suffisamment à votre sujet, pour toute la joie dont vous nous réjouissez devant notre Dieu ? 
###### 10
Nuit et jour nous lui demandons, avec une extrême instance, de revoir votre visage et de pouvoir compléter ce qui manque encore à votre foi. 
###### 11
Que Dieu lui-même, notre Père, et notre Seigneur Jésus aplanissent notre chemin jusqu'à vous. 
###### 12
Et vous, que le Seigneur vous fasse croître et abonder dans l'amour que vous avez les uns envers les autres et envers tous, comme nous-mêmes envers vous : 
###### 13
qu'il affermisse ainsi vos cœurs irréprochables en sainteté devant Dieu, notre Père, lors de l'Avènement de notre Seigneur Jésus avec tous ses saints. 
