---
aliases : 
- 1 Thessaloniciens 1
- 1 Thessaloniciens 1
- 1 Th 1
- 1 Thessalonians 1
tags : 
- Bible/1Th/1
- français
cssclass : français
---

# 1 Thessaloniciens 1

###### 1
Paul, Silvain et Timothée, à l'Église des Thessaloniciens qui est en Dieu le Père et dans le Seigneur Jésus Christ. A vous grâce et paix. 
###### 2
Nous rendons grâces à Dieu à tout moment pour vous tous, en faisant mention de vous sans cesse dans nos prières. 
###### 3
Nous nous rappelons en présence de notre Dieu et Père l'activité de votre foi, le labeur de votre charité, la constance de votre espérance, qui sont dus à notre Seigneur Jésus Christ. 
###### 4
Nous le savons, frères aimés de Dieu, vous avez été choisis. 
###### 5
Car notre Évangile ne s'est pas présenté à vous en paroles seulement, mais en puissance, dans l'action de l'Esprit Saint, en surabondance. De fait, vous savez comment nous nous sommes comportés au milieu de vous pour votre service. 
###### 6
Et vous vous êtes mis à nous imiter, nous et le Seigneur, en accueillant la Parole, parmi bien des tribulations, avec la joie de l'Esprit Saint : 
###### 7
vous êtes ainsi devenus un modèle pour tous les croyants de Macédoine et d'Achaïe. 
###### 8
De chez vous, en effet, la Parole du Seigneur a retenti, et pas seulement en Macédoine et en Achaïe, mais de tous côtés votre foi en Dieu s'est répandue, si bien que nous n'avons plus besoin d'en rien dire. 
###### 9
On raconte là-bas comment nous sommes venus chez vous, et comment vous vous êtes tournés vers Dieu, abandonnant les idoles pour servir le Dieu vivant et véritable, 
###### 10
dans l'attente de son Fils qui viendra des cieux, qu'il a ressuscité des morts, Jésus, qui nous délivre de la colère qui vient. 
