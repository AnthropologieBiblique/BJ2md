---
aliases : 
- 1 Thessaloniciens 5
- 1 Thessaloniciens 5
- 1 Th 5
- 1 Thessalonians 5
tags : 
- Bible/1Th/5
- français
cssclass : français
---

# 1 Thessaloniciens 5

###### 1
Quant aux temps et moments, vous n'avez pas besoin, frères, qu'on vous en écrive. 
###### 2
Vous savez vous-mêmes parfaitement que le Jour du Seigneur arrive comme un voleur en pleine nuit. 
###### 3
Quand les hommes se diront : Paix et sécurité ! c'est alors que tout d'un coup fondra sur eux la perdition, comme les douleurs sur la femme enceinte, et ils ne pourront y échapper. 
###### 4
Mais vous, frères, vous n'êtes pas dans les ténèbres, de telle sorte que ce jour vous surprenne comme un voleur : 
###### 5
tous vous êtes des fils de la lumière, des fils du jour. Nous ne sommes pas de la nuit, des ténèbres. 
###### 6
Alors ne nous endormons pas, comme font les autres, mais restons éveillés et sobres. 
###### 7
Ceux qui dorment dorment la nuit, ceux qui s'enivrent s'enivrent la nuit. 
###### 8
Nous, au contraire, nous qui sommes du jour, soyons sobres ; revêtons la cuirasse de la foi et de la charité, avec le casque de l'espérance du salut. 
###### 9
Dieu ne nous a pas réservés pour sa colère, mais pour entrer en possession du salut par notre Seigneur Jésus Christ, 
###### 10
qui est mort pour nous afin que, éveillés ou endormis, nous vivions unis à lui. 
###### 11
C'est pourquoi il faut vous réconforter mutuellement et vous édifier l'un l'autre, comme déjà vous le faites. 
###### 12
Nous vous demandons, frères, d'avoir de la considération pour ceux qui se donnent de la peine au milieu de vous, qui sont à votre tête dans le Seigneur et qui vous reprennent. 
###### 13
Estimez-les avec une extrême charité, en raison de leur travail. Soyez en paix entre vous. 
###### 14
Nous vous y engageons, frères, reprenez les désordonnés, encouragez les craintifs, soutenez les faibles, ayez de la patience envers tous. 
###### 15
Veillez à ce que personne ne rende le mal pour le mal, mais poursuivez toujours le bien, soit entre vous soit envers tous. 
###### 16
Restez toujours joyeux. 
###### 17
Priez sans cesse. 
###### 18
En toute condition soyez dans l'action de grâces. C'est la volonté de Dieu sur vous dans le Christ Jésus. 
###### 19
N'éteignez pas l'Esprit, 
###### 20
ne dépréciez pas les dons de prophétie ; 
###### 21
mais vérifiez tout : ce qui est bon, retenez-le ; 
###### 22
gardez-vous de toute espèce de mal. 
###### 23
Que le Dieu de la paix lui-même vous sanctifie totalement, et que votre être entier, l'esprit, l'âme et le corps, soit gardé sans reproche à l'Avènement de notre Seigneur Jésus Christ. 
###### 24
Il est fidèle, celui qui vous appelle : c'est encore lui qui fera cela. 
###### 25
Frères, priez vous aussi pour nous. 
###### 26
Saluez tous les frères par un saint baiser. 
###### 27
Je vous en adjure par le Seigneur, que cette lettre soit lue à tous les frères. 
###### 28
Que la grâce de notre Seigneur Jésus Christ soit avec vous. 
