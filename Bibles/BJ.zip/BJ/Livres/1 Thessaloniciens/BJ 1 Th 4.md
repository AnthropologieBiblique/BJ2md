---
aliases : 
- 1 Thessaloniciens 4
- 1 Thessaloniciens 4
- 1 Th 4
- 1 Thessalonians 4
tags : 
- Bible/1Th/4
- français
cssclass : français
---

# 1 Thessaloniciens 4

###### 1
Enfin, frères, nous vous le demandons et vous y engageons dans le Seigneur Jésus : vous avez reçu notre enseignement sur la manière de vivre qui plaît à Dieu, et déjà c'est ainsi que vous vivez ; faites-y des progrès encore. 
###### 2
Vous savez bien quelles prescriptions nous vous avons données de par le Seigneur Jésus. 
###### 3
Et voici quelle est la volonté de Dieu : c'est votre sanctification ; c'est que vous vous absteniez d'impudicité, 
###### 4
que chacun de vous sache user du corps qui lui appartient avec sainteté et respect, 
###### 5
sans se laisser emporter par la passion comme font les païens qui ne connaissent pas Dieu ; 
###### 6
que personne en cette matière ne supplante ou ne dupe son frère. Le Seigneur tire vengeance de tout cela, nous vous l'avons déjà dit et attesté. 
###### 7
Car Dieu ne nous a pas appelés à l'impureté mais à la sanctification. 
###### 8
Dès lors, qui rejette cela, ce n'est pas un homme qu'il rejette, c'est Dieu, lui qui vous a fait le don de son Esprit Saint. 
###### 9
Sur l'amour fraternel, vous n'avez pas besoin qu'on vous écrive, car vous avez personnellement appris de Dieu à vous aimer les uns les autres, 
###### 10
et vous le faites bien envers tous les frères de la Macédoine entière. Mais nous vous engageons, frères, à faire encore des progrès 
###### 11
en mettant votre honneur à vivre calmes, à vous occuper chacun de vos affaires, à travailler de vos mains, comme nous vous l'avons ordonné. 
###### 12
Ainsi vous mènerez une vie honorable au regard de ceux du dehors et vous n'aurez besoin de personne. 
###### 13
Nous ne voulons pas, frères, que vous soyez ignorants au sujet des morts ; il ne faut pas que vous vous désoliez comme les autres, qui n'ont pas d'espérance. 
###### 14
Puisque nous croyons que Jésus est mort et qu'il est ressuscité, de même, ceux qui se sont endormis en Jésus, Dieu les emmènera avec lui. 
###### 15
Voici en effet ce que nous avons à vous dire, sur la parole du Seigneur. Nous, les vivants, nous qui serons encore là pour l'Avènement du Seigneur, nous ne devancerons pas ceux qui seront endormis. 
###### 16
Car lui-même, le Seigneur, au signal donné par la voix de l'archange et la trompette de Dieu, descendra du ciel, et les morts qui sont dans le Christ ressusciteront en premier lieu ; 
###### 17
après quoi nous, les vivants, nous qui serons encore là, nous serons réunis à eux et emportés sur des nuées pour rencontrer le Seigneur dans les airs. Ainsi nous serons avec le Seigneur toujours. 
###### 18
Réconfortez-vous donc les uns les autres de ces pensées. 
