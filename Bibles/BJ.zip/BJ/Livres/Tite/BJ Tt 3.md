---
aliases : 
- Tite 3
- Tite 3
- Tt 3
- Titus 3
tags : 
- Bible/Tt/3
- français
cssclass : français
---

# Tite 3

###### 1
Rappelle à tous qu'il faut être soumis aux magistrats et aux autorités, pratiquer l'obéissance, être prêt à toute bonne œuvre, 
###### 2
n'outrager personne, éviter les disputes, se montrer bienveillant, témoigner à tous les hom-mes une parfaite douceur. 
###### 3
Car nous aussi, nous étions naguère des insensés, des rebelles, des égarés, esclaves d'une foule de convoitises et de plaisirs, vivant dans la malice et l'envie, odieux et nous haïssant les uns les autres. 
###### 4
Mais le jour où apparurent la bonté de Dieu notre Sauveur et son amour pour les hommes, 
###### 5
il ne s'est pas occupé des œuvres de justice que nous avions pu accomplir, mais, poussé par sa seule miséricorde, il nous a sauvés par le bain de la régénération et de la rénovation en l'Esprit Saint. 
###### 6
Et cet Esprit, il l'a répandu sur nous à profusion, par Jésus Christ notre Sauveur, 
###### 7
afin que, justifiés par la grâce du Christ, nous obtenions en espérance l'héritage de la vie éternelle. 
###### 8
Elle est sûre cette parole et je tiens à ce que, sur ce point, tu sois catégorique, afin que ceux qui ont placé leur foi en Dieu aient à cœur d'exceller dans la pratique du bien. Voilà qui est bon et utile aux hommes. 
###### 9
Mais les folles recherches, les généalogies, les disputes, les polémiques au sujet de la Loi, évite-les. Elles sont sans utilité et sans profit. 
###### 10
Quant à l'homme de parti, après un premier et un second avertissement, romps avec lui. 
###### 11
Un tel individu, tu le sais, est un dévoyé et un pécheur qui se condamne lui-même. 
###### 12
Lorsque je t'aurai envoyé Artémas ou Tychique, hâte-toi de me rejoindre à Nicopolis. C'est là que j'ai décidé de passer l'hiver. 
###### 13
Prends toutes dispositions pour le voyage du juriste Zénas et d'Apollos, afin qu'ils ne manquent de rien. 
###### 14
Les nôtres aussi doivent apprendre à exceller dans la pratique du bien pour faire face aux nécessités pressantes. Ainsi ne seront-ils pas sans fruits. 
###### 15
Tu as le salut de tous ceux qui sont avec moi. Salue ceux qui nous aiment dans la foi. La grâce soit avec vous tous ! 
