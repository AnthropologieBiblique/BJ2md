---
aliases : 
- Tite 2
- Tite 2
- Tt 2
- Titus 2
tags : 
- Bible/Tt/2
- français
cssclass : français
---

# Tite 2

###### 1
Pour toi, enseigne ce qui est conforme à la saine doctrine. 
###### 2
Que les vieillards soient sobres, dignes, pondérés, robustes dans la foi, la charité, la constance. 
###### 3
Que pareillement les fem-mes âgées aient le comportement qui sied à des saintes : ni médisantes, ni adonnées au vin, mais de bon conseil ; 
###### 4
ainsi elles apprendront aux jeunes femmes à aimer leur mari et leurs enfants, 
###### 5
à être réservées, chastes, femmes d'intérieur, bonnes, soumises à leur mari, en sorte que la parole de Dieu ne soit pas blasphémée. 
###### 6
Exhorte également les jeunes gens à garder en tout la pondération, 
###### 7
offrant en ta personne un exemple de bonne conduite : pureté de doctrine, dignité, 
###### 8
enseignement sain, irréprochable, afin que l'adversaire, ne pouvant dire aucun mal de nous, soit rempli de confusion. 
###### 9
Que les esclaves soient soumis en tout à leurs maîtres, cherchant à leur donner satisfaction, évitant de les contredire, 
###### 10
ne commettant aucune indélicatesse, se montrant au contraire d'une parfaite fidélité : ainsi feront-ils honneur en tout à la doctrine de Dieu notre Sauveur. 
###### 11
Car la grâce de Dieu, source de salut pour tous les hommes, s'est manifestée, 
###### 12
nous enseignant à renoncer à l'impiété et aux convoitises de ce monde, pour vivre en ce siècle présent dans la réserve, la justice et la piété, 
###### 13
attendant la bien-heureuse espérance et l'Apparition de la gloire de notre grand Dieu et Sauveur, le Christ Jésus 
###### 14
qui s'est livré pour nous afin de nous racheter de toute iniquité et de purifier un peuple qui lui appartienne en propre, zélé pour le bien. 
###### 15
C'est ainsi que tu dois parler, exhorter, reprendre avec une autorité entière. Que personne ne te méprise. 
