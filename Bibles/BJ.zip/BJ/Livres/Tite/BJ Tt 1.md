---
aliases : 
- Tite 1
- Tite 1
- Tt 1
- Titus 1
tags : 
- Bible/Tt/1
- français
cssclass : français
---

# Tite 1

###### 1
Paul, serviteur de Dieu, apôtre de Jésus Christ pour amener les élus de Dieu à la foi et à la connaissance de la vérité ordonnée à la piété, 
###### 2
dans l'espérance de la vie éternelle promise avant tous les siècles par le Dieu qui ne ment pas 
###### 3
et qui, aux temps marqués, a manifesté sa parole par une proclamation dont un ordre de Dieu notre Sauveur m'a confié la charge, 
###### 4
à Tite mon véritable enfant en notre foi commune, grâce et paix de par Dieu le Père et le Christ Jésus notre Sauveur. 
###### 5
Si je t'ai laissé en Crète, c'est pour y achever l'organisation et pour établir dans chaque ville des presbytres, conformément à mes instructions. 
###### 6
Chaque candidat doit être irréprochable, mari d'une seule femme, avoir des enfants croyants, qui ne puissent être accusés d'inconduite et ne soient pas insoumis. 
###### 7
L'épiscope, en effet, en sa qualité d'intendant de Dieu, doit être irréprochable : ni arrogant, ni coléreux, ni buveur, ni batailleur, ni avide de gains déshonnêtes, 
###### 8
mais au contraire hospitalier, ami du bien, pondéré, juste, pieux, maître de soi, 
###### 9
attaché à l'enseignement sûr, conforme à la doctrine ; ne doit-il pas être capable, à la fois, d'exhorter dans la saine doctrine et de confondre les contradicteurs ? 
###### 10
Nombreux sont en effet les esprits rebelles, les vains discoureurs, les séducteurs, surtout chez les circoncis. 
###### 11
Il faut leur fermer la bouche ; ces gens-là bouleversent des familles entières, enseignant pour de scandaleux profits ce qui ne se doit pas. 
###### 12
L'un d'entre eux, leur propre prophète, a dit : " Crétois : perpétuels menteurs, mauvaises bêtes, ventres paresseux. " 
###### 13
Ce témoignage est vrai ; aussi reprends-les vertement, pour qu'ils conservent une foi saine, 
###### 14
sans prêter attention à des fables juives et aux prescriptions de gens qui tournent le dos à la vérité. 
###### 15
Tout est pur pour les purs. Mais pour ceux qui sont souillés et qui n'ont pas la foi, rien n'est pur. Leur esprit même et leur conscience sont souillés. 
###### 16
Ils font profession de connaître Dieu, mais, par leur conduite, ils le renient : être abominables, rebelles, incapables d'aucun bien. 
