---
aliases : 
- Siracide 12
- Siracide 12
- Si 12
- Ecclesiasticus 12
tags : 
- Bible/Si/12
- français
cssclass : français
---

# Siracide 12

###### 1
Si tu fais le bien, sache à qui tu le fais et tes bienfaits ne seront pas perdus.
###### 2
Fais le bien à un homme pieux, il te le rendra, sinon par lui-même, du moins par le Très-Haut.
###### 3
Pas de bienfaits à qui persévère dans le mal et se refuse à faire la charité.
###### 4
Donne à l'homme pieux et ne viens pas en aide au pécheur.
###### 5
Fais le bien à qui est humble et ne donne pas à l'impie. Refuse-lui son pain, ne le lui donne pas, il en deviendrait plus fort que toi. Car tu serais payé au double en méchanceté pour tous les bienfaits dont tu l'aurais gratifié.
###### 6
Car le Très-Haut lui-même a les pécheurs en horreur et aux impies il infligera une punition.
###### 7
Donne à l'homme bon, mais ne viens pas en aide au pécheur.
###### 8
Dans la prospérité on ne peut reconnaître le véritable ami, et dans l'adversité l'ennemi ne peut se cacher.
###### 9
Quand un homme est heureux, ses ennemis ont du chagrin; quand il est malheureux, même son ami l'abandonne.
###### 10
Ne te fie jamais à ton ennemi; de même que l'airain se rouille, ainsi fait sa méchanceté.
###### 11
Même s'il se fait humble et s'avance en courbant l'échine, veille sur toi-même et méfie-toi de lui. Agis envers lui comme si tu polissais un miroir, sache que sa rouille ne tiendra pas jusqu'à la fin.
###### 12
Ne le mets pas près de toi, il pourrait te renverser et prendre ta place. Ne le fais pas asseoir à ta droite, il chercherait à te ravir ton siège, et finalement tu comprendrais mes paroles, tu te repentirais en songeant à mon discours.
###### 13
Qui aurait pitié du charmeur que mord le serpent et de tous ceux qui affrontent les bêtes féroces?
###### 14
Il en va de même de celui qui fait du pécheur son compagnon et qui prend part à ses péchés.
###### 15
Il reste quelque temps avec toi, mais, si tu chancelles, il ne se contient plus.
###### 16
L'ennemi n'a que douceur sur les lèvres, mais dans son cœur il médite de te jeter dans la fosse. L'ennemi a des larmes dans les yeux, et s'il trouve l'occasion il ne se rassasiera pas de sang.
###### 17
Si le sort t'est contraire, tu le trouveras là avant toi, et sous prétexte de t'aider il te saisira le talon.
###### 18
Il hochera la tête et battra des mains, il ne fera que murmurer et changer de visage.
