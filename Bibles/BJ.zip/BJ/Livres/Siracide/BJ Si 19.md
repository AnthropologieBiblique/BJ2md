---
aliases : 
- Siracide 19
- Siracide 19
- Si 19
- Ecclesiasticus 19
tags : 
- Bible/Si/19
- français
cssclass : français
---

# Siracide 19

###### 1
Un ouvrier buveur ne sera jamais riche, qui méprise les riens peu à peu s'appauvrit.
###### 2
Le vin et les femmes pervertissent les hommes sensés, qui fréquente les prostituées perd toute pudeur.
###### 3
Des larves et des vers il sera la proie et l'homme téméraire y perdra la vie.
###### 4
Celui qui a la confiance facile montre sa légèreté, celui qui pèche se fait tort à soi-même.
###### 5
Celui qui prend plaisir au mal sera condamné,
###### 6
celui qui hait le bavardage échappe au mal.
###### 7
Ne rapporte jamais ce qu'on t'a dit et jamais on ne te nuira;
###### 8
à ton ami comme à ton ennemi ne raconte rien, à moins qu'il n'y ait faute pour toi, ne le révèle pas;
###### 9
on t'écouterait, on se méfierait de toi et à l'occasion on te haïrait.
###### 10
As-tu entendu quelque chose? Sois un tombeau. Courage! tu n'en éclateras pas!
###### 11
Une parole entendue, et voilà le sot en travail comme la femme en mal d'enfant.
###### 12
Une flèche plantée dans la cuisse, telle est une parole dans le ventre du sot.
###### 13
Va trouver ton ami : peut-être n'a-t-il rien fait, et s'il a fait quelque chose il ne recommencera pas.
###### 14
Va trouver ton voisin : peut-être n'a-t-il rien dit, et s'il a dit quelque chose il ne le redira pas.
###### 15
Va trouver ton ami, car on calomnie souvent, ne crois pas tout ce qu'on te dit.
###### 16
Souvent on glisse sans mauvaise intention; qui n'a jamais péché en parole?
###### 17
Va trouver ton voisin avant d'en venir aux menaces, obéis à la loi du Très-Haut.
###### 18

###### 19

###### 20
Toute sagesse est crainte du Seigneur et en toute sagesse il y a l'accomplissement de la loi.
###### 21

###### 22
Mais connaître le mal n'est pas la sagesse et le conseil des pécheurs n'est pas la prudence.
###### 23
Il y a un savoir-faire qui est abominable; est insensé celui à qui manque la sagesse.
###### 24
Mieux vaut être pauvre d'intelligence avec la crainte que surabonder de prudence et violer la loi.
###### 25
Il y a un habile savoir-faire au service de l'injustice et tel pour établir son droit use de fourberie.
###### 26
Tel marche courbé sous le chagrin mais au fond de lui ce n'est que ruse
###### 27
baissant la tête et faisant le sourd, s'il n'est pas démasqué il prend l'avantage sur toi.
###### 28
Tel se sent trop faible pour pécher, qui fera le mal à la première occasion.
###### 29
A son air on connaît un homme, à son visage on connaît l'homme de sens.
###### 30
L'habit d'un homme, son rire, sa démarche révèlent ce qu'il est.
