---
aliases : 
- Siracide 27
- Siracide 27
- Si 27
- Ecclesiasticus 27
tags : 
- Bible/Si/27
- français
cssclass : français
---

# Siracide 27

###### 1
Beaucoup ont péché par amour du gain, celui qui veut s'enrichir se montre impitoyable.
###### 2
Un piquet s'enfonce entre deux pierres jointes, entre vente et achat une faute s'introduit.
###### 3
Qui ne s'attache pas fermement à la crainte du Seigneur, sa maison sera bientôt détruite.
###### 4
Dans le crible qu'on secoue il reste des saletés, de même les défauts de l'homme dans ses discours.
###### 5
Le four éprouve les vases du potier, l'épreuve de l'homme est dans sa conversation.
###### 6
Le verger où croît l'arbre est jugé à ses fruits, ainsi la parole d'un homme fait connaître ses sentiments.
###### 7
Ne loue personne avant qu'il n'ait parlé, car c'est là qu'est la pierre de touche.
###### 8
Si tu poursuis la justice, tu l'atteindras, tu t'en revêtiras comme d'une robe d'apparat.
###### 9
Les oiseaux cherchent la compagnie de leurs semblables, la vérité revient à ceux qui la pratiquent.
###### 10
Le lion guette sa proie, ainsi le péché guette ceux qui commettent l'injustice.
###### 11
Le discours de l'homme pieux est toujours sagesse, mais l'insensé est changeant comme la lune.
###### 12
Pour aller chez les insensés, attends l'occasion, avec les gens réfléchis attarde-toi sans crainte.
###### 13
Le discours des sots est une horreur, leur rire éclate dans les délices du péché.
###### 14
Le langage de l'homme prodigue de serments fait dresser les cheveux, quand il se querelle on se bouche les oreilles.
###### 15
La querelle des orgueilleux fait couler le sang et leurs injures sont pénibles à entendre.
###### 16
Qui révèle les secrets perd son crédit et ne trouve plus d'ami selon son cœur.
###### 17
Envers ton ami sois affectueux et confiant, mais si tu as révélé ses secrets ne cours plus après lui;
###### 18
car, comme on supprime un homme en le tuant, tu as tué l'amitié de ton prochain.
###### 19
Comme on ouvre la main et l'oiseau s'envole, tu as perdu ton ami, tu ne le rattraperas pas.
###### 20
Ne le poursuis pas : il est loin, il s'est enfui comme la gazelle échappée au filet.
###### 21
Car on panse une blessure, on pardonne une injure, mais pour qui a révélé un secret, plus d'espoir.
###### 22
Qui cligne de l'œil machine le mal, nul ne peut l'en détourner.
###### 23
En ta présence il est tout miel, il s'extasie devant tes propos; mais par derrière il change de langage et de tes paroles fait une pierre d'achoppement.
###### 24
Je hais bien des choses, mais rien tant que cet homme, et le Seigneur le hait aussi.
###### 25
Qui jette une pierre en l'air se la jette sur la tête, qui frappe en traître en subit le contrecoup.
###### 26
Qui creuse une fosse y tombera, qui tend un piège s'y fera prendre.
###### 27
Qui fait le mal, le mal retombera sur lui, sans même qu'il sache d'où il lui vient.
###### 28
Sarcasme et injure sont le fait de l'orgueilleux, mais la vengeance le guette comme un lion.
###### 29
Ils seront pris au piège ceux que réjouit la chute des hommes pieux, la douleur les consumera avant leur mort.
###### 30
Rancune et colère, voilà encore des choses abominables qui sont le fait du pécheur.
