---
aliases : 
- Siracide 5
- Siracide 5
- Si 5
- Ecclesiasticus 5
tags : 
- Bible/Si/5
- français
cssclass : français
---

# Siracide 5

###### 1
Ne te confie pas en tes richesses et ne dis pas : "Cela me suffit."
###### 2
Ne laisse pas ton désir et ta force t'entraîner à suivre les passions de ton cœur.
###### 3
Ne dis pas : "Qui a pouvoir sur moi?" Car le Seigneur ne manquera pas de te punir.
###### 4
Ne dis pas : "J'ai péché! que m'est-il arrivé?" Car le Seigneur sait attendre.
###### 5
Ne sois pas si assuré du pardon que tu entasses péché sur péché.
###### 6
Ne dis pas : "Sa miséricorde est grande, il me pardonnera la multitude de mes péchés!" car il y a chez lui pitié et colère et son courroux s'abat sur les pécheurs.
###### 7
Ne tarde pas à revenir au Seigneur et ne remets pas jour après jour, car soudain éclate la colère du Seigneur et au jour du châtiment tu serais anéanti.
###### 8
Ne te fie pas aux richesses mal acquises, elles te seront inutiles au jour du malheur.
###### 9
Ne vanne pas à tout vent, ne t'engage pas dans tout sentier ainsi fait le pécheur à la parole double .
###### 10
Sache être ferme dans ton sentiment et n'avoir qu'une parole.
###### 11
Sois prompt à écouter et lent à donner ta réponse.
###### 12
Si tu sais quelque chose, réponds à ton prochain, sinon mets la main sur ta bouche.
###### 13
Honneur et confusion sont dans la parole et la langue de l'homme fait son malheur.
###### 14
Ne te fais pas traiter de médisant et ne sois pas un rusé discoureur; car si la honte est pour le voleur, une dure condamnation atteint le fourbe.
###### 15
Dans les grandes comme dans les petites choses évite les fautes et d'ami ne deviens pas ennemi.
