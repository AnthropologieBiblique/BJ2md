---
aliases : 
- Siracide 51
- Siracide 51
- Si 51
- Ecclesiasticus 51
tags : 
- Bible/Si/51
- français
cssclass : français
---

# Siracide 51

###### 1
Je vais te rendre grâce, Seigneur, Roi, et te louer, Dieu mon sauveur. Je rends grâce à ton nom.
###### 2
Car tu as été pour moi un protecteur et un soutien et tu as délivré mon corps de la ruine, du piège de la langue mauvaise et des lèvres qui fabriquent le mensonge; en présence de ceux qui m'entourent, tu as été mon soutien, et tu m'as délivré,
###### 3
selon l'abondance de ta miséricorde et la gloire de ton nom, des morsures de ceux qui sont prêts à me dévorer, de la main de ceux qui en veulent à ma vie, des innombrables épreuves que j'ai subies,
###### 4
de la suffocation du feu qui m'entourait, du milieu d'un feu que je n'avais pas allumé,
###### 5
des profondeurs des entrailles du shéol, de la langue impure, de la parole menteuse, 
###### 6
calomnie d'une langue injuste auprès du roi. Mon âme a été tout près de la mort, ma vie était descendue aux portes du shéol.
###### 7
On m'entourait de partout et nul ne me soutenait; je cherchais du regard un homme secourable, et rien.
###### 8
Alors je me souvins de ta miséricorde, Seigneur, et de tes œuvres, de toute éternité, sachant que tu délivres ceux qui espèrent en toi, que tu les sauves des mains de leurs ennemis.
###### 9
Et je fis monter de la terre ma prière, je suppliai d'être délivré de la mort.
###### 10
J'invoquai le Seigneur, père de mon Seigneur "Ne m'abandonne pas au jour de l'épreuve, au temps des orgueilleux et de l'abandon. Je louerai ton nom continuellement, je le chanterai dans la reconnaissance."
###### 11
Et ma prière fut exaucée, tu me sauvas de la ruine, tu me délivras de l'époque du mal.
###### 12
C'est pourquoi je te rendrai grâce et je te louerai, et je bénirai le nom du Seigneur.
###### 13
Dans ma jeunesse, avant mes voyages, je cherchai ouvertement la sagesse dans la prière;
###### 14
à la porte du sanctuaire, je l'appréciais, et jusqu'à mon dernier jour je la poursuivrai.
###### 15
Dans sa fleur, comme un raisin qui mûrit, mon cœur mettait sa joie en elle. Mon pied s'est avancé dans le droit chemin et dès ma jeunesse je l'ai recherchée.
###### 16
Si peu que j'aie tendu l'oreille, je l'ai reçue, et j'ai trouvé beaucoup d'instruction.
###### 17
Grâce à elle j'ai progressé, je glorifierai celui qui m'a donné la sagesse.
###### 18
Car j'ai décidé de la mettre en pratique, j'ai cherché ardemment le bien, je ne serai pas confondu.
###### 19
Mon âme a combattu pour la posséder, j'ai été attentif à observer la loi, j'ai tendu les mains vers le ciel et j'ai déploré mes ignorances.
###### 20
J'ai dirigé mon âme vers elle et dans la pureté je l'ai trouvée; j'y ai appliqué mon cœur dès le commencement, aussi ne serai-je pas abandonné.
###### 21
Mes entrailles se sont émues pour la chercher, aussi ai-je fait une bonne acquisition.
###### 22
Le Seigneur m'a donné, en récompense, une langue avec laquelle je le glorifierai.
###### 23
Approchez-vous de moi, ignorants, mettez-vous à l'école.
###### 24
Pourquoi vous prétendre si dépourvus, quand votre gorge en est si assoiffée?
###### 25
J'ai ouvert la bouche pour parler achetez-la sans argent,
###### 26
mettez votre cou sous le joug, que vos âmes reçoivent l'instruction, elle est tout près, à votre portée.
###### 27
Voyez de vos yeux : comme j'ai eu peu de mal pour me procurer beaucoup de repos.
###### 28
Achetez l'instruction au prix de beaucoup d'argent, grâce à elle vous acquerrez beaucoup d'or.
###### 29
Que votre âme trouve sa joie dans la miséricorde du Seigneur, ne rougissez pas de le louer.
###### 30
Faites votre œuvre avant le temps fixé, et au jour fixé il vous donnera votre récompense. Sagesse de Jésus, fils de Sira.
