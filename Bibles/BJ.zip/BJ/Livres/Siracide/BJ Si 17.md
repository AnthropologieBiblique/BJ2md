---
aliases : 
- Siracide 17
- Siracide 17
- Si 17
- Ecclesiasticus 17
tags : 
- Bible/Si/17
- français
cssclass : français
---

# Siracide 17

###### 1
Le Seigneur a tiré l'homme de la terre pour l'y renvoyer ensuite.
###### 2
Il a assigné aux hommes un nombre précis de jours et un temps déterminé, il a remis en leur pouvoir ce qui est sur terre.
###### 3
Il les a revêtus de force, comme lui-même, à son image il les a créés.
###### 4
A toute chair il a inspiré la terreur de l'homme, pour qu'il domine bêtes sauvages et oiseaux
###### 5
.
###### 6
Il leur forma une langue, des yeux, des oreilles, il leur donna un cœur pour penser.
###### 7
Il les remplit de science et d'intelligence et leur fit connaître le bien et le mal.
###### 8
Il mit sa lumière dans leur cœur pour leur montrer la grandeur de ses œuvres.
###### 9

###### 10
Ils loueront son saint nom, racontant la grandeur de ses œuvres.
###### 11
Il leur accorda encore la connaissance, il les gratifia de la loi de la vie
###### 12
il a conclu avec eux une alliance éternelle et leur a fait connaître ses jugements;
###### 13
leurs yeux contemplèrent la grandeur de sa majesté, leurs oreilles entendirent la magnificence de sa voix.
###### 14
Il leur dit : "Gardez-vous de tout mal", il leur donna des commandements chacun à l'égard de son prochain.
###### 15
Leur conduite est toujours devant lui, jamais cachée à ses regards.
###### 16

###### 17
A chaque peuple il a préposé un prince, mais Israël est la portion du Seigneur.
###### 18

###### 19
Toutes leurs actions sont devant lui comme le soleil, ses regards sont assidus à observer leur conduite.
###### 20
Leurs injustices ne lui sont point cachées, tous leurs péchés sont devant le Seigneur.
###### 21

###### 22
L'aumône d'un homme est pour lui comme un sceau, il conserve un bienfait comme la pupille de l'œil.
###### 23
Un jour il se lèvera et les récompensera, sur leur tête il fera venir leur récompense.
###### 24
Mais à ceux qui se repentent il accorde un retour, il réconforte ceux qui ont perdu l'espérance.
###### 25
Convertis-toi au Seigneur et renonce à tes péchés, implore-le bien en face, cesse de l'offenser.
###### 26
Reviens vers le Très-Haut, détourne-toi de l'injustice et hais vigoureusement l'iniquité.
###### 27
Car qui louera le Très-Haut dans le shéol, si les vivants ne lui rendent gloire?
###### 28
La louange est inconnue des morts comme de ceux qui ne sont pas, celui qui a vie et santé glorifie le Seigneur.
###### 29
Qu'elle est grande la miséricorde du Seigneur, son indulgence pour ceux qui se tournent vers lui!
###### 30
Car l'homme ne peut tout avoir, puisque le fils d'homme n'est pas immortel.
###### 31
Quoi de plus lumineux que le soleil? Pourtant il disparaît. La chair et le sang ne peuvent nourrir que malice.
###### 32
C'est lui qui surveille les puissances en haut des cieux, et tous les hommes ne sont que terre et cendre.
