---
aliases : 
- Siracide 34
- Siracide 34
- Si 34
- Ecclesiasticus 34
tags : 
- Bible/Si/34
- français
cssclass : français
---

# Siracide 34

###### 1
Les espérances vaines et trompeuses sont pour l'insensé et les songes donnent des ailes aux sots.
###### 2
C'est saisir une ombre et poursuivre le vent que de s'arrêter à des songes.
###### 3
Miroir et songes sont choses semblables en face d'un visage paraît son image.
###### 4
De l'impur que peut-on tirer de pur? Du mensonge que peut-on tirer de vrai?
###### 5
Divination, augures, songes, autant de vanités, ce sont là rêveries de femme enceinte.
###### 6
A moins qu'ils ne soient envoyés en visiteurs du Très-Haut, n'y applique pas ton cœur.
###### 7
Les songes ont égaré beaucoup de gens, ceux qui comptaient dessus ont échoué.
###### 8
C'est sans mensonge que s'accomplit la Loi et la sagesse est parfaite dans la sincérité.
###### 9
On a beaucoup appris quand on a beaucoup voyagé et un homme d'expérience parle avec intelligence.
###### 10
Celui qui n'a pas été à l'épreuve connaît peu de choses, mais celui qui a voyagé déborde de savoir-faire.
###### 11
J'ai beaucoup vu au cours de mes voyages et j'en ai compris plus que je ne saurais dire.
###### 12
Bien des fois j'ai été en danger de mort, et j'ai été sauvé, voici de quelle manière
###### 13
Ceux qui craignent le Seigneur, leur esprit vivra, car leur espérance s'appuie sur qui peut les sauver.
###### 14
Celui qui craint le Seigneur n'a peur de rien, il ne tremble pas, car Dieu est son espérance.
###### 15
Heureuse l'âme de qui craint le Seigneur sur qui s'appuie-t-il et qui est son soutien?
###### 16
Les regards du Seigneur sont fixés sur ceux qui l'aiment, puissante protection, soutien plein de force, abri contre le vent du désert, ombrage contre l'ardeur du midi, protection contre les obstacles, assurance contre les chutes.
###### 17
Il élève l'âme, il illumine les yeux, il donne santé, vie et bénédiction.
###### 18
Sacrifier un bien mal acquis, c'est se moquer, les dons des méchants ne sont pas agréables.
###### 19
Le Très-Haut n'agrée pas les offrandes des impies, ce n'est pas pour l'abondance des victimes qu'il pardonne les péchés.
###### 20
C'est immoler le fils en présence de son père que d'offrir un sacrifice avec les biens des pauvres.
###### 21
Une maigre nourriture, c'est la vie des pauvres, les en priver, c'est commettre un meurtre.
###### 22
C'est tuer son prochain que de lui ôter la subsistance, c'est répandre le sang que de priver le salarié de son dû.
###### 23
L'un bâtit, l'autre démolit; qu'en retirent-ils sinon de la peine?
###### 24
L'un bénit, l'autre maudit de qui le Maître écoutera-t-il la voix?
###### 25
Qui se purifie du contact d'un mort et de nouveau le touche, que lui sert son ablution?
###### 26
Ainsi l'homme qui jeûne pour ses péchés, puis s'en va et les commet encore; qui exaucera sa prière? Que lui sert de s'humilier?
