---
aliases : 
- Siracide 8
- Siracide 8
- Si 8
- Ecclesiasticus 8
tags : 
- Bible/Si/8
- français
cssclass : français
---

# Siracide 8

###### 1
Ne lutte pas avec un grand, de peur de tomber entre ses mains.
###### 2
Ne te querelle pas avec un riche, de peur qu'il n'ait plus de poids que toi; car l'or a perdu bien des gens et a fait fléchir le cœur des rois.
###### 3
Ne dispute pas avec un beau parleur, ne mets pas de bois sur le feu.
###### 4
Ne plaisante pas avec un homme mal élevé, de peur de voir insulter tes ancêtres.
###### 5
Ne fais pas de reproches au pécheur repentant, souviens-toi que nous sommes tous coupables.
###### 6
Ne méprise pas un homme avancé en âge, car peut-être nous aussi deviendrons vieux.
###### 7
Ne te réjouis pas de la mort d'un homme, souviens-toi que tous nous devons mourir.
###### 8
Ne méprise pas le discours des sages et reviens souvent à leurs maximes; car c'est d'eux que tu apprendras la doctrine et l'art de servir les grands.
###### 9
Ne fais pas fi du discours des vieillards, car eux-mêmes ont été à l'école de leurs parents; c'est d'eux que tu apprendras la prudence et l'art de répondre à point nommé.
###### 10
Ne mets pas le feu aux charbons du pécheur de crainte de te brûler à sa flamme.
###### 11
Ne te laisse pas pousser à bout par l'homme coléreux, ce serait un piège tendu devant tes lèvres.
###### 12
Ne prête pas à un homme plus fort que toi si tu prêtes, tiens la chose pour perdue.
###### 13
Ne te porte pas caution au-delà de tes moyens si tu t'es porté caution, sois prêt à payer.
###### 14
N'aie pas de procès avec un juge, car la sentence sera rendue en sa faveur.
###### 15
Ne te mets pas en route avec un aventurier, de peur qu'il ne s'impose à toi car il n'en fait qu'à sa tête et sa folie te perdra avec lui.
###### 16
Ne te dispute pas avec un homme coléreux, ne t'engage pas avec lui dans un lieu désert, car le sang ne compte pas à ses yeux et là où il n'y a pas de secours il se jettera sur toi.
###### 17
Ne prends pas un sot pour confident, car il ne saurait garder ton secret.
###### 18
Devant un étranger, ne fais rien qui doive rester secret, car tu ne sais pas ce qu'il peut inventer.
###### 19
N'ouvre pas ton cœur à n'importe qui et ne prétends pas obtenir ses bonnes grâces.
