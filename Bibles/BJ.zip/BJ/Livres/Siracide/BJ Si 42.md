---
aliases : 
- Siracide 42
- Siracide 42
- Si 42
- Ecclesiasticus 42
tags : 
- Bible/Si/42
- français
cssclass : français
---

# Siracide 42

###### 1
Mais de ce qui suit n'aie pas honte et ne pèche pas en tenant compte des personnes
###### 2
n'aie pas honte de la loi du Très-Haut ni de l'alliance, du jugement qui rend justice aux impies,
###### 3
de compter avec un compagnon de voyage, de distribuer ton héritage à tes amis,
###### 4
d'examiner les balances et les poids, d'obtenir de petits et de grands profits,
###### 5
de faire du bénéfice en matière commerciale, de corriger sévèrement tes enfants, de meurtrir les flancs de l'esclave vicieux.
###### 6
Avec une femme curieuse il est bon d'utiliser le sceau, là où il y a beaucoup de mains, mets les choses sous clef!
###### 7
Pour les dépôts, comptes et poids sont de rigueur, et que tout, doit et avoir, soit mis par écrit.
###### 8
N'aie pas honte de corriger l'insensé et le sot, et le vieillard décrépit qui discute avec des jeunes. Ainsi tu te montreras vraiment instruit et tu seras approuvé de tout le monde.
###### 9
Sans le savoir une fille cause à son père bien du souci; le tracas qu'elle lui donne l'empêche de dormir jeune, c'est la crainte qu'elle ne tarde à se marier, et, mariée, qu'elle ne soit prise en grippe.
###### 10
Vierge, si elle se laissait séduire et devenait enceinte dans la maison paternelle! En puissance de mari, si elle faisait une faute, établie, si elle demeurait stérile!
###### 11
Ta fille est indocile? Surveille-la bien, qu'elle n'aille pas faire de toi la risée de tes ennemis, la fable de la ville, l'objet des commérages, et te déshonorer aux yeux de tous.
###### 12
Devant qui que ce soit ne t'arrête pas à la beauté et ne t'assieds pas avec les femmes.
###### 13
Car du vêtement sort la teigne et de la femme une malice de femme.
###### 14
Mieux vaut la malice d'un homme que la bonté d'une femme une femme cause la honte et les reproches.
###### 15
Maintenant je vais rappeler les œuvres du Seigneur, ce que j'ai vu, je vais le raconter. Par ses paroles le Seigneur a fait ses œuvres et la création obéit à sa volonté.
###### 16
Le soleil qui brille regarde toutes choses et l'œuvre du Seigneur est pleine de sa gloire.
###### 17
Le Seigneur n'a pas donné pouvoir aux Saints de raconter toutes ses merveilles, ce que le Seigneur, maître de tout, a fermement établi pour que l'univers subsiste dans sa gloire.
###### 18
Il a sondé les profondeurs de l'abîme et du cœur humain et il a découvert leurs calculs. Car le Très-Haut possède toute science, il a regardé les signes des temps.
###### 19
Il annonce le passé et l'avenir et dévoile les choses cachées.
###### 20
Aucune pensée ne lui échappe, aucune parole ne lui est cachée.
###### 21
Il a disposé dans l'ordre les merveilles de sa sagesse, car il est depuis l'éternité jusqu'à l'éternité sans que rien lui soit ajouté ni ôté, et il n'a besoin du conseil de personne.
###### 22
Que toutes ses œuvres sont aimables, comme une étincelle qu'on pourrait contempler.
###### 23
Tout cela vit et demeure éternellement et en toutes circonstances tout obéit.
###### 24
Toutes les choses vont par deux, en vis-à-vis, et il n'a rien fait de déficient.
###### 25
Une chose souligne l'excellence de l'autre, qui pourrait se lasser de contempler sa gloire?
