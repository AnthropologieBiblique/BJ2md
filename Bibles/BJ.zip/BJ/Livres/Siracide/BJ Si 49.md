---
aliases : 
- Siracide 49
- Siracide 49
- Si 49
- Ecclesiasticus 49
tags : 
- Bible/Si/49
- français
cssclass : français
---

# Siracide 49

###### 1
Le souvenir de Josias est une mixture d'encens préparée par les soins du parfumeur; il est comme le miel doux à toutes les bouches, comme une musique au milieu d'un banquet.
###### 2
Lui-même prit la bonne voie, celle de convertir le peuple, il extirpa l'impiété abominable;
###### 3
il dirigea son cœur vers le Seigneur, en des temps impies il fit prévaloir la piété.
###### 4
Hormis David, Ezéchias et Josias, tous multiplièrent les transgressions, ils abandonnèrent la loi du Très-Haut les rois de Juda disparurent.
###### 5
Car ils livrèrent leur vigueur à d'autres, leur gloire à une nation étrangère.
###### 6
Les ennemis brûlèrent la ville sainte élue, rendirent désertes ses rues,
###### 7
selon la parole de Jérémie. Car ils l'avaient maltraité, lui, consacré prophète dès le sein de sa mère pour déraciner, détruire et ruiner, mais aussi pour construire et pour planter.
###### 8
C'est Ezéchiel qui vit une vision de gloire que Dieu lui montra sur le char des chérubins,
###### 9
car il fit mention des ennemis dans l'averse pour favoriser ceux qui suivent la voie droite.
###### 10
Quant aux douze prophètes, que leurs os refleurissent dans la tombe, car ils ont consolé Jacob, ils l'ont racheté dans la foi et l'espérance.
###### 11
Comment faire l'éloge de Zorobabel? Il est comme un sceau dans la main droite;
###### 12
et de même Josué fils de Iosédek, eux qui, de leur temps, construisirent le Temple et firent monter vers le Seigneur un peuple saint, destiné à une gloire éternelle.
###### 13
De Néhémie le souvenir est grand, lui qui releva pour nous les murs en ruine, établit portes et verrous et releva nos habitations.
###### 14
Personne sur terre ne fut créé l'égal d'Hénok, c'est lui qui fut enlevé de terre.
###### 15
On ne vit jamais non plus naître un homme comme Joseph, chef de ses frères, soutien de son peuple; ses os furent visités.
###### 16
Sem et Seth furent glorieux parmi les hommes, mais au-dessus de toute créature vivante est Adam.
