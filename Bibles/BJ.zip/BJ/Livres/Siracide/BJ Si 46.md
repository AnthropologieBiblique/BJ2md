---
aliases : 
- Siracide 46
- Siracide 46
- Si 46
- Ecclesiasticus 46
tags : 
- Bible/Si/46
- français
cssclass : français
---

# Siracide 46

###### 1
Vaillant à la guerre, tel fut Josué fils de Nûn, successeur de Moïse dans l'office prophétique, lui qui, méritant bien son nom, se montra grand pour sauver les élus, pour châtier les ennemis révoltés et installer Israël dans son territoire.
###### 2
Qu'il était glorieux lorsque, les bras levés, il brandissait l'épée contre les villes!
###### 3
Quel homme avant lui avait eu sa fermeté? Il a mené lui-même les combats du Seigneur.
###### 4
N'est-ce pas sur son ordre que le soleil s'arrêta et qu'un seul jour en devint deux?
###### 5
Il invoqua le Très-Haut, le Puissant, alors qu'il pressait les ennemis de toutes parts, et le Seigneur grand l'exauça en lançant des grêlons d'une puissance inouïe.
###### 6
Il fondit sur la nation ennemie et dans la descente il anéantit les assaillants pour faire connaître aux nations la force de ses armes et qu'il menait la guerre devant le Seigneur.
###### 7
Car il s'attacha au Tout-Puissant, au temps de Moïse il manifesta sa piété, ainsi que Caleb, fils de Yephunné, en s'opposant à la multitude, en empêchant le peuple de pécher, en faisant taire les murmures mauvais.
###### 8
Eux deux furent seuls épargnés sur 600.000 hommes de pied, pour être introduits dans l'héritage, dans la terre où coulent le lait et le miel.
###### 9
Et le Seigneur accorda à Caleb la force qui lui resta jusqu'à sa vieillesse, il lui fit gravir les hauteurs du pays que sa descendance garda en héritage,
###### 10
afin que tout Israël voie qu'il est bon de suivre le Seigneur.
###### 11
Les Juges, chacun selon son appel, tous hommes dont le cœur ne fut pas infidèle et qui ne se détournèrent pas du Seigneur, que leur souvenir soit en bénédiction!
###### 12
Que leurs ossements refleurissent dans la tombe, que leurs noms, portés de nouveau, conviennent aux fils de ces hommes illustres.
###### 13
Samuel fut le bien-aimé de son Seigneur; prophète du Seigneur, il établit la royauté et donna l'onction aux chefs établis sur son peuple.
###### 14
Dans la loi du Seigneur il jugea l'assemblée et le Seigneur visita Jacob.
###### 15
Par sa fidélité il fut reconnu prophète, par ses discours il se montra un voyant véridique.
###### 16
Il invoqua le Seigneur tout-puissant, quand les ennemis le pressaient de toutes parts, en offrant un agneau de lait.
###### 17
Et du ciel le Seigneur fit retentir son tonnerre, à grand fracas il fit entendre sa voix;
###### 18
il anéantit les chefs de l'ennemi et tous les princes des Philistins.
###### 19
Avant l'heure de son éternel repos, il rendit témoignage devant le Seigneur et son oint "De ses biens, pas même de ses sandales, je n'ai dépouillé personne." Et personne ne l'accusa.
###### 20
Après s'être endormi il prophétisa encore et annonça au roi sa fin; du sein de la terre il éleva la voix pour prophétiser, pour effacer l'iniquité du peuple.
