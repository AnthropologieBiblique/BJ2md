---
aliases : 
- Siracide 36
- Siracide 36
- Si 36
- Ecclesiasticus 36
tags : 
- Bible/Si/36
- français
cssclass : français
---

# Siracide 36

###### 1
Aie pitié de nous, maître, Dieu de l'univers, et regarde, répands ta crainte sur toutes les nations.
###### 2
Lève la main contre les nations étrangères, et qu'elles voient ta puissance.
###### 3
Comme, à leurs yeux, tu t'es montré saint envers nous, de même, à nos yeux, montre-toi grand envers elles.
###### 4
Qu'elles te connaissent, tout comme nous avons connu qu'il n'y a pas d'autre Dieu que toi, Seigneur.
###### 5
Renouvelle les prodiges et fais d'autres miracles, glorifie ta main et ton bras droit.
###### 6
Réveille ta fureur, déverse ta colère, détruis l'adversaire, anéantis l'ennemi.
###### 7
Hâte le temps, souviens-toi du serment, que l'on célèbre tes hauts faits.
###### 8
Qu'un feu vengeur dévore les survivants, que les oppresseurs de ton peuple soient voués à la ruine.
###### 9
Brise la tête des chefs étrangers qui disent : "Il n'y a que nous."
###### 10
Rassemble toutes les tribus de Jacob, rends-leur leur héritage comme au commencement.
###### 11
Aie pitié, Seigneur, du peuple appelé de ton nom, d'Israël dont tu as fait un premier-né.
###### 12
Aie compassion de ta ville sainte, de Jérusalem le lieu de ton repos.
###### 13
Remplis Sion de ta louange et ton sanctuaire de ta gloire.
###### 14
Rends témoignage à tes premières créatures, accomplis les prophéties faites en ton nom.
###### 15
Donne satisfaction à ceux qui espèrent en toi, que tes prophètes soient véridiques.
###### 16
Exauce, Seigneur, la prière de tes serviteurs selon la bénédiction d'Aaron sur ton peuple.
###### 17
Et que tous, sur la terre, reconnaissent que tu es le Seigneur, le Dieu éternel!
###### 18
L'estomac accueille toute sorte de nourriture, mais tel aliment est meilleur qu'un autre.
###### 19
Le palais reconnaît à son goût le gibier, de même le cœur avisé discerne les paroles mensongères.
###### 20
Un cœur pervers donne du chagrin, l'homme d'expérience le paie de retour.
###### 21
Une femme accepte n'importe quel mari, mais il y a des filles meilleures que d'autres.
###### 22
La beauté d'une femme réjouit le regard, c'est le plus grand de tous les désirs de l'homme.
###### 23
Si la bonté et la douceur sont sur ses lèvres, son mari est le plus heureux des hommes.
###### 24
Celui qui acquiert une femme a le principe de la fortune, une aide semblable à lui, une colonne d'appui.
###### 25
Faute de clôture le domaine est livré au pillage, sans une femme l'homme gémit et va à la dérive.
###### 26
Comment se fier à un voleur de grand chemin qui court de ville en ville?
###### 27
De même à l'homme qui n'a pas de nid, qui s'arrête là où la nuit le surprend.
