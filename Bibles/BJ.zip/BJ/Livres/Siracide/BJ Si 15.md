---
aliases : 
- Siracide 15
- Siracide 15
- Si 15
- Ecclesiasticus 15
tags : 
- Bible/Si/15
- français
cssclass : français
---

# Siracide 15

###### 1
Ainsi fait celui qui craint le Seigneur; celui qui se saisit de la loi reçoit la sagesse.
###### 2
Elle vient au-devant de lui comme une mère, comme une épouse vierge elle l'accueille;
###### 3
elle le nourrit du pain de la prudence, elle lui donne à boire l'eau de la sagesse;
###### 4
il s'appuie sur elle et ne chancelle pas, il s'attache à elle et n'est pas confondu.
###### 5
Elle l'élève au-dessus de ses compagnons, au milieu de l'assemblée elle lui ouvre la bouche.
###### 6
Il trouve le bonheur et une couronne de joie, il reçoit en partage une renommée éternelle.
###### 7
Jamais les insensés ne la posséderont, et les pécheurs jamais ne la verront.
###### 8
Elle se tient à distance de l'orgueil et les menteurs ne songent pas à elle.
###### 9
La louange ne sied pas à la bouche du pécheur puisqu'elle ne lui est pas accordée par le Seigneur.
###### 10
Car c'est en sagesse que s'exprime la louange, et c'est le Seigneur qui la guide.
###### 11
Ne dis pas : "C'est le Seigneur qui m'a fait pécher", car il ne fait pas ce qu'il a en horreur.
###### 12
Ne dis pas : "C'est lui qui m'a égaré", car il n'a que faire d'un pécheur.
###### 13
Le Seigneur hait toute espèce d'abomination et aucune n'est aimée de ceux qui le craignent.
###### 14
C'est lui qui au commencement a fait l'homme et il l'a laissé à son conseil.
###### 15
Si tu le veux, tu garderas les commandements pour rester fidèle à son bon plaisir.
###### 16
Devant toi il a mis le feu et l'eau, selon ton désir étends la main.
###### 17
Devant les hommes sont la vie et la mort, à leur gré l'une ou l'autre leur est donnée.
###### 18
Car grande est la sagesse du Seigneur, il est tout-puissant et voit tout.
###### 19
Ses regards sont tournés vers ceux qui le craignent, il connaît lui-même toutes les œuvres des hommes.
###### 20
Il n'a commandé à personne d'être impie, il n'a donné à personne licence de pécher.
