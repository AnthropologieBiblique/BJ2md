---
aliases : 
- Siracide 2
- Siracide 2
- Si 2
- Ecclesiasticus 2
tags : 
- Bible/Si/2
- français
cssclass : français
---

# Siracide 2

###### 1
Mon fils, si tu prétends servir le Seigneur, prépare-toi à l'épreuve.
###### 2
Fais-toi un cœur droit, arme-toi de courage, ne te laisse pas entraîner, au temps de l'adversité.
###### 3
Attache-toi à lui, ne t'éloigne pas, afin d'être exalté à ton dernier jour.
###### 4
Tout ce qui t'advient, accepte-le et, dans les vicissitudes de ta pauvre condition, montre-toi patient,
###### 5
car l'or est éprouvé dans le feu, et les élus dans la fournaise de l'humiliation.
###### 6
Mets en Dieu ta confiance et il te viendra en aide, suis droit ton chemin et espère en lui.
###### 7
Vous qui craignez le Seigneur, comptez sur sa miséricorde, ne vous écartez pas, de peur de tomber.
###### 8
Vous qui craignez le Seigneur, ayez confiance en lui, et votre récompense ne saurait faillir.
###### 9
Vous qui craignez le Seigneur, espérez ses bienfaits, la joie éternelle et la miséricorde.
###### 10
Considérez les générations passées et voyez qui donc, confiant dans le Seigneur, a été confondu? Ou qui, persévérant dans sa crainte, a été abandonné? Ou qui l'a imploré sans avoir été écouté?
###### 11
Car le Seigneur est compatissant et miséricordieux, il remet les péchés et sauve au jour de la détresse.
###### 12
Malheur aux cœurs lâches et aux mains nonchalantes, et au pécheur dont la conduite est double.
###### 13
Malheur au cœur nonchalant faute de foi, car il ne sera pas protégé.
###### 14
Malheur à vous qui avez perdu l'endurance, que ferez-vous lorsque le Seigneur vous visitera?
###### 15
Ceux qui craignent le Seigneur ne transgressent pas ses paroles, ceux qui l'aiment observent ses voies.
###### 16
Ceux qui craignent le Seigneur cherchent à lui plaire, ceux qui l'aiment se rassasient de la loi.
###### 17
Ceux qui craignent le Seigneur ont un cœur toujours prêt et savent s'humilier devant lui.
###### 18
Jetons-nous dans les bras du Seigneur, et non dans ceux des hommes, car telle est sa majesté, telle aussi sa miséricorde.
