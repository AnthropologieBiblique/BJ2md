---
aliases : 
- Siracide 28
- Siracide 28
- Si 28
- Ecclesiasticus 28
tags : 
- Bible/Si/28
- français
cssclass : français
---

# Siracide 28

###### 1
Celui qui se venge éprouvera la vengeance du Seigneur qui tient un compte rigoureux des péchés.
###### 2
Pardonne à ton prochain ses torts, alors, à ta prière, tes péchés te seront remis.
###### 3
Si un homme nourrit de la colère contre un autre, comment peut-il demander à Dieu la guérison?
###### 4
Pour un homme, son semblable, il est sans compassion, et il prierait pour ses propres fautes!
###### 5
Lui qui n'est que chair garde rancune, qui lui pardonnera ses péchés?
###### 6
Souviens-toi de la fin et cesse de haïr, de la corruption et de la mort, et sois fidèle aux commandements.
###### 7
Souviens-toi des commandements et ne garde pas rancune au prochain, de l'alliance du Très-Haut, et passe par-dessus l'offense.
###### 8
Reste à l'écart des querelles et tu éviteras le péché; l'homme passionné attise les querelles;
###### 9
le pécheur sème le trouble parmi les amis, parmi les gens qui vivent en paix il jette la brouille.
###### 10
Le feu brûle suivant son combustible, la querelle se propage d'après sa violence; la fureur d'un homme dépend de sa force, sa colère monte selon sa richesse.
###### 11
Une querelle soudaine allume le feu, une dispute irréfléchie fait verser le sang.
###### 12
Souffle sur une flammèche, elle s'enflamme, crache dessus, elle s'éteint telle est la puissance de ta bouche.
###### 13
Fi du bavard et du fourbe ils ont perdu beaucoup de gens qui vivaient en paix.
###### 14
La troisième langue a ébranlé bien des gens, les a dispersés d'une nation à l'autre; elle a détruit de puissantes cités et renversé des maisons de grands.
###### 15
La troisième langue a fait répudier des femmes parfaites, les dépouillant du fruit de leurs travaux.
###### 16
Qui lui prête l'oreille ne trouve plus le repos, ne peut plus demeurer dans la paix.
###### 17
Un coup de fouet laisse une marque, mais un coup de langue brise les os.
###### 18
Bien des gens sont tombés par l'épée, mais beaucoup plus ont péri par la langue.
###### 19
Heureux qui est à l'abri de ses atteintes, qui n'est pas exposé à sa fureur, qui n'a pas porté son joug, qui n'a pas été lié de ses chaînes.
###### 20
Car son joug est un joug de fer et ses chaînes des chaînes d'airain.
###### 21
Une mort terrible, la mort qu'elle inflige, et le shéol lui est préférable.
###### 22
Elle n'a pas d'emprise sur les hommes pieux, ils ne sont pas brûlés à sa flamme.
###### 23
Ceux qui abandonnent le Seigneur sont ses victimes, en eux elle brûlera sans s'éteindre, elle sera lancée contre eux comme un lion, elle les déchirera comme une panthère.
###### 24
Vois, entoure d'épines ta propriété, serre ton argent et ton or.
###### 25
Dans ton langage use de balances et de poids, à ta bouche mets porte et verrou.
###### 26
Garde-toi de faire par elle des faux pas, tu tomberais au pouvoir de celui qui te guette.
