---
aliases : 
- Siracide 16
- Siracide 16
- Si 16
- Ecclesiasticus 16
tags : 
- Bible/Si/16
- français
cssclass : français
---

# Siracide 16

###### 1
Ne désire pas une nombreuse descendance de propres à rien et ne mets pas ta joie dans des fils impies.
###### 2
Quel que soit leur nombre ne te réjouis pas s'ils ne possèdent pas la crainte de Dieu.
###### 3
Ne compte pas pour eux sur une longue vie et n'aie pas confiance dans leur destin, car mieux vaut un seul que mille et mourir sans enfants qu'avoir des fils impies.
###### 4
Par un seul homme intelligent une ville se peuple, mais la race des pervers sera détruite.
###### 5
J'ai vu de mes yeux beaucoup de choses semblables et de mes oreilles j'en ai entendu de plus fortes.
###### 6
Dans l'assemblée des pécheurs s'allume le feu, dans la race rebelle s'est enflammée la Colère.
###### 7
Dieu n'a point pardonné aux géants d'autrefois qui s'étaient révoltés, fiers de leur puissance.
###### 8
Il n'a pas épargné la ville où habitait Lot leur orgueil lui faisait horreur.
###### 9
Il n'a pas eu pitié de la race de perdition ceux qui se prévalaient de leurs péchés.
###### 10
Il traita de même 600.000 hommes de pied, qui s'étaient ligués dans la dureté de leur cœur.
###### 11
N'y eût-il qu'un seul homme au cou raide, il serait inouï qu'il restât impuni, car pitié et colère appartiennent au Seigneur puissant dans le pardon, répandant la colère.
###### 12
Autant que sa miséricorde, autant est grande sa sévérité, il juge les hommes selon leurs œuvres.
###### 13
Il ne laisse pas impuni le pécheur avec ses larcins, il ne frustre pas la patience de l'homme pieux.
###### 14
Il tient compte de tout acte de charité et chacun est traité selon ses œuvres.
###### 15

###### 16

###### 17
Ne dis pas : "Je me cacherai pour échapper au Seigneur; là-haut qui se souviendra de moi? Au milieu de la foule je ne serai pas reconnu, que suis-je dans la création immense?"
###### 18
Voici : le ciel, le plus haut des cieux, l'abîme et la terre sont ébranlés lors de sa visite.
###### 19
En même temps les montagnes et les fondements de la terre tremblent sous son regard.
###### 20
Mais à tout cela on ne réfléchit pas; qui donc s'intéresse à ses voies?
###### 21
La tempête aussi reste invisible, la plupart de ses œuvres sont dans le secret.
###### 22
"Les œuvres de la justice, qui les annoncera? Qui les attendra? Car l'alliance est loin."
###### 23
Ainsi pense l'homme court de sens; l'insensé, égaré, ne rêve que folies.
###### 24
Ecoute-moi, mon fils, et acquiers la connaissance, applique ton cœur à mes paroles.
###### 25
Avec mesure je te révélerai la discipline, avec soin je proclamerai la connaissance.
###### 26
Lorsqu'au commencement Dieu créa ses œuvres, sitôt faites, il leur attribua une place.
###### 27
Il ordonna ses œuvres pour l'éternité, depuis leurs origines jusqu'à leurs générations lointaines. Elles ne souffrent la faim ni la fatigue et n'abandonnent jamais leur tâche.
###### 28
Aucune n'a jamais heurté l'autre et jamais elles ne désobéissent à sa parole.
###### 29
Ensuite le Seigneur jeta les yeux sur la terre et la remplit de ses biens.
###### 30
De toute espèce d'animaux il en couvrit la face et ils retourneront à la terre.
