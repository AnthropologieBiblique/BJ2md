---
aliases : 
- Siracide 9
- Siracide 9
- Si 9
- Ecclesiasticus 9
tags : 
- Bible/Si/9
- français
cssclass : français
---

# Siracide 9

###### 1
Ne sois pas jaloux de ton épouse bien-aimée et ne lui donne pas l'idée de te faire du mal.
###### 2
Ne te livre pas entre les mains d'une femme, de peur qu'elle ne prenne de l'ascendant sur toi.
###### 3
Ne va pas au-devant d'une prostituée tu pourrais tomber dans ses pièges.
###### 4
Ne fréquente pas une chanteuse tu te ferais prendre à ses artifices.
###### 5
N'arrête pas ton regard sur une jeune fille, de crainte d'être puni avec elle.
###### 6
Ne te livre pas aux mains des prostituées tu y perdrais ton patrimoine.
###### 7
Ne promène pas ton regard dans les rues de la ville et ne rôde pas dans les coins déserts.
###### 8
Détourne ton regard d'une jolie femme et ne l'arrête pas sur une beauté étrangère. Beaucoup ont été égarés par la beauté d'une femme et l'amour s'y enflamme comme un feu.
###### 9
Près d'une femme mariée garde-toi bien de t'asseoir et de t'attabler pour des beuveries, de crainte que ton cœur ne succombe à ses charmes et que dans ta passion tu ne glisses à ta perte.
###### 10
N'abandonne pas un vieil ami, le nouveau venu ne le vaudra pas. Vin nouveau, ami nouveau, laisse-le vieillir, tu le boiras avec délices.
###### 11
N'envie pas le succès du pécheur, tu ne sais comment cela finira.
###### 12
Ne te félicite pas de la réussite des impies, souviens-toi qu'ici-bas ils ne resteront pas impunis.
###### 13
Tiens-toi éloigné de l'homme qui est capable de tuer et tu n'auras aucune crainte de la mort. Si tu l'approches surveille-le bien, il pourrait t'ôter la vie. Sache bien que tu es entouré de pièges et que tu marches sur les remparts.
###### 14
Autant que tu le peux fréquente ton prochain et prends conseil des sages.
###### 15
Pour ta conversation recherche les hommes intelligents et que tous tes entretiens portent sur la loi du Très-Haut.
###### 16
Que les justes soient tes commensaux et que ta fierté soit dans la crainte du Seigneur.
###### 17
Un ouvrage fait de main d'ouvrier mérite louange, mais le chef du peuple, lui, doit être habile dans le discours.
###### 18
Le beau parleur est redouté dans la ville et le bavard est détesté.
