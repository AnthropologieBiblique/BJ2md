---
aliases : 
- Siracide 30
- Siracide 30
- Si 30
- Ecclesiasticus 30
tags : 
- Bible/Si/30
- français
cssclass : français
---

# Siracide 30

###### 1
Qui aime son fils lui prodigue le fouet, plus tard ce fils sera sa consolation.
###### 2
Qui élève bien son fils en tirera satisfaction et parmi ses connaissances il s'en montrera fier.
###### 3
Celui qui instruit son fils rend jaloux son ennemi et se montre joyeux devant ses amis.
###### 4
Qu'un père vienne à mourir, c'est comme s'il n'était pas mort, car il laisse après lui un fils qui lui ressemble.
###### 5
Vivant, il a trouvé la joie dans sa présence, devant la mort il n'a pas eu de peine.
###### 6
Contre ses ennemis il laisse un vengeur et pour ses amis quelqu'un qui leur rende leurs bienfaits.
###### 7
Celui qui gâte son fils pansera ses blessures, à chacun de ses cris ses entrailles tressailliront.
###### 8
Un cheval mal dressé devient rétif, un enfant laissé à lui-même devient mal élevé.
###### 9
Cajole ton enfant, il te terrorisera, joue avec lui, il te fera pleurer.
###### 10
Ne ris pas avec lui, si tu ne veux pas pleurer avec lui, tu finirais par grincer des dents.
###### 11
Ne lui laisse pas de liberté pendant sa jeunesse et ne ferme pas les yeux sur ses sottises.
###### 12
Fais-lui courber l'échine pendant sa jeunesse, meurtris-lui les côtes tant qu'il est enfant, de crainte que, révolté, il ne te désobéisse et que tu n'en éprouves de la peine.
###### 13
Elève ton fils et forme-le bien, pour ne pas avoir à endurer son insolence.
###### 14
Mieux vaut un pauvre sain et vigoureux qu'un riche éprouvé dans son corps.
###### 15
Santé et vigueur valent mieux que tout l'or du monde, un corps vigoureux mieux qu'une immense fortune.
###### 16
Il n'y a richesse préférable à la santé ni bien-être supérieur à la joie du cœur.
###### 17
Plutôt la mort qu'une vie chagrine, l'éternel repos qu'une maladie persistante.
###### 18
Des mets à profusion devant une bouche fermée, telles sont les offrandes déposées sur une tombe.
###### 19
Que sert l'offrande à une idole qui ne mange ni ne sent! Tel est celui que le Seigneur persécute
###### 20
il regarde et soupire, il est comme un eunuque qui étreint une vierge et soupire.
###### 21
Ne te laisse pas aller à la tristesse et ne t'abandonne pas aux idées noires.
###### 22
La joie du cœur, voilà la vie de l'homme, la gaîté, voilà qui prolonge ses jours.
###### 23
Trompe tes soucis, console ton cœur, chasse la tristesse car la tristesse en a perdu beaucoup, elle ne saurait apporter de profit.
###### 24
Passion et colère abrègent les jours, les soucis font vieillir avant l'heure.
###### 25
A cœur généreux, bon appétit il se soucie de ce qu'il mange.
