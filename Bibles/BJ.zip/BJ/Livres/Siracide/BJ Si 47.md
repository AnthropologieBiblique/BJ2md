---
aliases : 
- Siracide 47
- Siracide 47
- Si 47
- Ecclesiasticus 47
tags : 
- Bible/Si/47
- français
cssclass : français
---

# Siracide 47

###### 1
Après lui se leva Natân pour prophétiser au temps de David.
###### 2
Comme on prélève la graisse pour le sacrifice de communion, ainsi David fut choisi parmi les Israélites.
###### 3
Il se joua du lion comme du chevreau, de l'ours comme de l'agneau.
###### 4
Jeune encore, n'a-t-il pas tué le géant et lavé la honte du peuple, en lançant avec la fronde la pierre qui abattit l'arrogance de Goliath?
###### 5
Car il invoqua le Seigneur Très-Haut, qui accorda à sa droite la force pour mettre à mort un puissant guerrier et relever la vigueur de son peuple.
###### 6
Aussi lui a-t-on fait gloire de 10.000 et l'a-t-on loué dans les bénédictions du Seigneur, en lui offrant une couronne de gloire.
###### 7
Car il détruisit les ennemis alentour, il anéantit les Philistins ses adversaires, pour toujours il brisa leur vigueur.
###### 8
Dans toutes ses œuvres il rendit hommage au Saint Très-Haut dans des paroles de gloire; de tout son cœur il chanta, montrant son amour pour son Créateur.
###### 9
Il établit devant l'autel des chantres, pour émettre les chants les plus doux;
###### 10
il donna aux fêtes la splendeur, un éclat parfait aux solennités, faisant louer le saint nom du Seigneur, faisant retentir le sanctuaire dès le matin.
###### 11
Le Seigneur a effacé ses fautes, il a fait grandir sa vigueur pour toujours, il lui a accordé une alliance royale, un trône glorieux en Israël.
###### 12
Un fils savant lui succéda qui, grâce à lui, vécut heureux.
###### 13
Salomon régna dans un temps de paix et Dieu lui accorda la tranquillité alentour, afin qu'il élevât une maison pour son nom et préparât un sanctuaire éternel.
###### 14
Comme tu étais sage dans ta jeunesse, rempli d'intelligence ainsi qu'un fleuve!
###### 15
Ton esprit a couvert la terre, tu l'as remplie de sentences obscures.
###### 16
Ta renommée est parvenue jusqu'aux îles lointaines et tu fus aimé dans ta paix.
###### 17
Tes chants, tes proverbes, tes sentences et tes réponses ont fait l'admiration du monde.
###### 18
Au nom du Seigneur Dieu, de celui qu'on appelle le Dieu d'Israël, tu as amassé l'or comme de l'étain et comme le plomb tu as multiplié l'argent.
###### 19
Tu as livré ton corps aux femmes, tu as été l'esclave de tes sens.
###### 20
Tu as fait une tache à ta gloire, tu as profané ta race, au point de faire venir la colère contre tes enfants et l'affliction pour ta folie
###### 21
il se dressa un double pouvoir, il surgit d'Ephraïm un royaume révolté.
###### 22
Mais le Seigneur ne renonce jamais à sa miséricorde et n'efface aucune de ses paroles, il ne refuse pas à son élu une postérité et n'extirpe point la race de celui qui l'a aimé. Aussi a-t-il donné à Jacob un reste et à David une racine issue de lui.
###### 23
Et Salomon se reposa avec ses pères, laissant après lui quelqu'un de sa race, le plus fou du peuple, dénué d'intelligence Roboam, qui poussa le peuple à la révolte.
###### 24
Quant à Jéroboam, fils de Nebat, c'est lui qui fit pécher Israël et enseigna à Ephraïm la voie du mal. Dès lors leurs fautes se multiplièrent tant qu'elles les firent exiler loin de leur pays.
###### 25
Car ils cherchaient toute sorte de mal, jusqu'à encourir le châtiment.
