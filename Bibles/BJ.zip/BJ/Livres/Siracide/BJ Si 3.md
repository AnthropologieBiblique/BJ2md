---
aliases : 
- Siracide 3
- Siracide 3
- Si 3
- Ecclesiasticus 3
tags : 
- Bible/Si/3
- français
cssclass : français
---

# Siracide 3

###### 1
Enfants, écoutez-moi, je suis votre père, faites ce que je vous dis, afin d'être sauvés.
###### 2
Car le Seigneur glorifie le père dans ses enfants, il fortifie le droit de la mère sur ses fils.
###### 3
Celui qui honore son père expie ses fautes,
###### 4
celui qui glorifie sa mère est comme quelqu'un qui amasse un trésor.
###### 5
Celui qui honore son père trouvera de la joie dans ses enfants, au jour de sa prière il sera exaucé.
###### 6
Celui qui glorifie son père verra de longs jours, celui qui obéit au Seigneur donne satisfaction à sa mère.
###### 7
Il sert ses parents comme son Seigneur.
###### 8
En actes comme en paroles honore ton père afin que la bénédiction te vienne de lui.
###### 9
Car la bénédiction d'un père affermit la maison de ses enfants, mais la malédiction d'une mère en détruit les fondations.
###### 10
Ne te glorifie pas du déshonneur de ton père il n'y a pour toi aucune gloire au déshonneur de ton père.
###### 11
Car c'est la gloire d'un homme que l'honneur de son père et c'est une honte pour les enfants qu'une mère méprisée.
###### 12
Mon fils, viens en aide à ton père dans sa vieillesse, ne lui fais pas de peine pendant sa vie.
###### 13
Même si son esprit faiblit, sois indulgent, ne le méprise pas, toi qui es en pleine force.
###### 14
Car une charité faite à un père ne sera pas oubliée, et, pour tes péchés, elle te vaudra réparation.
###### 15
Au jour de ton épreuve Dieu se souviendra de toi, comme glace au soleil, s'évanouiront tes péchés.
###### 16
Tel un blasphémateur, celui qui délaisse son père, un maudit du Seigneur, celui qui fait de la peine à sa mère.
###### 17
Mon fils, conduis tes affaires avec douceur, et tu seras plus aimé qu'un homme munificent.
###### 18
Plus tu es grand, plus il faut t'abaisser pour trouver grâce devant le Seigneur,
###### 19

###### 20
car grande est la puissance du Seigneur, mais il est honoré par les humbles.
###### 21
Ne cherche pas ce qui est trop difficile pour toi, ne scrute pas ce qui est au-dessus de tes forces.
###### 22
Sur ce qui t'a été assigné exerce ton esprit, tu n'as pas à t'occuper de choses mystérieuses.
###### 23
Ne te tracasse pas de ce qui te dépasse, l'enseignement que tu as reçu est déjà trop vaste pour l'esprit humain.
###### 24
Car beaucoup se sont fourvoyés dans leurs conception, une prétention coupable a égaré leurs pensées.
###### 25

###### 26
Un cœur obstiné finira dans le malheur et qui aime le danger y tombera.
###### 27
Un cœur obstiné se charge de peines, le pécheur accumule péché sur péché.
###### 28
Au mal de l'orgueilleux il n'est pas de guérison, car la méchanceté est enracinée en lui.
###### 29
L'homme prudent médite en son cœur les paraboles, une oreille qui l'écoute, c'est le rêve du sage.
###### 30
L'eau éteint les flammes, l'aumône remet les péchés.
###### 31
Qui répond par des bienfaits prépare l'avenir, au jour de sa chute il trouvera un soutien.
