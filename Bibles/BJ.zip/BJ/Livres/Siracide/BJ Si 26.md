---
aliases : 
- Siracide 26
- Siracide 26
- Si 26
- Ecclesiasticus 26
tags : 
- Bible/Si/26
- français
cssclass : français
---

# Siracide 26

###### 1
Heureux l'époux dont la femme est excellente, le nombre de ses jours sera doublé.
###### 2
Une femme parfaite est la joie de son mari, il passera dans la paix toutes les années de sa vie.
###### 3
Une femme excellente est une part de choix, attribuée à ceux qui craignent le Seigneur
###### 4
riches ou pauvres, leur cœur est en liesse, ils montrent toujours un visage joyeux.
###### 5
Trois choses me font peur et une quatrième m'épouvante une calomnie qui court la ville, une émeute populaire, une fausse accusation : tout cela est pire que la mort;
###### 6
mais c'est crève-cœur et douleur qu'une femme jalouse d'une autre, et tout cela, c'est le fléau de la langue.
###### 7
Une femme méchante, c'est un joug à bœufs mal attaché; prétendre la maîtriser, c'est saisir un scorpion.
###### 8
Une femme qui boit, c'est un sujet de grande colère, elle ne peut cacher son déshonneur.
###### 9
L'inconduite d'une femme se lit dans la vivacité de son regard et se reconnaît à ses œillades.
###### 10
Méfie-toi bien d'une fille hardie de peur que, se sentant les coudées franches, elle n'en profite.
###### 11
Garde-toi bien des regards effrontés et ne t'étonne pas s'ils t'entraînent au mal.
###### 12
Comme un voyageur altéré elle ouvre la bouche, elle boit de toutes les eaux qu'elle rencontre, elle va au-devant de toute fornication et offre son corps à l'impureté.
###### 13
La grâce d'une épouse fait la joie de son mari et sa science est pour lui une force.
###### 14
Une femme silencieuse est un don du Seigneur, celle qui est bien élevée est sans prix.
###### 15
Une femme pudique est une double grâce, celle qui est chaste est d'une valeur inestimable.
###### 16
Comme le soleil levant sur les montagnes du Seigneur, ainsi le charme d'une jolie femme dans une maison bien tenue.
###### 17
Une lumière brillant sur un lampadaire sacré, ainsi la beauté d'un visage sur un corps bien planté.
###### 18
Des colonnes d'or sur une base d'argent, ainsi de belles jambes sur des talons solides.
###### 19

###### 20

###### 21

###### 22

###### 23

###### 24

###### 25

###### 26

###### 27

###### 28
Il y a deux choses qui me font de la peine et la troisième m'excite la bile un guerrier qui vieillit dans la misère, des hommes de sens qui souffrent le mépris, celui qui passe de la justice au péché; le Seigneur le destine à périr par l'épée.
###### 29
Un marchand résiste difficilement à la tentation et le trafiquant ne saurait être sans péché.
