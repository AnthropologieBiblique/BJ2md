---
aliases : 
- Siracide 35
- Siracide 35
- Si 35
- Ecclesiasticus 35
tags : 
- Bible/Si/35
- français
cssclass : français
---

# Siracide 35

###### 1
Observer la loi c'est multiplier les offrandes, s'attacher aux préceptes c'est offrir des sacrifices de communion.
###### 2
Se montrer charitable c'est faire une oblation de fleur de farine, faire l'aumône c'est offrir un sacrifice de louange.
###### 3
Ce qui plaît au Seigneur c'est qu'on se détourne du mal, c'est offrir un sacrifice expiatoire que de fuir l'injustice.
###### 4
Ne parais pas devant le Seigneur les mains vides, car tout cela est dû selon les préceptes.
###### 5
L'offrande du juste réjouit l'autel, son parfum s'élève devant le Très-Haut.
###### 6
Le sacrifice du juste est agréable, son mémorial ne sera pas oublié.
###### 7
Glorifie le Seigneur avec générosité et ne sois pas avare des prémices que tu offres.
###### 8
Chaque fois que tu fais une offrande montre un visage joyeux et consacre la dîme avec joie.
###### 9
Donne au Très-Haut comme il t'a donné, avec générosité, selon tes moyens.
###### 10
Car le Seigneur paie de retour, il te rendra au septuple.
###### 11
N'essaie pas de le corrompre par des présents, il les refuse, ne t'appuie pas sur un sacrifice injuste.
###### 12
Car le Seigneur est un juge qui ne fait pas acception de personnes.
###### 13
Il ne considère pas les personnes pour faire tort au pauvre, il écoute l'appel de l'opprimé.
###### 14
Il ne néglige pas la supplication de l'orphelin, ni de la veuve qui épanche ses plaintes.
###### 15
Les larmes de la veuve ne coulent-elles pas sur ses joues et son cri n'accable-t-il pas celui qui les provoque?
###### 16
Celui qui sert Dieu de tout son cœur est agréé et son appel parvient jusqu'aux nuées.
###### 17
La prière de l'humble pénètre les nuées; tant qu'elle n'est pas arrivée il ne se console pas.
###### 18
Il n'a de cesse que le Très-Haut n'ait jeté les yeux sur lui, qu'il n'ait fait droit aux justes et rétabli l'équité.
###### 19
Et le Seigneur ne tardera pas, il n'aura pas de patience à leur égard,
###### 20
tant qu'il n'aura brisé les reins des violents et tiré vengeance des nations,
###### 21
exterminé la multitude des orgueilleux et brisé le sceptre des injustes,
###### 22
tant qu'il n'aura rendu à chacun selon ses œuvres et jugé les actions humaines selon les cœurs,
###### 23
tant qu'il n'aura rendu justice à son peuple et ne l'aura comblé de joie dans sa miséricorde.
###### 24
La miséricorde est bonne au temps de la tribulation, comme les nuages de pluie au temps de la sécheresse.
