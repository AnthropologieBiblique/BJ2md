---
aliases : 
- Siracide 32
- Siracide 32
- Si 32
- Ecclesiasticus 32
tags : 
- Bible/Si/32
- français
cssclass : français
---

# Siracide 32

###### 1
On t'a fait président? Ne le prends pas de haut, sois avec les convives comme l'un d'eux, prends soin d'eux et ensuite assieds-toi.
###### 2
Ayant rempli tous tes devoirs, prends place pour te réjouir avec eux et recevoir la couronne, prix de ta réussite.
###### 3
Parle, vieillard, car cela te sied, mais avec discrétion : n'empêche pas la musique.
###### 4
Au cours d'une audition ne prodigue pas les discours, ne sermonne pas à contretemps.
###### 5
Un sceau d'escarboucle sur un bijou, tel est un concert musical au cours d'un banquet.
###### 6
Un sceau d'émeraude sur une monture d'or, telle est une mélodie avec un vin de choix.
###### 7
Parle, jeune homme, quand c'est nécessaire, deux fois au plus, si l'on t'interroge.
###### 8
Résume ton discours, dis beaucoup en peu de mots, sache te montrer ensemble entendu et silencieux.
###### 9
Ne traite pas avec les grands d'égal à égal, si un autre parle, sois sobre de paroles.
###### 10
L'éclair précède le tonnerre, la grâce s'avance devant l'homme modeste.
###### 11
L'heure venue, va-t'en, ne traîne pas, cours à la maison, ne flâne pas.
###### 12
Là, divertis-toi, fais ce qui te plaît, mais ne pèche pas en parlant avec insolence.
###### 13
Et pour cela bénis le Créateur, celui qui te comble de ses bienfaits.
###### 14
Celui qui craint le Seigneur entend ses leçons, ceux qui le cherchent trouvent sa faveur.
###### 15
Celui qui scrute la loi en est rassasié, mais pour l'hypocrite elle est un scandale.
###### 16
Ceux qui craignent le Seigneur sont justifiés, ils font briller leurs bonnes actions comme une lumière.
###### 17
Le pécheur n'accepte pas la réprimande, pour suivre sa volonté il trouve des excuses.
###### 18
L'homme sensé ne méprise pas les avis, l'étranger et l'orgueilleux ne connaissent pas la crainte.
###### 19
Ne fais rien sans réflexion, tu ne te repentiras pas de tes actes.
###### 20
Ne suis pas un chemin raboteux, de crainte de buter sur les pierres.
###### 21
Ne te fie pas au chemin uni
###### 22
et méfie-toi de tes enfants.
###### 23
En toutes choses veille sur toi-même, cela aussi, c'est observer les commandements.
###### 24
Celui qui a confiance dans la loi observe ses préceptes, celui qui met sa confiance dans le Seigneur ne souffre aucun dommage.
