---
aliases : 
- Siracide 40
- Siracide 40
- Si 40
- Ecclesiasticus 40
tags : 
- Bible/Si/40
- français
cssclass : français
---

# Siracide 40

###### 1
Un sort pénible a été fait à tous les hommes, un joug pesant accable les fils d'Adam, depuis le jour qu'ils sortent du sein maternel jusqu'au jour de leur retour à la mère universelle.
###### 2
L'objet de leurs réflexions, la crainte de leur cœur, c'est l'attente anxieuse du jour de leur mort.
###### 3
Depuis celui qui siège sur un trône, dans la gloire, jusqu'au miséreux assis sur la terre et la cendre,
###### 4
depuis celui qui porte la pourpre et la couronne jusqu'à celui qui est vêtu d'étoffe grossière, ce n'est que fureur, envie, trouble, inquiétude, crainte de la mort, rivalités et querelles.
###### 5
Et à l'heure où, couché, l'on repose, le sommeil de la nuit ne fait que varier les soucis
###### 6
à peine a-t-on trouvé le repos qu'aussitôt, dormant, comme en plein jour, on est agité de cauchemars, comme un fuyard échappé du combat.
###### 7
Au moment de la délivrance on s'éveille, tout surpris que sa peur soit vaine.
###### 8
Pour toute créature, de l'homme à la bête, mais pour les pécheurs, au septuple,
###### 9
la mort, le sang, la querelle et l'épée, malheurs, famine, tribulation, calamité!
###### 10
Tout cela a été créé pour les pécheurs, et c'est à cause d'eux que vint le déluge.
###### 11
Tout ce qui vient de la terre retourne à la terre, et ce qui vient de l'eau fait retour à la mer.
###### 12
Les pots-de-vin et les injustices disparaîtront, mais la bonne foi tiendra éternellement.
###### 13
Les richesses mal acquises s'évanouiront comme un torrent, comme le coup de tonnerre qui éclate pendant l'averse.
###### 14
Quand il ouvre les mains il se réjouit, ainsi les pécheurs iront à la ruine.
###### 15
Les rejetons des impies sont pauvres de rameaux, les racines impures ne trouvent qu'âpre rocher.
###### 16
Le roseau qui abonde sur toutes les eaux et sur les bords du fleuve sera arraché le premier.
###### 17
La charité est comme un paradis de bénédiction et l'aumône demeure à jamais.
###### 18
L'homme indépendant et le travailleur ont la vie douce; mieux loti encore celui qui trouve un trésor.
###### 19
Des enfants et une ville fondée perpétuent un nom; mieux encore apprécie-t-on une femme parfaite.
###### 20
Le vin et les arts mettent la joie au cœur; mieux encore l'amour de la sagesse.
###### 21
La flûte et la cithare agrémentent le chant; mieux encore une voix mélodieuse.
###### 22
Beauté et grâce font la joie de l'œil; mieux encore la verdure des champs.
###### 23
Ami et camarade se rencontrent au bon moment; mieux encore la femme et l'homme.
###### 24
Frères et protecteurs sont utiles aux mauvais jours; mieux encore l'aumône tire d'affaire.
###### 25
L'or et l'argent rendent la démarche ferme; mieux encore estime-t-on le conseil.
###### 26
La richesse et la force donnent un cœur assuré; mieux encore la crainte du Seigneur. Avec la crainte du Seigneur rien ne manque; avec elle on n'a pas à chercher d'appui.
###### 27
La crainte du Seigneur est un paradis de bénédiction; mieux que toute gloire elle protège.
###### 28
Mon fils, ne vis pas de mendicité, mieux vaut mourir que mendier.
###### 29
L'homme qui louche vers la table d'autrui, sa vie ne saurait passer pour une vie. Il se souille la gorge de nourritures étrangères, un homme instruit et bien élevé s'en gardera.
###### 30
A la bouche de l'impudent la mendicité est douce, mais à ses entrailles, c'est un feu brûlant.
