---
aliases : 
- Siracide 48
- Siracide 48
- Si 48
- Ecclesiasticus 48
tags : 
- Bible/Si/48
- français
cssclass : français
---

# Siracide 48

###### 1
Alors le prophète Elie se leva comme un feu, sa parole brûlait comme une torche.
###### 2
C'est lui qui fit venir sur eux la famine et qui, dans son zèle, les décima.
###### 3
Par la parole du Seigneur il ferma le ciel, il fit aussi trois fois descendre le feu.
###### 4
Comme tu étais glorieux, Elie, dans tes prodiges! qui peut dans son orgueil se faire ton égal?
###### 5
Toi qui as arraché un homme à la mort et au shéol, par la parole du Très-Haut.
###### 6
Toi qui as mené des rois à la ruine, précipité des hommes glorieux de leur couche,
###### 7
qui entendis au Sinaï un reproche, à l'Horeb des décrets de vengeance,
###### 8
qui oignis des rois comme vengeurs, des prophètes pour te succéder,
###### 9
qui fus emporté dans un tourbillon de feu, par un char aux chevaux de feu,
###### 10
toi qui fus désigné dans des menaces futures pour apaiser la colère avant qu'elle n'éclate, pour ramener le cœur des pères vers les fils et rétablir les tribus de Jacob.
###### 11
Bienheureux ceux qui te verront et ceux qui se sont endormis dans l'amour, car nous aussi nous posséderons la vie.
###### 12
Tel fut Elie qui fut enveloppé dans un tourbillon. Elisée fut rempli de son esprit; pendant sa vie aucun chef ne put l'ébranler, personne ne put le subjuguer.
###### 13
Rien n'était trop grand pour lui et jusque dans la mort son corps prophétisa.
###### 14
Pendant sa vie il fit des prodiges et dans sa mort ses œuvres furent merveilleuses.
###### 15
Malgré tout, le peuple ne se convertit pas, ne renonça pas à ses péchés, jusqu'à ce qu'il fût déporté loin de son pays et dispersé sur toute la terre;
###### 16
il ne resta que le peuple le moins nombreux et un chef de la maison de David. Quelques-uns d'entre eux firent le bien, d'autres multiplièrent les fautes.
###### 17
Ezéchias fortifia sa ville et fit venir l'eau dans ses murs, avec le fer il fora le rocher et construisit des citernes.
###### 18
De son temps Sennachérib se mit en campagne et envoya Rabsakès, il leva la main contre Sion, dans l'insolence de son orgueil.
###### 19
Alors leur cœur et leurs mains tremblèrent, ils souffrirent les douleurs de femmes en travail,
###### 20
ils firent appel au Seigneur miséricordieux, tendant les mains vers lui. Du ciel, le Saint se hâta de les écouter et les délivra par la main d'Isaïe,
###### 21
il frappa le camp des Assyriens et son Ange les extermina.
###### 22
Car Ezéchias fit ce qui plaît au Seigneur et se montra fort en suivant David son père, comme le lui ordonna le prophète Isaïe, le grand, le fidèle dans ses visions.
###### 23
De son temps le soleil recula; il prolongea la vie du roi.
###### 24
Dans la puissance de l'esprit il vit la fin des temps, il consola les affligés de Sion,
###### 25
il révéla l'avenir jusqu'à l'éternité et les choses cachées avant qu'elles n'advinssent.
