---
aliases : 
- Isaïe 6
- Isaïe 6
- Is 6
- Isaiah 6
tags : 
- Bible/Is/6
- français
cssclass : français
---

# Isaïe 6

###### 1
L'année de la mort du roi Ozias, je vis le Seigneur assis sur un trône grandiose et surélevé. Sa traîne emplissait le sanctuaire. 
###### 2
Des séraphins se tenaient au-dessus de lui, ayant chacun six ailes, deux pour se couvrir la face, deux pour se couvrir les pieds, deux pour voler. 
###### 3
Ils se criaient l'un à l'autre ces paroles : " Saint, saint, saint est Yahvé Sabaot, sa gloire emplit toute la terre. " 
###### 4
Les montants des portes vibrèrent au bruit de ces cris et le Temple était plein de fumée. 
###### 5
Alors je dis : " Malheur à moi, je suis perdu! car je suis un homme aux lèvres impures, j'habite au sein d'un peuple aux lèvres impures, et mes yeux ont vu le Roi, Yahvé Sabaot. " 
###### 6
L'un des séraphins vola vers moi, tenant dans sa main une braise qu'il avait prise avec des pinces sur l'autel. 
###### 7
Il m'en toucha la bouche et dit : " Voici, ceci a touché tes lèvres, ta faute est effacée, ton péché est pardonné. " 
###### 8
Alors j'entendis la voix du Seigneur qui disait : " Qui enverrai-je ? Qui ira pour nous ? " Et je dis : " Me voici, envoie-moi. " 
###### 9
Il me dit : " Va, et tu diras à ce peuple : Écoutez, écoutez, et ne comprenez pas; regardez, regardez, et ne discernez pas. 
###### 10
Appesantis le cœur de ce peuple, rends-le dur d'oreille, englue-lui les yeux, de peur que ses yeux ne voient, que ses oreilles n'entendent, que son cœur ne comprenne, qu'il ne se convertisse et ne soit guéri. " 
###### 11
Et je dis : " Jusques à quand, Seigneur ? " Il me répondit : " Jusqu'à ce que les villes soient détruites et dépeuplées, les maisons inhabitées; que le sol soit dévasté, désolé; 
###### 12
que Yahvé en chasse les gens, et qu'une grande détresse règne au milieu du pays. 
###### 13
Et s'il en reste un dixième, de nouveau il sera dépouillé, comme le térébinthe et comme le chêne qui une fois émondés n'ont plus qu'un tronc; leur tronc est une semence sainte. " 
