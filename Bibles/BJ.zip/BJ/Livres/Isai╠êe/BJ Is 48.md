---
aliases : 
- Isaïe 48
- Isaïe 48
- Is 48
- Isaiah 48
tags : 
- Bible/Is/48
- français
cssclass : français
---

# Isaïe 48

###### 1
Écoutez ceci, maison de Jacob, vous que l'on appelle du nom d'Israël, vous qui êtes issus des eaux de Juda, qui jurez par le nom de Yahvé et qui invoquez le Dieu d'Israël, sans loyauté ni justice. 
###### 2
Car ils tirent leur nom de la ville sainte, ils s'appuient sur le Dieu d'Israël, Yahvé Sabaot est son nom. 
###### 3
Les choses anciennes, depuis longtemps je les avais annoncées, elles étaient sorties de ma bouche, je les avais proclamées, et soudain j'ai agi, elles sont arrivées. 
###### 4
Car je savais que tu es obstiné, de fer est le muscle de ton cou, et ton front est d'airain. 
###### 5
Aussi te l'ai-je annoncé depuis longtemps, avant que cela n'arrive je l'avais proclamé, de peur que tu ne dises : " Mon image a tout fait, mon idole et ma statue ont tout ordonné. " 
###### 6
Tu as entendu et vu tout cela, et vous, ne l'annoncerez-vous pas ? Je t'ai fait entendre dès maintenant des choses nouvelles, secrètes et inconnues de toi. 
###### 7
C'est maintenant qu'elles sont créées, et non depuis longtemps, et jusqu'à ce jour tu n'en avais pas entendu parler, de peur que tu ne dises : " Oui, je les connaissais. " 
###### 8
Eh bien non, tu n'entendais rien, tu ne savais rien, depuis longtemps ton oreille n'était pas attentive, car je savais combien tu es perfide, et que dès le berceau on t'appelle révolté. 
###### 9
A cause de mon nom, je vais différer ma colère, pour mon honneur, je vais patienter avec toi, pour ne pas t'exterminer. 
###### 10
Voici que je t'ai acheté mais non pour de l'argent, je t'ai choisi au creuset du malheur. 
###### 11
C'est à cause de moi, de moi seul, que je vais agir, comment mon nom serait-il profané ? Je ne donnerai pas ma gloire à un autre. 
###### 12
Écoute-moi, Jacob, Israël que j'ai appelé, c'est moi, moi qui suis le premier et c'est moi aussi le dernier. 
###### 13
Ma main a fondé la terre, ma droite a tendu les cieux, moi, je les appelle et tous ensemble ils se présentent. 
###### 14
Assemblez-vous, vous tous, et écoutez, qui parmi eux a annoncé cela ? Yahvé l'aime; il accomplira son bon plaisir sur Babylone et la race des Chaldéens : 
###### 15
c'est moi, c'est moi qui ai parlé et qui l'ai appelé, je l'ai fait venir et son entreprise réussira. 
###### 16
Approchez-vous de moi et écoutez ceci : dès le début je n'ai pas parlé en cachette, lorsque c'est arrivé, j'étais là, et maintenant le Seigneur Yahvé m'a envoyé avec son esprit. 
###### 17
Ainsi parle Yahvé ton rédempteur, le Saint d'Israël : Je suis Yahvé ton Dieu, je t'instruis pour ton bien, je te conduis par le chemin où tu marches. 
###### 18
Si seulement tu avais été attentif à mes commandements! Ton bonheur serait comme un fleuve et ta justice comme les flots de la mer. 
###### 19
Ta race serait comme le sable, et comme le grain, ceux qui sont issus de toi! Son nom ne serait pas retranché ni effacé devant moi. 
###### 20
Sortez de Babylone, fuyez de chez les Chaldéens, avec des cris de joie, annoncez, proclamez ceci, répandez-le jusqu'aux extrémités de la terre, dites : Yahvé a racheté son serviteur Jacob. 
###### 21
Ils n'ont pas eu soif quand il les menait dans les déserts, il a fait couler pour eux l'eau du rocher, il a fendu le rocher et l'eau a jailli. 
###### 22
Point de bonheur, dit Yahvé, pour les méchants. 
