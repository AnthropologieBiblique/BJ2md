---
aliases : 
- Isaïe 26
- Isaïe 26
- Is 26
- Isaiah 26
tags : 
- Bible/Is/26
- français
cssclass : français
---

# Isaïe 26

###### 1
En ce jour-là, on chantera ce chant au pays de Juda : Nous avons une ville forte; pour nous protéger, il a mis mur et avant-mur. 
###### 2
Ouvrez les portes! Qu'elle entre, la nation juste qui observe la fidélité. 
###### 3
C'est un dessein arrêté : tu assureras la paix, la paix qui t'est confiée. 
###### 4
Confiez-vous en Yahvé à jamais! Car Yahvé est un rocher, éternellement. 
###### 5
C'est lui qui a précipité les habitants des hauteurs, la cité élevée; il l'abaisse, il l'abaisse jusqu'à terre, il lui fait mordre la poussière. 
###### 6
Elle sera foulée aux pieds, par les pieds du malheureux, par les pas du faible. 
###### 7
Le sentier du juste, c'est la droiture, tu aplanis la droite trace du juste. 
###### 8
Oui, dans le sentier de tes jugements, nous t'attendions, Yahvé, à ton nom et à ta mémoire va le désir de l'âme. 
###### 9
Mon âme t'a désiré pendant la nuit, oui, au plus profond de moi, mon esprit te cherche, car lorsque tu rends tes jugements pour la terre, les habitants du monde apprennent la justice. 
###### 10
Si l'on fait grâce au méchant sans qu'il apprenne la justice, au pays de la droiture il fait le mal, sans voir la majesté de Yahvé. 
###### 11
Yahvé, ta main est levée et ils ne voient pas! Ils verront, pleins de confusion, ton amour jaloux pour ce peuple, oui, le feu préparé pour tes ennemis les dévorera. 
###### 12
Yahvé, tu nous assures la paix, et même toutes nos œuvres, tu les accomplis pour nous. 
###### 13
Yahvé notre Dieu, d'autres maîtres que toi ont dominé sur nous, mais, attachés à toi seul, nous invoquons ton nom. 
###### 14
Les morts ne revivront pas, les ombres ne se relèveront pas, car tu les as visités, exterminés, tu as détruit jusqu'à leur souvenir. 
###### 15
Tu as fait de nous une nation, Yahvé, tu as fait de nous une nation et tu as été glorifié. Tu as fait reculer les limites du pays. 
###### 16
Yahvé, dans la détresse ils t'ont cherché, ils se répandirent en prière car ton châtiment était sur eux. 
###### 17
Comme la femme enceinte à l'heure de l'enfantement souffre et crie dans ses douleurs, ainsi étions-nous devant ta face, Yahvé. 
###### 18
Nous avons conçu, nous avons souffert, mais c'était pour enfanter du vent : nous n'avons pas donné le salut à la terre, il ne naît pas d'habitants au monde. 
###### 19
Tes morts revivront, tes cadavres ressusciteront. Réveillez-vous et chantez, vous qui habitez la poussière, car ta rosée est une rosée lumineuse, et le pays va enfanter des ombres. 
###### 20
Va, mon peuple, entre dans tes chambres, ferme tes portes sur toi; cache-toi un tout petit instant, jusqu'à ce qu'ait passé la fureur. 
###### 21
Car voici Yahvé qui sort de sa demeure pour châtier la faute des habitants de la terre; et la terre dévoilera son sang, elle cessera de recouvrir ses cadavres. 
