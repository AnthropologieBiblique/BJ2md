---
aliases : 
- Isaïe 53
- Isaïe 53
- Is 53
- Isaiah 53
tags : 
- Bible/Is/53
- français
cssclass : français
---

# Isaïe 53

###### 1
Qui a cru ce que nous entendions dire, et le bras de Yahvé, à qui s'est-il révélé ? 
###### 2
Comme un surgeon il a grandi devant lui, comme une racine en terre aride; sans beauté ni éclat pour attirer nos regards, et sans apparence qui nous eût séduits; 
###### 3
objet de mépris, abandonné des hommes, homme de douleur, familier de la souffrance, comme quelqu'un devant qui on se voile la face, méprisé, nous n'en faisions aucun cas. 
###### 4
Or ce sont nos souffrances qu'il portait et nos douleurs dont il était chargé. Et nous, nous le considérions comme puni, frappé par Dieu et humilié. 
###### 5
Mais lui, il a été transpercé à cause de nos crimes, écrasé à cause de nos fautes. Le châtiment qui nous rend la paix est sur lui, et dans ses blessures nous trouvons la guérison. 
###### 6
Tous, comme des moutons, nous étions errants, chacun suivant son propre chemin, et Yahvé a fait retomber sur lui nos fautes à tous. 
###### 7
Maltraité, il s'humiliait, il n'ouvrait pas la bouche, comme l'agneau qui se laisse mener à l'abattoir, comme devant les tondeurs une brebis muette, il n'ouvrait pas la bouche. 
###### 8
Par contrainte et jugement il a été saisi. Parmi ses contemporains, qui s'est inquiété qu'il ait été retranché de la terre des vivants, qu'il ait été frappé pour le crime de son peuple ? 
###### 9
On lui a donné un sépulcre avec les impies et sa tombe est avec le riche, bien qu'il n'ait pas commis de violence et qu'il n'y ait pas eu de tromperie dans sa bouche. 
###### 10
Yahvé a voulu l'écraser par la souffrance; s'il offre sa vie en sacrifice expiatoire, il verra une postérité, il prolongera ses jours, et par lui la volonté de Yahvé s'accomplira. 
###### 11
A la suite de l'épreuve endurée par son âme, il verra la lumière et sera comblé. Par sa connaissance, le juste, mon serviteur, justifiera les multitudes en s'accablant lui-même de leurs fautes. 
###### 12
C'est pourquoi il aura sa part parmi les multitudes, et avec les puissants il partagera le butin, parce qu'il s'est livré lui-même à la mort et qu'il a été compté parmi les criminels, alors qu'il portait le péché des multitudes et qu'il intercédait pour les criminels. 
