---
aliases : 
- Isaïe 29
- Isaïe 29
- Is 29
- Isaiah 29
tags : 
- Bible/Is/29
- français
cssclass : français
---

# Isaïe 29

###### 1
Malheur, Ariel, Ariel, cité où campa David! ajoutez année sur année, que les fêtes accomplissent leur cycle, 
###### 2
j'opprimerai Ariel; ce sera gémissements et sanglots, et elle sera pour moi comme Ariel. 
###### 3
Je camperai en cercle contre toi, j'entreprendrai contre toi un siège et je dresserai contre toi des retranchements. 
###### 4
Tu seras abaissée, ta voix s'élèvera de la terre, de la poussière elle s'élèvera comme un murmure; ta voix comme celle d'un esprit viendra de la terre, comme venant de la poussière elle murmurera. 
###### 5
La horde de tes ennemis sera comme des grains de poussière, la horde des guerriers, comme la bale qui s'envole. Et soudain, en un instant, 
###### 6
tu seras visitée de Yahvé Sabaot dans le fracas, le tremblement, le vacarme, ouragan et tempête, flamme de feu dévorant. 
###### 7
Ce sera comme un rêve, une vision nocturne : la horde de toutes les nations en guerre contre Ariel, tous ceux qui le combattent, l'assiègent et l'oppriment. 
###### 8
Et ce sera comme le rêve de l'affamé : le voici qui mange, puis il s'éveille, l'estomac creux; ou comme le rêve de l'assoiffé : le voici qui boit, puis il s'éveille épuisé, la gorge sèche. Ainsi en sera-t-il de la horde de toutes les nations en guerre contre la montagne de Sion. 
###### 9
Soyez stupides et stupéfaits, devenez aveugles et sans vue; soyez ivres, mais non de vin, titubants, mais non de boisson, 
###### 10
car Yahvé a répandu sur vous un esprit de torpeur, il a fermé vos yeux les prophètes , il a voilé vos têtes les voyants . 
###### 11
Et toutes les visions sont devenues pour vous comme les mots d'un livre scellé que l'on remet à quelqu'un qui sait lire en disant : " Lis donc cela. " Mais il répond : " Je ne puis, car il est scellé. " 
###### 12
Et on remet le livre à quelqu'un qui ne sait pas lire en disant : " Lis donc cela. " Mais il répond : " Je ne sais pas lire. " 
###### 13
Le Seigneur a dit : Parce que ce peuple est près de moi en paroles et me glorifie de ses lèvres, mais que son cœur est loin de moi et que sa crainte n'est qu'un commandement humain, une leçon apprise, 
###### 14
eh bien! voici que je vais continuer à étonner ce peuple par des prodiges et des merveilles; la sagesse des sages se perdra et l'intelligence des intelligents s'envolera. 
###### 15
Malheur à ceux qui se terrent pour dissimuler à Yahvé leurs desseins, qui trament dans les ténèbres leurs actions et disent : " Qui nous voit ? qui nous connaît ? " 
###### 16
Quelle perversité! Le potier ressemble-t-il à l'argile pour qu'une œuvre ose dire à celui qui l'a faite : " Il ne m'a pas faite ", et un pot à son potier : " Il ne sait pas travailler " ? 
###### 17
N'est-il pas vrai que dans peu de temps le Liban redeviendra un verger, et le verger fera penser à une forêt ? 
###### 18
En ce jour-là, les sourds entendront les paroles du livre et, délivrés de l'ombre et des ténèbres, les yeux des aveugles verront. 
###### 19
Les malheureux trouveront toujours plus de joie en Yahvé, les plus pauvres des hommes exulteront à cause du Saint d'Israël. 
###### 20
Car le tyran ne sera plus, le moqueur aura disparu, tous les veilleurs infâmes auront été retranchés : 
###### 21
ceux dont la parole porte condamnation, ceux qui tendent un piège à celui qui juge à la porte, et sans raison font débouter le juste. 
###### 22
C'est pourquoi, ainsi parle Yahvé, Dieu de la maison de Jacob, lui qui a racheté Abraham : Désormais Jacob ne sera plus déçu, désormais son visage ne blêmira plus, 
###### 23
car lorsqu'il verra ses enfants, l'œuvre de mes mains, chez lui, il sanctifiera mon nom, il sanctifiera le Saint de Jacob, il redoutera le Dieu d'Israël. 
###### 24
Les esprits égarés apprendront l'intelligence, et ceux qui murmurent recevront l'instruction. Contre l'ambassade envoyée en Égypte. 
