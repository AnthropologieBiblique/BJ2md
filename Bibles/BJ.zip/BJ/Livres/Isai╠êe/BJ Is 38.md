---
aliases : 
- Isaïe 38
- Isaïe 38
- Is 38
- Isaiah 38
tags : 
- Bible/Is/38
- français
cssclass : français
---

# Isaïe 38

###### 1
En ces jours-là, Ézéchias fut atteint d'une maladie mortelle. Le prophète Isaïe, fils d'Amoç, vint lui dire : " Ainsi parle Yahvé. Mets ordre à ta maison, car tu vas mourir, tu ne vivras pas. " 
###### 2
Ézéchias se tourna vers le mur et fit cette prière à Yahvé : 
###### 3
" Ah! Yahvé, souviens-toi, de grâce, que je me suis conduit fidèlement et en toute probité de cœur devant toi, et que j'ai fait ce qui était bien à tes yeux. " Et Ézéchias versa d'abondantes larmes. 
###### 4
Alors la parole de Yahvé se fit entendre à Isaïe : 
###### 5
" Va dire à Ézéchias : Ainsi parle Yahvé, Dieu de ton ancêtre David. J'ai entendu ta prière, j'ai vu tes larmes. Je vais te guérir; dans trois jours, tu monteras au Temple de Yahvé. J'ajouterai quinze années à ta vie. 
###### 6
Je te délivrerai, toi et cette ville, de la main du roi d'Assyrie, et je protégerai cette ville. " 
###### 7
Isaïe répondit : "Voici, de la part de Yahvé, le signe qu'il fera ce qu'il a dit.
###### 8
Voici que je vais faire reculer l'ombre des degrés que le soleil a descendus sur les degrés de la chambre haute d'Achaz dix degrés en arrière." Et le soleil recula de dix degrés, sur les degrés qu'il avait descendus.
###### 9
Cantique d'Ezéchias, roi de Juda, lors de la maladie dont il fut guéri
###### 10
Je disais : Au midi de mes jours, je m'en vais, aux portes du shéol je serai gardé pour le reste de mes ans.
###### 11
Je disais : Je ne verrai pas Yahvé sur la terre des vivants, je n'aurai plus un regard pour personne parmi les habitants du monde.
###### 12
Ma demeure est arrachée, jetée loin de moi, comme une tente de bergers; comme un tisserand j'ai enroulé ma vie, il m'a séparé de la chaîne. Du point du jour jusqu'à la nuit tu m'as achevé;
###### 13
j'ai crié jusqu'au matin; comme un lion, c'est ainsi qu'il broie tous mes os, du point du jour jusqu'à la nuit tu m'as achevé.
###### 14
Comme l'hirondelle, je pépie, je gémis comme la colombe, mes yeux faiblissent à regarder en haut. Seigneur je suis accablé, viens à mon aide.
###### 15
Comment parlerai-je et que lui dirai-je? Car c'est lui qui agit. Je m'avancerai toutes mes années durant dans l'amertume de mon âme.
###### 16
Le Seigneur est sur eux, ils vivent et tout ce qui est en eux est vie de son esprit. Tu me guériras, fais-moi vivre.
###### 17
Voici que mon amertume se change en bien-être. C'est toi qui as préservé mon âme de la fosse du néant, tu as jeté derrière toi tous mes péchés.
###### 18
Ce n'est pas le shéol qui te loue, ni la mort qui te célèbre. Ils n'espèrent plus en ta fidélité, ceux qui descendent dans la fosse.
###### 19
Le vivant, le vivant lui seul te loue, comme moi aujourd'hui. Le père à ses fils fait connaître ta fidélité.
###### 20
Yahvé, viens à mon aide, et nous ferons résonner nos harpes tous les jours de notre vie dans le Temple de Yahvé.
###### 21
Isaïe dit : "Qu'on apporte un pain de figues, qu'on l'applique sur l'ulcère, et il vivra."
###### 22
Ezéchias dit : "A quel signe connaîtrai-je que je monterai au Temple de Yahvé?"
