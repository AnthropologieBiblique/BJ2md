---
aliases : 
- Isaïe 28
- Isaïe 28
- Is 28
- Isaiah 28
tags : 
- Bible/Is/28
- français
cssclass : français
---

# Isaïe 28

###### 1
Malheur à l'orgueilleuse couronne des ivrognes d'Éphraïm, à la fleur fanée de sa superbe splendeur sise au sommet de la grasse vallée, à ceux que terrasse le vin. 
###### 2
Voici un homme fort et puissant au service du Seigneur, comme une tornade de grêle, une tempête dévastatrice, comme d'énormes trombes d'eau qui se déversent, de sa main il les jette à terre. 
###### 3
Elles seront foulées aux pieds, l'orgueilleuse couronne des ivrognes d'Éphraïm 
###### 4
et la fleur fanée de sa superbe splendeur sise au sommet de la grasse vallée. C'est comme une figue mûre avant l'été : qui l'aperçoit aussitôt la saisit et l'avale. 
###### 5
Ce jour-là, c'est Yahvé Sabaot qui deviendra une couronne de splendeur et un superbe diadème pour le reste de son peuple, 
###### 6
un esprit de justice pour qui doit rendre la justice, et la force de ceux qui repoussent l'assaut aux portes. 
###### 7
Eux aussi, ils ont été troublés par le vin, ils ont divagué sous l'effet de la boisson. Prêtre et prophète, ils ont été troublés par la boisson, ils ont été pris de vin, ils ont divagué sous l'effet de la boisson, ils ont été troublés dans leurs visions, ils ont divagué dans leurs sentences. 
###### 8
Oui, toutes les tables sont couvertes de vomissements abjects, pas une place nette! 
###### 9
A qui enseigne-t-il la leçon ? A qui explique-t-il la doctrine ? A des enfants à peine sevrés, à peine éloignés de la mamelle, 
###### 10
quand il dit : çav laçav, çav laçav; qav laqav, qav laqav; ze'êr sham, ze'êr sham. 
###### 11
Oui, c'est par des lèvres bégayantes et dans une langue étrangère qu'il parlera à ce peuple. 
###### 12
Il leur avait dit : " Voici le repos! Donnez le repos à l'accablé : ceci est un endroit tranquille. " Mais ils n'ont pas voulu écouter. 
###### 13
Aussi Yahvé va leur parler ainsi : çav laçav, çav laçav; qav laqav, qav laqav; ze'êr sham, ze'êr sham, afin qu'en marchant ils tombent à la renverse, qu'ils soient brisés, pris au piège, emprisonnés. 
###### 14
C'est pourquoi, écoutez la parole de Yahvé, hommes insolents, gouverneurs de ce peuple qui est à Jérusalem. 
###### 15
Vous avez dit : " Nous avons conclu une alliance avec la mort, avec le shéol nous avons fait un pacte. Quant au fléau menaçant, il passera sans nous atteindre, car nous avons fait du mensonge notre refuge, et dans la fausseté nous nous sommes cachés. " 
###### 16
C'est pourquoi, ainsi parle le Seigneur Yahvé : Voici que je vais poser en Sion une pierre, une pierre de granit, pierre angulaire, précieuse, pierre de fondation bien assise : celui qui s'y fie ne sera pas ébranlé. 
###### 17
Et je prendrai le droit comme mesure et la justice comme niveau. Mais la grêle balaiera le refuge de mensonge et les eaux inonderont la cachette; 
###### 18
votre alliance avec la mort sera rompue, votre pacte avec le shéol ne tiendra pas. Quant au fléau destructeur, lorsqu'il passera, vous serez piétinés par lui. 
###### 19
Chaque fois qu'il passera, il vous saisira, car chaque matin il passera, et le jour et la nuit, et seule la terreur fera comprendre la révélation. 
###### 20
Car la couche sera trop courte pour s'y étendre, et la couverture trop étroite pour s'en envelopper. 
###### 21
Oui, comme au mont de Peraçim, Yahvé se lèvera, comme au val de Gabaôn, il frémira, pour opérer son œuvre, son œuvre étrange, pour accomplir sa tâche, sa tâche mystérieuse. 
###### 22
Et maintenant, cessez de vous moquer, de peur que ne se resserrent vos liens, car je l'ai entendu : c'est irrévocablement décidé par le Seigneur Yahvé Sabaot, contre tout le pays. 
###### 23
Prêtez l'oreille et entendez ma voix; soyez attentifs, entendez ma parole. 
###### 24
Le laboureur passe-t-il tout son temps à labourer pour semer, à défoncer et herser son coin de terre ? 
###### 25
Après avoir aplani la surface, ne jette-t-il pas la nigelle, ne répand-il pas le cumin ? Puis il met le blé, le millet, l'orge ... et l'épeautre en bordure. 
###### 26
Son Dieu lui a enseigné cette règle et l'a instruit. 
###### 27
On n'écrase pas la nigelle avec le traîneau, on ne fait pas passer sur le cumin les roues du chariot. C'est avec un bâton qu'on bat la nigelle, et le cumin se bat au fléau. 
###### 28
Lorsqu'on foule le froment, on ne s'attarde pas à l'écraser; on met en marche la roue du chariot et son attelage, on ne le broie pas. 
###### 29
Tout cela est un don de Yahvé Sabaot, merveilleux conseil qui fait de grandes choses. 
