---
aliases : 
- Isaïe 59
- Isaïe 59
- Is 59
- Isaiah 59
tags : 
- Bible/Is/59
- français
cssclass : français
---

# Isaïe 59

###### 1
Non, la main de Yahvé n'est pas trop courte pour sauver, ni son oreille trop dure pour entendre. 
###### 2
Mais ce sont vos fautes qui ont creusé un abîme entre vous et votre Dieu. Vos péchés ont fait qu'il vous cache sa face et refuse de vous entendre. 
###### 3
Car vos mains sont souillées par le sang et vos doigts par le crime, vos lèvres ont proféré le mensonge, votre langue médite le mal. 
###### 4
Nul n'accuse à juste titre, nul ne plaide de bonne foi. On se confie au néant, on profère la fausseté, on conçoit la peine, on enfante le mal. 
###### 5
Ils ont fait éclore des œufs de vipère, ils tissent des toiles d'araignée. Qui mange de leurs œufs en meurt; écrasés, il en sort un serpent. 
###### 6
Leurs toiles ne feront pas un vêtement, ils ne pourront se vêtir de leurs œuvres; leurs œuvres sont des œuvres mauvaises, les actes de violence sont dans leurs mains. 
###### 7
Leurs pieds courent au mal; ils ont hâte de verser le sang innocent. Leurs pensées sont des pensées mauvaises, ravage et destruction sont sur leur chemin. 
###### 8
Ils n'ont pas connu la voie de la paix, le droit ne suit pas leurs traces, ils se font des sentiers tortueux, quiconque les suit ignore la paix. 
###### 9
Aussi le droit reste loin de nous, la justice ne nous atteint pas. Nous attendions la lumière, et voici les ténèbres, la clarté, et nous marchons dans l'obscurité. 
###### 10
Nous tâtonnons comme des aveugles cherchant un mur, comme privés d'yeux nous tâtonnons. Nous trébuchons en plein midi comme au crépuscule, parmi les bien-portants nous sommes comme des morts. 
###### 11
Nous grognons tous comme des ours, comme des colombes nous ne faisons que gémir; nous attendons le jugement, et rien! le salut, et il demeure loin de nous. 
###### 12
Car nombreux sont nos crimes contre toi, nos péchés témoignent contre nous. Oui, nos crimes nous sont présents et nous reconnaissons nos fautes : 
###### 13
nous révolter, renier Yahvé, cesser de suivre notre Dieu; proférer violence et révolte, concevoir et méditer le mensonge. 
###### 14
On repousse le jugement, on tient éloignée la justice, car la vérité a trébuché sur la place publique, et la droiture ne trouve point d'accès. 
###### 15
La vérité a disparu; ceux qui s'abstiennent du mal sont dépouillés. Yahvé l'a vu, il a jugé mauvais qu'il n'y ait plus de jugement. 
###### 16
Il a vu qu'il n'y avait personne, il s'est étonné que nul n'intervînt, alors son bras devint son secours, et sa justice, son appui. 
###### 17
Il a revêtu comme cuirasse la justice, sur sa tête le casque du salut, il a revêtu comme tunique des habits de vengeance, il s'est drapé de la jalousie comme d'un manteau. 
###### 18
Selon les œuvres il rétribue, fureur pour les adversaires, châtiment pour les ennemis, aux îles il paiera leur salaire. 
###### 19
Et l'on craindra, depuis l'Occident, le nom de Yahvé, et depuis le Levant sa gloire, car il viendra comme un torrent resserré, chassé par le souffle de Yahvé. 
###### 20
Alors un rédempteur viendra à Sion, pour ceux qui se détournent de leur crime, en Jacob. Oracle de Yahvé. 
###### 21
Et moi, voici mon alliance avec eux, dit Yahvé : mon esprit qui est sur toi et mes paroles que j'ai mises dans ta bouche ne s'éloigneront pas de ta bouche, ni de la bouche de ta descendance, ni de la bouche de la descendance de ta descendance, dit Yahvé, dès maintenant et à jamais. 
