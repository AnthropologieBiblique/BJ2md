---
aliases : 
- Isaïe 47
- Isaïe 47
- Is 47
- Isaiah 47
tags : 
- Bible/Is/47
- français
cssclass : français
---

# Isaïe 47

###### 1
Descends, assieds-toi dans la poussière, Vierge, fille de Babylone, assieds-toi à terre, sans trône, fille des Chaldéens, car jamais plus on ne t'appellera douce et exquise. 
###### 2
Prends la meule et broie la farine; dénoue ton voile, relève ta robe, découvre tes jambes, traverse les rivières. 
###### 3
Que paraisse ta nudité et que ta honte soit visible; j'exécute ma vengeance et personne ne s'y opposera. 
###### 4
Notre rédempteur, Yahvé Sabaot est son nom, le Saint d'Israël, a dit : 
###### 5
Assieds-toi en silence, enfonce-toi dans l'ombre, fille des Chaldéens, car jamais plus on ne t'appellera souveraine des royaumes. 
###### 6
J'étais irrité contre mon peuple, j'avais rejeté mon héritage, je l'avais livré entre tes mains. Tu les as traités sans pitié, sur le vieillard tu as fait durement peser ton joug. 
###### 7
Tu as dit : " A jamais je serai souveraine éternelle ", tu n'as pas réfléchi à cela dans ton cœur, tu n'as pas songé à l'avenir. 
###### 8
Maintenant écoute ceci, voluptueuse! toi qui es assise en sécurité et qui dis dans ton cœur : " Moi, sans égale, je ne resterai pas veuve, je ne connaîtrai pas la privation d'enfants! " 
###### 9
Eh bien, ces deux malheurs fondront sur toi, soudainement, en un jour, privation d'enfants et veuvage, tout à coup ils fondront sur toi, en dépit de tous tes sortilèges, de la puissance de tes incantations. 
###### 10
Tu as eu confiance dans ta méchanceté, tu as dit : " Personne ne me voit. " C'est ta sagesse et ta science qui t'ont pervertie, et tu as dit dans ton cœur : " Moi, sans égale. " 
###### 11
Un malheur fondra sur toi, tu ne sauras comment le conjurer; un désastre fondra sur toi, tu ne pourras t'en préserver; soudain fondra sur toi une calamité que tu ne connaîtras pas. 
###### 12
Reste donc avec tes incantations et tous tes sortilèges dans lesquels tu t'es fatiguée depuis ta jeunesse. Peut-être pourras-tu en tirer profit, peut-être sauras-tu faire trembler. 
###### 13
Tu t'es épuisée à force de consultations, qu'ils se présentent donc et te sauvent ceux qui détaillent le ciel, qui observent les étoiles, qui annoncent chaque mois ce qui va fondre sur toi. 
###### 14
Voici qu'ils sont comme fétus de paille, le feu les brûlera, ils ne sauveront pas leur vie de l'étreinte de la flamme; et ce ne sera pas une braise pour se chauffer, un foyer pour s'y asseoir! 
###### 15
Ainsi auront été pour toi tes devins, pour lesquels tu t'es fatiguée depuis ta jeunesse : ils ont erré, chacun devant soi, et pas un ne t'a sauvée. 
