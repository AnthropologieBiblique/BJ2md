---
aliases : 
- Isaïe 3
- Isaïe 3
- Is 3
- Isaiah 3
tags : 
- Bible/Is/3
- français
cssclass : français
---

# Isaïe 3

###### 1
Oui, voici que le Seigneur Yahvé Sabaot va ôter de Jérusalem et de Juda ressource et provision - toute réserve de pain et toute réserve d'eau -, 
###### 2
héros et homme de guerre, juge et prophète, devin et vieillard, 
###### 3
capitaine et dignitaire, conseiller, architecte et enchanteur. 
###### 4
Je leur donnerai comme princes des adolescents, et des gamins feront la loi chez eux. 
###### 5
Les gens se molesteront l'un l'autre, et entre voisins; le jeune garçon s'en prendra au vieillard, l'homme de peu au notable. 
###### 6
Oui, un homme saisira son frère dans la maison paternelle : " Tu as un manteau, tu seras notre chef, et cette chose branlante, qu'elle te soit confiée! " 
###### 7
Et l'autre, en ce jour-là, s'écriera : " Je ne suis pas un guérisseur; chez moi, il n'y a ni pain ni manteau, ne me faites pas chef du peuple! " 
###### 8
Car Jérusalem a trébuché et Juda est tombé, oui, leurs paroles et leurs actes s'adressent à Yahvé, pour insulter ses regards glorieux. 
###### 9
Leur complaisance témoigne contre eux, ils étalent leur péché comme Sodome. Ils n'ont pas dissimulé, malheur à eux! car ils ont préparé leur propre ruine. 
###### 10
Dites : le juste, qu'il est heureux! car il se nourrira du fruit de ses actes. 
###### 11
Malheur au méchant, malfaisant! car il sera traité selon ses œuvres. 
###### 12
O mon peuple, ses oppresseurs le mettent au pillage, et des exacteurs font la loi chez lui. O mon peuple, tes guides t'égarent, ils ont effacé les chemins que tu suis. 
###### 13
Yahvé s'est levé pour accuser, il est debout pour juger les peuples. 
###### 14
Yahvé entre en jugement, avec les anciens et les princes de son peuple : " C'est vous qui avez dévasté la vigne, la dépouille du malheureux est dans vos maisons. 
###### 15
De quel droit écraser mon peuple et broyer le visage des malheureux ? " Oracle du Seigneur Yahvé Sabaot. Les femmes de Jérusalem. 
###### 16
Yahvé dit : Parce qu'elles font les fières, les filles de Sion, qu'elles vont le cou tendu et les yeux provocants, qu'elles vont à pas menus, en faisant sonner les anneaux de leurs pieds, 
###### 17
le Seigneur rendra galeux le crâne des filles de Sion, Yahvé dénudera leur front. 
###### 18
Ce jour-là le Seigneur ôtera l'ornement de chaînettes, les médaillons et les croissants, 
###### 19
les pendentifs, les bracelets, les breloques, 
###### 20
les diadèmes et les chaînettes de chevilles, les parures, les boîtes à parfums et les amulettes, 
###### 21
les bagues et les anneaux de narines, 
###### 22
les vêtements de fête et les manteaux, les écharpes et les bourses, 
###### 23
les miroirs, les linges fins, les turbans et les mantilles. 
###### 24
Alors, au lieu de baume, ce sera la pourriture, au lieu de ceinture, une corde, au lieu de coiffure, la tête rase, au lieu d'une robe d'apparat, un pagne de grosse toile, et la marque au fer rouge au lieu de beauté. 
###### 25
Tes hommes tomberont sous l'épée, et tes braves dans le combat. 
###### 26
Ses portes gémiront et seront dans le deuil; désertée, elle s'assiéra par terre. 
