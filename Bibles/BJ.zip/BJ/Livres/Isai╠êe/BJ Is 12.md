---
aliases : 
- Isaïe 12
- Isaïe 12
- Is 12
- Isaiah 12
tags : 
- Bible/Is/12
- français
cssclass : français
---

# Isaïe 12

###### 1
Et tu diras, en ce jour-là : Je te loue, Yahvé, car tu as été en colère contre moi. Puisse ta colère se détourner, puisses-tu me consoler. 
###### 2
Voici le Dieu de mon salut : j'aurai confiance et je ne tremblerai plus, car ma force et mon chant c'est Yahvé, il a été mon salut. 
###### 3
Dans l'allégresse vous puiserez de l'eau aux sources du salut. 
###### 4
Et vous direz, en ce jour-là : Louez Yahvé, invoquez son nom, annoncez aux peuples ses hauts faits, rappelez que son nom est sublime. 
###### 5
Chantez Yahvé, car il a fait de grandes choses, qu'on le proclame sur toute la terre. 
###### 6
Pousse des cris de joie, des clameurs, habitante de Sion, car il est grand, au milieu de toi, le Saint d'Israël. Contre Babylone. 
