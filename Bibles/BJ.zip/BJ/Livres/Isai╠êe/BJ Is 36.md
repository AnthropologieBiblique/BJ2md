---
aliases : 
- Isaïe 36
- Isaïe 36
- Is 36
- Isaiah 36
tags : 
- Bible/Is/36
- français
cssclass : français
---

# Isaïe 36

###### 1
Il arriva qu'en la quatorzième année du roi Ézéchias, Sennachérib, roi d'Assyrie, monta contre toutes les villes fortes de Juda et s'en empara. 
###### 2
De Lakish, le roi d'Assyrie envoya vers le roi Ézéchias, à Jérusalem, le grand échanson avec un important corps de troupes. Le grand échanson se posta près du canal de la piscine supérieure, sur le chemin du champ du Foulon. 
###### 3
Le maître du palais Élyaqim, fils de Hilqiyyahu, le secrétaire Shebna et le héraut Yoah, fils d'Asaph, sortirent à sa rencontre. 
###### 4
Le grand échanson leur dit : " Dites à Ézéchias : Ainsi parle le grand roi, le roi d'Assyrie : Quelle est cette confiance sur laquelle tu te reposes ? 
###### 5
Tu t'imagines que paroles en l'air valent conseil et vaillance pour faire la guerre. En quoi donc mets-tu ta confiance pour t'être révolté contre moi ? 
###### 6
Voici que tu te fies au soutien de ce roseau brisé, l'Égypte, qui pénètre et perce la main de qui s'appuie sur lui. Tel est Pharaon, roi d'Égypte, pour tous ceux qui se fient à lui. 
###### 7
Vous me direz peut-être : "C'est en Yahvé notre Dieu que nous avons confiance", mais n'est-ce pas lui dont Ézéchias a supprimé les hauts lieux et les autels en disant aux gens de Juda et de Jérusalem : "C'est devant cet autel que vous vous prosternerez" ? 
###### 8
Eh bien! fais un pari avec Monseigneur le roi d'Assyrie : je te donnerai deux mille chevaux si tu peux trouver des cavaliers pour les monter. 
###### 9
Comment ferais-tu reculer un seul des moindres serviteurs de mon maître ? Mais tu t'es fié à l'Égypte pour avoir chars et cavaliers! 
###### 10
Et puis, est-ce sans la volonté de Yahvé que je suis monté contre ce pays pour le dévaster ? C'est Yahvé qui m'a dit : "Monte contre ce pays et dévaste-le! " " 
###### 11
Élyaqim, Shebna et Yoah dirent au grand échanson : " Je t'en prie, parle à tes serviteurs en araméen, car nous l'entendons, ne nous parle pas en judéen à portée des oreilles du peuple qui est sur les remparts. " 
###### 12
Mais le grand échanson dit : " Est-ce à toi ou à ton maître que Monseigneur m'a envoyé dire ces choses ? N'est-ce pas plutôt aux gens assis sur le rempart et condamnés à manger leurs excréments et à boire leur urine avec vous ? " 
###### 13
Alors le grand échanson se tint debout, il cria d'une voix forte, en langue judéenne, et dit : " Écoutez les paroles du grand roi, le roi d'Assyrie! 
###### 14
Ainsi parle le roi : Qu'Ézéchias ne vous abuse pas! Il ne pourra vous délivrer. 
###### 15
Qu'Ézéchias n'entretienne pas votre confiance en Yahvé en disant : "Sûrement Yahvé nous délivrera, cette ville ne tombera pas entre les mains du roi d'Assyrie. " 
###### 16
N'écoutez pas Ézéchias, car ainsi parle le roi d'Assyrie : Faites la paix avec moi, rendez-vous à moi, et chacun de vous mangera le fruit de sa vigne et de son figuier, chacun boira l'eau de sa citerne, 
###### 17
jusqu'à ce que je vienne et que je vous emmène vers un pays comme le vôtre, un pays de froment et de moût, un pays de pain et de vignobles. 
###### 18
Qu'Ézéchias ne vous abuse pas en vous disant : "Yahvé nous délivrera. " Les dieux des nations ont-ils vraiment délivré chacun son pays des mains du roi d'Assyrie ? 
###### 19
Où sont les dieux de Hamat et d'Arpad, où sont les dieux de Sepharvayim, où sont les dieux du pays de Samarie ? Ont-ils délivré Samarie de ma main ? 
###### 20
Parmi tous les dieux de ces pays, lesquels ont délivré leur pays de ma main, pour que Yahvé délivre Jérusalem ? " 
###### 21
Ils gardèrent le silence et ne lui répondirent pas un mot, car tel était l'ordre du roi : " Vous ne lui répondrez pas. " 
###### 22
Le maître du palais Élyaqim, fils de Hilqiyyahu, le secrétaire Shebna et le héraut Yoah, fils d'Asaph, vinrent auprès d'Ézéchias, les vêtements déchirés, et ils lui rapportèrent les paroles du grand échanson. 
