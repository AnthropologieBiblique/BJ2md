---
aliases : 
- Isaïe 39
- Isaïe 39
- Is 39
- Isaiah 39
tags : 
- Bible/Is/39
- français
cssclass : français
---

# Isaïe 39

###### 1
En ce temps-là, Mérodak-Baladan, fils de Baladan, roi de Babylone, envoya des lettres et un présent à Ézéchias, car il avait appris sa maladie et son rétablissement. 
###### 2
Ézéchias s'en réjouit et il montra aux messagers sa chambre du trésor, l'argent, l'or, les aromates, l'huile précieuse ainsi que son arsenal et tout ce qui se trouvait dans ses magasins. Il n'y eut rien qu'Ézéchias ne leur montrât dans son palais et dans tout son domaine. 
###### 3
Alors le prophète Isaïe vint trouver le roi Ézéchias et lui demanda : " Qu'ont dit ces gens-là, et d'où sont-ils venus chez toi ? " Ézéchias répondit : " Ils sont venus d'un pays lointain, de Babylone. " 
###### 4
Isaïe reprit : " Qu'ont-ils vu dans ton palais ? " Ézéchias répondit : " Ils ont vu tout ce qu'il y a dans mon palais : il n'y a dans mes magasins rien que je ne leur aie montré. " 
###### 5
Alors Isaïe dit à Ézéchias : " Écoute la parole de Yahvé Sabaot! 
###### 6
Des jours viennent où tout ce qui est dans ton palais, tout ce qu'ont amassé tes pères jusqu'à ce jour, sera emporté à Babylone. Rien ne sera laissé, dit Yahvé. 
###### 7
Parmi les fils issus de toi, ceux que tu as engendrés, on en prendra pour être eunuques dans le palais du roi de Babylone. " 
###### 8
Ézéchias dit à Isaïe : " C'est une parole favorable de Yahvé que tu annonces. " Il pensait en effet : " Il y aura paix et sûreté ma vie durant. " 
