---
aliases : 
- Isaïe 18
- Isaïe 18
- Is 18
- Isaiah 18
tags : 
- Bible/Is/18
- français
cssclass : français
---

# Isaïe 18

###### 1
Malheur! pays du grillon ailé, au-delà des fleuves de Kush, 
###### 2
toi qui envoies par mer des messagers, dans des nacelles de jonc, sur les eaux. Allez, messagers rapides, vers une nation élancée et bronzée, vers un peuple redouté ici comme au loin, une nation puissante et dominatrice, au pays sillonné de fleuves. 
###### 3
Vous tous, habitants du monde, vous qui peuplez la terre, quand on lèvera un signal sur les montagnes, vous verrez, quand on sonnera du cor, vous entendrez. 
###### 4
Car ainsi m'a parlé Yahvé : Je veux rester ici impassible et regarder, comme la chaleur brûlante en pleine lumière, comme un nuage de rosée au plus chaud de la moisson. 
###### 5
Car avant la moisson, quand prend fin la floraison, quand la fleur devient grappe mûrissante, on taille les pampres à la serpe, on ôte les sarments, on élague. 
###### 6
Tout est abandonné aux rapaces des montagnes et aux bêtes du pays; les rapaces s'y vautreront pendant l'été, toutes les bêtes du pays pendant l'automne. 
###### 7
Alors, on apportera une offrande à Yahvé Sabaot de la part d'un peuple élancé et bronzé, de la part d'un peuple redouté ici comme au loin, d'une nation puissante et dominatrice, d'un pays sillonné de fleuves; on l'apportera au lieu où réside le nom de Yahvé, au mont Sion. 
