---
aliases : 
- Isaïe 19
- Isaïe 19
- Is 19
- Isaiah 19
tags : 
- Bible/Is/19
- français
cssclass : français
---

# Isaïe 19

###### 1
Oracle sur l'Égypte. Voici que Yahvé, monté sur un nuage léger, vient en Égypte. Les faux dieux d'Égypte chancellent devant lui et le cœur de l'Égypte défaille en elle. 
###### 2
J'exciterai l'Égypte contre l'Égypte, ils se battront, chacun contre son frère, chacun contre son prochain, ville contre ville, royaume contre royaume. 
###### 3
L'esprit de l'Égypte s'évanouira en elle, et je confondrai son conseil. On consultera les faux dieux et les enchanteurs, les spectres et les devins. 
###### 4
Je livrerai l'Égypte aux mains d'un maître impitoyable, un roi cruel les dominera. Oracle du Seigneur Yahvé Sabaot. 
###### 5
Les eaux disparaîtront de la mer, le fleuve tarira et se desséchera; 
###### 6
les rivières deviendront infectes, les fleuves d'Égypte baisseront et tariront, le roseau et le jonc noirciront. 
###### 7
Les herbes du Nil sur les bords du Nil, toute la verdure du Nil, sera desséchée, dispersée, anéantie. 
###### 8
Les pêcheurs gémiront, ce sera le deuil pour tous ceux qui lancent l'hameçon dans le Nil, ceux qui jettent le filet sur les eaux seront désolés. 
###### 9
Ils seront déçus, ceux qui travaillent le lin cardé et ceux qui tissent des étoffes blanches; 
###### 10
ses tisserands seront consternés, tous les salariés seront attristés. 
###### 11
Oui, insensés sont les princes de Çoân, les plus sages conseillers du pharaon forment un conseil stupide. Comment osez-vous dire à Pharaon : " Je suis fils des sages, fils des rois de jadis ? " 
###### 12
Où sont-ils donc, tes sages ? Qu'ils t'annoncent et que l'on sache ce qu'a décidé Yahvé Sabaot contre l'Égypte! 
###### 13
Ils déraisonnent, les princes de Çoân, ils s'abusent, les princes de Noph, et l'élite de ses nomes a fait divaguer l'Égypte. 
###### 14
Yahvé a répandu au milieu d'eux un esprit de vertige; ils ont fait divaguer l'Égypte dans toutes ses entreprises, comme divague un ivrogne en vomissant. 
###### 15
On ne fait plus rien pour l'Égypte de ce que faisaient tête et queue, palme et jonc. 
###### 16
Ce jour-là, l'Égypte sera comme les femmes, tremblante et terrorisée devant la menace de la main de Yahvé Sabaot, lorsqu'il la lèvera contre elle. 
###### 17
Le territoire de Juda deviendra la honte de l'Égypte : chaque fois qu'on le lui rappellera, elle sera terrorisée à cause du dessein que Yahvé Sabaot a formé contre elle. 
###### 18
Ce jour-là, il y aura cinq villes au pays d'Égypte qui parleront la langue de Canaan et prêteront serment à Yahvé Sabaot; l'une d'elles sera dite " ville du soleil ". 
###### 19
Ce jour-là, il y aura un autel dédié à Yahvé au milieu du pays d'Égypte, et près de la frontière une stèle dédiée à Yahvé. 
###### 20
Ce sera un signe et un témoin de Yahvé Sabaot au pays d'Égypte. Quand ils crieront vers Yahvé par crainte des oppresseurs, il leur enverra un sauveur et un défenseur qui les délivrera. 
###### 21
Yahvé se fera connaître des Égyptiens, et les Égyptiens connaîtront Yahvé, en ce jour-là. Ils offriront sacrifices et oblations, ils feront des vœux à Yahvé et les accompliront. 
###### 22
Et si Yahvé frappe les Égyptiens, il frappera et guérira, ils se convertiront à Yahvé qui accueillera leurs demandes et les guérira. 
###### 23
Ce jour-là, il y aura un chemin allant d'Égypte à Assur. Assur viendra en Égypte et l'Égypte en Assur. L'Égypte servira avec Assur. 
###### 24
Ce jour-là, Israël viendra en troisième avec l'Égypte et Assur, bénédiction au milieu de la terre, 
###### 25
bénédiction que prononcera Yahvé Sabaot : " Béni mon peuple l'Égypte, et Assur l'œuvre de mes mains, et Israël mon héritage. " 
