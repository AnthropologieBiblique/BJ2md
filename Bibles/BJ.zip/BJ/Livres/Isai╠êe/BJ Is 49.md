---
aliases : 
- Isaïe 49
- Isaïe 49
- Is 49
- Isaiah 49
tags : 
- Bible/Is/49
- français
cssclass : français
---

# Isaïe 49

###### 1
Iles, écoutez-moi, soyez attentifs, peuples lointains! Yahvé m'a appelé dès le sein maternel, dès les entrailles de ma mère il a prononcé mon nom. 
###### 2
Il a fait de ma bouche une épée tranchante, il m'a abrité à l'ombre de sa main; il a fait de moi une flèche acérée, il m'a caché dans son carquois. 
###### 3
Il m'a dit : " Tu es mon serviteur, Israël, toi en qui je me glorifierai. " 
###### 4
Et moi, j'ai dit : " C'est en vain que j'ai peiné, pour rien, pour du vent j'ai usé mes forces. " Et pourtant mon droit était avec Yahvé et mon salaire avec mon Dieu. 
###### 5
Et maintenant Yahvé a parlé, lui qui m'a modelé dès le sein de ma mère pour être son serviteur, pour ramener vers lui Jacob, et qu'Israël lui soit réuni; - je serai glorifié aux yeux de Yahvé, et mon Dieu a été ma force; - 
###### 6
il a dit : " C'est trop peu que tu sois pour moi un serviteur pour relever les tribus de Jacob et ramener les survivants d'Israël. Je fais de toi la lumière des nations pour que mon salut atteigne aux extrémités de la terre. " 
###### 7
Ainsi parle Yahvé, le rédempteur, le Saint d'Israël, à celui dont l'âme est méprisée, honnie de la nation, à l'esclave des tyrans : des rois verront et se lèveront, des princes verront et se prosterneront, à cause de Yahvé qui est fidèle, du Saint d'Israël qui t'a élu. 
###### 8
Ainsi parle Yahvé : Au temps de la faveur je t'ai exaucé, au jour du salut je t'ai secouru. Je t'ai façonné et j'ai fait de toi l'alliance d'un peuple pour relever le pays, pour restituer les héritages dévastés, 
###### 9
pour dire aux captifs : " Sortez ", à ceux qui sont dans les ténèbres : " Montrez-vous. " Ils paîtront le long des chemins, sur tous les monts chauves ils auront un pâturage. 
###### 10
Ils n'auront plus faim ni soif, ils ne souffriront pas du vent brûlant ni du soleil, car celui qui les prend en pitié les conduira, il les mènera vers les eaux jaillissantes. 
###### 11
De toutes mes montagnes je ferai un chemin et mes routes seront relevées. 
###### 12
Les voici, ils viennent de loin, ceux-ci du Nord et de l'Occident, et ceux-là du pays de Sînîm. 
###### 13
Cieux, criez de joie, terre exulte, que les montagnes poussent des cris, car Yahvé a consolé son peuple, il prend en pitié ses affligés. 
###### 14
Sion avait dit : " Yahvé m'a abandonnée; le Seigneur m'a oubliée. " 
###### 15
Une femme oublie-t-elle son petit enfant, est-elle sans pitié pour le fils de ses entrailles ? Même si les femmes oubliaient, moi, je ne t'oublierai pas. 
###### 16
Vois, je t'ai gravée sur les paumes de mes mains, tes remparts sont devant moi sans cesse. 
###### 17
Tes bâtisseurs se hâtent, ceux qui te détruisent et te ravagent vont s'en aller. 
###### 18
Lève les yeux aux alentours et regarde : tous sont rassemblés, ils viennent à toi. Par ma vie, oracle de Yahvé, ils sont tous comme une parure dont tu te couvriras, comme fait une fiancée, tu te les attacheras. 
###### 19
Car tes ruines, tes décombres, ton pays désolé sont désormais trop étroits pour tes habitants, et ceux qui te dévoraient s'éloigneront. 
###### 20
Ils diront de nouveau à tes oreilles, les fils dont tu étais privée : " L'endroit est trop étroit pour moi, fais-moi une place pour que je m'installe. " 
###### 21
Et tu diras dans ton cœur : " Qui m'a enfanté ceux-ci ? J'étais privée d'enfants et stérile, exilée et rejetée, et ceux-ci, qui les a élevés ? Pendant que moi j'étais laissée seule, ceux-ci, où étaient-ils ? " 
###### 22
Ainsi parle le Seigneur Yahvé : Voici que je lève la main vers les nations, que je dresse un signal pour les peuples : ils t'amèneront tes fils dans leurs bras, et tes filles seront portées sur l'épaule. 
###### 23
Des rois seront tes pères adoptifs, et leurs princesses, tes nourrices. Face contre terre, ils se prosterneront devant toi, ils lècheront la poussière de tes pieds. Et tu sauras que je suis Yahvé, ceux qui espèrent en moi ne seront pas déçus. 
###### 24
Au guerrier arrache-t-on sa prise ? Le prisonnier d'un tyran sera-t-il libéré ? 
###### 25
Mais ainsi parle Yahvé : Eh bien, le prisonnier du guerrier lui sera arraché, et la prise du tyran sera libérée. Je vais moi-même chercher querelle à qui te cherche querelle, tes enfants, c'est moi qui les sauverai. 
###### 26
A tes oppresseurs je ferai manger leur propre chair, comme de vin nouveau ils s'enivreront de leur sang. Et toute chair saura que moi, Yahvé, je suis ton sauveur, que ton rédempteur, c'est le Puissant de Jacob. 
