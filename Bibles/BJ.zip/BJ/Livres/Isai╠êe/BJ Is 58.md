---
aliases : 
- Isaïe 58
- Isaïe 58
- Is 58
- Isaiah 58
tags : 
- Bible/Is/58
- français
cssclass : français
---

# Isaïe 58

###### 1
Crie à pleine gorge, ne te retiens pas, comme le cor, élève la voix, annonce à mon peuple ses crimes, à la maison de Jacob ses péchés. 
###### 2
C'est moi qu'ils recherchent jour après jour, ils désirent connaître mes voies, comme une nation qui a pratiqué la justice, qui n'a pas négligé le droit de son Dieu. Ils s'informent près de moi des lois justes, ils désirent être proches de Dieu. 
###### 3
" Pourquoi avons-nous jeûné sans que tu le voies, nous sommes-nous mortifiés sans que tu le saches ? " C'est qu'au jour où vous jeûnez, vous traitez des affaires, et vous opprimez tous vos ouvriers. 
###### 4
C'est que vous jeûnez pour vous livrer aux querelles et aux disputes, pour frapper du poing méchamment. Vous ne jeûnerez pas comme aujourd'hui, si vous voulez faire entendre votre voix là-haut! 
###### 5
Est-ce là le jeûne qui me plaît, le jour où l'homme se mortifie ? Courber la tête comme un jonc, se faire une couche de sac et de cendre, est-ce là ce que tu appelles un jeûne, un jour agréable à Yahvé ? 
###### 6
N'est-ce pas plutôt ceci, le jeûne que je préfère : défaire les chaînes injustes, délier les liens du joug; renvoyer libres les opprimés, et briser tous les jougs ? 
###### 7
N'est-ce pas partager ton pain avec l'affamé, héberger chez toi les pauvres sans abri, si tu vois un homme nu, le vêtir, ne pas te dérober devant celui qui est ta propre chair ? 
###### 8
Alors ta lumière éclatera comme l'aurore, ta blessure se guérira rapidement, ta justice marchera devant toi et la gloire de Yahvé te suivra. 
###### 9
Alors tu crieras et Yahvé répondra, tu appelleras, il dira : Me voici! Si tu bannis de chez toi le joug, le geste menaçant et les paroles méchantes, 
###### 10
si tu te prives pour l'affamé et si tu rassasies l'opprimé, ta lumière se lèvera dans les ténèbres, et l'obscurité sera pour toi comme le milieu du jour. 
###### 11
Yahvé sans cesse te conduira, il te rassasiera dans les lieux arides, il donnera la vigueur à tes os, et tu seras comme un jardin arrosé, comme une source jaillissante dont les eaux ne tarissent pas. 
###### 12
On reconstruira, chez toi, les ruines antiques, tu relèveras les fondations des générations passées, on t'appellera Réparateur de brèches, Restaurateur des chemins, pour qu'on puisse habiter. 
###### 13
Et si tu t'abstiens de violer le sabbat, de vaquer à tes affaires en mon jour saint, si tu appelles le sabbat " délices " et " vénérable " le jour saint de Yahvé, si tu l'honores en t'abstenant de voyager, de traiter tes affaires et de tenir des discours, 
###### 14
alors tu trouveras tes délices en Yahvé, je te conduirai en triomphe sur les hauteurs du pays; je te nourrirai de l'héritage de ton père Jacob, car la bouche de Yahvé a parlé. 
