---
aliases : 
- Isaïe 7
- Isaïe 7
- Is 7
- Isaiah 7
tags : 
- Bible/Is/7
- français
cssclass : français
---

# Isaïe 7

###### 1
Au temps d'Achaz, fils de Yotam, fils d'Ozias, roi de Juda, Raçôn, roi d'Aram, monta avec Péqah, fils de Remalyahu, roi d'Israël, vers Jérusalem pour porter l'attaque contre elle, mais il ne put l'attaquer. 
###### 2
On annonça à la maison de David : " Aram a fait halte sur le territoire d'Éphraïm. " Alors son cœur et le cœur de son peuple se mirent à chanceler comme chancellent les arbres de la forêt sous le vent. 
###### 3
Et Yahvé dit à Isaïe : Sors au-devant d'Achaz, toi et Shéar-Yashub ton fils, vers l'extrémité du canal de la piscine supérieure, vers le chemin du champ du Foulon. 
###### 4
Tu lui diras : Prends garde et calme-toi. Ne crains pas et que ton cœur ne défaille pas devant ces deux bouts de tisons fumants à cause de l'ardente colère de Raçôn, d'Aram et du fils de Remalyahu, 
###### 5
parce qu'Aram, Éphraïm et le fils de Remalyahu ont tramé contre toi un mauvais coup en disant : 
###### 6
" Montons contre Juda, détruisons-le, brisons-le pour le ramener vers nous, et nous y établirons comme roi le fils de Tabeel. " 
###### 7
Ainsi parle le Seigneur Yahvé : Cela ne tiendra pas, cela ne sera pas; 
###### 8
car la tête d'Aram c'est Damas, et la tête de Damas c'est Raçôn; encore soixante-cinq ans, et Éphraïm cessera d'être un peuple. 
###### 9
La tête d'Éphraïm c'est Samarie, et la tête de Samarie c'est le fils de Remalyahu. Si vous ne croyez pas, vous ne vous maintiendrez pas. 
###### 10
Yahvé parla encore à Achaz en disant : 
###### 11
Demande un signe à Yahvé ton Dieu, au fond, dans le shéol, ou vers les hauteurs, au-dessus. 
###### 12
Et Achaz dit : Je ne demanderai rien, je ne tenterai pas Yahvé. 
###### 13
Il dit alors : Écoutez donc, maison de David! est-ce trop peu pour vous de lasser les hommes, que vous lassiez aussi mon Dieu ? 
###### 14
C'est pourquoi le Seigneur lui-même vous donnera un signe : Voici, la jeune femme est enceinte, elle va enfanter un fils et elle lui donnera le nom d'Emmanuel. 
###### 15
Il mangera du lait caillé et du miel jusqu'à ce qu'il sache rejeter le mal et choisir le bien. 
###### 16
Car avant que l'enfant sache rejeter le mal et choisir le bien, elle sera abandonnée, la terre dont les deux rois te jettent dans l'épouvante. 
###### 17
Yahvé fera venir sur toi, sur ton peuple et sur la maison de ton père des jours tels qu'il n'en est pas venu depuis la séparation d'Éphraïm et de Juda le roi d'Assur . 
###### 18
Il arrivera, en ce jour-là, que Yahvé sifflera les mouches qui sont à l'extrémité des fleuves d'Égypte et les abeilles qui sont au pays d'Assur. 
###### 19
Elles viendront et se poseront toutes dans les torrents des ravins et dans les fentes des rochers, sur tous les buissons et à tous les points d'eau. 
###### 20
En ce jour-là, le Seigneur rasera avec un rasoir loué au-delà du fleuve avec le roi d'Assur la tête et le poil des jambes, et même la barbe, il l'enlèvera. 
###### 21
Il arrivera, en ce jour-là, que chacun élèvera une génisse et deux têtes de petit bétail. 
###### 22
Et il arrivera qu'en raison de l'abondante production du lait, il mangera du lait caillé tout survivant au milieu du pays mangera du lait caillé et du miel. 
###### 23
Il arrivera, en ce jour-là, que tout lieu où il y a mille pieds de vigne valant mille pièces d'argent deviendra ronces et épines. 
###### 24
Avec flèches et arc on y pénétrera, car tout le pays sera ronces et épines. 
###### 25
Sur toutes les montagnes qui sont cultivées à la houe, tu n'iras plus par crainte des ronces et des épines, et ce sera pacage de bœufs et terre piétinée par les moutons. 
