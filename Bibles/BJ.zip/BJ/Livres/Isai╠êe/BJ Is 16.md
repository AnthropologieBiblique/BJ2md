---
aliases : 
- Isaïe 16
- Isaïe 16
- Is 16
- Isaiah 16
tags : 
- Bible/Is/16
- français
cssclass : français
---

# Isaïe 16

###### 1
Envoyez l'agneau du maître du pays, de Séla, située vers le désert, à la montagne de la fille de Sion. 
###### 2
Elles seront semblables à l'oiseau qui s'enfuit, à une nichée dispersée, les filles de Moab, aux gués de l'Arnon. 
###### 3
" Tenez un conseil; prenez une décision. En plein midi, étends ton ombre comme celle de la nuit, cache les dispersés, ne trahis pas le fugitif; 
###### 4
qu'ils demeurent chez toi, les dispersés de Moab, sois pour eux un asile contre le dévastateur. Quand l'oppression aura cessé, que la dévastation aura pris fin, que seront partis ceux qui foulent le pays, 
###### 5
le trône sera affermi dans la piété, et sur ce trône, dans la fidélité, sous la tente de David, siégera un juge, soucieux du droit et zélé pour la justice. " 
###### 6
Nous avons entendu parler de l'orgueil de Moab, le très orgueilleux, de son arrogance, de son orgueil et de sa rage, de ses bavardages ineptes. 
###### 7
C'est pourquoi Moab se lamente sur Moab, tout entier il se lamente. Au sujet des gâteaux de raisin de Qir-Harésèt, vous gémissez, tout consternés. 
###### 8
Car les vignobles de Heshbôn dépérissent, la vigne de Sibma, dont les raisins vermeils terrassaient les maîtres des nations. Elle atteignait jusqu'à Yazèr et s'infiltrait au désert, ses rejetons se multipliaient, ils franchissaient la mer. 
###### 9
Aussi je pleure, comme pleure Yazèr, la vigne de Sibma; je t'arrose de mes larmes, Heshbôn et toi, Éléalé, parce que sur ta récolte et sur ta moisson le cri s'est éteint. 
###### 10
La joie et l'allégresse ont disparu des vergers, dans les vignes, plus de liesse ni de cri joyeux; le fouleur ne foule plus le vin dans les pressoirs, le cri a cessé. 
###### 11
C'est pourquoi mes entrailles, pour Moab, frémissent comme une cithare, et mon cœur pour Qir-Hérès. 
###### 12
On verra Moab se fatiguer sur le haut lieu et entrer dans son sanctuaire pour supplier, mais il ne pourra rien. 
###### 13
Telle est la parole qu'a adressée Yahvé à Moab jadis. 
###### 14
Et maintenant Yahvé a parlé en ces termes : dans trois ans, comme des années de mercenaire, la gloire de Moab sera humiliée, malgré sa grande multitude. Elle sera réduite à rien, un reste insignifiant. 
