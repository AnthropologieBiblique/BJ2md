---
aliases : 
- Isaïe 43
- Isaïe 43
- Is 43
- Isaiah 43
tags : 
- Bible/Is/43
- français
cssclass : français
---

# Isaïe 43

###### 1
Et maintenant, ainsi parle Yahvé, celui qui t'a créé, Jacob, qui t'a modelé, Israël. Ne crains pas, car je t'ai racheté, je t'ai appelé par ton nom : tu es à moi. 
###### 2
Si tu traverses les eaux je serai avec toi, et les rivières, elles ne te submergeront pas. Si tu passes par le feu, tu ne souffriras pas, et la flamme ne te brûlera pas. 
###### 3
Car je suis Yahvé, ton Dieu, le Saint d'Israël, ton sauveur. Pour ta rançon, j'ai donné l'Égypte, Kush et Séba à ta place. 
###### 4
Car tu comptes beaucoup à mes yeux, tu as du prix et je t'aime. Aussi je livre des hommes à ta place et des peuples en rançon de ta vie. 
###### 5
Ne crains pas, car je suis avec toi, du levant je vais faire revenir ta race, et du couchant je te rassemblerai. 
###### 6
Je dirai au Nord : Donne! et au Midi : Ne retiens pas! Ramène mes fils de loin et mes filles du bout de la terre, 
###### 7
quiconque se réclame de mon nom, ceux que j'ai créés pour ma gloire, que j'ai formés et que j'ai faits. 
###### 8
Fais sortir un peuple aveugle qui a des yeux, et des sourds qui ont des oreilles. 
###### 9
Que toutes les nations se rassemblent, que tous les peuples s'unissent! Qui parmi eux a proclamé cela et nous a fait connaître les choses anciennes ? Qu'ils produisent leurs témoins et qu'ils se justifient, qu'on les entende et qu'on dise : C'est la vérité! 
###### 10
C'est vous qui êtes mes témoins, oracle de Yahvé, vous êtes le serviteur que je me suis choisi, afin que vous le sachiez, que vous croyiez en moi et que vous compreniez que c'est moi : avant moi aucun dieu n'a été formé et après moi il n'y en aura pas. 
###### 11
Moi, c'est moi Yahvé, et en dehors de moi il n'y a pas de sauveur. 
###### 12
C'est moi qui ai révélé, sauvé et fait entendre, ce n'est pas un étranger qui est parmi vous, vous, vous êtes mes témoins, oracle de Yahvé, et moi, je suis Dieu, 
###### 13
de toute éternité je le suis; nul ne peut délivrer de ma main, si j'agis, qui pourrait me faire renoncer ? 
###### 14
Ainsi parle Yahvé, votre rédempteur, le Saint d'Israël. A cause de vous, j'ai envoyé quelqu'un à Babylone, je vais faire tomber tous les verrous, et les Chaldéens changeront leurs cris en lamentations. 
###### 15
Je suis Yahvé, votre Saint, le créateur d'Israël, votre roi. 
###### 16
Ainsi parle Yahvé, celui qui traça dans la mer un chemin, un sentier dans les eaux déchaînées, 
###### 17
qui fit sortir char et cheval, armée et troupe d'élite ensemble; ils se sont couchés pour ne plus se relever, ils se sont éteints, comme une mèche ils se sont consumés. 
###### 18
Ne vous souvenez plus des événements anciens, ne pensez plus aux choses passées, 
###### 19
voici que je vais faire une chose nouvelle, déjà elle pointe, ne la reconnaissez-vous pas ? Oui, je vais mettre dans le désert un chemin, et dans la steppe, des fleuves. 
###### 20
Les bêtes sauvages m'honoreront, les chacals et les autruches, car j'ai mis dans le désert de l'eau et des fleuves dans la steppe, pour abreuver mon peuple, mon élu. 
###### 21
Le peuple que je me suis formé publiera mes louanges. 
###### 22
Tu ne m'as pas invoqué, Jacob, oui, tu t'es lassé de moi, Israël. 
###### 23
Tu ne m'as pas apporté d'agneaux en holocauste, et tu ne m'as pas honoré par tes sacrifices. Je ne t'ai pas asservi à des oblations, je ne t'ai pas lassé en exigeant de l'encens. 
###### 24
Pour moi, tu n'as pas acquis de roseau à prix d'argent, et tu ne m'as pas rassasié de la graisse de tes sacrifices. Mais par tes péchés, tu as fait de moi un esclave, tu m'as lassé par tes fautes. 
###### 25
C'est moi, moi, qui efface tes crimes par égard pour moi, et je ne me souviendrai plus de tes fautes. 
###### 26
Fais-moi me souvenir, et nous jugerons ensemble, fais toi-même le compte afin d'être justifié. 
###### 27
Ton premier père a péché, tes interprètes se sont révoltés contre moi. 
###### 28
Alors j'ai destitué les chefs du sanctuaire, j'ai livré Jacob à l'anathème et Israël aux outrages. 
