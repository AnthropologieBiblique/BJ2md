---
aliases : 
- Isaïe 2
- Isaïe 2
- Is 2
- Isaiah 2
tags : 
- Bible/Is/2
- français
cssclass : français
---

# Isaïe 2

###### 1
Vision d'Isaïe, fils d'Amoç, au sujet de Juda et de Jérusalem. 
###### 2
Il arrivera dans la suite des temps que la montagne de la maison de Yahvé sera établie en tête des montagnes et s'élèvera au-dessus des collines. Alors toutes les nations afflueront vers elle, 
###### 3
alors viendront des peuples nombreux qui diront : " Venez, montons à la montagne de Yahvé, à la maison du Dieu de Jacob, qu'il nous enseigne ses voies et que nous suivions ses sentiers. " Car de Sion vient la Loi et de Jérusalem la parole de Yahvé. 
###### 4
Il jugera entre les nations, il sera l'arbitre de peuples nombreux. Ils briseront leurs épées pour en faire des socs et leurs lances pour en faire des serpes. On ne lèvera plus l'épée nation contre nation, on n'apprendra plus à faire la guerre. 
###### 5
Maison de Jacob, allons, marchons à la lumière de Yahvé. L'éclat de la majesté de Yahvé. 
###### 6
Oui, tu as rejeté ton peuple, la maison de Jacob, car il regorge depuis longtemps de magiciens, comme les Philistins, il surabonde d'enfants d'étrangers. 
###### 7
Le pays s'est rempli d'argent et d'or, ses trésors sont sans limites; le pays s'est rempli de chevaux, ses chars sont sans nombre; 
###### 8
le pays s'est rempli de faux dieux, eux se prosternent devant l'œuvre de leurs mains, devant ce qu'ont fabriqué leurs doigts. 
###### 9
Le mortel s'est humilié, l'homme s'est abaissé : ne les relève pas! 
###### 10
Va dans le rocher, terre-toi dans la poussière devant la Terreur de Yahvé, devant l'éclat de sa majesté, quand il se lèvera pour faire trembler la terre. 
###### 11
L'orgueil humain baissera les yeux, l'arrogance des hommes sera humiliée, Yahvé sera exalté, lui seul, en ce jour-là. 
###### 12
Oui, ce sera un jour de Yahvé Sabaot sur tout ce qui est orgueilleux et hautain, sur tout ce qui est élevé, pour qu'il soit abaissé; 
###### 13
sur tous les cèdres du Liban, hautains et élevés, et sur tous les chênes de Basân; 
###### 14
sur toutes les montagnes hautaines et sur toutes les collines élevées; 
###### 15
sur toute tour altière et sur tout rempart escarpé; 
###### 16
sur tous les vaisseaux de Tarsis et sur tout ce qui paraît précieux. 
###### 17
L'orgueil humain sera humilié, l'arrogance de l'homme sera abaissée, et Yahvé sera exalté, lui seul, en ce jour-là. 
###### 18
Les faux dieux, en masse, disparaîtront. 
###### 19
Pour eux, ils iront dans les cavernes des rochers et dans les fissures du sol, devant la Terreur de Yahvé, devant l'éclat de sa majesté, quand il se lèvera pour faire trembler la terre. 
###### 20
En ce jour-là, l'homme jettera aux taupes et aux chauves-souris ses faux dieux d'argent et ses faux dieux d'or, ceux qu'on lui a fabriqués pour qu'il les adore, 
###### 21
il s'en ira dans les crevasses des rochers et dans les fentes des falaises, devant la Terreur de Yahvé, devant l'éclat de sa majesté, quand il se lèvera pour faire trembler la terre. 
###### 22
Tenez-vous à l'écart de l'homme, qui n'a qu'un souffle dans les narines! A combien l'estimer ? 
