---
aliases : 
- 3 Jean 1
- 3 Jean 1
- 3 Jn 1
- 3 John 1
tags : 
- Bible/3Jn/1
- français
cssclass : français
---

# 3 Jean 1

###### 
Moi, l'Ancien, au très cher Gaïus, que j'aime en vérité. 
###### 
Très cher, je souhaite que tu te portes bien sous tous les rapports et que ton corps soit en aussi bonne santé que ton âme. 
###### 
Je me suis beaucoup réjoui des frères qui sont venus et qui ont rendu témoignage à ta vérité, je veux dire à la façon dont tu vis dans la vérité. 
###### 
Apprendre que mes enfants vivent dans la vérité, rien ne m'est un plus grand sujet de joie. 
###### 
Très cher, tu agis fidèlement en te dépensant pour les frères, bien que ce soient des étrangers. 
###### 
Ils ont rendu témoignage à ta charité, devant l'Église. Tu feras une bonne action en pourvoyant à leur voyage, d'une manière digne de Dieu. 
###### 
C'est pour le Nom qu'ils se sont mis en route, sans rien recevoir des païens. 
###### 
Nous devons accueillir de tels hommes, afin de collaborer à leurs travaux pour la Vérité. 
###### 
J'ai écrit un mot à l'Église. Mais Diotréphès, qui est avide d'y occuper la première place, ne nous reçoit pas. 
###### 
C'est pourquoi je ne manquerai pas, si je viens, de rappeler sa conduite. Il se répand en mauvais propos contre nous. Non satisfait de cela, il refuse lui-même de recevoir les frères, et ceux qui voudraient les recevoir, il les en empêche et les expulse de l'Église. 
###### 
Très cher, imite non le mal mais le bien. Qui fait le bien est de Dieu. Qui fait le mal n'a pas vu Dieu. . 
###### 
Quant à Démétrius, tout le monde lui rend témoignage, y compris la Vérité elle-même. Nous aussi, nous lui rendons témoignage, et tu sais que notre témoignage est vrai. 
###### 
J'aurais beaucoup de choses à te dire. Mais je ne veux pas le faire avec de l'encre et un calame. 
###### 
J'espère en effet te voir sous peu, et nous nous entretiendrons de vive voix. 
###### 
Que la paix soit avec toi ! Tes amis te saluent. Salue les nôtres, chacun par son nom. 
