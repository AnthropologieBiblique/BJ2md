---
aliases : 
- Philémon
- Philémon
- Phm
- Philemon
tags : 
- Bible/Phm
- français
cssclass : français
---

# Philémon

[[BJ Phm 1|Philémon 1]]
