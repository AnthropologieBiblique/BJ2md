---
aliases : 
- Michée 5
- Michée 5
- Mi 5
- Micah 5
tags : 
- Bible/Mi/5
- français
cssclass : français
---

# Michée 5

###### 1
Et toi Bethléem , Éphrata, le moindre des clans de Juda, c'est de toi que me naîtra celui qui doit régner sur Israël; ses origines remontent au temps jadis, aux jours antiques. 
###### 2
C'est pourquoi il les abandonnera jusqu'au temps où aura enfanté celle qui doit enfanter. Alors le reste de ses frères reviendra aux enfants d'Israël. 
###### 3
Il se dressera, il fera paître son troupeau par la puissance de Yahvé, par la majesté du nom de son Dieu. Ils s'établiront, car alors il sera grand jusqu'aux extrémités du pays. 
###### 4
Celui-ci sera paix! Assur, s'il envahit notre pays, s'il foule notre sol, nous dresserons contre lui sept pasteurs, huit chefs d'hommes; 
###### 5
ils feront paître le pays d'Assur avec l'épée, le pays de Nemrod avec le glaive. Il nous délivrera d'Assur s'il envahit notre pays, s'il foule notre territoire. 
###### 6
Alors, le reste de Jacob sera, au milieu des peuples nombreux, comme une rosée venant de Yahvé, comme des gouttes de pluie sur l'herbe, qui n'espère point en l'homme ni n'attend rien des humains. 
###### 7
Alors, le reste de Jacob sera, au milieu des peuples nombreux, comme un lion parmi les bêtes de la forêt, comme un lionceau parmi les troupeaux de moutons : chaque fois qu'il passe, il piétine, il déchire, et personne ne lui arrache sa proie. 
###### 8
Que ta main se lève sur tes adversaires et tous tes ennemis seront retranchés! 
###### 9
Voici ce qui arrivera ce jour-là, oracle de Yahvé! Je retrancherai de ton sein tes chevaux, je ferai disparaître tes chars; 
###### 10
je retrancherai les cités de ton pays, je détruirai toutes tes villes fortes; 
###### 11
je retrancherai de ta main les sortilèges, et tu n'auras plus de devins; 
###### 12
je retrancherai de ton sein tes statues et tes stèles et tu ne pourras plus te prosterner désormais devant l'ouvrage de tes mains, 
###### 13
j'arracherai de ton sein tes pieux sacrés, et j'anéantirai tes cités. 
###### 14
Avec colère, avec fureur, je tirerai vengeance des nations qui n'ont pas obéi. 
