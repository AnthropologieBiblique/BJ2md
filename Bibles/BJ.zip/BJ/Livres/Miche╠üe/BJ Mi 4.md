---
aliases : 
- Michée 4
- Michée 4
- Mi 4
- Micah 4
tags : 
- Bible/Mi/4
- français
cssclass : français
---

# Michée 4

###### 1
Or il adviendra dans la suite des temps que la montagne du Temple de Yahvé sera établie en tête des montagnes et s'élèvera au-dessus des collines. Alors des peuples afflueront vers elle, 
###### 2
alors viendront des nations nombreuses qui diront : " Venez, montons à la montagne de Yahvé, au Temple du Dieu de Jacob, qu'il nous enseigne ses voies et que nous suivions ses sentiers. Car de Sion vient la Loi et de Jérusalem la parole de Yahvé. " 
###### 3
Il jugera entre des peuples nombreux et sera l'arbitre de nations puissantes. Ils briseront leurs épées pour en faire des socs et leur lances pour en faire des serpes. On ne lèvera plus l'épée nation contre nation, on n'apprendra plus à faire la guerre. 
###### 4
Mais chacun restera assis sous sa vigne et sous son figuier, sans personne pour l'inquiéter. La bouche de Yahvé Sabaot a parlé. 
###### 5
Car tous les peuples marchent chacun au nom de son dieu; mais nous, nous marcherons au nom de Yahvé notre Dieu, pour toujours et à jamais. 
###### 6
En ce jour-là - oracle de Yahvé - je veux rassembler les éclopées, rallier les égarées et celles que j'ai maltraitées. 
###### 7
Des éclopées je ferai un reste, des éloignées une nation puissante. Alors Yahvé régnera sur eux à la montagne de Sion, dès maintenant et à jamais. 
###### 8
Et toi, Tour du Troupeau, Ophel de la fille de Sion, à toi va revenir la souveraineté d'antan, la royauté de la fille de Jérusalem. 
###### 9
Maintenant pourquoi pousses-tu des clameurs ? N'y a-t-il pas un roi chez toi ? Tes conseillers sont-ils perdus, que la douleur t'ait saisie comme la femme qui enfante ? 
###### 10
Tords-toi de douleur et crie, fille de Sion, comme la femme qui enfante, car tu vas maintenant sortir de la cité et demeurer en rase campagne. Tu iras jusqu'à Babel, c'est là que tu seras délivrée; c'est là que Yahvé te rachètera de la main de tes ennemis. 
###### 11
Maintenant, des nations nombreuses se sont assemblées contre toi. Elles disent : " Qu'on la profane et que nos yeux se repaissent de Sion! " 
###### 12
C'est qu'elles ne connaissent pas les plans de Yahvé et qu'elles n'ont pas compris son dessein : il les a rassemblées comme les gerbes sur l'aire. 
###### 13
Debout! foule le grain, fille de Sion! car je rendrai tes cornes de fer, de bronze tes sabots, et tu broieras des peuples nombreux. Tu voueras à Yahvé leurs rapines, et leurs richesses au Seigneur de toute la terre. 
###### 14
Maintenant, fortifie-toi, Forteresse! Ils ont dressé un retranchement contre nous; à coups de verge ils frappent à la joue le juge d'Israël. 
