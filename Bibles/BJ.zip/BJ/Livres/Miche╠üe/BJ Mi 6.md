---
aliases : 
- Michée 6
- Michée 6
- Mi 6
- Micah 6
tags : 
- Bible/Mi/6
- français
cssclass : français
---

# Michée 6

###### 1
Écoutez donc ce que dit Yahvé : " Debout! Entre en procès devant les montagnes et que les collines entendent ta voix! " 
###### 2
Écoutez, montagnes, le procès de Yahvé, prêtez l'oreille, fondements de la terre, car Yahvé est en procès avec son peuple, il plaide contre Israël : 
###### 3
" Mon peuple, que t'ai-je fait ? en quoi t'ai-je fatigué ? Réponds-moi. 
###### 4
Car je t'ai fait monter du pays d'Égypte, je t'ai racheté de la maison de servitude; j'ai envoyé devant toi Moïse, Aaron et Miryam. 
###### 5
Mon peuple, souviens-toi donc : quel était le projet de Balaq, roi de Moab ? Que lui répondit Balaam, fils de Béor ? ... de Shittim à Gilgal, pour que tu connaisses les justes œuvres de Yahvé. " 
###### 6
- " Avec quoi me présenterai-je devant Yahvé, me prosternerai-je devant le Dieu de là-haut ? Me présenterai-je avec des holocaustes, avec des veaux d'un an ? 
###### 7
Prendra-t-il plaisir à des milliers de béliers, à des libations d'huile par torrents ? Faudra-t-il que j'offre mon aîné pour prix de mon crime, le fruit de mes entrailles pour mon propre péché ? " 
###### 8
- " On t'a fait savoir, homme, ce qui est bien, ce que Yahvé réclame de toi : rien d'autre que d'accomplir la justice, d'aimer la bonté et de marcher humblement avec ton Dieu. " 
###### 9
C'est la voix de Yahvé! Il crie à la cité : Écoutez, tribu et assemblée de la cité! 
###### 10
Puis-je supporter une mesure fausse et un boisseau diminué, abominable ? 
###### 11
Puis-je tenir pour pur qui se sert de balances fausses, d'une bourse de poids truqués ? 
###### 12
Elle dont les riches sont pleins de violence et dont les habitants profèrent le mensonge! 
###### 13
Aussi, moi-même, j'ai commencé à te frapper, à te dévaster pour tes péchés. 
###### 14
Tu mangeras, mais tu ne pourras te rassasier; tu mettras de côté, mais tu ne pourras rien garder; et si tu peux garder quelque chose, je le livrerai à l'épée. 
###### 15
Tu sèmeras, mais tu ne pourras faire la moisson; tu presseras l'olive, mais tu ne pourras t'oindre d'huile, le moût, mais tu ne pourras boire de vin. 
###### 16
Tu observes les lois d'Omri, toutes les pratiques de la maison d'Achab; tu te conduis selon leurs principes, pour que je fasse de toi un objet de stupeur, de tes habitants une dérision, et que vous portiez l'opprobre des peuples. 
