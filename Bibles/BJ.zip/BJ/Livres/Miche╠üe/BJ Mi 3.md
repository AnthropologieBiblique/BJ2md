---
aliases : 
- Michée 3
- Michée 3
- Mi 3
- Micah 3
tags : 
- Bible/Mi/3
- français
cssclass : français
---

# Michée 3

###### 1
Puis je dis : Écoutez donc, chefs de la maison de Jacob et commandants de la maison d'Israël! N'est-ce pas à vous de connaître le droit, 
###### 2
vous qui haïssez le bien et aimez le mal, qui leur arrachez la peau, et la chair de sur leurs os ! 
###### 3
Ceux qui ont dévoré la chair de mon peuple, et lui ont arraché la peau et brisé les os, qui l'ont déchiré comme chair dans la marmite et comme viande en plein chaudron, 
###### 4
alors, ils crieront vers Yahvé, mais il ne leur répondra pas. Il leur cachera sa face en ce temps-là, à cause des crimes qu'ils ont commis. 
###### 5
Ainsi parle Yahvé contre les prophètes qui égarent mon peuple : S'ils ont quelque chose entre les dents, ils proclament : " Paix! " Mais à qui ne leur met rien dans la bouche ils déclarent la guerre. 
###### 6
C'est pourquoi la nuit pour vous sera sans vision, les ténèbres pour vous sans divination. Le soleil va se coucher pour les prophètes et le jour s'obscurcir pour eux. 
###### 7
Alors les voyants seront couverts de honte et les devins de confusion; tous, ils se couvriront les lèvres, car il n'y aura pas de réponse de Dieu. 
###### 8
Moi, au contraire, je suis plein de force et du souffle de Yahvé , de justice et de courage, pour proclamer à Jacob son crime, à Israël son péché. 
###### 9
Écoutez donc ceci, chefs de la maison de Jacob et commandants de la maison d'Israël, vous qui exécrez la justice et qui tordez tout ce qui est droit, 
###### 10
vous qui construisez Sion avec le sang et Jérusalem avec le crime! 
###### 11
Ses chefs jugent pour des présents, ses prêtres décident pour un salaire, ses prophètes vaticinent à prix d'argent. Et c'est sur Yahvé qu'ils s'appuient! Ils disent : " Yahvé n'est-il pas au milieu de nous ? le malheur ne tombera pas sur nous. " 
###### 12
C'est pourquoi, par votre faute, Sion deviendra une terre de labour, Jérusalem un monceau de décombres, et la montagne du Temple une hauteur boisée. Le règne futur de Yahvé à Sion. 
