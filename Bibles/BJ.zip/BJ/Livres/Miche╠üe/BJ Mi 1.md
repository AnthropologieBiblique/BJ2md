---
aliases : 
- Michée 1
- Michée 1
- Mi 1
- Micah 1
tags : 
- Bible/Mi/1
- français
cssclass : français
---

# Michée 1

###### 1
Parole de Yahvé qui fut adressée à Michée de Moréshèt, au temps de Yotam, d'Achaz et d'Ézéchias, rois de Juda. Ses visions sur Samarie et Jérusalem. 
###### 2
Écoutez, tous les peuples! Sois attentive, terre, et tout ce qui t'emplit! Yahvé va témoigner contre vous, le Seigneur, au sortir de son palais sacré! 
###### 3
Car voici Yahvé qui sort de son lieu saint : il descend, il foule les sommets de la terre. 
###### 4
Les montagnes fondent sous ses pas, les vallées s'effondrent, comme la cire devant le feu, comme l'eau répandue sur la pente. 
###### 5
Tout cela, à cause du crime de Jacob, du péché de la maison d'Israël. Quel est le crime de Jacob ? N'est-ce pas Samarie ? Quel est le péché de la maison de Juda ? N'est-ce pas Jérusalem ? 
###### 6
" Je vais faire de Samarie une ruine dans la campagne, une terre à vignes. Je ferai rouler ses pierres à la vallée, je mettrai à nu ses fondations. 
###### 7
Toutes ses statues seront brisées, tous ses salaires dévorés par le feu, toutes ses idoles, je les livrerai à la solitude, car elles ont été amassées avec le salaire des prostituées et elles redeviendront salaire de prostituées. " Complainte sur les cités du Bas-Pays. 
###### 8
Pour cela, je vais gémir et me lamenter, je vais aller déchaussé et nu, je pousserai des gémissements comme les chacals, des plaintes comme les autruches. 
###### 9
Car il n'y a pas de remède au coup de Yahvé; il atteint jusqu'à Juda, il frappe jusqu'à la porte de mon peuple, jusqu'à Jérusalem! 
###### 10
A Gat, ne le publiez pas, à... ne versez pas vos pleurs! A Bet-Léaphra, roulez-vous dans la poussière! 
###### 11
Sonne du cor, toi qui demeures à Shaphir! Elle n'est pas sortie de sa cité, celle qui demeure à Çaanân! Bet-ha-Éçel est arrachée de ses fondations, de la base de son assise! 
###### 12
Pourrait-elle donc espérer le bonheur, celle qui demeure à Marôt ? Car le malheur est descendu de chez Yahvé à la porte de Jérusalem. 
###### 13
Attelle au char le coursier, toi qui demeures à Lakish! Ce fut le début du péché pour la fille de Sion, car c'est en toi que l'on trouve les forfaits d'Israël. 
###### 14
Aussi tu devras verser une dot pour Moréshèt-Gat. Bet-Akzib sera une déception pour les rois d'Israël. 
###### 15
Le pillard te reviendra encore, toi qui demeures à Maresha! Jusqu'à Adullam s'en ira la gloire d'Israël. 
###### 16
Arrache tes cheveux, rase-les, pour les fils qui faisaient ta joie! Rends-toi chauve comme le vautour, car ils sont exilés loin de toi! 
