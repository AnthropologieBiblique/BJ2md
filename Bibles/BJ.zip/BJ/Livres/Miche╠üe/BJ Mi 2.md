---
aliases : 
- Michée 2
- Michée 2
- Mi 2
- Micah 2
tags : 
- Bible/Mi/2
- français
cssclass : français
---

# Michée 2

###### 1
Malheur à ceux qui projettent le méfait et qui trament le mal sur leur couche! Dès que luit le matin, ils l'exécutent, car c'est au pouvoir de leurs mains. 
###### 2
S'ils convoitent des champs, ils s'en emparent; des maisons, ils les prennent; ils saisissent le maître avec sa maison, l'homme avec son héritage. 
###### 3
C'est pourquoi ainsi parle Yahvé : Voici que je projette contre cette engeance un malheur tel que vous n'en pourrez retirer votre cou; et vous ne pourrez marcher la tête haute, car ce sera un temps de malheur. 
###### 4
Ce jour-là, on fera sur vous une satire! on chantera une complainte, et l'on dira : " Nous sommes dépouillés de tout; la part de mon peuple est mesurée au cordeau, personne ne la lui rend; nos champs sont attribués à celui qui nous pille. " 
###### 5
Aussi il n'y aura pour vous personne qui jette le cordeau sur un lot dans l'assemblée de Yahvé. 
###### 6
Ne vaticinez pas, vaticinent-ils, qu'on ne vaticine pas ainsi! L'opprobre ne nous atteindra pas. 
###### 7
La maison de Jacob serait-elle maudite ? Yahvé a-t-il perdu patience ? Est-ce là sa manière d'agir ? Ses paroles ne sont-elles pas bienveillantes pour son peuple Israël ? 
###### 8
C'est vous qui vous dressez en ennemis contre mon peuple. A qui est sans reproche vous arrachez son manteau; à qui se croit en sécurité vous infligez les désastres de la guerre. 
###### 9
Les femmes de mon peuple, vous les chassez des maisons qu'elles aimaient; à leurs enfants, vous enlevez pour toujours l'honneur que je leur ai donné : 
###### 10
" Debout, en avant! ce n'est pas la pause! " Pour un rien vous extorquez un gage écrasant. 
###### 11
S'il pouvait y avoir un inspiré qui forge ce mensonge : " Je te prophétise vin et boisson ", il serait le prophète de ce peuple-là. 
###### 12
Oui, je veux rassembler Jacob tout entier, je veux réunir le reste d'Israël! Je les regrouperai comme des moutons dans l'enclos; comme un troupeau au milieu de son pâturage, ils feront du bruit loin des hommes. 
###### 13
Celui qui fait la brèche devant eux montera; ils feront la brèche, ils passeront la porte, ils sortiront par elle; leur roi passera devant eux et Yahvé à leur tête. 
