---
aliases : 
- Michée 7
- Michée 7
- Mi 7
- Micah 7
tags : 
- Bible/Mi/7
- français
cssclass : français
---

# Michée 7

###### 1
Malheur à moi! je suis devenu comme un moissonneur en été, comme un grappilleur aux vendanges : plus une grappe à manger, plus une figue précoce que je désire! 
###### 2
Les fidèles ont disparu du pays : pas un juste parmi les gens! Tous sont aux aguets pour verser le sang, ils traquent chacun son frère au filet. 
###### 3
Pour faire le mal leurs mains sont habiles : le prince réclame, le juge juge pour un cadeau, le grand prononce suivant son bon plaisir. 
###### 4
Parmi eux le meilleur est comme une ronce, le plus juste comme une haie d'épines. Aujourd'hui arrive du Nord leur épreuve; c'est l'instant de leur confusion. 
###### 5
Ne vous fiez pas au prochain, n'ayez point confiance en l'ami; devant celle qui partage ta couche, garde-toi d'ouvrir la bouche. 
###### 6
Car le fils insulte le père, la fille se dresse contre sa mère, la belle-fille contre sa belle-mère, chacun a pour ennemis les gens de sa maison. 
###### 7
Mais moi, je regarde vers Yahvé, j'espère dans le Dieu qui me sauvera; mon Dieu m'entendra. 
###### 8
Ne te réjouis pas à mon sujet, ô mon ennemie : si je suis tombée, je me relèverai; si je demeure dans les ténèbres, Yahvé est ma lumière. 
###### 9
Je dois porter la colère de Yahvé, puisque j'ai péché contre lui, jusqu'à ce qu'il juge ma cause et me fasse justice; il me fera sortir à la lumière, et je contemplerai ses justes œuvres. 
###### 10
Quand mon ennemie le verra, elle sera couverte de honte, elle qui me disait : " Où est-il, Yahvé ton Dieu ? " Mes yeux la contempleront, tandis qu'elle sera piétinée comme la boue des rues. 
###### 11
Le jour de rebâtir tes remparts! Ce jour-là s'étendront tes frontières; 
###### 12
ce jour-là, on viendra jusqu'à toi depuis l'Assyrie jusqu'à l'Égypte, depuis Tyr jusqu'au Fleuve, de la mer à la mer, de la montagne à la montagne. 
###### 13
La terre deviendra une solitude à cause de ses habitants, pour prix de leur conduite. 
###### 14
Fais paître ton peuple sous ta houlette, le troupeau de ton héritage, qui demeure isolé dans les broussailles, au milieu des vergers. Puisse-t-il paître en Bashân et en Galaad comme aux jours antiques! 
###### 15
Comme aux jours où tu sortis du pays d'Égypte, fais-nous voir des merveilles! 
###### 16
Les nations verront et seront confondues malgré toute leur puissance; elles se mettront la main sur la bouche, elles en auront les oreilles assourdies. 
###### 17
Elles lécheront la poussière comme le serpent, comme les bêtes qui rampent sur la terre. Elles sortiront tremblantes de leurs repaires, terrifiées et craintives devant toi. 
###### 18
Quel est le dieu comme toi, qui enlève la faute, qui pardonne le crime, qui n'exaspère pas pour toujours sa colère, mais qui prend plaisir à faire grâce ? 
###### 19
Une fois de plus, aie pitié de nous! foule aux pieds nos fautes, jette au fond de la mer tous nos péchés! 
###### 20
Accorde à Jacob ta fidélité, à Abraham ta grâce, que tu as jurées à nos pères dès les jours d'antan. 
