---
aliases : 
- Daniel 5
- Daniel 5
- Dn 5
tags : 
- Bible/Dn/5
- français
cssclass : français
---

# Daniel 5

###### 1
Le roi Balthazar donna un grand festin pour ses seigneurs, qui étaient au nombre de mille, et devant ces mille il but du vin.
###### 2
Ayant goûté le vin, Balthazar ordonna d'apporter les vases d'or et d'argent que son père Nabuchodonosor avait pris au sanctuaire de Jérusalem, pour y faire boire le roi, ses seigneurs, ses concubines et ses chanteuses.
###### 3
On apporta donc les vases d'or et d'argent pris au sanctuaire du Temple de Dieu à Jérusalem, et y burent le roi et ses seigneurs, ses concubines et ses chanteuses.
###### 4
Ils burent du vin et firent louange aux dieux d'or et d'argent, de bronze et de fer, de bois et de pierre.
###### 5
Soudain apparurent des doigts de main humaine qui se mirent à écrire, derrière le lampadaire, sur le plâtre du mur du palais royal, et le roi vit la paume de la main qui écrivait.
###### 6
Alors le roi changea de couleur, ses pensées se troublèrent, les jointures de ses hanches se relâchèrent et ses genoux se mirent à s'entrechoquer.
###### 7
Il manda en criant devins, Chaldéens et exorcistes. Et le roi dit aux sages de Babylone : "Quiconque lira cette écriture et m'en découvrira l'interprétation, on le vêtira de pourpre, on lui mettra une chaîne d'or autour du cou et il gouvernera en troisième dans le royaume."
###### 8
Alors, accoururent tous les sages du roi; mais ils ne purent ni lire l'écriture ni en faire connaître l'interprétation au roi.
###### 9
Le roi Balthazar en fut très troublé, il changea de couleur et ses seigneurs demeurèrent perplexes.
###### 10
S'en vint dans la salle du festin la reine, alertée par les paroles du roi et des seigneurs. Et la reine dit : "O roi, vis à jamais! Que tes pensées ne se troublent pas et que ton éclat ne se ternisse point.
###### 11
Il est un homme dans ton royaume en qui réside l'esprit des dieux saints. Du temps de ton père, il se trouva en lui lumière, intelligence et sagesse pareille à la sagesse des dieux. Le roi Nabuchodonosor, ton père, le nomma chef des magiciens, devins, Chaldéens et exorcistes.
###### 12
Et puisqu'il s'est trouvé en ce Daniel, que le roi avait surnommé Baltassar, un esprit extraordinaire, connaissance, intelligence, art d'interpréter les songes, de résoudre les énigmes et de défaire les noeuds, fais donc mander Daniel et il te fera connaître l'interprétation."
###### 13
On fit venir Daniel devant le roi, et le roi dit à Daniel "Est-ce toi qui es Daniel, des gens de la déportation de Juda, amenés de Juda par le roi mon père?
###### 14
J'ai entendu dire que l'esprit des dieux réside en toi et qu'il se trouve en toi lumière, intelligence et sagesse extraordinaire.
###### 15
On m'a amené les sages et les devins pour lire cette écriture et m'en faire connaître l'interprétation, mais ils sont incapables de m'en découvrir l'interprétation.
###### 16
J'ai entendu dire que tu es capable de donner des interprétations et de défaire des noeuds. Si donc tu es capable de lire cette écriture et de m'en faire connaître l'interprétation, tu seras revêtu de pourpre et tu porteras une chaîne d'or autour du cou et tu seras en troisième dans le royaume."
###### 17
Daniel prit la parole et dit devant le roi : "Que tes dons te soient retournés, et donne à d'autres tes cadeaux! Pour moi, je lirai au roi cette écriture et je lui en ferai connaître l'interprétation.
###### 18
O roi, le Dieu Très-Haut a donné royaume, grandeur, majesté et gloire à Nabuchodonosor ton père.
###### 19
La grandeur qu'il lui avait donnée faisait trembler de crainte devant lui peuples, nations et langues : il tuait qui il voulait, laissait vivre qui il voulait, élevait qui il voulait, abaissait qui il voulait.
###### 20
Mais son coeur s'étant élevé et son esprit durci jusqu'à l'arrogance, il fut rejeté du trône de sa royauté et la gloire lui fut ôtée.
###### 21
Il fut retranché d'entre les hommes, et par le coeur il devint semblable aux bêtes; sa demeure fut avec les onagres; comme les boeufs il se nourrit d'herbe; son corps fut baigné de la rosée du ciel, jusqu'à ce qu'il eût appris que le Dieu Très-Haut a domaine sur le royaume des hommes et met à sa tête qui lui plaît.
###### 22
Mais toi, Balthazar, son fils, tu n'as pas humilié ton coeur, bien que tu aies su tout cela
###### 23
tu t'es exalté contre le Seigneur du Ciel, tu t'es fait apporter les vases de son Temple, et toi, tes seigneurs, tes concubines et tes chanteuses, vous y avez bu du vin, et avez fait louange aux dieux d'or et d'argent, de bronze et de fer, de bois et de pierre, qui ne voient, n'entendent, ni ne comprennent, et tu n'as pas glorifié le Dieu qui tient ton souffle entre ses mains et de qui relèvent toutes tes voies.
###### 24
Il a donc envoyé cette main qui, toute seule, a tracé cette écriture.
###### 25
L'écriture tracée, c'est : Mené, Mené, Teqel et Parsîn.
###### 26
Voici l'interprétation de ces mots : Mené : Dieu a mesuré ton royaume et l'a livré;
###### 27
Teqel : tu as été pesé dans la balance et ton poids se trouve en défaut;
###### 28
Parsîn : ton royaume a été divisé et donné aux Mèdes et aux Perses."
###### 29
Alors Balthazar ordonna de revêtir Daniel de pourpre, de lui mettre au cou une chaîne d'or et de proclamer qu'il gouvernerait en troisième dans le royaume.
###### 30
Cette nuit-là, le roi chaldéen Balthazar fut assassiné
