---
aliases : 
- Daniel 7
- Daniel 7
- Dn 7
tags : 
- Bible/Dn/7
- français
cssclass : français
---

# Daniel 7

###### 1
En l'an un de Balthazar, roi de Babylone, Daniel vit un songe et des visions de sa tête, sur sa couche. Il rédigea le rêve par écrit. Début du récit
###### 2
Daniel dit : J'ai contemplé des visions dans la nuit. Voici les quatre vents du ciel soulevaient la grande mer;
###### 3
quatre bêtes énormes sortirent de la mer, toutes différentes entre elles.
###### 4
La première était pareille à un lion avec des ailes d'aigle. Tandis que je la regardais, ses ailes lui furent arrachées, elle fut soulevée de terre et dressée sur ses pattes comme un homme, et un coeur d'homme lui fut donné.
###### 5
Voici : une deuxième bête, tout autre, semblable à un ours, dressée d'un côté, trois côtes dans la gueule, entre les dents. Il lui fut dit : "Lève-toi, dévore quantité de chair."
###### 6
Ensuite, je regardai et voici : une autre bête pareille à un léopard, portant sur les flancs quatre ailes d'oiseau; elle avait quatre têtes, et la domination lui fut donnée.
###### 7
Ensuite je contemplai une vision dans les visions de la nuit. Voici : une quatrième bête, terrible, effrayante et forte extrêmement; elle avait des dents de fer énormes : elle mangeait, broyait, et foulait aux pieds ce qui restait. Elle était différente des premières bêtes et portait dix cornes.
###### 8
Tandis que je considérais ses cornes, voici : parmi elles poussa une autre corne, petite; trois des premières cornes furent arrachées de devant elle, et voici qu'à cette corne, il y avait des yeux comme des yeux d'homme, et une bouche qui disait de grandes choses!
###### 9
Tandis que je contemplais Des trônes furent placés et un Ancien s'assit. Son vêtement, blanc comme la neige; les cheveux de sa tête, purs comme la laine. Son trône était flammes de feu, aux roues de feu ardent.
###### 10
Un fleuve de feu coulait, issu de devant lui. Mille milliers le servaient, myriade de myriades, debout devant lui. Le tribunal était assis, les livres étaient ouverts.
###### 11
Je regardais; alors, à cause du bruit des grandes choses que disait la corne, tandis que je regardais, la bête fut tuée, son corps détruit et livré à la flamme de feu.
###### 12
Aux autres bêtes la domination fut ôtée, mais elles reçurent un délai de vie, pour un temps et une époque.
###### 13
Je contemplais, dans les visions de la nuit Voici, venant sur les nuées du ciel, comme un Fils d'homme. Il s'avança jusqu'à l'Ancien et fut conduit en sa présence.
###### 14
A lui fut conféré empire, honneur et royaume, et tous peuples, nations et langues le servirent. Son empire est un empire éternel qui ne passera point, et son royaume ne sera point détruit.
###### 15
Moi, Daniel, mon esprit en fut écrasé et les visions de ma tête me troublèrent.
###### 16
Je m'approchai de l'un de ceux qui se tenaient là et lui demandai de me dire la vérité concernant tout cela. Il me répondit et me fit connaître l'interprétation de ces choses
###### 17
"Ces bêtes énormes au nombre de quatre sont quatre rois qui se lèveront de la terre.
###### 18
Ceux qui recevront le royaume sont les saints du Très-Haut, et ils posséderont le royaume pour l'éternité, et d'éternité en éternité."
###### 19
Puis je demandai à connaître la vérité concernant la quatrième bête, qui était différente de toutes les autres, terrible extrêmement, aux dents de fer et aux griffes de bronze, qui mangeait et broyait, et foulait aux pieds ce qui restait;
###### 20
et concernant les dix cornes qui étaient sur sa tête et l'autre corne poussa et les trois premières tombèrent, et cette corne avait des yeux et une bouche qui disait de grandes choses, et elle avait plus grand air que les autres cornes.
###### 21
Je contemplais cette corne qui faisait la guerre aux saints et l'emportait sur eux,
###### 22
jusqu'à la venue de l'Ancien qui rendit jugement en faveur des saints du Très-Haut, et le temps vint et les saints possédèrent le royaume.
###### 23
Il dit "La quatrième bête sera un quatrième royaume sur la terre, différent de tous les royaumes. Elle mangera toute la terre, la foulera aux pieds et l'écrasera.
###### 24
Et les dix cornes : de ce royaume, dix rois se lèveront et un autre se lèvera après eux; il sera différent des premiers et abattra les trois rois;
###### 25
il proférera des paroles contre le Très-Haut et mettra à l'épreuve les saints du Très-Haut. Il méditera de changer les temps et le droit, et les saints seront livrés entre ses mains pour un temps et des temps et un demi-temps.
###### 26
Mais le tribunal siégera et la domination lui sera ôtée, détruite et réduite à néant jusqu'à la fin.
###### 27
Et le royaume et l'empire et les grandeurs des royaumes sous tous les cieux seront donnés au peuple des saints du Très-Haut. Son empire est un empire éternel et tous les empires le serviront et lui obéiront."
###### 28
Ici finit le récit. Moi, Daniel, je fus grandement troublé dans mes pensées, ma mine changea et je gardai ces choses dans mon coeur.
