---
aliases : 
- Daniel 1
- Daniel 1
- Dn 1
tags : 
- Bible/Dn/1
- français
cssclass : français
---

# Daniel 1

###### 1
En l'an trois du règne de Joiaqim, roi de Juda, Nabuchodonosor, roi de Babylone, s'en vint à Jérusalem et l'investit.
###### 2
Le Seigneur livra entre ses mains Joiaqim, roi de Juda, ainsi qu'une partie des objets du Temple de Dieu. Il les emmena au pays de Shinéar et déposa les objets dans le trésor de ses dieux.
###### 3
Le roi dit à Ashpenaz, chef de ses eunuques, de prendre d'entre les gens d'Israël quelques enfants de race royale ou de grande famille
###### 4
ils devaient être sans tare, de belle apparence, instruits en toute sagesse, savants en science et subtils en savoir, aptes à se tenir à la cour du roi; Ashpenaz leur enseignerait les lettres et la langue des Chaldéens.
###### 5
Le roi leur assignait une portion journalière des mets du roi et du vin de sa table. Ils seraient éduqués pendant trois ans; après quoi, ils auraient à se tenir devant le roi.
###### 6
Parmi eux se trouvaient Daniel, Ananias, Misaèl et Azarias, qui étaient des Judéens.
###### 7
Le chef des eunuques leur imposa des noms : Daniel s'appellerait Baltassar, Ananias Shadrak, Misaèl Méshak, et Azarias Abed-Nego.
###### 8
Daniel, ayant à coeur de ne pas se souiller en prenant part aux mets du roi et au vin de sa table, supplia le chef des eunuques de lui épargner cette souillure.
###### 9
Dieu accorda à Daniel de trouver auprès du chef des eunuques grâce et miséricorde.
###### 10
Mais le chef des eunuques dit à Daniel : "Je redoute Monseigneur le roi; il vous a assigné chère et boisson et, s'il vous voit le visage émacié plus que les enfants de votre âge, c'est moi qui, à cause de vous, serai coupable aux yeux du roi."
###### 11
Daniel dit alors au garde que le chef des eunuques avait assigné à Daniel, Ananias, Misaèl et Azarias
###### 12
"Je t'en prie, mets tes serviteurs à l'épreuve pendant dix jours : qu'on nous donne des légumes à manger et de l'eau à boire.
###### 13
Tu verras notre mine et la mine des enfants qui mangent des mets du roi, et tu feras de tes serviteurs selon ce que tu auras vu."
###### 14
Il consentit à ce qu'ils lui demandaient et les mit à l'épreuve pendant dix jours.
###### 15
Au bout de dix jours, ils avaient bonne mine et ils avaient grossi plus que tous les enfants qui mangeaient des mets du roi.
###### 16
Dès lors, le garde supprima leurs mets et la portion de vin qu'ils avaient à boire et leur donna des légumes.
###### 17
A ces quatre enfants Dieu donna savoir et instruction en matière de lettres et en sagesse. Daniel, lui, possédait le discernement des visions et des songes.
###### 18
Au terme fixé par le roi pour qu'on les lui amenât, le chef des eunuques les conduisit devant Nabuchodonosor.
###### 19
Le roi s'entretint avec eux, et dans le nombre il ne s'en trouva pas tels que Daniel, Ananias, Misaèl et Azarias. Ils se tinrent donc devant le roi
###### 20
et, sur quelque point de sagesse ou de prudence qu'il les interrogeât, le roi les trouvait dix fois supérieurs à tous les magiciens et devins de son royaume tout entier.
###### 21
Daniel demeura là jusqu'en l'an un du roi Cyrus.
