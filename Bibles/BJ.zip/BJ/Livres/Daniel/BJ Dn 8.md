---
aliases : 
- Daniel 8
- Daniel 8
- Dn 8
tags : 
- Bible/Dn/8
- français
cssclass : français
---

# Daniel 8

###### 1
En l'an trois du règne du roi Balthazar, une vision m'apparut, à moi Daniel, après celle qui m'était apparue en premier.
###### 2
Je contemplais la vision, et tandis que je contemplais, je me trouvais à Suse, la place forte qui est dans la province d'Elam; et, contemplant la vision, je me trouvais à la porte de l'Ulaï.
###### 3
Je levai les yeux pour voir. Voici : un bélier se tenait devant la porte. Il avait deux cornes; les deux cornes étaient hautes, mais l'une plus que l'autre, et la plus haute qui se dressa fut la seconde.
###### 4
Je vis le bélier donner de la corne vers l'ouest, vers le nord et vers le sud. Nulle bête ne pouvait lui résister, rien ne pouvait lui échapper. Il faisait ce qui lui plaisait et devint puissant.
###### 5
Voici ce que je discernai : un bouc vint de l'occident, ayant parcouru la terre entière mais sans toucher le sol, et le bouc avait une corne "magnifique" entre les yeux.
###### 6
Il s'approcha du bélier aux deux cornes que j'avais vu se tenir devant la porte, et courut vers lui dans l'ardeur de sa force.
###### 7
Je le vis atteindre et affronter le bélier : il était en rage contre lui et frappa le bélier, lui brisant les deux cornes, sans que le bélier eût la force de lui résister; il le jeta à terre et le foula aux pieds; personne n'était là pour délivrer le bélier.
###### 8
Le bouc devint très puissant, mais, en pleine force, la grande corne se brisa et à sa place se dressèrent quatre "magnifiques" à l'encontre des quatre vents du ciel.
###### 9
De l'une d'elles, de la petite, sortit une corne, mais qui grandit beaucoup dans la direction du sud et de l'orient et du Pays de Splendeur.
###### 10
Elle grandit jusqu'aux armées du ciel, précipita à terre des armées et des étoiles et les foula aux pieds.
###### 11
Elle s'exalta même contre le Prince de l'armée, abolit le sacrifice perpétuel et renversa le fondement de son sanctuaire
###### 12
et l'armée; sur le sacrifice elle posa l'iniquité et renversa à terre la vérité; elle agit et réussit.
###### 13
J'entendis un saint qui parlait, et un autre saint dit à celui qui parlait : "Jusques à quand la vision : le sacrifice perpétuel, désolation de l'iniquité, sanctuaire et légion foulés aux pieds?"
###### 14
Il lui dit : "Encore 2.300 soirs et matins, alors le sanctuaire sera revendiqué."
###### 15
Moi, Daniel, contemplant cette vision, j'en cherchai l'intelligence. Voici, se tenant devant moi, quelqu'un qui avait l'aspect d'un homme.
###### 16
J'entendis une voix d'homme, sur l'Ulaï, criant : "Gabriel, donne-lui l'intelligence de cette vision!"
###### 17
Il s'avança vers le lieu où je me tenais, et, comme il approchait, je fus saisi de terreur et tombai face contre terre. Il me dit : "Fils d'homme, comprends : c'est le temps de la Fin que révèle la vision."
###### 18
Il parlait encore que je m'évanouis, la face contre terre. Il me toucha et me releva.
###### 19
Il dit : "Voici, je vais te faire connaître ce qui viendra à la fin de la Colère, pour la Fin assignée.
###### 20
Le bélier que tu as vu, ses deux cornes, ce sont les rois des Mèdes et des Perses.
###### 21
Le bouc velu est le roi de Yavân, la grande corne qui est entre ses yeux, c'est le premier roi.
###### 22
La corne brisée et les quatre cornes qui ont poussé à sa place, sont quatre royaumes issus de sa nation mais qui n'auront pas sa force.
###### 23
"Et au terme de leur règne, au temps de la plénitude de leurs péché, se lèvera un roi au visage fier, sachant pénétrer les énigmes.
###### 24
Sa puissance croîtra en force, mais non par sa propre puissance il tramera des choses inouïes il prospérera dans ses entreprises, il détruira des puissants et le peuple des saints.
###### 25
Et, par son intelligence, la trahison réussira entre ses mains. Il s'exaltera dans son coeur et détruira un grand nombre par surprise. Il s'opposera au Prince des Princes, mais sans acte de main il sera brisé.
###### 26
Elle est vraie, la vision des soirs et des matins qui a été dite, mais, toi, garde silence sur la vision, car il doit s'écouler bien des jours."
###### 27
Alors, moi Daniel, je défaillis et je fus malade plusieurs jours. Puis je me levai, pour accomplir mon office auprès du roi, gardant silence sur la vision, et demeurant sans la comprendre.
