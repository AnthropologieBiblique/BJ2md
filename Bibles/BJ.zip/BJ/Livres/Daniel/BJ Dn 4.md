---
aliases : 
- Daniel 4
- Daniel 4
- Dn 4
tags : 
- Bible/Dn/4
- français
cssclass : français
---

# Daniel 4

###### 1
Moi, Nabuchodonosor, je me tenais sans souci dans ma maison, et florissant dans mon palais.
###### 2
J'ai eu un songe : il m'a épouvanté; des angoisses, sur ma couche, et les visions de ma tête m'ont tourmenté.
###### 3
Je décrétai : qu'on m'amène tous les sages de Babylone pour qu'ils me fassent connaître l'interprétation du rêve.
###### 4
Magiciens, devins, Chaldéens et exorcistes sont venus : je leur dis mon rêve, ils ne m'en donnèrent pas l'interprétation.
###### 5
Puis se présenta devant moi Daniel, surnommé Baltassar, selon le nom de mon dieu, et en qui réside l'esprit des dieux saints. Je lui dis mon songe
###### 6
"Baltassar, chef des magiciens, je sais qu'en toi réside l'esprit des dieux saints et qu'aucun secret ne t'embarrasse voici le songe que j'ai eu; donne-m'en l'interprétation.
###### 7
"Sur ma couche, j'ai contemplé les visions de ma tête "Voici : un arbre au centre de la terre, très grand de taille.
###### 8
L'arbre grandit, devint puissant, sa hauteur atteignait le ciel, sa vue, les confins de toute la terre.
###### 9
Son feuillage était beau, abondant son fruit; en lui chacun trouvait sa nourriture, il donnait l'ombre aux bêtes des champs, dans ses branches nichaient les oiseaux du ciel et toute chair se nourrissait de lui.
###### 10
Je contemplai les visions de ma tête, sur ma couche. Voici : un Vigilant, un saint descend du ciel.
###### 11
A pleine voix, il crie Abattez l'arbre, brisez ses branches, arrachez son feuillage, jetez son fruit, que les bêtes fuient son abri et les oiseaux ses branches.
###### 12
Mais que restent en terre souche et racines dans des liens de fer et de bronze, dans l'herbe des champs. Qu'il soit baigné de la rosée du ciel et que l'herbe de la terre soit sa part avec les bêtes des champs.
###### 13
Son coeur se détournera des hommes, un coeur de bête lui sera donné et sept temps passeront sur lui!
###### 14
C'est la sentence que prononcent les Vigilants, la question tranchée par les saints, afin que sache tout vivant que le Très-Haut a domaine sur le royaume des hommes il le donne à qui lui plaît et élève le plus bas d'entre les hommes!
###### 15
Tel est le songe que j'ai eu, moi Nabuchodonosor, roi. Toi, Baltassar, donne-m'en l'interprétation, car aucun des sages de mon royaume n'a pu m'en faire connaître l'interprétation; mais toi tu le peux, puisque en toi réside l'esprit des dieux saints."
###### 16
Alors Daniel, surnommé Baltassar, fut un instant confondu et troublé dans ses pensées. Le roi dit : "Baltassar, ne sois pas troublé par ce songe et son interprétation." Baltassar répondit : "Monseigneur, ce songe soit pour ceux qui te haïssent, et son interprétation pour tes adversaires!
###### 17
Cet arbre que tu as vu, grand et fort et élevé, atteignant au ciel et visible par toute la terre,
###### 18
au beau feuillage, au fruit abondant, portant nourriture pour tous, sous lequel demeurent les bêtes des champs et dans ses branches nichent les oiseaux du ciel ,
###### 19
c'est toi, ô roi, qui es devenu grand et puissant, et ta grandeur a augmenté et a atteint jusqu'au ciel, et ton empire jusqu'aux confins de la terre.
###### 20
"Quant à ce qu'a vu le roi : un Vigilant, un saint, descendu du ciel, qui disait : Abattez l'arbre, détruisez-le, mais la souche et ses racines, laissez-les en terre, dans des liens de fer et de bronze, dans l'herbe des champs, et qu'il soit baigné de la rosée du ciel et que sa part soit avec les bêtes des champs jusqu'à ce que sept temps soient passés sur lui 
###### 21
voici quelle en est l'interprétation, ô roi, et la décision du Très-Haut qui est venue sur mon Seigneur le roi
###### 22
"Tu seras chassé d'entre les hommes et avec les bêtes des champs sera ta demeure, tu te nourriras d'herbe, comme les boeufs, tu seras baigné de la rosée du ciel, sept temps passeront sur toi, jusqu'à ce que tu aies appris que le Très-Haut a domaine sur le royaume des hommes et qu'il le donne à qui lui plaît.
###### 23
"Et cette parole : Laissez la souche et les racines de l'arbre, c'est que ton royaume sera préservé pour toi jusqu'à ce que tu aies appris que les Cieux ont tout domaine.
###### 24
C'est pourquoi, ô roi, agrée mon conseil : romps tes péchés par les oeuvres de justice, et tes iniquités en faisant miséricorde aux pauvres, afin d'avoir longue sécurité."
###### 25
Tout cela advint au roi Nabuchodonosor.
###### 26
Douze mois plus tard, se promenant sur la terrasse du palais royal de Babylone,
###### 27
le roi disait : "N'est-ce pas là cette grande Babylone que j'ai bâtie, pour en faire ma résidence royale, par la force de ma puissance et pour la majesté de ma gloire?"
###### 28
Ces paroles étaient encore dans sa bouche, quand une voix tomba du ciel "C'est à toi qu'il est parlé, ô roi Nabuchodonosor! la royauté s'est retirée de toi,
###### 29
d'entre les hommes tu seras chassé, avec les bêtes des champs sera ta demeure, d'herbe, comme les boeufs, tu te nourriras, et sept temps passeront sur toi, jusqu'à ce que tu aies appris que le Très-Haut a domaine sur le royaume des hommes et qu'il le donne à qui lui plaît."
###### 30
Et aussitôt, la parole s'accomplit en Nabuchodonosor : il fut chassé d'entre les hommes; comme les boeufs, il mangea de l'herbe, son corps fut baigné de la rosée du ciel, et ses cheveux poussèrent comme des plumes d'aigle et ses ongles comme des griffes d'oiseau.
###### 31
"Au temps fixé, moi, Nabuchodonosor, je levai les yeux vers le ciel : l'intelligence me revint; alors je bénis le Très-Haut, louant et glorifiant Celui qui vit à jamais son empire est un empire éternel, son royaume, pour toutes les générations.
###### 32
Tous les habitants de la terre, c'est comme s'ils ne comptaient pas, selon son bon plaisir, il agit avec l'armée du ciel et avec les habitants de la terre. Nul ne peut arrêter sa main ou lui dire : Qu'as-tu fait là?
###### 33
A cet instant, l'intelligence me revint, et pour l'honneur de ma royauté me revinrent gloire et splendeur; mes conseillers et mes grands me réclamèrent, je fus rétabli dans ma royauté, et ma grandeur fut accrue.
###### 34
A présent, moi, Nabuchodonosor, je loue, exalte et glorifie le Roi du Ciel, dont toutes les oeuvres sont vérité, toutes les voies justice, et qui sait abaisser ceux qui marchent dans l'orgueil."
