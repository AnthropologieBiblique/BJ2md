---
aliases : 
- Daniel 10
- Daniel 10
- Dn 10
tags : 
- Bible/Dn/10
- français
cssclass : français
---

# Daniel 10

###### 1
En l'an trois de Cyrus, roi de Perse, une parole fut révélée à Daniel, surnommé Baltassar : parole sûre; haute lutte. Il pénétra la parole, l'intelligence lui en fut donnée en vision.
###### 2
En ces temps-là, moi, Daniel, je faisais une pénitence de trois semaines
###### 3
je ne mangeais point de nourriture désirable; viande ni vin n'approchaient de ma bouche, et je ne m'oignais point, jusqu'au terme de ces trois semaines.
###### 4
Le vingt-quatrième jour du premier mois, étant au bord du grand fleuve, le Tigre,
###### 5
je levai les yeux pour regarder. Voici Un homme vêtu de lin, les reins ceints d'or pur,
###### 6
son corps avait l'apparence de la chrysolithe, son visage, l'aspect de l'éclair, ses yeux comme des lampes de feu, ses bras et ses jambes comme l'éclat du bronze poli, le son de ses paroles comme la rumeur d'une multitude.
###### 7
Seul, moi Daniel, je contemplais cette apparition; les hommes qui étaient avec moi ne voyaient pas la vision, mais un grand tremblement s'abattit sur eux et ils s'enfuirent pour se cacher.
###### 8
Je demeurai seul, contemplant cette grande vision; j'étais sans force, mon visage changea, défiguré, ma force m'abandonna.
###### 9
J'entendis le son de ses paroles, et au son de ses paroles je défaillis et tombai face contre terre.
###### 10
Voici : une main me toucha, faisant frémir mes genoux et les paumes de mes mains.
###### 11
Il me dit : "Daniel, homme des prédilections, comprends les paroles que je vais te dire; lève-toi; me voici, envoyé à toi." Il dit ces mots et je me relevai en tremblant.
###### 12
Il me dit : "Ne crains point, Daniel, car du premier jour où, pour comprendre, tu as résolu de te mortifier devant ton Dieu, tes paroles ont été entendues, et c'est à cause de tes paroles que je suis venu.
###### 13
Le Prince du royaume de Perse m'a résisté pendant 21 jours, mais Michel, l'un des Premiers Princes, est venu à mon aide. Je l'ai laissé affrontant les rois de Perse,
###### 14
et je suis venu te faire comprendre ce qui adviendra à ton peuple, à la fin des jours. Car voici pour ces jours une nouvelle vision."
###### 15
Lorsqu'il m'eut dit ces choses, je me prosternai à terre sans rien dire;
###### 16
et voici : une semblance de fils d'homme me toucha les lèvres. J'ouvris la bouche pour parler, et je dis à celui qui se tenait devant moi : "Mon Seigneur, à cette apparition, l'angoisse revient sur moi et je n'ai plus de forces.
###### 17
Et comment le serviteur de mon Seigneur que voici, pourra-t-il parler avec mon Seigneur, alors que déjà il n'est plus de force en moi et que le souffle m'abandonne?"
###### 18
De nouveau l'apparence humaine me toucha et me réconforta.
###### 19
Il dit : "Ne crains point, homme des prédilections; paix à toi, prends force et courage!" Et tandis qu'il me parlait, je me sentais fortifié et je dis : "Que mon Seigneur parle, car tu m'as réconforté."
###### 20
Alors il dit : "Sais-tu pourquoi je suis venu à toi? Je dois retourner combattre le Prince de Perse : quand j'en aurai fini, voici que viendra le Prince de Yavân.
###### 21
Mais je vais t'annoncer ce qui est inscrit dans le Livre de Vérité. Nul ne me prête main-forte pour ces choses, sinon Michel, votre Prince,
