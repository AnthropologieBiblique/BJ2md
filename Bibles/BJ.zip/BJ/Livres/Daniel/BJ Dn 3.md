---
aliases : 
- Daniel 3
- Daniel 3
- Dn 3
tags : 
- Bible/Dn/3
- français
cssclass : français
---

# Daniel 3

###### 1
Le roi Nabuchodonosor fit une statue d'or, haute de 60 coudées et large de six, qu'il dressa dans la plaine de Dura, dans la province de Babylone.
###### 2
Le roi Nabuchodonosor manda aux satrapes, magistrats, gouverneurs, conseillers, trésoriers, juges et juristes, et à toutes les autorités de la province, de s'assembler et de se rendre à la dédicace de la statue élevée par le roi Nabuchodonosor.
###### 3
Lors s'assemblèrent satrapes, magistrats, gouverneurs, conseillers, trésoriers, juges et juristes et toutes les autorités de la province pour la dédicace de la statue qu'avait élevée le roi Nabuchodonosor, et ils se tinrent devant la statue qu'avait élevée le roi Nabuchodonosor.
###### 4
Le héraut proclama avec force : "A vous, peuples, nations et langues, voici ce qui a été commandé
###### 5
à l'instant où vous entendrez sonner trompe, pipeau, cithare, sambuque, psaltérion, cornemuse et toute espèce de musique, vous vous prosternerez et ferez adoration à la statue d'or qu'a élevée le roi Nabuchodonosor.
###### 6
Quant à celui qui ne se prosternera ni ne fera adoration, il sera incontinent jeté dans la fournaise de feu ardent."
###### 7
Sur quoi, dès que tous les peuples eurent entendu sonner trompe, pipeau, cithare, sambuque, psaltérion, cornemuse et toute espèce de musique, se prosternèrent tous les peuples, nations et langues, faisant adoration à la statue d'or qu'avait élevée le roi Nabuchodonosor.
###### 8
Cependant certains Chaldéens s'en vinrent dénoncer les Juifs.
###### 9
Ils dirent au roi Nabuchodonosor : "O roi, vis à jamais!
###### 10
O roi, tu as promulgué un décret prescrivant à tout homme qui entendrait sonner trompe, pipeau, cithare, sambuque, psaltérion, cornemuse et toute espèce de musique, de se prosterner et de faire adoration à la statue d'or,
###### 11
et arrêtant que ceux qui ne se prosterneraient ni ne feraient adoration seraient jetés dans la fournaise de feu ardent.
###### 12
Or voici des Juifs que tu as assignés aux affaires de la province de Babylone : Shadrak, Méshak et Abed-Nego; ces gens n'ont pas tenu compte de tes ordres, ô roi; ils ne servent pas ton dieu et ils n'ont pas fait adoration à la statue d'or que tu as élevée."
###### 13
Alors, frémissant de colère, Nabuchodonosor manda Shadrak, Méshak et Abed-Nego. Aussitôt on amena ces gens devant le roi.
###### 14
Et Nabuchodonosor leur dit : "Est-il vrai, Shadrak, Méshak et Abed-Nego, que vous ne serviez point mes dieux et ne fassiez pas adoration à la statue d'or que j'ai élevée?
###### 15
Etes-vous disposés, quand vous entendrez sonner trompe, pipeau, cithare, sambuque, psaltérion, cornemuse et toute espèce de musique, à vous prosterner et à faire adoration à la statue que j'ai faite? Si vous ne lui faites pas adoration, vous serez incontinent jetés dans la fournaise de feu ardent; et quel est le dieu qui vous délivrerait de ma main?"
###### 16
Shadrak, Méshak et Abed-Nego répondirent au roi Nabuchodonosor : "Point n'est besoin pour nous de te donner réponse à ce sujet
###### 17
si notre Dieu, celui que nous servons, est capable de nous délivrer de la fournaise de feu ardent, et de ta main, ô roi, il nous délivrera;
###### 18
et s'il ne le fait pas, sache ô roi, que nous ne servirons pas ton dieu, ni n'adorerons la statue d'or que tu as élevée."
###### 19
Alors le roi Nabuchodonosor fut rempli de colère et l'expression de son visage changea à l'égard de Shadrak, Méshak et Abed-Nego. Il donna ordre de chauffer la fournaise sept fois plus que d'ordinaire
###### 20
et à des hommes forts de son armée de lier Shadrak, Méshak et Abed-Nego et de les jeter dans la fournaise de feu ardent.
###### 21
Ceux-ci furent donc liés, avec leur manteau, leurs chausses, leur chapeau, tous leurs vêtements, et jetés dans la fournaise de feu ardent.
###### 22
L'ordre du roi était péremptoire; la fournaise étant excessivement brûlante, les hommes qui y portèrent Shadrak, Méshak et Abed-Nego furent brûlés à mort par la flamme du feu.
###### 23
Quant aux trois hommes Shadrak, Méshak et Abed-Nego, ils tombèrent tout liés dans la fournaise de feu ardent.
###### 24
Et ils marchaient au milieu de la flamme, louant Dieu et bénissant le Seigneur.
###### 25
Azarias, debout, priait ainsi, ouvrant la bouche, au milieu du feu, il dit
###### 26
Béni sois-tu, Seigneur, Dieu de nos pères, et vénéré, et que ton nom soit glorifié éternellement.
###### 27
Car tu es juste en toutes les choses que tu as faites pour nous toutes tes oeuvres sont vérité toutes tes voies droites, tous tes jugements vérité.
###### 28
Tu as porté une sentence de vérité en toutes les choses que tu as fait venir sur nous et sur la ville sainte de nos pères, Jérusalem. Car c'est dans la vérité et dans le droit que tu nous as traités à cause de nos péchés.
###### 29
Oui, nous avons péché et commis l'iniquité en te désertant, oui, nous avons grandement péché; tes commandements, nous ne les avons pas écoutés,
###### 30
nous ne les avons pas observés, nous n'avons pas accompli ce qui nous était commandé pour notre bien.
###### 31
Oui, tout ce que tu as fait venir sur nous, tout ce que tu nous as fait, en jugement de vérité tu l'as fait.
###### 32
Tu nous as livrés aux mains de nos ennemis, gens sans loi, et les pires des impies, à un roi injuste, au plus mauvais qui soit sur toute la terre,
###### 33
et aujourd'hui nous ne pouvons ouvrir la bouche, la honte et l'opprobre sont la part de ceux qui te servent et qui t'adorent.
###### 34
Oh! ne nous abandonne pas pour toujours, à cause de ton nom, ne répudie pas ton alliance,
###### 35
ne nous retire pas ta grâce, pour l'amour d'Abraham ton ami et d'Isaac ton serviteur et d'Israël ton saint,
###### 36
à qui tu as promis une postérité nombreuse comme les étoiles du ciel et comme le sable sur le rivage de la mer.
###### 37
Seigneur, nous voici plus petits que toutes les nations, nous voici humiliés par toute la terre, aujourd'hui, à cause de nos péchés.
###### 38
Il n'est plus, en ce temps, chef, prophète ni prince, holocauste, sacrifice, oblation ni encens, lieu où te faire des offrandes
###### 39
et trouver grâce auprès de toi. Mais qu'une âme brisée et un esprit humilié soient agréés de toi,
###### 40
comme des holocaustes de béliers et de taureaux, comme des milliers d'agneaux gras; que tel soit notre sacrifice aujourd'hui devant toi, et qu'il te plaise que pleinement nous te suivions, car il n'est point de confusion pour ceux qui espèrent en toi.
###### 41
Et maintenant nous mettons tout notre coeur à te suivre, à te craindre et à rechercher ta face.
###### 42
Ne nous laisse pas dans la honte, mais agis avec nous selon ta mansuétude et selon la grandeur de ta grâce.
###### 43
Délivre-nous selon tes oeuvres merveilleuses, fais qu'à ton nom, Seigneur, gloire soit rendue.
###### 44
Qu'ils soient confondus, tous ceux qui font du mal à tes serviteurs qu'ils soient couverts de honte, privés de toute leur puissance, et que leur force soit brisée.
###### 45
Qu'ils sachent que tu es seul Dieu et Seigneur, en gloire sur toute la terre."
###### 46
Les serviteurs du roi qui les avaient jetés dans la fournaise ne cessaient d'alimenter le feu de naphte, de poix, d'étoupe et de sarments,
###### 47
si bien que la flamme s'élevait de 49 coudées au-dessus de la fournaise.
###### 48
En s'étendant, elle brûla les Chaldéens qui se trouvaient autour de la fournaise.
###### 49
Mais l'ange du Seigneur descendit dans la fournaise auprès d'Azarias et de ses compagnons; il repoussa au-dehors la flamme du feu
###### 50
et il leur souffla, au milieu de la fournaise, comme une fraîcheur de brise et de rosée, si bien que le feu ne les toucha aucunement et ne leur causa douleur ni angoisse.
###### 51
Alors tous trois, d'une seule voix, se mirent à chanter, glorifiant et bénissant Dieu dans la fournaise, et disant
###### 52
"Béni sois-tu, Seigneur, Dieu de nos pères, loué sois-tu, exalté éternellement. Béni soit ton nom de gloire et de sainteté, loué soit-il, exalté éternellement.
###### 53
Béni sois-tu dans le temple de ta sainte gloire, chanté, glorifié par-dessus tout éternellement.
###### 54
Béni sois-tu sur le trône de ton royaume, chanté par-dessus tout, exalté éternellement.
###### 55
Béni sois-tu, toi qui sondes les abîmes, qui sièges sur les chérubins, loué, chanté par-dessus tout éternellement.
###### 56
Béni sois-tu dans le firmament du ciel, chanté, glorifié éternellement.
###### 57
Vous toutes, oeuvres du Seigneur, bénissez le Seigneur chantez-le, exaltez-le éternellement!
###### 58
Anges du Seigneur, bénissez le Seigneur chantez-le, exaltez-le éternellement
###### 59
O cieux, bénissez le Seigneur chantez-le, exaltez-le éternellement!
###### 60
O vous, toutes les eaux au-dessus du ciel, bénissez le Seigneur chantez-le, exaltez-le éternellement!
###### 61
O vous, toutes les puissances, bénissez le Seigneur chantez-le, exaltez-le éternellement!
###### 62
O vous, soleil et lune, bénissez le Seigneur chantez-le, exaltez-le éternellement!
###### 63
O vous, astres du ciel, bénissez le Seigneur chantez-le, exaltez-le éternellement!
###### 64
O vous toutes, pluies et rosées, bénissez le Seigneur chantez-le, exaltez-le éternellement!
###### 65
O vous tous, vents, bénissez le Seigneur chantez-le, exaltez-le éternellement!
###### 66
O vous, feu et ardeur, bénissez le Seigneur chantez-le, exaltez-le éternellement!
###### 67
O vous, froidure et ardeur, bénissez le Seigneur chantez-le, exaltez-le éternellement!
###### 68
O vous, rosées et giboulées, bénissez le Seigneur chantez-le, exaltez-le éternellement!
###### 69
O vous, gel et froidure, bénissez le Seigneur chantez-le, exaltez-le éternellement!
###### 70
O vous, glaces et neiges, bénissez le Seigneur chantez-le, exaltez-le éternellement!
###### 71
O vous, nuits et jours, bénissez le Seigneur chantez-le, exaltez-le éternellement!
###### 72
O vous, lumière et ténèbre, bénissez le Seigneur chantez-le, exaltez-le éternellement!
###### 73
O vous, éclairs et nuées, bénissez le Seigneur chantez-le, exaltez-le éternellement!
###### 74
Que la terre bénisse le Seigneur qu'elle le chante et l'exalte éternellement!
###### 75
O vous, montagnes et collines, bénissez le Seigneur chantez-le, exaltez-le éternellement!
###### 76
O vous, toutes choses germant sur la terre, bénissez le Seigneur chantez-le, exaltez-le éternellement!
###### 77
O vous, sources, bénissez le Seigneur chantez-le, exaltez-le éternellement!
###### 78
O vous, mers et rivières, bénissez le Seigneur chantez-le, exaltez-le éternellement!
###### 79
O vous, baleines et tout ce qui se meut dans les eaux, bénissez le Seigneur chantez-le, exaltez-le éternellement!
###### 80
O vous tous, oiseaux du ciel, bénissez le Seigneur chantez-le, exaltez-le éternellement!
###### 81
O vous tous, bêtes et bestiaux, bénissez le Seigneur chantez-le, exaltez-le éternellement!
###### 82
O vous, enfants des hommes, bénissez le Seigneur chantez-le, exaltez-le éternellement!
###### 83
O Israël, bénis le Seigneur chantez-le, exaltez-le éternellement!
###### 84
O vous, prêtres, bénissez le Seigneur chantez-le, exaltez-le éternellement!
###### 85
O vous, ses serviteurs, bénissez le Seigneur chantez-le, exaltez-le éternellement!
###### 86
O vous, esprits et âmes des justes, bénissez le Seigneur chantez-le, exaltez-le éternellement!
###### 87
O vous, saints et humbles de coeur, bénissez le Seigneur chantez-le, exaltez-le éternellement!
###### 88
Ananias, Azarias, Misaèl, bénissez le Seigneur chantez-le, exaltez-le éternellement! Car il nous a délivrés des enfers, il nous a sauvés de la main de la mort, il nous a arrachés à la fournaise de flamme ardente, il nous a tirés du milieu de la flamme.
###### 89
Rendez grâces au Seigneur, car il est bon, car son amour est éternel.
###### 90
Vous tous qui le craignez, bénissez le Seigneur Dieu des dieux, chantez-le, rendez-lui grâces, car son amour est éternel." 
###### 91
Alors le roi Nabuchodonosor s'émut et se leva en toute hâte. Il interrogea ses intimes : "N'avons-nous pas jeté ces trois hommes tout liés dans le feu?" Ils répondirent : "Assurément, ô roi." 
###### 92
Il dit : "Mais je vois quatre hommes en liberté qui se promènent dans le feu sans qu'il leur arrive de mal, et le quatrième a l'aspect d'un fils des dieux." 
###### 93
Nabuchodonosor s'approcha de l'ouverture de la fournaise de feu ardent et dit : "Shadrak, Méshak et Abed-Nego, serviteurs du Dieu Très-Haut, sortez et venez ici." Alors du milieu du feu sortirent Shadrak, Méshak et Abed-Nego. 
###### 94
S'assemblèrent satrapes, magistrats, gouverneurs et intimes du roi pour voir ces hommes : le feu n'avait pas eu de pouvoir sur leur corps, les cheveux de leur tête n'avaient pas été consumés, leur manteau n'avait pas été altéré, nulle odeur de feu ne s'attachait à eux. 
###### 95
Nabuchodonosor dit : "Béni soit le Dieu de Shadrak, Méshak et Abed-Nego, qui a envoyé son ange et délivré ses serviteurs, eux qui, se confiant en lui, ont désobéi à l'ordre du roi et ont livré leur corps plutôt que de servir ou d'adorer tout autre dieu que leur Dieu. 
###### 96
Voici le décret que je porte : Peuples, nations et langues, que tous ceux d'entre vous qui parleraient légèrement du Dieu de Shadrak, Méshak et Abed-Nego soient mis en pièces, et que leurs maisons soient changées en bourbiers, car il n'est pas d'autre dieu qui puisse délivrer de la sorte." 
###### 97
Alors le roi fit prospérer Shadrak, Méshak et Abed-Nego dans la province de Babylone.
###### 98
Nabuchodonosor, Roi, à tous les peuples, nations, et langues qui habitent sur toute la terre: abondance de paix sur vous
###### 99
Il m'a semblé bon de faire connaître les signes et merveilles qu'a faits pour moi le Dieu très haut.
###### 100
Si grands, ses signes, si puissantes, ses merveilles, son royaume est un royaume éternel, son empire de génération en génération.
