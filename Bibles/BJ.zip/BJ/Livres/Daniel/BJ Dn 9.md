---
aliases : 
- Daniel 9
- Daniel 9
- Dn 9
tags : 
- Bible/Dn/9
- français
cssclass : français
---

# Daniel 9

###### 1
En l'an un de Darius, de la race des Mèdes, fils d'Artaxerxès, qui régna sur le royaume de Chaldée,
###### 2
en l'an un de son règne, moi, Daniel, je scrutai les Ecritures, computant le nombre des années tel qu'il fut révélé par Yahvé au prophète Jérémie qui doivent s'accomplir pour les ruines de Jérusalem, à savoir 70 ans.
###### 3
Je tournai ma face vers le Seigneur Dieu pour implorer un délai de prière et de supplications dans le jeûne, le sac et la poussière.
###### 4
Je suppliai Yahvé mon Dieu, faisant confession "Ah! mon Seigneur, Dieu grand et redoutable, qui gardes l'Alliance et la grâce pour ceux qui t'aiment et observent tes commandements.
###### 5
Nous avons péché, nous avons commis l'iniquité, nous avons fait le mal, nous avons trahi et nous nous sommes détournés de tes commandements et décisions.
###### 6
Nous n'avons pas écouté tes serviteurs, les prophètes qui parlaient en ton nom à nos rois, à nos princes, à nos pères, à tout le peuple du pays.
###### 7
A toi, Seigneur, la justice, à nous la honte au visage, comme en ce jour, à nous, gens de Juda, habitants de Jérusalem, tout Israël, proches et lointains, dans tous les pays où tu nous as chassés à cause des infidélités commises à ton égard.
###### 8
Yahvé, à nous la honte au visage, à nos rois, à nos princes, à nos pères, parce que nous avons péché contre toi.
###### 9
Au Seigneur notre Dieu, les miséricordes et les pardons, car nous l'avons trahi,
###### 10
et nous n'avons pas écouté la voix de Yahvé notre Dieu pour marcher selon les lois qu'il nous avait données par ses serviteurs les prophètes.
###### 11
Tout Israël a transgressé ta loi, a déserté sans écouter ta voix, et se sont répandues sur nous la malédiction et l'imprécation inscrites dans la loi de Moïse, le serviteur de Dieu car nous avons péché contre lui.
###### 12
Et il a mis a exécution les paroles qu'il avait dites contre nous et contre les princes qui nous gouvernaient : il ferait venir à nous calamité si grande qu'il n'en sera pas sous le ciel de plus grande qu'à Jérusalem.
###### 13
Ainsi qu'il est écrit dans la loi de Moïse, toute cette calamité est venue sur nous, mais nous n'avons pas rasséréné la face de Yahvé, notre Dieu, en revenant de nos iniquités, en apprenant à connaître ta vérité.
###### 14
Yahvé a veillé à la calamité, il l'a fait venir sur nous. Car juste est Yahvé notre Dieu, dans toutes les oeuvres qu'il a faites, mais nous, nous n'avons pas écouté sa voix.
###### 15
Et maintenant, Seigneur notre Dieu, qui par ta main puissante as fait sortir ton peuple du pays d'Egypte, et ton renom en perdure jusqu'à ce jour , nous avons péché, nous avons commis le mal.
###### 16
Seigneur, par toutes tes justices, détourne ta colère et ta fureur de Jérusalem, ta ville, ta montagne sainte, car à cause de nos péchés et des fautes de nos pères, Jérusalem et ton peuple sont en opprobre à tous ceux qui nous environnent.
###### 17
Et maintenant, écoute, ô notre Dieu, la prière de ton serviteur et ses supplications. Que ta face illumine ton sanctuaire désolé, par toi-même, Seigneur!
###### 18
Prête l'oreille, mon Dieu, et écoute! Ouvre les yeux et vois nos désolations et la ville sur laquelle on invoque ton nom! Ce n'est pas en raison de nos oeuvres justes que nous répandons devant toi nos supplications, mais en raison de tes grandes miséricordes.
###### 19
Seigneur, écoute! Seigneur, pardonne! Seigneur, veille et agis! Ne tarde point! par toi-même, mon Dieu! car ton nom est invoqué sur ta ville et ton peuple."
###### 20
Je parlais encore, proférant ma prière, confessant mes péchés et les péchés de mon peuple Israël, et répandant ma supplication devant Yahvé mon Dieu, pour la sainte montagne de mon Dieu;
###### 21
je parlais encore en prière, quand Gabriel, l'être que j'avais vu en vision au début, fondit sur moi en plein vol, à l'heure de l'oblation du soir.
###### 22
Il vint, me parla et me dit : "Daniel, me voici : je suis sorti pour venir t'instruire dans l'intelligence.
###### 23
Dès le début de ta supplication une parole a été émise et je suis venu te l'annoncer. Tu es l'homme des prédilections. Pénètre la parole, comprends la vision
###### 24
"Sont assignées 70 semaines pour ton peuple et ta ville sainte pour mettre un terme à la transgression, pour apposer les scellés aux péchés, pour expier l'iniquité, pour introduire éternelle justice, pour sceller vision et prophétie, pour oindre le Saint des Saints.
###### 25
Prends-en connaissance et intelligence Depuis l'instant que sortit cette parole Qu'on revienne et qu'on rebâtisse Jérusalem jusqu'à un Prince Messie, sept semaines et 62 semaines, restaurés, rebâtis places et remparts, mais dans l'angoisse des temps.
###### 26
Et après les 62 semaines, un messie supprimé, et il n'y a pas pour lui... la ville et le sanctuaire détruits par un prince qui viendra. Sa fin sera dans le cataclysme et, jusqu'à la fin, la guerre et les désastres décrétés.
###### 27
Et il consolidera une alliance avec un grand nombre. Le temps d'une semaine; et le temps d'une demi- semaine il fera cesser le sacrifice et l'oblation, et sur l'aile du Temple sera l'abomination de la désolation jusqu'à la fin, jusqu'au terme assigné pour le désolateur."
