---
aliases : 
- Daniel 12
- Daniel 12
- Dn 12
tags : 
- Bible/Dn/12
- français
cssclass : français
---

# Daniel 12

###### 1
"En ce temps se lèvera Michel, le grand Prince qui se tient auprès des enfants de ton peuple. Ce sera un temps d'angoisse tel qu'il n'y en aura pas eu jusqu'alors depuis que nation existe. En ce temps-là, ton peuple échappera : tous ceux qui se trouveront inscrits dans le Livre.
###### 2
"Un grand nombre de ceux qui dorment au pays de la poussière s'éveilleront, les uns pour la vie éternelle, les autres pour l'opprobre, pour l'horreur éternelle.
###### 3
Les doctes resplendiront comme la splendeur du firmament, et ceux qui ont enseigné la justice à un grand nombre, comme les étoiles, pour toute l'éternité.
###### 4
Toi, Daniel, serre ces paroles et scelle le livre jusqu'au temps de la Fin. Beaucoup erreront de-ci de-là, et l'iniquité grandira."
###### 5
Je regardai, moi Daniel, et voici : deux autres se tenaient debout, de part et d'autre du fleuve.
###### 6
L'un dit à l'homme vêtu de lin, qui était en amont du fleuve "Jusques à quand, le temps des choses inouïes?"
###### 7
J'entendis l'homme vêtu de lin, qui se tenait en amont du fleuve : il leva la main droite et la main gauche vers le ciel et attesta par l'Eternel Vivant : "Pour un temps, des temps et un demi-temps, et toutes ces choses s'achèveront quand sera achevé l'écrasement de la force du Peuple saint."
###### 8
J'écoutai sans comprendre. Puis je dis : "Mon Seigneur, quel sera cet achèvement?"
###### 9
Il dit : "Va, Daniel; ces paroles sont closes et scellées jusqu'au temps de la Fin.
###### 10
Beaucoup seront lavés, blanchis et purifiés; les méchants feront le mal, les méchants ne comprendront point; les doctes comprendront.
###### 11
A compter du moment où sera aboli le sacrifice perpétuel et posée l'abomination de la désolation : 1.290 jours.
###### 12
Heureux celui qui tiendra et qui atteindra 1.335 jours.
###### 13
Pour toi, va, prends ton repos; et tu te lèveras pour ta part à la fin des jours."
