---
aliases : 
- Daniel 6
- Daniel 6
- Dn 6
tags : 
- Bible/Dn/6
- français
cssclass : français
---

# Daniel 6

###### 1
et Darius le Mède reçut le royaume, étant âgé déjà de 62 ans.
###### 2
Il plut à Darius d'établir sur son royaume 120 satrapes pour tout le royaume,
###### 3
sous la présidence de trois chefs Daniel en était un auxquels les satrapes auraient à rendre compte. Ceci afin d'empêcher qu'un tort fût fait au roi.
###### 4
Ce même Daniel l'emportait si bien sur les chefs et les satrapes parce qu'il avait en lui un esprit extraordinaire, que le roi se proposait de le placer à la tête du royaume tout entier.
###### 5
Alors les chefs et les satrapes se mirent en quête d'une affaire d'Etat qui pût faire du tort à Daniel; mais ils ne purent trouver d'affaire ou de manquement tant il était fidèle, et on ne trouvait à lui reprocher ni négligence ni manquement.
###### 6
Ces hommes se dirent donc : "Faute d'affaire au préjudice de ce Daniel, trouvons-en une contre lui à propos de la religion de son Dieu."
###### 7
Chefs et satrapes s'en vinrent donc en nombre auprès du roi et lui parlèrent ainsi : "O roi Darius, vis à jamais!
###### 8
Chefs du royaume, magistrats, satrapes, ministres et gouverneurs, nous sommes tous d'avis que le roi devrait rendre un édit pour donner vigueur à l'interdit suivant : tout homme qui, au cours des 30 jours à venir, adressera une prière à quiconque, dieu ou homme, autre que toi, ô roi, sera jeté à la fosse aux lions.
###### 9
O roi, donne à présent force de loi à cet interdit en signant cet acte, en sorte qu'on n'y change rien, selon la loi des Mèdes et des Perses, laquelle ne passe point."
###### 10
En raison de quoi, le roi Darius signa l'acte d'interdit.
###### 11
Apprenant que l'acte avait été signé, Daniel monta dans sa maison. Les fenêtres de sa chambre haute étaient orientées vers Jérusalem, et trois fois par jour il se mettait à genoux, priant et confessant Dieu; c'est ainsi qu'il avait toujours fait.
###### 12
Ces hommes s'en vinrent en nombre et trouvèrent Daniel qui suppliait et implorait Dieu.
###### 13
Alors ils s'introduisirent auprès du roi et lui rappelèrent l'interdit royal : "N'as-tu pas signé l'interdit selon lequel tout homme qui, dans les 30 jours, adresserait une prière à quiconque, dieu ou homme, autre que toi, ô roi, serait jeté dans la fosse aux lions?" Le roi répondit : "La chose est tranchée définitivement, selon la loi des Mèdes et des Perses, laquelle ne passe point."
###### 14
Sur quoi, ils dirent au roi : "Daniel, cet homme d'entre les gens de la déportation de Juda, n'a cure de toi, ô roi, ni de l'interdit que tu as signé : trois fois par jour il s'acquitte de sa prière."
###### 15
En entendant ces mots, le roi éprouva une grande douleur et résolut de sauver Daniel. Jusqu'au coucher du soleil, il s'ingénia à lui trouver une échappatoire.
###### 16
Mais ces hommes s'empressèrent auprès du roi en disant "Sache, ô roi, que selon la loi des Mèdes et des Perses aucun interdit ou édit porté par le roi ne peut être révoqué."
###### 17
Alors, le roi donna ordre de faire venir Daniel et de le jeter dans la fosse aux lions. Le roi dit à Daniel : "Ton Dieu, que tu as servi avec persévérance, c'est lui qui te sauvera."
###### 18
On apporta une pierre qu'on posa sur l'entrée de la fosse, et le roi y apposa son sceau et celui de ses seigneurs, en sorte que rien ne pût être modifié de ce qui concernait Daniel.
###### 19
Le roi rentra dans son palais, passa la nuit à jeûner et ne se laissa pas amener de concubines. Le sommeil le fuit
###### 20
et dès l'aube, au petit jour, le roi se leva et se rendit en hâte à la fosse aux lions.
###### 21
S'approchant de la fosse, il cria à Daniel d'une voix angoissée : "Daniel, serviteur du Dieu vivant, ce Dieu que tu sers avec persévérance a-t-il pu te faire échapper aux lions?"
###### 22
Daniel répondit au roi : "O roi, vis à jamais!
###### 23
Mon Dieu a envoyé son ange, il a fermé la gueule des lions et ils ne m'ont pas fait de mal, parce que j'ai été trouvé innocent devant lui. Et devant toi aussi, ô roi, je suis sans faute."
###### 24
Le roi éprouva une grande joie et ordonna de faire sortir Daniel de la fosse. On fit sortir Daniel de la fosse et on le trouva indemne, parce qu'il avait eu foi en son Dieu.
###### 25
Le roi manda ces hommes qui avaient calomnié Daniel et les fit jeter dans la fosse aux lions, eux, leurs enfants et leurs femmes : et avant même qu'ils eussent atteint le fond de la fosse, les lions s'étaient emparés d'eux et leur avaient broyé les os.
###### 26
Et le roi Darius écrivit à tous peuples, nations et langues qui habitent sur toute la terre : "Abondance de paix sur vous!
###### 27
Voici le décret que je porte : dans tout le domaine de mon royaume, que les gens tremblent et frémissent devant le Dieu de Daniel il est le Dieu vivant, il perdure à jamais, son royaume ne sera point détruit et son empire n'aura point de fin 
###### 28
il sauve et délivre, opère signes et merveilles aux cieux et sur la terre; il a sauvé Daniel du pouvoir des lions."
###### 29
Ce même Daniel fleurit sous le règne de Darius et sous le règne de Cyrus le Perse.
