---
aliases : 
- Daniel 11
- Daniel 11
- Dn 11
tags : 
- Bible/Dn/11
- français
cssclass : français
---

# Daniel 11

###### 1
mon appui pour me prêter main-forte et me soutenir.
###### 2
A présent, je vais t'annoncer la vérité. "Voici : trois rois encore se lèveront pour la Perse; le quatrième aura plus de richesses qu'eux tous, et lorsque sa richesse l'aura rendu puissant, il se lèvera contre tous les royaumes de Yavân.
###### 3
Un roi vaillant se lèvera et gouvernera un vaste empire et fera ce qu'il lui plaît.
###### 4
Tandis qu'il s'élèvera, son royaume sera brisé et partagé aux quatre vents du ciel, mais non pas au profit de sa descendance; il ne sera pas gouverné comme il l'avait gouverné, car son royaume sera extirpé et livré à d'autres qu'elle.
###### 5
Le roi du Midi deviendra fort; un de ses princes l'emportera sur lui et son empire sera plus grand que le sien.
###### 6
Quelques années plus tard ils contracteront une alliance et la fille du roi du Midi s'en viendra auprès du roi du Nord pour exécuter les accords. Mais la force de son bras ne tiendra pas, ni sa descendance ne subsistera : elle sera livrée, elle et ceux qui l'ont amenée, et son enfant, et celui qui a eu pouvoir sur elle. En son temps,
###### 7
un rejeton de ses racines se lèvera à sa place, qui s'en viendra vers les remparts et pénétrera dans la forteresse du roi du Nord, et il les traitera en vainqueur.
###### 8
Leurs dieux mêmes, leurs statues et leurs vases précieux d'argent et d'or seront le butin qu'il emportera en Egypte. Pendant quelques années il se tiendra à distance du roi du Nord.
###### 9
Il se rendra vers le royaume du roi du Midi puis s'en retournera dans son pays.
###### 10
Ses fils se lèveront et réuniront une multitude de forces puissantes, et il s'avancera, déferlera, passera et se lèvera de nouveau jusqu'à sa forteresse.
###### 11
Et le roi du Midi se mettra en fureur et partira en guerre contre le roi du Nord qui ralliera une grande multitude; mais la multitude sera livrée entre ses mains.
###### 12
La multitude sera anéantie; son coeur s'exaltera, il abattra des myriades, mais il n'aura point de force.
###### 13
Le roi du Nord reviendra, ayant levé des multitudes plus nombreuses que les premières, et après des années il s'avancera avec une grande armée et un abondant équipement.
###### 14
En ces temps un grand nombre se dresseront contre le roi du Midi et les violents parmi ceux de ton peuple se lèveront pour accomplir la vision, mais ils trébucheront.
###### 15
Viendra le roi du Nord qui construira des retranchements pour assiéger une ville fortifiée. Les bras du Midi ne résisteront pas; l'élite du peuple n'aura pas la force de résister.
###### 16
Celui qui s'avance contre lui le traitera selon son bon plaisir, personne ne lui résistera : il se tiendra dans le Pays de Splendeur, la destruction entre les mains.
###### 17
Il aura en tête de conquérir son royaume tout entier; puis il fera un pacte avec lui en lui donnant une fille des femmes afin de le détruire, mais cela ne tiendra pas et ne sera pas à lui.
###### 18
Il se tournera vers les îles et en prendra un grand nombre; mais un magistrat fera cesser son outrage sans qu'il puisse lui revaloir son outrage.
###### 19
Il tournera sa face vers les bastions de son pays, mais il trébuchera, tombera, on ne le trouvera plus.
###### 20
A sa place en viendra un qui fera passer un exacteur portant atteinte à la splendeur royale : en quelques jours il sera brisé, mais non au vu de tous ou à la guerre.
###### 21
"A sa place se lèvera un misérable : on ne lui donnera pas les honneurs de la royauté. Il s'en viendra à son aise et s'emparera du royaume par des intrigues.
###### 22
Les forces seront en débâcle devant lui et seront brisées même le Prince d'une alliance.
###### 23
Par ses complicités il agira en traître et ira en se fortifiant, bien qu'avec peu de monde.
###### 24
A son aise, il envahira les grasses provinces, agissant comme n'avaient agi ni ses pères ni les pères de ses pères, dispersant parmi eux butin, profits et richesses, tendant ses stratagèmes contre les forteresses, pour un temps.
###### 25
Il excitera sa force et son coeur contre le roi du Midi, avec une grande armée. Le roi du Midi se lèvera pour la guerre avec une armée très grande et très puissante, mais il ne tiendra pas, car des stratagèmes seront tendus contre lui.
###### 26
Et ceux qui mangeaient de ses mets le mettront en pièces; son armée sera débordée, et nombreux tomberont les morts.
###### 27
Les deux rois, leur coeur tourné vers le mal, assis à la même table, diront des mensonges; mais ils n'aboutiront point, car le temps fixé est encore à venir.
###### 28
Il rentrera dans son pays avec de grandes richesses, le coeur contre l'Alliance sainte; il agira, puis il rentrera dans son pays.
###### 29
Le moment venu, il retournera vers le Midi, mais il n'en sera pas de la fin comme du commencement.
###### 30
Les vaisseaux des Kittim viendront contre lui et il sera découragé. Il reviendra et sévira furieusement contre l'Alliance sainte, et de nouveau, il aura en considération ceux qui abandonnent l'Alliance sainte.
###### 31
Des forces viendront de sa part profaner le sanctuaire-citadelle, ils aboliront le sacrifice perpétuel, et y mettront l'abomination de la désolation.
###### 32
Ceux qui transgressent l'Alliance, il les pervertira par ses paroles douces, mais les gens qui connaissent leur Dieu s'affermiront et agiront.
###### 33
Les doctes d'entre le peuple enseigneront la multitude; ils trébucheront par l'épée et la flamme, et la captivité et la spoliation durant des jours.
###### 34
Qu'ils trébuchent, peu de gens leur viendront en aide; nombreux seront ceux qui s'associeront à eux par des intrigues.
###### 35
Parmi les doctes, certains trébucheront, en sorte que dans le nombre il y en ait qui soient purifiés, lavés et blanchis jusqu'au temps de la Fin, car le temps fixé est encore à venir.
###### 36
Le roi agira selon son bon plaisir, s'enorgueillissant et s'exaltant par-dessus tous les dieux, contre le Dieu des dieux il dira des choses inouïes et il prospérera jusqu'à ce que soit comble la colère car ce qui est déterminé s'accomplira.
###### 37
Sans égards pour les dieux de ses pères, sans égards pour le favori des femmes ou pour tout autre dieu, c'est lui-même qu'il exaltera au-dessus de tout.
###### 38
A leur place il vénérera le dieu des forteresses, il vénérera un dieu que ses pères n'ont point connu, par l'or et l'argent, pierres précieuses et choses de prix.
###### 39
Il prendra comme défenseurs des forteresses le peuple d'un dieu étranger, à ceux qu'il reconnaîtra, il fera grands honneurs en leur donnant autorité sur la multitude, et en partageant la terre pour un rendement.
###### 40
"Au temps de la Fin, le roi du Midi s'affrontera avec lui; le roi du Nord déferlera sur lui avec ses chars, ses cavaliers et ses nombreux navires. Il viendra dans les pays, qu'il envahira et traversera.
###### 41
Il viendra dans le Pays de Splendeur, et il en tombera un grand nombre, mais ceux-ci échapperont de ses mains : Edom et Moab et les restes des fils d'Ammon.
###### 42
Il étendra sa main sur les pays : le pays d'Egypte n'y échappera point.
###### 43
Il aura en son pouvoir les trésors d'or et d'argent et toutes les choses précieuses d'Egypte. Libyens et Kushites seront à ses pieds.
###### 44
Mais des rumeurs viendront le troubler de l'Orient et du Nord; il s'en ira en grande fureur détruire et exterminer une multitude.
###### 45
Il dressera les tentes de ses quartiers entre la mer et les monts de la Sainte Splendeur. Il s'en ira jusqu'à son terme pour lui aucun secours.
