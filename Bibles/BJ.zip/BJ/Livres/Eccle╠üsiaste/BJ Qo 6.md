---
aliases : 
- Ecclésiaste 6
- Ecclésiaste 6
- Qo 6
- Ecclesiastes 6
tags : 
- Bible/Qo/6
- français
cssclass : français
---

# Ecclésiaste 6

###### 1
Il y a un autre mal que je vois sous le soleil et qui est grand pour l'homme : 
###### 2
soit un homme à qui Dieu donne richesses, ressources et gloire, et à qui rien ne manque de tout ce qu'il peut désirer; mais Dieu ne le laisse pas maître de s'en nourrir et c'est un étranger qui s'en nourrit : cela est vanité et cruelle souffrance. 
###### 3
Soit un homme qui a eu cent enfants et a vécu de nombreuses années, et alors que ses années ont été nombreuses, il ne s'est pas rassasié de bonheur et il n'a même pas de tombeau : je vois que l'avorton est plus heureux que lui. 
###### 4
Il est venu dans la vanité, il s'en va dans les ténèbres, et dans les ténèbres son nom est enseveli. 
###### 5
Il n'a même pas vu le soleil et ne l'a pas connu : il y a plus de repos pour lui que pour l'autre. 
###### 6
Et même s'il avait vécu deux fois mille ans, il n'aurait pas vu le bonheur; n'est-ce pas vers un même lieu que tous s'en vont ? 
###### 7
Toute la peine que prend l'homme est pour sa bouche, et pourtant son appétit n'est jamais satisfait. 
###### 8
Quel avantage a le sage sur l'insensé ? Et qu'en est-il de l'indigent qui sait se conduire devant les vivants ? 
###### 9
Mieux vaut ce que voient les yeux que le mouvement du désir, cela aussi est vanité et poursuite de vent! 
###### 10
Ce qui fut a déjà été nommé et l'on sait ce qu'est un homme : il ne peut faire procès à celui qui est plus fort que lui. 
###### 11
Plus il y a de paroles, plus il y a de vanité, quel avantage pour l'homme ? 
###### 12
Et qui sait ce qui convient à l'homme pendant sa vie, tout au long des jours de la vie de vanité qu'il passe comme une ombre ? Qui annoncera à l'homme ce qui doit venir après lui sous le soleil ? 
