---
aliases : 
- Ecclésiaste 11
- Ecclésiaste 11
- Qo 11
- Ecclesiastes 11
tags : 
- Bible/Qo/11
- français
cssclass : français
---

# Ecclésiaste 11

###### 1
Lance ton pain sur l'eau, à la longue tu le retrouveras. 
###### 2
Donne une part à sept ou à huit, car tu ne sais pas quel malheur peut venir sur la terre. 
###### 3
Si les nuages sont pleins de pluie, ils la déversent sur la terre; et si un arbre tombe, au sud ou bien au nord, l'arbre reste où il est tombé. 
###### 4
Qui observe le vent ne sème pas, qui regarde les nuages ne moissonne pas. 
###### 5
De même que tu ne connais pas le chemin que suit le vent, ou celui de l'embryon dans le sein de la femme, de même tu ne connais pas l'œuvre de Dieu qui fait tout. 
###### 6
Le matin, sème ton grain, et le soir, ne laisse pas ta main inactive, car de deux choses tu ne sais pas celle qui réussira, ou si elles sont aussi bonnes l'une que l'autre. 
###### 7
Douce est la lumière et il plaît aux yeux de voir le soleil; 
###### 8
si l'homme vit de longues années, qu'il profite de toutes, mais qu'il se rappelle que les jours de ténèbres seront nombreux : tout ce qui vient est vanité. 
###### 9
Réjouis-toi, jeune homme, dans ta jeunesse, sois heureux aux jours de ton adolescence, suis les voies de ton cœur et les désirs de tes yeux, mais sache que sur tout cela Dieu te fera venir en jugement. 
###### 10
Éloigne de ton cœur le chagrin, écarte de ta chair la souffrance, mais la jeunesse et l'âge des cheveux noirs sont vanité. 
