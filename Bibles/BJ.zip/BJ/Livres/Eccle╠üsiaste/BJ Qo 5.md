---
aliases : 
- Ecclésiaste 5
- Ecclésiaste 5
- Qo 5
- Ecclesiastes 5
tags : 
- Bible/Qo/5
- français
cssclass : français
---

# Ecclésiaste 5

###### 1
Ne hâte pas tes lèvres, que ton cœur ne se presse pas de proférer une parole devant Dieu, car Dieu est au ciel et toi sur la terre; aussi, que tes paroles soient peu nombreuses. 
###### 2
Car du nombre des tracas vient le songe, du nombre des paroles, le ton de l'insensé. 
###### 3
Si tu fais un vœu à Dieu, ne tarde pas à l'accomplir, car Dieu n'aime pas les insensés. Ton vœu, accomplis-le. 
###### 4
Et mieux vaut ne pas faire de vœu que d'en faire un sans l'accomplir. 
###### 5
Ne laisse pas ta bouche faire de toi un pécheur. Et ne va pas dire au Messager que c'était par inadvertance : pourquoi donner à Dieu l'occasion de s'irriter contre toi et de ruiner l'œuvre de tes mains ? 
###### 6
Car du nombre des songes viennent les vanités et les paroles multipliées. 
###### 7
Si tu vois dans une province le pauvre opprimé, la justice et le droit bafoués, n'en sois pas surpris; car au-dessus d'une autorité veille une plus haute autorité, et de plus hautes au-dessus d'elles. 
###### 8
Mais le profit qu'on tire d'une terre est à tous, un roi est servi par les champs. 
###### 9
Qui aime l'argent ne se rassasie pas d'argent, qui aime l'abondance n'a pas de revenu, cela aussi est vanité. 
###### 10
Où abonde le bien, abondent ceux qui le mangent, quel avantage pour le propriétaire, sinon un spectacle pour les yeux ? 
###### 11
Le sommeil du travailleur est doux, qu'il ait mangé peu ou beaucoup; mais la satiété du riche ne le laisse pas dormir. 
###### 12
Il est un tort criant que je vois sous le soleil : la richesse gardée par son possesseur à son propre détriment. 
###### 13
Il perd cette richesse dans une mauvaise affaire, il met au monde un fils, il n'a plus rien en main. 
###### 14
Comme il était sorti du sein de sa mère, tout nu, il s'en retournera, comme il était venu. De son travail il n'a rien retiré qui lui reste en main. 
###### 15
Cela aussi est un tort criant qu'il s'en aille comme il était venu : Quel profit retire-t-il d'avoir travaillé pour le vent ? 
###### 16
Et puis tous ses jours se passent dans l'obscurité, le deuil, les chagrins nombreux, la maladie et l'irritation. 
###### 17
Voici ce que j'ai vu : le bonheur qui convient à l'homme, c'est de manger et de boire, et de trouver le bonheur dans tout le travail qu'il accomplit sous le soleil, tout au long des jours de la vie que Dieu lui donne, car c'est là sa part. 
###### 18
Et tout homme à qui Dieu donne richesses et ressources, qu'il laisse maître de s'en nourrir, d'en recevoir sa part et de jouir de son travail, cela est un don de Dieu. 
###### 19
Car il ne se souvient guère des jours de sa vie tant que Dieu occupe son cœur à la joie. 
