---
aliases : 
- Ecclésiaste 3
- Ecclésiaste 3
- Qo 3
- Ecclesiastes 3
tags : 
- Bible/Qo/3
- français
cssclass : français
---

# Ecclésiaste 3

###### 1
Il y a un moment pour tout et un temps pour toute chose sous le ciel. 
###### 2
Un temps pour enfanter, et un temps pour mourir; un temps pour planter, et un temps pour arracher le plant. 
###### 3
Un temps pour tuer, et un temps pour guérir; un temps pour détruire, et un temps pour bâtir. 
###### 4
Un temps pour pleurer, et un temps pour rire; un temps pour gémir, et un temps pour danser. 
###### 5
Un temps pour lancer des pierres, et un temps pour en ramasser; un temps pour embrasser, et un temps pour s'abstenir d'embrassements. 
###### 6
Un temps pour chercher, et un temps pour perdre; un temps pour garder, et un temps pour jeter. 
###### 7
Un temps pour déchirer, et un temps pour coudre; un temps pour se taire, et un temps pour parler. 
###### 8
Un temps pour aimer, et un temps pour haïr; un temps pour la guerre, et un temps pour la paix. 
###### 9
Quel profit celui qui travaille trouve-t-il à la peine qu'il prend ? 
###### 10
Je regarde la tâche que Dieu donne aux enfants des hommes : 
###### 11
tout ce qu'il fait convient en son temps. Il a mis dans leur cœur l'ensemble du temps, mais sans que l'homme puisse saisir ce que Dieu fait, du commencement à la fin. 
###### 12
Et je sais qu'il n'y a pas de bonheur pour l'homme, sinon dans le plaisir et le bien-être durant sa vie. 
###### 13
Et si un homme mange, boit et trouve le bonheur dans son travail, cela est un don de Dieu. 
###### 14
Je sais que tout ce que Dieu fait sera pour toujours. A cela il n'y a rien à ajouter, de cela il n'y a rien à retrancher, et Dieu fait en sorte qu'on le craigne. 
###### 15
Ce qui est fut déjà; ce qui sera est déjà. Or Dieu recherche le persécuté. 
###### 16
Je regarde encore sous le soleil : à la place du droit, là se trouve le crime, à la place du juste se trouve le criminel; 
###### 17
et je me dis en moi-même : le juste et le criminel, Dieu les jugera, car il y a un temps pour toutes choses et pour toute action ici. 
###### 18
Je me dis en moi-même, en ce qui concerne les enfants des hommes : c'est pour que Dieu les éprouve et leur montre qu'ils sont des bêtes. 
###### 19
Car le sort de l'homme et le sort de la bête sont un sort identique : comme meurt l'un, ainsi meurt l'autre, et c'est un même souffle qu'ils ont tous les deux. La supériorité de l'homme sur la bête est nulle, car tout est vanité. 
###### 20
Tout s'en va vers un même lieu : tout vient de la poussière, tout s'en retourne à la poussière. 
###### 21
Qui sait si le souffle de l'homme monte vers le haut et si le souffle de la bête descend en bas, vers la terre ? 
###### 22
Je vois qu'il n'y a de bonheur pour l'homme qu'à se réjouir de ses œuvres, car c'est là sa part. Qui donc l'emmènera voir ce qui sera après lui ? 
