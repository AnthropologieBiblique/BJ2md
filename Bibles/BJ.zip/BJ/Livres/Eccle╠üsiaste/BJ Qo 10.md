---
aliases : 
- Ecclésiaste 10
- Ecclésiaste 10
- Qo 10
- Ecclesiastes 10
tags : 
- Bible/Qo/10
- français
cssclass : français
---

# Ecclésiaste 10

###### 1
Une mouche morte gâte l'huile du parfumeur, un peu de sottise compte plus que sagesse et gloire. 
###### 2
Le sage se dirige bien, l'insensé va de travers. 
###### 3
Qu'il avance sur la route, celui qui est insensé, l'esprit lui manque, et tous disent : " C'est un insensé! " 
###### 4
Si l'humeur de celui qui commande se monte contre toi, ne quitte pas ta place, car le calme évite de grands péchés. 
###### 5
Il y a un mal que je vois sous le soleil, c'est comme une méprise de la part du souverain : 
###### 6
la folie placée au plus haut et des riches qui restent dans l'abaissement. 
###### 7
Je vois des esclaves aller à cheval et des princes à pied comme des esclaves. 
###### 8
Qui creuse une fosse tombe dedans, qui sape un mur, un serpent le mord; 
###### 9
qui extrait des pierres se blesse avec, qui fend du bois prend un risque. 
###### 10
Si le fer est émoussé et qu'on n'en aiguise pas la lame, il faut redoubler de forces; mais il y a profit à faire aboutir la sagesse. 
###### 11
Si, faute d'être charmé, le serpent mord, il n'y a pas de profit pour le charmeur. 
###### 12
Les paroles du sage plaisent, les lèvres de l'insensé le perdront : 
###### 13
le début de ses paroles est folie et la fin de son propos perfide sottise. 
###### 14
Le fou multiplie les paroles, mais l'homme ne sait pas ce qui sera : ce qui arrivera après lui, qui le lui annoncera ? 
###### 15
Le travail de l'insensé le fatigue, lui qui ne sait même pas aller à la ville. 
###### 16
Malheur à toi, pays dont le roi est un gamin, et dont les princes mangent dès le matin! 
###### 17
Heureux le pays dont le roi est né noble, dont les princes mangent au temps voulu pour prendre des forces et non pour banqueter! 
###### 18
Pour des mains paresseuses, la poutre cède, pour des mains négligentes, il pleut dans la maison. 
###### 19
Pour se divertir on fait un repas, le vin réjouit les vivants et l'argent a réponse à tout. 
###### 20
Ne maudis pas le roi, fût-ce en pensée, ne maudis pas le riche, fût-ce dans ta chambre, car un oiseau du ciel emporterait le bruit, celui qui a des ailes redirait ta parole. 
