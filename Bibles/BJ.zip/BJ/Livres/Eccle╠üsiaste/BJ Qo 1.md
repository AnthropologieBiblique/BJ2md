---
aliases : 
- Ecclésiaste 1
- Ecclésiaste 1
- Qo 1
- Ecclesiastes 1
tags : 
- Bible/Qo/1
- français
cssclass : français
---

# Ecclésiaste 1

###### 1
Paroles de Qohélet, fils de David, roi à Jérusalem.
###### 2
Vanité des vanités, dit Qohélet; vanité des vanités, tout est vanité. 
###### 3
Quel profit trouve l'homme à toute la peine qu'il prend sous le soleil ? 
###### 4
Un âge va, un âge vient, mais la terre tient toujours. 
###### 5
Le soleil se lève, le soleil se couche, il se hâte vers son lieu et c'est là qu'il se lève. 
###### 6
Le vent part au midi, tourne au nord, il tourne, tourne et va, et sur son parcours retourne le vent. 
###### 7
Tous les fleuves coulent vers la mer et la mer n'est pas remplie. Vers l'endroit où coulent les fleuves, c'est par là qu'ils continueront de couler. 
###### 8
Toute parole est lassante! Personne ne peut dire que l'œil n'est pas rassasié de voir, et l'oreille saturée par ce qu'elle a entendu. 
###### 9
Ce qui fut, cela sera, ce qui s'est fait se refera, et il n'y a rien de nouveau sous le soleil! 
###### 10
Qu'il y ait quelque chose dont on dise : " Tiens, voilà du nouveau! ", cela fut dans les siècles qui nous ont précédés. 
###### 11
Il n'y a pas de souvenir d'autrefois, et même pour ceux des temps futurs : il n'y aura d'eux aucun souvenir auprès de ceux qui les suivront. 
###### 12
Moi, Qohélet, j'ai été roi d'Israël à Jérusalem. 
###### 13
J'ai mis tout mon cœur à rechercher et à explorer par la sagesse tout ce qui se fait sous le ciel. C'est une mauvaise besogne que Dieu a donnée aux enfants des hommes pour qu'ils s'y emploient. 
###### 14
J'ai regardé toutes les œuvres qui se font sous le soleil : eh bien, tout est vanité et poursuite de vent! 
###### 15
Ce qui est courbé ne peut être redressé, ce qui manque ne peut être compté. 
###### 16
Je me suis dit à moi-même : Voici que j'ai amassé et accumulé la sagesse plus que quiconque avant moi à Jérusalem, et, en moi-même, j'ai pénétré toute sorte de sagesse et de savoir. 
###### 17
J'ai mis tout mon cœur à comprendre la sagesse et le savoir, la sottise et la folie, et j'ai compris que tout cela aussi est recherche de vent. 
###### 18
Beaucoup de sagesse, beaucoup de chagrin; plus de savoir, plus de douleur. 
