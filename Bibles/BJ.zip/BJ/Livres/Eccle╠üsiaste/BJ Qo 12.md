---
aliases : 
- Ecclésiaste 12
- Ecclésiaste 12
- Qo 12
- Ecclesiastes 12
tags : 
- Bible/Qo/12
- français
cssclass : français
---

# Ecclésiaste 12

###### 1
Et souviens-toi de ton Créateur aux jours de ton adolescence, avant que viennent les jours mauvais et qu'arrivent les années dont tu diras : " Je ne les aime pas "; 
###### 2
avant que s'obscurcissent le soleil et la lumière, la lune et les étoiles, et que reviennent les nuages après la pluie; 
###### 3
au jour où tremblent les gardiens de la maison, où se courbent les hommes vigoureux, où les femmes, l'une après l'autre, cessent de moudre, où l'obscurité gagne celles qui regardent par la fenêtre. 
###### 4
Quand la porte est fermée sur la rue, quand tombe la voix du moulin, quand on se lève à la voix de l'oiseau, quand se taisent toutes les chansons. 
###### 5
Quand on redoute la montée et qu'on a des frayeurs en chemin. Et l'amandier est en fleur, et la sauterelle est pesante, et la câpre perd son goût. Tandis que l'homme s'en va vers sa maison d'éternité et les pleureurs tournent déjà dans la rue. 
###### 6
Avant que lâche le fil d'argent, que la coupe d'or se brise, que la jarre se casse à la fontaine, que la poulie se rompe au puits 
###### 7
et que la poussière retourne à la terre comme elle en est venue, et le souffle à Dieu qui l'a donné. 
###### 8
Vanité des vanités, dit Qohélet, tout est vanité. 
###### 9
Sans compter que Qohélet fut un sage, il a encore enseigné au peuple le savoir; il a pesé, examiné et corrigé beaucoup de proverbes; 
###### 10
Qohélet s'est efforcé de trouver beaucoup de paroles plaisantes et d'écrire des paroles de vérité. 
###### 11
Les paroles du sage sont comme des aiguillons et comme des piquets plantés par les maîtres de troupeaux; ils sont mis par le même pasteur. 
###### 12
En plus de cela, mon fils, sois averti que faire des livres est un travail sans fin et que beaucoup d'étude fatigue le corps. 
###### 13
Fin du discours. Tout est entendu. Crains Dieu et observe ses commandements, car c'est là le devoir de tout homme. 
###### 14
Car Dieu amènera en jugement toutes les actions de l'homme, tout ce qui est caché, que ce soit bien ou mal. 
