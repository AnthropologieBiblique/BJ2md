---
aliases : 
- Ecclésiaste 4
- Ecclésiaste 4
- Qo 4
- Ecclesiastes 4
tags : 
- Bible/Qo/4
- français
cssclass : français
---

# Ecclésiaste 4

###### 1
Je regarde encore toute l'oppression qui se commet sous le soleil : Voici les larmes des opprimés, et ils n'ont pas de consolateur; et la force du côté des oppresseurs, et ils n'ont pas de consolateur. 
###### 2
Alors je félicite les morts qui sont déjà morts plutôt que les vivants qui sont encore vivants. 
###### 3
Et plus heureux que tous les deux est celui qui ne vit pas encore et ne voit pas l'iniquité qui se commet sous le soleil. 
###### 4
Et je vois que tout travail et toute réussite n'est que jalousie de l'un pour l'autre : cela est vanité et poursuite de vent! 
###### 5
l'insensé se croise les bras et se dévore lui-même. 
###### 6
Mieux vaut une poignée de repos que deux poignées de travail à poursuivre le vent. 
###### 7
Je vois encore une autre vanité sous le soleil : 
###### 8
soit quelqu'un de seul qui n'a pas de second, pas de fils ni de frère; il n'y a pas de limite à toute sa besogne , et ses yeux ne sont pas rassasiés de richesses : " Pour qui donc est-ce que je travaille et me prive de bonheur ? " Cela aussi est vanité, et c'est une mauvaise besogne. 
###### 9
Mieux vaut être deux que seul, car ainsi le travail donne bon profit. 
###### 10
En cas de chute, l'un relève l'autre; mais qu'en est-il de celui qui tombe sans personne pour le relever ? 
###### 11
Et si l'on couche à deux, on se réchauffe, mais seul, comment avoir chaud ? 
###### 12
Là où un homme seul est renversé, deux résistent, et le fil triple ne rompt pas facilement. 
###### 13
Mieux vaut un enfant pauvre et sage qu'un roi vieux et insensé qui ne sait plus prendre conseil. 
###### 14
Même s'il est sorti de prison pour régner, et même s'il est né mendiant dans le royaume, 
###### 15
je vois tous les vivants qui vont sous le soleil être avec l'enfant, le second, l'usurpateur, 
###### 16
et c'est d'une foule sans fin qu'il se trouve à la tête. Mais ceux qui viennent après ne s'en réjouiront pas, car cela aussi est vanité et recherche de vent. 
###### 17
Prends garde à tes pas quand tu vas à la Maison de Dieu : approcher pour écouter vaut mieux que le sacrifice offert par les insensés, mais ils ne savent pas qu'ils font le mal. 
