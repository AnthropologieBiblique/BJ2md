---
aliases : 
- Esther, Grec 10
- Esther, Grec 10
- Estgrec 10
- Esther, Greek 10
tags : 
- Bible/Estgrec/10
- français
cssclass : français
---

# Esther, Grec 10

###### 1
Le roi Assuérus leva tribut sur le continent et sur les îles de la mer.
###### 2
Tous les exploits de sa vigueur et de sa vaillance, ainsi que la relation de l'élévation de Mardochée qu'il avait exalté, tout cela est écrit dans le livre des Chroniques des rois des Mèdes et des Perses.
###### 3
Car le Juif Mardochée était le premier après le roi Assuérus. C'était un homme considéré par les Juifs, aimé par la multitude de ses frères, recherchant le bien de son peuple et se préoccupant du bonheur de sa race. 
###### 3
Et Mardochée dit : "C'est de Dieu qu'est venu tout cela! 
###### 3
Si je me remémore le songe que j'eus à ce sujet, rien n'a été omis 
###### 3
ni la petite source qui devient un fleuve, ni la lumière qui brille, ni le soleil, ni l'abondance d'eaux. Esther est ce fleuve, elle qu'épousa le roi et qu'il fit reine. 
###### 3
Les deux dragons, c'est Aman et moi. 
###### 3
Les peuples, ce sont ceux qui se coalisèrent pour détruire le nom des Juifs. 
###### 3
Mon peuple, c'est Israël, ceux qui crièrent vers Dieu et furent sauvés. Oui, le Seigneur a sauvé son peuple, le Seigneur nous a arrachés à tous ces maux, Dieu a accompli des prodiges et des merveilles comme il n'y en eut jamais parmi les nations. 
###### 3
De fait, il a établi deux destinées, l'une en faveur de son peuple, l'autre pour les nations. 
###### 3
Et ces destinées se sont accomplies à l'heure, au temps et au jour arrêtés selon son dessein et chez tous les peuples. 
###### 3
Dieu, alors, s'est souvenu de son peuple, il a fait justice à son héritage, 
###### 3
pour qui ces jours, les quatorzième et quinzième du mois d'Adar, seront désormais des jours d'assemblée, de liesse et de joie devant Dieu, pour toutes les générations et à perpétuité, dans Israël, son peuple." 
###### 3
La quatrième année du règne de Ptolémée et de Cléopâtre, Dosithée qui se disait prêtre et lévite, ainsi que son fils Ptolémée, apportèrent la présente lettre concernant les Purim. Ils la donnaient comme authentique et traduite par Lysimaque, fils de Ptolémée, de la communauté de Jérusalem.
