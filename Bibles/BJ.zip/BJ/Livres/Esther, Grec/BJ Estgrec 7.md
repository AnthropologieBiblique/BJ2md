---
aliases : 
- Esther, Grec 7
- Esther, Grec 7
- Estgrec 7
- Esther, Greek 7
tags : 
- Bible/Estgrec/7
- français
cssclass : français
---

# Esther, Grec 7

###### 1
Le roi et Aman allèrent banqueter chez la reine Esther,
###### 2
et ce deuxième jour, pendant le banquet, le roi dit encore à Esther : "Dis-moi ce que tu demandes, reine Esther, c'est accordé d'avance! Dis-moi ce que tu désires; serait-ce la moitié du royaume, c'est chose faite" 
###### 3
"Si vraiment j'ai trouvé grâce à tes yeux, ô roi, lui répondit la reine Esther, et si tel est ton bon plaisir, accorde-moi la vie, voilà ma demande, et la vie de mon peuple, voilà mon désir.
###### 4
Car nous sommes livrés, mon peuple et moi, à l'extermination, à la tuerie et à l'anéantissement. Si encore nous avions seulement été livrés comme esclaves ou servantes, je me serais tue. Mais en l'occurrence le persécuteur sera hors d'état de compenser le dommage qui va en résulter pour le roi."
###### 5
Mais Assuérus prit la parole et dit à la reine Esther : "Qui est-ce? Où est l'homme qui a pensé agir ainsi?"
###### 6
Alors Esther : "Le persécuteur, l'ennemi, c'est Aman, c'est ce misérable!" A la vue du roi et de la reine, Aman fut glacé de terreur.
###### 7
Furieux, le roi se leva et quitta le banquet pour gagner le jardin du palais, cependant qu'Aman demeurait près de la reine Esther pour implorer la grâce de la vie, sentant trop bien que le roi avait décidé sa perte.
###### 8
Quand le roi revint du jardin dans la salle du banquet, il trouva Aman effondré sur le divan où Esther était étendue. "Va-t-il après cela faire violence à la reine chez moi, dans le palais?" S'écria-t-il. A peine le mot était-il sorti de sa bouche qu'un voile fut jeté sur la face d'Aman.
###### 9
Harbona, un des eunuques, dit en présence du roi : "Justement il y a une potence de 50 coudées qu'Aman a fait préparer pour ce Mardochée qui a parlé pour le bien du roi; elle est toute dressée dans sa maison""Qu'on l'y pende", ordonna le roi.
###### 10
Aman fut donc pendu à la potence dressée par lui pour Mardochée et la colère du roi s'apaisa.
