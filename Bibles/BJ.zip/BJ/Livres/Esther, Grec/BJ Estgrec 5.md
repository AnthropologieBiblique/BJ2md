---
aliases : 
- Esther, Grec 5
- Esther, Grec 5
- Estgrec 5
- Esther, Greek 5
tags : 
- Bible/Estgrec/5
- français
cssclass : français
---

# Esther, Grec 5

###### 1
Le troisième jour, lorsqu'elle eut cessé de prier, elle quitta ses vêtements de suppliante et se revêtit de toute sa splendeur. 
###### 1
Ainsi devenue éclatante de beauté, elle invoqua le Dieu qui veille sur tous et les sauve. Puis elle prit avec elle deux servantes. Sur l'une elle s'appuyait mollement. L'autre l'accompagnait et soulevait son vêtement. 
###### 1
A l'apogée de sa beauté, elle rougissait et son visage joyeux était comme épanoui d'amour. Mais la crainte faisait gémir son cœur. 
###### 1
Franchissant toutes les portes, elle se trouva devant le roi. Il était assis sur son trône royal, revêtu de tous les ornements de ses solennelles apparitions, tout rutilant d'or et de pierreries, redoutable au possible. 
###### 1
Il leva son visage empourpré de splendeur et, au comble de la colère, regarda. La reine s'effondra. Dans son évanouissement son teint blêmit et elle appuya la tête sur la servante qui l'accompagnait. 
###### 1
Dieu changea le cœur du roi et l'inclina à la douceur. Anxieux, il s'élança de son trône et la prit dans ses bras jusqu'à ce qu'elle se remît, la réconfortant par des paroles apaisantes. 
###### 1
"Qu'y a-t-il, Esther? Je suis ton frère! Rassure-toi! Tu ne mourras pas. Notre ordonnance ne vaut que pour le commun des gens. Approche-toi."
###### 2
Levant son sceptre d'or il le posa sur le cou d'Esther, l'embrassa et lui dit : "Parle-moi"
###### 2
"Seigneur, lui dit-elle, je t'ai vu pareil à un ange de Dieu. Mon cœur s'est alors troublé et j'ai eu peur de ta splendeur. Car tu es admirable, Seigneur, et ton visage est plein de charmes." 
###### 2
Tandis qu'elle parlait, elle défaillit. Le roi se troubla et tout son entourage cherchait à la ranimer.
###### 3
"Qu'y a-t-il, reine Esther? Lui dit le roi. Dis-moi ce que tu désires, et, serait-ce la moitié du royaume, c'est accordé d'avance" 
###### 4
"Plairait-il au roi, répondit Esther, de venir aujourd'hui avec Aman au banquet que je lui ai préparé" 
###### 5
"Qu'on prévienne aussitôt Aman pour combler le souhait d'Esther", dit alors le roi. Le roi et Aman vinrent ainsi au banquet préparé par Esther
###### 6
et, pendant le banquet, le roi redit à Esther : "Dis-moi ce que tu demandes, c'est accordé d'avance! Dis-moi ce que tu désires, serait-ce la moitié du royaume, c'est chose faite" 
###### 7
"Ce que je demande, ce que je désire? Répondit Esther.
###### 8
Si vraiment j'ai trouvé grâce aux yeux du roi, s'il lui plaît d'exaucer ma demande et de combler mon désir, que demain encore le roi vienne avec Aman au banquet que je leur donnerai et j'y exécuterai l'ordre du roi."
###### 9
Ce jour-là Aman sortit joyeux et le cœur en fête, mais quand, à la Porte Royale, il vit Mardochée ne point se lever devant lui ni bouger de sa place, il fut prit de colère contre lui.
###### 10
Néanmoins il se contint. Revenu chez lui, il convoqua ses amis et sa femme Zéresh
###### 11
et, longuement, devant eux, parla de son éblouissante richesse, du nombre de ses enfants, de tout ce dont le roi l'avait comblé pour l'élever et l'exalter au-dessus de tous ses grands officiers et serviteurs.
###### 12
"Ce n'est pas tout, ajouta-t-il, la reine Esther vient de m'inviter avec le roi, et moi seul, à un banquet qu'elle lui offrait, et bien plus, je suis encore invité par elle avec le roi demain.
###### 13
Mais que me fait tout cela aussi longtemps que je verrai Mardochée, le Juif, siéger à la Porte Royale" 
###### 14
"Fais seulement dresser une potence de 50 coudées, lui répondirent sa femme, Zéresh, et ses amis; demain matin tu demanderas au roi qu'on y pende Mardochée! Tu pourras alors, tout joyeux, aller rejoindre le roi au banquet!" Ravi du conseil, Aman fit préparer la potence.
