---
aliases : 
- Esther, Grec 1
- Esther, Grec 1
- Estgrec 1
- Esther, Greek 1
tags : 
- Bible/Estgrec/1
- français
cssclass : français
---

# Esther, Grec 1

###### 1
C'était au temps d'Assuérus, cet Assuérus dont l'empire s'étendait de l'Inde à l'Ethiopie, soit sur 127 provinces.
###### 2
En ce temps-là, comme il siégeait sur son trône royal, à la citadelle de Suse,
###### 3
la troisième année de son règne, il donna un banquet, présidé par lui, à tous ses grands officiers et serviteurs chefs de l'armée des Perses et des Mèdes, nobles et gouverneurs de provinces.
###### 4
Il voulait étaler à leurs yeux la richesse et la magnificence de son royaume ainsi que l'éclat splendide de sa grandeur, pendant une longue suite de jours, exactement 180.
###### 5
Ce temps écoulé, ce fut alors toute la population de la citadelle de Suse, du plus grand au plus petit, qui se vit offrir par le roi un banquet de sept jours, sur l'esplanade du jardin du palais royal.
###### 6
Ce n'étaient que tentures de toile blanche et de pourpre violette attachées par des cordons de byssus et de pourpre rouge, eux-mêmes suspendus à des anneaux d'argent fixés sur des colonnes de marbre blanc, lits d'or et d'argent posés sur un dallage de pierres rares, de marbre blanc, de nacre et de mosaïques!
###### 7
Pour boire, des coupes d'or, toutes différentes, et abondance de vin offert par le roi avec une libéralité royale.
###### 8
Le décret royal toutefois ne contraignait pas à boire, le roi ayant prescrit à tous les officiers de sa maison que chacun fût traité comme il l'entendait.
###### 9
La reine Vasthi, de son côté, avait offert aux femmes un festin dans le palais royal d'Assuérus.
###### 10
Le septième jour, mis en gaîté par le vin, le roi ordonna à Mehumân, à Bizzeta, à Harbona, à Bigta, à Abgata, à Zétar et à Karkas, les sept eunuques attachés au service personnel du roi Assuérus,
###### 11
de lui amener la reine Vasthi coiffée du diadème royal, en vue de faire montre de sa beauté au peuple et aux grands officiers. Le fait est qu'elle était très belle.
###### 12
Mais la reine Vasthi refusa de venir selon l'ordre du roi que les eunuques lui avaient transmis. L'irritation du roi fut extrême et sa colère s'enflamma.
###### 13
Il s'adressa aux sages versés dans la science des lois car c'est ainsi que les affaires du roi étaient traitées, en présence de tous ceux qui étaient versés dans la science de la loi et du droit.
###### 14
Il fit venir près de lui Karshena, Shétar, Admata, Tarshish, Mérès, Marsena et Memukân, sept grands officiers perses et mèdes admis à voir la face du roi et siégeant aux premières places du royaume.
###### 15
"Selon la loi, dit-il, que faut-il faire à la reine Vasthi pour n'avoir pas obtempéré à l'ordre du roi Assuérus que les eunuques lui transmettaient?"
###### 16
Et en présence du roi et des grands officiers Memukân répondit : "Ce n'est pas seulement contre le roi que la reine Vasthi a mal agi, c'est aussi contre tous les grands officiers et contre toutes les populations répandues à travers les provinces du roi Assuérus.
###### 17
La façon d'agir de la reine ne manquera pas de venir à la connaissance de toutes les femmes, qui regarderont leur mari avec mépris. Le roi Assuérus lui-même, pourront-elles dire, avait donné l'ordre de lui amener la reine Vasthi, et elle n'est pas venue!
###### 18
Aujourd'hui même les femmes des grands officiers perses et mèdes vont parler à tous les grands officiers du roi de ce qu'elles ont appris de la façon d'agir de la reine, et ce sera grand mépris et grande colère.
###### 19
Si tel est le bon plaisir du roi, qu'un édit émané de lui s'inscrive, irrévocable, parmi les lois des Perses et des Mèdes, pour interdire à Vasthi de paraître en présence du roi Assuérus, et que le roi confère sa qualité de reine à une autre qui vaille mieux qu'elle.
###### 20
Puis l'ordonnance portée par le roi sera promulguée dans tout son royaume, qui est grand, et lors les femmes rendront honneur à leur mari, du plus grand jusqu'au plus humble."
###### 21
Ce discours plut au roi et aux grands officiers, et le roi suivit l'avis de Memukân.
###### 22
Il envoya des lettres à toutes les provinces de l'empire, à chaque province selon son écriture et à chaque peuple selon sa langue, afin que tout mari fût maître chez lui.
