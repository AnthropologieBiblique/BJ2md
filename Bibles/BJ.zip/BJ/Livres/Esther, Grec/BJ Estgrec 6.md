---
aliases : 
- Esther, Grec 6
- Esther, Grec 6
- Estgrec 6
- Esther, Greek 6
tags : 
- Bible/Estgrec/6
- français
cssclass : français
---

# Esther, Grec 6

###### 1
Or, cette nuit-là, comme le sommeil le fuyait, le roi réclama le livre des Mémoires ou Chroniques pour s'en faire donner lecture.
###### 2
Il s'y trouvait la dénonciation par Mardochée de Bigtân et Téresh, les deux eunuques gardes du seuil, coupables d'avoir projeté d'attenter à la vie d'Assuérus.
###### 3
"Et quelle distinction, quelle dignité, s'enquit le roi, furent pour cela conférées à ce Mardochée""Rien n'a été fait pour lui", répondirent les courtisans de service.
###### 4
Le roi leur demanda alors : "Qui est dans le vestibule?" C'était juste le moment où Aman arrivait dans le vestibule extérieur du palais royal pour demander au roi de faire pendre Mardochée à la potence dressée pour lui par ses soins,
###### 5
si bien que les courtisans répondirent : "C'est Aman qui se tient dans le vestibule""Qu'il entre!" ordonna le roi,
###### 6
et, sitôt entré : "Comment faut-il traiter un homme que le roi veut honorer""Quel autre que moi le roi voudrait-il honorer" , se dit Aman.
###### 7
"Le roi veut honorer quelqu'un? Répondit-il donc,
###### 8
qu'on prenne des vêtements princiers, de ceux que porte le roi; qu'on amène un cheval, de ceux que monte le roi et sur la tête duquel on aura mis un diadème royal.
###### 9
Puis vêtements et cheval seront confiés à l'un des plus nobles des grands officiers royaux. Celui-ci revêtira alors de ce costume l'homme que le roi veut honorer et le conduira à cheval sur la grand-place en criant devant lui : Voyez comment l'on traite l'homme que le roi veut honorer" 
###### 10
"Ne perds pas un instant, répondit le roi à Aman, prends vêtements et cheval, et tout ce que tu viens de dire, fais-le à Mardochée, le Juif, l'attaché de la Royale Porte. Surtout, n'omets rien de ce que tu as dit!"
###### 11
Prenant donc vêtements et cheval, Aman habilla Mardochée, puis le promena à cheval sur la grand-place en criant devant lui "Voyez comment l'on traite l'homme que le roi veut honorer!"
###### 12
Après quoi Mardochée s'en revint à la Porte Royale tandis qu'Aman, de son côté, rentrait précipitamment chez lui, consterné et le visage voilé.
###### 13
Il raconta à sa femme Zéresh et à tous ses amis ce qui venait d'arriver. Sa femme Zéresh et ses amis lui dirent : "Tu viens de commencer à déchoir devant Mardochée : s'il est de la race des Juifs, tu ne pourras plus reprendre le dessus. Au contraire tu tomberas sans cesse plus bas devant lui."
###### 14
La conversation n'était pas achevée qu'arrivèrent les eunuques du roi, venus chercher Aman pour le conduire en hâte au banquet offert par Esther.
