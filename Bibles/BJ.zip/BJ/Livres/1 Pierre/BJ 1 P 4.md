---
aliases : 
- 1 Pierre 4
- 1 Pierre 4
- 1 P 4
- 1 Peter 4
tags : 
- Bible/1P/4
- français
cssclass : français
---

# 1 Pierre 4

###### 1
Le Christ ayant donc souffert dans la chair, vous aussi armez-vous de cette même pensée, à savoir : celui qui a souffert dans la chair a rompu avec le péché, 
###### 2
pour passer le temps qui reste à vivre dans la chair, non plus selon les passions humaines, mais selon le vouloir divin. 
###### 3
Il suffit bien en effet d'avoir accompli dans le passé la volonté des païens, en se prêtant aux débauches, aux passions, aux saouleries, orgies, beuveries, au culte illicite des idoles. 
###### 4
A ce sujet, ils jugent étrange que vous ne couriez pas avec eux vers ce torrent de perdition, et ils se répandent en outrages. 
###### 5
Ils en rendront compte à celui qui est prêt à juger vivants et morts. 
###### 6
C'est pour cela, en effet, que même aux morts a été annoncée la Bonne Nouvelle, afin que, jugés selon les hommes dans la chair, ils vivent selon Dieu dans l'esprit. 
###### 7
La fin de toutes choses est proche. Soyez donc sages et sobres en vue de la prière. 
###### 8
Avant tout, conservez entre vous une grande charité, car la charité couvre une multitude de péchés. 
###### 9
Pratiquez l'hospitalité les uns envers les autres, sans murmurer. 
###### 10
Chacun selon la grâce reçue, mettez-vous au service les uns des autres, comme de bons intendants d'une multiple grâce de Dieu. 
###### 11
Si quelqu'un parle, que ce soit comme les paroles de Dieu ; si quelqu'un assure le service, que ce soit comme par un mandat reçu de Dieu, afin qu'en tout Dieu soit glorifié par Jésus Christ, à qui sont la gloire et la puissance pour les siècles des siècles. Amen. 
###### 12
Très chers, ne jugez pas étrange l'incendie qui sévit au milieu de vous pour vous éprouver, comme s'il vous survenait quelque chose d'étrange. 
###### 13
Mais, dans la mesure où vous participez aux souffrances du Christ, réjouissez-vous, afin que, lors de la révélation de sa gloire, vous soyez aussi dans la joie et l'allégresse. 
###### 14
Heureux, si vous êtes outragés pour le nom du Christ, car l'Esprit de gloire, l'Esprit de Dieu repose sur vous. 
###### 15
Que nul de vous n'ait à souffrir comme meurtrier, ou voleur, ou malfaiteur, ou comme délateur, 
###### 16
mais si c'est comme chrétien, qu'il n'ait pas honte, qu'il glorifie Dieu de porter ce nom. 
###### 17
Car le moment est venu de commencer le jugement par la maison de Dieu. Or s'il débute par nous, quelle sera la fin de ceux qui refusent de croire à la Bonne Nouvelle de Dieu ? 
###### 18
Si le juste est à peine sauvé, l'impie, le pécheur, où se montrera-t-il ? 
###### 19
Ainsi, que ceux qui souffrent selon le vouloir divin remettent leurs âmes au Créateur fidèle, en faisant le bien. 
