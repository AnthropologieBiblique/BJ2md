---
aliases : 
- 1 Pierre 3
- 1 Pierre 3
- 1 P 3
- 1 Peter 3
tags : 
- Bible/1P/3
- français
cssclass : français
---

# 1 Pierre 3

###### 1
Pareillement, vous les femmes, soyez soumises à vos maris, afin que, même si quelques-uns refusent de croire à la Parole, ils soient, sans parole, gagnés par la conduite de leurs femmes, 
###### 2
en considérant votre vie chaste et pleine de respect. 
###### 3
Que votre parure ne soit pas extérieure, faite de cheveux tressés, de cercles d'or et de toilettes bien ajustées, 
###### 4
mais à l'intérieur de votre cœur dans l'incorruptibilité d'une âme douce et calme : voilà ce qui est précieux devant Dieu. 
###### 5
C'est ainsi qu'autrefois les saintes femmes qui espéraient en Dieu se paraient, soumises à leurs maris : 
###### 6
telle Sara obéissait à Abraham, en l'appelant son Seigneur. C'est d'elle que vous êtes devenues les enfants, si vous agissez bien, sans terreur et sans aucun trouble. 
###### 7
Vous pareillement, les maris, menez la vie commune avec compréhension, comme auprès d'un être plus fragile, la femme ; accordez-lui sa part d'honneur, comme cohéritière de la grâce de Vie. Ainsi vos prières ne seront pas entravées. 
###### 8
Enfin, vous tous, en esprit d'union, dans la compassion, l'amour fraternel, la miséricorde, l'esprit d'humilité, 
###### 9
ne rendez pas mal pour mal, insulte pour insulte. Bénissez, au contraire, car c'est à cela que vous avez été appelés, afin d'hériter la bénédiction. 
###### 10
Qui veut, en effet, aimer la vie et voir des jours heureux doit garder sa langue du mal et ses lèvres des paroles fourbes, 
###### 11
s'éloigner du mal et faire le bien, chercher la paix et la poursuivre. 
###### 12
Car le Seigneur a les yeux sur les justes et tend l'oreille à leur prière, mais le Seigneur tourne sa face contre ceux qui font le mal. 
###### 13
Et qui vous ferait du mal, si vous devenez zélés pour le bien ? 
###### 14
Heureux d'ailleurs quand vous souffririez pour la justice ! N'ayez d'eux aucune crainte et ne soyez pas troublés. 
###### 15
Au contraire, sanctifiez dans vos cœurs le Seigneur Christ, toujours prêts à la défense contre quiconque vous demande raison de l'espérance qui est en vous. 
###### 16
Mais que ce soit avec douceur et respect, en possession d'une bonne conscience, afin que, sur le point même où l'on vous calomnie, soient confondus ceux qui décrient votre bonne conduite dans le Christ. 
###### 17
Car mieux vaudrait souffrir en faisant le bien, si telle était la volonté de Dieu, qu'en faisant le mal. 
###### 18
Le Christ lui-même est mort une fois pour les péchés, juste pour des injustes, afin de nous mener à Dieu. Mis à mort selon la chair, il a été vivifié selon l'esprit. 
###### 19
C'est en lui qu'il s'en alla même prêcher aux esprits en prison, 
###### 20
à ceux qui jadis avaient refusé de croire lorsque se prolongeait la patience de Dieu, aux jours où Noé construisait l'Arche, dans laquelle un petit nombre, en tout huit personnes, furent sauvées à travers l'eau. 
###### 21
Ce qui y correspond, c'est le baptême qui vous sauve à présent et qui n'est pas l'enlèvement d'une souillure charnelle, mais l'engagement à Dieu d'une bonne conscience par la résurrection de Jésus Christ, 
###### 22
lui qui, passé au ciel, est à la droite de Dieu, après s'être soumis les Anges, les Dominations et les Puissances. 
