---
aliases : 
- 1 Pierre 5
- 1 Pierre 5
- 1 P 5
- 1 Peter 5
tags : 
- Bible/1P/5
- français
cssclass : français
---

# 1 Pierre 5

###### 1
Les anciens qui sont parmi nous, je les exhorte, moi, ancien comme eux, témoin des souffrances du Christ, et qui dois participer à la gloire qui va être révélée. 
###### 2
Paissez le troupeau de Dieu qui vous est confié, veillant sur lui, non par contrainte, mais de bon gré, selon Dieu ; non pour un gain sordide, mais avec l'élan du cœur ; 
###### 3
non pas en faisant les seigneurs à l'égard de ceux qui vous sont échus en partage, mais en devenant les modèles du troupeau. 
###### 4
Et quand paraîtra le Chef des pasteurs, vous recevrez la couronne de gloire qui ne se flétrit pas. 
###### 5
Pareillement, les jeunes, soyez soumis aux anciens : revêtez-vous tous d'humilité dans vos rapports mutuels, car Dieu résiste aux orgueilleux, mais c'est aux humbles qu'il donne sa grâce. 
###### 6
Humiliez-vous donc sous la puissante main de Dieu, pour qu'il vous élève au bon moment ; 
###### 7
de toute votre inquiétude, déchargez-vous sur lui, car il a soin de vous. 
###### 8
Soyez sobres, veillez. Votre partie adverse, le Diable, comme un lion rugissant, rôde, cherchant qui dévorer. 
###### 9
Résistez-lui, fermes dans la foi, sachant que c'est le même genre de souffrance que la communauté des frères, répandue dans le monde, supporte. 
###### 10
Quand vous aurez un peu souffert, le Dieu de toute grâce, qui vous a appelés à sa gloire éternelle, dans le Christ, vous rétablira lui-même, vous affermira, vous fortifiera, vous rendra inébranlables. 
###### 11
A Lui la puissance pour les siècles des siècles ! Amen. 
###### 12
Je vous écris ces quelques mots par Silvain, que je tiens pour un frère fidèle, pour vous exhorter et attester que telle est la vraie grâce de Dieu : tenez-vous-y. 
###### 13
Celle qui est à Babylone, élue comme vous, vous salue, ainsi que Marc, mon fils. 
###### 14
Saluez-vous les uns les autres dans un baiser de charité. Paix à vous tous qui êtes dans le Christ ! 
