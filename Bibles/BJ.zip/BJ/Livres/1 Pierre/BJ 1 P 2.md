---
aliases : 
- 1 Pierre 2
- 1 Pierre 2
- 1 P 2
- 1 Peter 2
tags : 
- Bible/1P/2
- français
cssclass : français
---

# 1 Pierre 2

###### 1
Rejetez donc toute malice et toute fourberie, hypocrisies, jalousies et toute sorte de médisances. 
###### 2
Comme des enfants nouveau-nés désirez le lait non frelaté de la parole, afin que, par lui, vous croissiez pour le salut, 
###### 3
si du moins vous avez goûté combien le Seigneur est excellent. 
###### 4
Approchez-vous de lui, la pierre vivante, rejetée par les hommes, mais choisie, précieuse auprès de Dieu. 
###### 5
Vous-mêmes, comme pierres vivantes, prêtez-vous à l'édification d'un édifice spirituel, pour un sacerdoce saint, en vue d'offrir des sacrifices spirituels, agréables à Dieu par Jésus Christ. 
###### 6
Car il y a dans l'Écriture : Voici que je pose en Sion une pierre angulaire, choisie, précieuse, et celui qui se confie en elle ne sera pas confondu. 
###### 7
A vous donc, les croyants, l'honneur, mais pour les incrédules, la pierre qu'ont rejetée les constructeurs, celle-là est devenue la tête de l'angle, 
###### 8
une pierre d'achoppement et un rocher qui fait tomber. Ils s'y heurtent parce qu'ils ne croient pas à la Parole ; c'est bien à cela qu'ils ont été destinés. 
###### 9
Mais vous, vous êtes une race élue, un sacerdoce royal, une nation sainte, un peuple acquis, pour proclamer les louanges de Celui qui vous a appelés des ténèbres à son admirable lumière, 
###### 10
vous qui jadis n'étiez pas un peuple et qui êtes maintenant le Peuple de Dieu, qui n'obteniez pas miséricorde et qui maintenant avez obtenu miséricorde. 
###### 11
Très chers, je vous exhorte, comme étrangers et voyageurs, à vous abstenir des désirs charnels, qui font la guerre à l'âme. 
###### 12
Ayez au milieu des nations une belle conduite afin que, sur le point même où ils vous calomnient comme malfaiteurs, la vue de vos bonnes œuvres les amène à glorifier Dieu, au jour de sa Visite. 
###### 13
Soyez soumis, à cause du Seigneur, à toute institution humaine : soit au roi, comme souverain, 
###### 14
soit aux gouverneurs, comme envoyés par lui pour punir ceux qui font le mal et féliciter ceux qui font le bien. 
###### 15
Car c'est la volonté de Dieu qu'en faisant le bien vous fermiez la bouche à l'ignorance des insensés. 
###### 16
Agissez en hommes libres, non pas en hommes qui font de la liberté un voile sur leur malice, mais en serviteurs de Dieu. 
###### 17
Honorez tout le monde, aimez vos frères, craignez Dieu, honorez le roi. 
###### 18
Vous les domestiques, soyez soumis à vos maîtres, avec une profonde crainte, non seulement aux bons et aux bienveillants, mais aussi aux difficiles. 
###### 19
Car c'est une grâce que de supporter, par égard pour Dieu, des peines que l'on souffre injustement. 
###### 20
Quelle gloire, en effet, à supporter les coups si vous avez commis une faute ? Mais si, faisant le bien, vous supportez la souffrance, c'est une grâce auprès de Dieu. 
###### 21
Or, c'est à cela que vous avez été appelés, car le Christ aussi a souffert pour vous, vous laissant un modèle afin que vous suiviez ses traces, 
###### 22
lui qui n'a pas commis de faute - et il ne s'est pas trouvé de fourberie dans sa bouche ; 
###### 23
lui qui insulté ne rendait pas l'insulte, souffrant ne menaçait pas, mais s'en remettait à Celui qui juge avec justice ; 
###### 24
lui qui, sur le bois, a porté lui-même nos fautes dans son corps, afin que, morts à nos fautes, nous vivions pour la justice ; lui dont la meurtrissure vous a guéris. 
###### 25
Car vous étiez égarés comme des brebis, mais à présent vous êtes retournés vers le pasteur et le gardien de vos âmes. 
