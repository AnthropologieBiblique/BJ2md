---
aliases : 
- 1 Pierre 1
- 1 Pierre 1
- 1 P 1
- 1 Peter 1
tags : 
- Bible/1P/1
- français
cssclass : français
---

# 1 Pierre 1

###### 1
Pierre, apôtre de Jésus Christ, aux étrangers de la Dispersion : du Pont, de Galatie, de Cappadoce, d'Asie et de Bithynie, élus 
###### 2
selon la prescience de Dieu le Père, dans la sanctification de l'Esprit, pour obéir et être aspergés du sang de Jésus Christ. A vous grâce et paix en abondance. 
###### 3
Béni soit le Dieu et Père de notre Seigneur Jésus Christ : dans sa grande miséricorde, il nous a engendrés de nouveau par la Résurrection de Jésus Christ d'entre les morts, pour une vivante espérance, 
###### 4
pour un héritage exempt de corruption, de souillure, de flétrissure, et qui vous est réservé dans les cieux, à vous 
###### 5
que, par la foi, la puissance de Dieu garde pour le salut prêt à se manifester au dernier moment. 
###### 6
Vous en tressaillez de joie, bien qu'il vous faille encore quelque temps être affligés par diverses épreuves, 
###### 7
afin que, bien éprouvée, votre foi, plus précieuse que l'or périssable que l'on vérifie par le feu, devienne un sujet de louange, de gloire et d'honneur, lors de la Révélation de Jésus Christ. 
###### 8
Sans l'avoir vu vous l'aimez ; sans le voir encore, mais en croyant, vous tressaillez d'une joie indicible et pleine de gloire, 
###### 9
sûrs d'obtenir l'objet de votre foi : le salut des âmes. 
###### 10
Sur ce salut ont porté les investigations et les recherches des prophètes, qui ont prophétisé sur la grâce à vous destinée. 
###### 11
Ils ont cherché à découvrir quel temps et quelles circonstances avait en vue l'Esprit du Christ, qui était en eux, quand il attestait à l'avance les souffrances du Christ et les gloires qui les suivraient. 
###### 12
Il leur fut révélé que ce n'était pas pour eux-mêmes, mais pour vous, qu'ils administraient ce message, que maintenant vous annoncent ceux qui vous prêchent l'Évangile, dans l'Esprit Saint envoyé du ciel, et sur lequel les anges se penchent avec convoitise. 
###### 13
L'intelligence en éveil, soyez sobres et espérez pleinement en la grâce qui doit vous être apportée par la révélation de Jésus Christ. 
###### 14
En enfants obéissants, ne vous laissez pas modeler par vos passions de jadis, du temps de votre ignorance. 
###### 15
Mais, à l'exemple du Saint qui vous a appelés, devenez saints, vous aussi, dans toute votre conduite, 
###### 16
selon qu'il est écrit : Vous serez saints, parce que moi, je suis saint. 
###### 17
Et si vous appelez Père celui qui, sans acception de personnes, juge chacun selon ses œuvres, conduisez-vous avec crainte pendant le temps de votre exil. 
###### 18
Sachez que ce n'est par rien de corruptible, argent ou or, que vous avez été affranchis de la vaine conduite héritée de vos pères, 
###### 19
mais par un sang précieux, comme d'un agneau sans reproche et sans tache, le Christ, 
###### 20
discerné avant la fondation du monde et manifesté dans les derniers temps à cause de vous. 
###### 21
Par lui vous croyez en Dieu, qui l'a fait ressusciter d'entre les morts et lui a donné la gloire, si bien que votre foi soit en Dieu comme votre espérance. 
###### 22
En obéissant à la vérité, vous avez sanctifié vos âmes, pour vous aimer sincèrement comme des frères. D'un cœur pur, aimez-vous les uns les autres sans défaillance, 
###### 23
engendrés de nouveau d'une semence non point corruptible, mais incorruptible : la Parole de Dieu, vivante et permanente. 
###### 24
Car toute chair est comme l'herbe et toute sa gloire comme fleur d'herbe ; l'herbe se dessèche et sa fleur tombe ; 
###### 25
mais la Parole du Seigneur demeure pour l'éternité. C'est cette Parole dont la Bonne Nouvelle vous a été portée. 
