---
aliases : 
- Ruth 1
- Ruth 1
- Rt 1
tags : 
- Bible/Rt/1
- français
cssclass : français
---

# Ruth 1

###### 1
Au temps où gouvernaient les Juges, une famine survint dans le pays et un homme de Bethléem de Juda s'en alla avec sa femme et ses deux fils pour séjourner dans les Champs de Moab. 
###### 2
Cet homme s'appelait Élimélek, sa femme Noémi, et ses deux fils Mahlôn et Kilyôn; ils étaient Éphratéens, de Bethléem de Juda. Arrivés dans les Champs de Moab, ils s'y établirent. 
###### 3
Élimélek, le mari de Noémi, mourut, et elle lui survécut avec ses deux fils. 
###### 4
Ils prirent pour femmes des Moabites, l'une se nommait Orpa et l'autre Ruth. Ils demeurèrent là une dizaine d'années. 
###### 5
Puis Mahlôn et Kilyôn moururent, tous deux aussi, et Noémi resta seule, privée de ses deux fils et de son mari. 
###### 6
Alors, avec ses brus, elle se disposa à revenir des Champs de Moab, car elle avait appris dans les Champs de Moab que Dieu avait visité son peuple pour lui donner du pain. 
###### 7
Elle quitta donc avec ses brus le lieu où elle avait demeuré et elles se mirent en chemin pour retourner au pays de Juda. 
###### 8
Noémi dit à ses deux brus : " Partez donc et retournez chacune à la maison de votre mère. Que Yahvé use de bienveillance envers vous comme vous en avez usé envers ceux qui sont morts et envers moi-même! 
###### 9
Que Yahvé accorde à chacune de vous de trouver une vie paisible dans la maison d'un mari! " Elle les embrassa, mais elles se mirent à crier et à pleurer, 
###### 10
et elles dirent : " Non! Nous reviendrons avec toi vers ton peuple. " - 
###### 11
" Retournez, mes filles, répondit Noémi, pourquoi viendriez-vous avec moi ? Ai-je encore dans mon sein des fils qui puissent devenir vos maris ? 
###### 12
Retournez, mes filles, allez-vous-en, car je suis bien trop vieille pour me marier! Et quand bien même je dirais : "Il y a encore pour moi de l'espoir, cette nuit même je vais appartenir à mon mari et j'aurai des fils", 
###### 13
attendriez-vous qu'ils soient devenus grands ? Renonceriez-vous à vous marier ? Non mes filles! Je suis pleine d'amertume à votre sujet, car la main de Yahvé s'est levée contre moi. " 
###### 14
Elles recommencèrent à crier et à pleurer, puis Orpa embrassa sa belle-mère et retourna vers son peuple, mais Ruth lui resta attachée. 
###### 15
Noémi dit alors : " Vois, ta belle-sœur s'en est retournée vers son peuple et vers son dieu; retourne toi aussi, et suis-la. " 
###### 16
Ruth répondit : " Ne me presse pas de t'abandonner et de m'éloigner de toi, car où tu iras, j'irai, où tu demeureras, je demeurerai; ton peuple sera mon peuple et ton Dieu sera mon Dieu.
###### 17
Là où tu mourras, je mourrai et là je serai ensevelie. Que Yahvé me fasse ce mal et qu'il y ajoute encore cet autre, si ce n'est pas la mort qui nous sépare! " 
###### 18
Voyant que Ruth s'obstinait à l'accompagner Noémi cessa d'insister auprès d'elle. 
###### 19
Elles s'en allèrent donc toutes deux et arrivèrent à Bethléem. Leur arrivée à Bethléem mit toute la ville en émoi : " Est-ce bien là Noémi ? " s'écriaient les femmes. 
###### 20
" Ne m'appelez plus Noémi, leur répondit-elle, appelez-moi Mara, car Shaddaï m'a remplie d'amertume. 
###### 21
Comblée j'étais partie, vide Yahvé me ramène! Pourquoi m'appelleriez-vous encore Noémi, alors que Yahvé a témoigné contre moi et que Shaddaï m'a rendue malheureuse ? " 
###### 22
C'est ainsi que Noémi revint, ayant avec elle sa belle-fille Ruth, la Moabite, celle qui était revenue des Champs de Moab. Elles arrivèrent à Bethléem au début de la moisson des orges. 
