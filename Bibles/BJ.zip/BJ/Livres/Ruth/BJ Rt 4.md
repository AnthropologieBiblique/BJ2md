---
aliases : 
- Ruth 4
- Ruth 4
- Rt 4
tags : 
- Bible/Rt/4
- français
cssclass : français
---

# Ruth 4

###### 1
Or Booz était monté à la porte et s'y était assis, et voici que le parent dont Booz avait parlé vint à passer. " Toi, dit Booz, approche et assieds-toi ici. " L'homme s'approcha et vint s'asseoir. 
###### 2
Booz prit dix hommes parmi les anciens de la ville : " Asseyez-vous ici ", dit-il, et ils s'assirent. 
###### 3
Alors il dit à celui qui avait droit de rachat : " La pièce de terre qui appartenait à notre frère Élimélek, Noémi, qui est revenue des Champs de Moab, la met en vente. 
###### 4
Je me suis dit que j'allais t'en informer en disant : "Acquiers-la en présence de ceux qui sont assis là et des anciens de mon peuple. " Si tu veux exercer ton droit de rachat, rachète. Mais si tu ne le veux pas, déclare-le moi pour que je le sache. Tu es le premier à avoir le droit de rachat, moi je ne viens qu'après toi. " L'autre répondit : " Oui! je veux racheter. " 
###### 5
Mais Booz dit : " Le jour où, de la main de Noémi, tu acquerras ce champ, tu acquiers aussi Ruth la Moabite, la femme de celui qui est mort, pour perpétuer le nom du mort sur son patrimoine. " 
###### 6
Celui qui avait droit de rachat répondit alors : " Je ne puis exercer mon droit, car je craindrais de nuire à mon patrimoine. Exerce pour toi-même mon droit de rachat, car moi je ne puis l'exercer. " 
###### 7
Or c'était autrefois la coutume en Israël, en cas de rachat ou d'héritage, pour valider toute affaire : l'un ôtait sa sandale et la donnait à l'autre. Telle était en Israël la manière de témoigner. 
###### 8
Celui qui avait droit de rachat dit donc à Booz : " Fais l'acquisition pour toi-même ", et il retira sa sandale. 
###### 9
Booz dit aux anciens et à tout le peuple : " Vous êtes témoins aujourd'hui que j'acquiers de la main de Noémi tout ce qui appartenait à Élimélek et tout ce qui appartenait à Mahlôn et à Kilyôn, 
###### 10
et que j'acquiers en même temps pour femme Ruth la Moabite, veuve de Mahlôn, pour perpétuer le nom du mort sur son héritage et pour que le nom du mort ne soit pas retranché d'entre ses frères ni de la porte de sa ville. Vous en êtes aujourd'hui les témoins. " 
###### 11
Tout le peuple qui se trouvait à la porte répondit : " Nous en sommes témoins ", et les anciens répondirent : " Que Yahvé rende la femme qui va entrer dans ta maison semblable à Rachel et à Léa qui, à elles deux, ont édifié la maison d'Israël. Deviens puissant en Ephrata et fais-toi un nom dans Bethléem. 
###### 12
Que grâce à la postérité que Yahvé t'accordera de cette jeune femme, ta maison soit semblable à celle de Pérèç, que Tamar enfanta à Juda. " 
###### 13
Booz prit Ruth et elle devint sa femme. Il alla vers elle, Yahvé donna à Ruth de concevoir et elle enfanta un fils. 
###### 14
Les femmes dirent alors à Noémi : " Béni soit Yahvé qui ne t'a pas laissé manquer aujourd'hui de quelqu'un pour te racheter. Que son nom soit proclamé en Israël! 
###### 15
Il sera pour toi un consolateur et le soutien de ta vieillesse, car il a pour mère ta bru qui t'aime, elle qui vaut mieux pour toi que sept fils. " 
###### 16
Et Noémi, prenant l'enfant, le mit sur son sein, et ce fut elle qui prit soin de lui. 
###### 17
Les voisines lui donnèrent un nom, elles dirent : " Il est né un fils à Noémi " et elles le nommèrent Obed. C'est le père de Jessé, père de David. 
###### 18
Voici la postérité de Pérèç : Pérèç engendra Heçrôn. 
###### 19
Heçrôn engendra Ram et Ram engendra Amminadab. 
###### 20
Amminadab engendra Nahshôn et Nahshôn engendra Salmôn. 
###### 21
Salmôn engendra Booz et Booz engendra Obed. 
###### 22
Et Obed engendra Jessé et Jessé engendra David. 
