---
aliases : 
- Ruth 3
- Ruth 3
- Rt 3
tags : 
- Bible/Rt/3
- français
cssclass : français
---

# Ruth 3

###### 1
Noémi, sa belle-mère, lui dit : " Ma fille, ne dois-je pas chercher à t'établir pour que tu sois heureuse ? 
###### 2
Eh bien! Booz n'est-il pas notre parent, lui dont tu as suivi les servantes ? Cette nuit, il doit vanner l'orge sur l'aire. 
###### 3
Lave-toi donc et parfume-toi, mets ton manteau et descends à l'aire, mais ne te laisse pas reconnaître par lui avant qu'il ait fini de manger et de boire. 
###### 4
Quand il sera couché, observe l'endroit où il repose, alors tu iras, tu dégageras une place à ses pieds et tu te coucheras. Il te fera savoir lui-même ce que tu devras faire. " 
###### 5
Et Ruth lui répondit : " Tout ce que tu me dis, je le ferai. " 
###### 6
Elle descendit donc à l'aire et fit tout ce que sa belle-mère lui avait commandé. 
###### 7
Booz mangea et but, puis, le cœur joyeux, s'en alla dormir auprès du tas d'orge. Alors Ruth s'en alla tout doucement, dégagea une place à ses pieds et se coucha. 
###### 8
Au milieu de la nuit, l'homme eut un frisson; il se retourna et vit une femme couchée à ses pieds. 
###### 9
" Qui es-tu ? " dit-il. - " Je suis Ruth, ta servante, lui dit-elle. Étends sur ta servante le pan de ton manteau, car tu as droit de rachat. " - 
###### 10
" Bénie sois-tu de Yahvé, ma fille, lui dit-il, ce second acte de piété que tu accomplis l'emporte sur le premier, car tu n'as pas recherché des jeunes gens, pauvres ou riches. 
###### 11
Et maintenant, ma fille, sois sans crainte, tout ce que tu me diras, je le ferai pour toi, car tout le peuple à la porte de ma ville sait que tu es une femme parfaite. 
###### 12
Toutefois, s'il est vrai que j'ai droit de rachat, il y a un parent plus proche que moi. 
###### 13
Passe la nuit ici et, au matin, s'il veut exercer son droit à ton égard, c'est bien, qu'il te rachète; mais s'il ne veut pas te racheter, alors, par Yahvé vivant, c'est moi qui te rachèterai. Reste couchée jusqu'au matin. " 
###### 14
Elle resta donc couchée à ses pieds jusqu'au matin, puis elle se leva avant l'heure où un homme peut en reconnaître un autre; il se disait : " Il ne faut pas qu'on sache que cette femme est venue à l'aire. " 
###### 15
Il dit alors : " Présente le manteau que tu as sur toi et tiens-le. " Elle le tint et il mesura six parts d'orge qu'il chargea sur elle, puis elle retourna à la ville. 
###### 16
Lorsque Ruth rentra chez sa belle-mère, celle-ci lui dit : " Qu'en est-il de toi, ma fille ? " Ruth lui raconta tout ce que cet homme avait fait pour elle. 
###### 17
Elle dit : " Ces six parts d'orge, il me les a données en disant : Tu ne reviendras pas les mains vides chez ta belle-mère. " - 
###### 18
" Ma fille, reste en repos, lui dit Noémi, jusqu'à ce que tu saches comment finira cette affaire; assurément, cet homme n'aura de cesse qu'il ne l'ait terminée aujourd'hui même. " 
