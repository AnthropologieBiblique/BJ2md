---
aliases : 
- Ruth 2
- Ruth 2
- Rt 2
tags : 
- Bible/Rt/2
- français
cssclass : français
---

# Ruth 2

###### 1
Noémi avait, du côté de son mari, un parent. C'était un homme de condition qui appartenait au même clan qu'Élimélek, il s'appelait Booz. 
###### 2
Ruth la Moabite dit à Noémi : " Permets-moi d'aller dans les champs glaner des épis derrière celui aux yeux duquel je trouverai grâce. " Elle lui répondit : " Va, ma fille. " 
###### 3
Ruth partit donc et s'en vint glaner dans les champs derrière les moissonneurs. Sa chance la conduisit dans une pièce de terre appartenant à Booz, du clan d'Élimélek. 
###### 4
Or voici que Booz arrivait de Bethléem : " Que Yahvé soit avec vous! " dit-il aux moissonneurs, et eux répondirent : " Que Yahvé te bénisse! " 
###### 5
Booz demanda alors à celui de ses serviteurs qui commandait aux moissonneurs : " A qui est cette jeune femme ? " 
###### 6
Et le serviteur qui commandait aux moissonneurs répondit : " Cette jeune femme est la Moabite, celle qui est revenue des Champs de Moab avec Noémi. 
###### 7
Elle a dit : "Permets-moi de glaner et de ramasser ce qui tombe des gerbes derrière les moissonneurs. " Elle est donc venue et elle est restée; depuis le matin jusqu'à présent elle s'est à peine reposée. " 
###### 8
Booz dit à Ruth : " Tu entends, n'est-ce pas ma fille ? Ne va pas glaner dans un autre champ, ne t'éloigne pas d'ici mais attache-toi à mes servantes. 
###### 9
Regarde la pièce de terre qu'on moissonne et suis-les. Sache que j'ai interdit aux serviteurs de te frapper. Si tu as soif, va aux cruches et bois de ce qu'ils auront puisé. " 
###### 10
Alors Ruth, tombant la face contre terre, se prosterna et lui dit : " Comment ai-je trouvé grâce à tes yeux pour que tu t'intéresses à moi qui ne suis qu'une étrangère ? " - 
###### 11
" C'est qu'on m'a bien rapporté, lui dit Booz, tout ce que tu as fait pour ta belle-mère après la mort de ton mari; comment tu as quitté ton père, ta mère et ton pays natal pour te rendre chez un peuple que tu n'avais jamais connu, ni d'hier ni d'avant-hier. 
###### 12
Que Yahvé te rende ce que tu as fait et que tu obtiennes pleine récompense de la part de Yahvé, le Dieu d'Israël, sous les ailes de qui tu es venue t'abriter! " 
###### 13
Elle dit : " Puissé-je toujours trouver grâce à tes yeux, Monseigneur! Tu m'as consolée et tu as parlé au cœur de ta servante, alors que je ne suis même pas l'égale d'une de tes servantes. " 
###### 14
Au moment du repas, Booz dit à Ruth : " Approche-toi, mange de ce pain et trempe ton morceau dans le vinaigre. " Elle s'assit donc à côté des moissonneurs et Booz lui fit aussi un tas de grains rôtis. Après qu'elle eut mangé à satiété, elle en eut de reste. 
###### 15
Lorsqu'elle se fut levée pour glaner, Booz donna cet ordre à ses serviteurs : " Laissez-la glaner entre les gerbes, et vous, ne la molestez pas. 
###### 16
Et même, ayez soin de tirer vous-mêmes quelques épis de vos javelles, vous les laisserez tomber, elle pourra les ramasser et vous ne crierez pas après elle. " 
###### 17
Ruth glana dans le champ jusqu'au soir, et lorsqu'elle eut battu ce qu'elle avait ramassé, il y avait environ une mesure d'orge. 
###### 18
Elle l'emporta, rentra à la ville et sa belle-mère vit ce qu'elle avait glané; elle tira ce qu'elle avait mis en réserve après avoir mangé à sa faim et le lui donna. 
###### 19
" Où as-tu glané aujourd'hui, lui dit sa belle-mère, où as-tu travaillé ? Béni soit celui qui s'est intéressé à toi! " Ruth fit connaître à sa belle-mère chez qui elle avait travaillé; elle dit : " L'homme chez qui j'ai travaillé aujourd'hui s'appelle Booz. " 
###### 20
Noémi dit à sa bru : " Qu'il soit béni de Yahvé qui ne cesse d'exercer sa bienveillance envers les vivants et les morts! " Et Noémi ajouta : " Cet homme est notre proche parent, il est de ceux qui ont sur nous droit de rachat. "
###### 21
Ruth la Moabite dit à sa belle-mère : " Il m'a dit aussi : Reste avec mes serviteurs jusqu'à ce qu'ils aient achevé toute la moisson. " 
###### 22
Noémi dit à Ruth, sa bru : " Il est bon, ma fille, que tu ailles avec ses servantes, ainsi on ne te maltraitera pas dans un autre champ. " 
###### 23
Et elle resta parmi les servantes de Booz pour glaner jusqu'à la fin de la moisson des orges et de la moisson des blés, et elle habitait avec sa belle-mère. 
