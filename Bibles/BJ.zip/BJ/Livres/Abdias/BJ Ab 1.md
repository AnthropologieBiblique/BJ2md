---
aliases : 
- Abdias 1
- Abdias 1
- Ab 1
- Obadiah 1
tags : 
- Bible/Ab/1
- français
cssclass : français
---

# Abdias 1

###### 1
Vision d'Abdias. Sur Édom. J'ai reçu de Yahvé un message, un héraut était dépêché parmi les nations : "Debout ! Marchons contre ce peuple ! Au combat !" Ainsi parle le Seigneur Yahvé :
###### 2
Vois, je te rends petit parmi les peuples, tu es au plus bas du mépris !
###### 3
L'arrogance de ton coeur t'a égaré, toi qui habites au creux du rocher, toi qui fais des hauteurs ta demeure, toi qui dis en ton cœur : "Qui me fera descendre à terre ?"
###### 4
Quand tu t'élèverais comme l'aigle, quand tu placerais ton nid parmi les étoiles, je t'en précipiterais ! oracle de Yahvé.
###### 5
Si des voleurs venaient chez toi (ou des pillards de nuit), ne déroberaient-ils pas ce qui leur suffit ? Si des vendangeurs venaient chez toi, ne laisseraient-ils rien à grappiller ? Comme tu as été ravagé !
###### 6
Comme Ésaü a été fouillé, ses trésors cachés, explorés ! 
###### 7
Ils t'ont chassé jusqu'aux frontières, ils se sont joué de toi, tous tes alliés ! Ils t'ont dupé, tes bons amis ! Ceux qui mangeaient ton pain tendent des pièges sous tes pas : "Il n'a plus sa raison !"
###### 8
Est-ce qu'en ce jour-là - oracle de Yahvé - je ne supprimerai pas d'Édom les sages et l'intelligence de la montagne d'Ésaü !
###### 9
Témân, tes guerriers seront figés de terreur,
###### 10
pour la violence exercée contre Jacob ton frère, la honte te couvrira et tu disparaîtras à jamais !
###### 11
Quand tu te tenais à l'écart, le jour où des étrangers emmenaient ses richesses, où des barbares franchissaient sa porte et jetaient le sort sur Jérusalem, toi tu étais comme l'un d'eux !
###### 12
Ne te délecte pas à la vue de ton frère au jour de son malheur ! Ne fais pas des enfants de Juda le sujet de ta joie au jour de leur ruine ! Ne tiens pas des propos insolents au jour de l'angoisse ! 
###### 13
Ne franchis pas la porte de mon peuple au jour de sa détresse ! Ne te délecte pas, toi aussi, de la vue de ses maux au jour de sa détresse ! Ne porte pas la main sur ses richesses au jour de sa détresse ! 
###### 14
Ne te poste pas aux carrefours pour exterminer ses fuyards ! Ne livre point ses survivants au jour de l'angoisse ! 
###### 15
Car il est proche, le jour de Yahvé, contre tous les peuples ! Comme tu as fait, il te sera fait : tes actes te retomberont sur la tête ! 
###### 16
Oui, comme vous avez bu sur ma montagne sainte, tous les peuples boiront sans trêve ; ils boiront et se gorgeront, et ils seront comme s'ils n'avaient jamais été ! 
###### 17
Mais sur le mont Sion il y aura des rescapés - ce sera un lieu saint - et la maison de Jacob rentrera dans ses possessions ! 
###### 18
La maison de Jacob sera du feu, la maison de Joseph, une flamme, la maison d'Ésaü, du chaume ! Elles l'embraseront et la dévoreront, et nul ne survivra de la maison d'Ésaü : Yahvé a parlé ! 
###### 19
Ceux du Négeb posséderont la montagne d'Ésaü, ceux du Bas-Pays, la terre des Philistins, ils posséderont le territoire d'Éphraïm et le territoire de Samarie, et Benjamin possédera Galaad.
###### 20
Les exilés de cette armée, les enfants d'Israël, posséderont la terre des Cananéens jusqu'à Sarepta, et les exilés de Jérusalem qui sont à Sepharad posséderont les villes du Négeb.
###### 21
Ils graviront, victorieux, la montagne de Sion pour juger la montagne d'Ésaü, et à Yahvé sera l'empire !
