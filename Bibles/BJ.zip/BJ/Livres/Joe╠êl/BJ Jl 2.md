---
aliases : 
- Joël 2
- Joël 2
- Jl 2
- Joel 2
tags : 
- Bible/Jl/2
- français
cssclass : français
---

# Joël 2

###### 1
Sonnez du cor à Sion, donnez l'alarme sur ma montagne sainte! Que tous les habitants du pays tremblent, car il vient, le jour de Yahvé, car il est proche! 
###### 2
Jour d'obscurité et de sombres nuages, jour de nuées et de ténèbres! Comme l'aurore, se déploie sur les montagnes un peuple nombreux et fort, tel que jamais il n'y en eut, tel qu'il n'en sera plus après lui, de génération en génération. 
###### 3
Devant lui, le feu dévore, derrière lui, la flamme consume. Le pays est comme un jardin d'Éden devant lui, derrière lui, c'est une lande désolée! Aussi rien ne lui échappe. 
###### 4
Son aspect est celui des chevaux; comme des coursiers, tels ils s'élancent. 
###### 5
On dirait un fracas de chars bondissant sur les sommets des monts, le crépitement de la flamme ardente qui dévore le chaume, un peuple fort rangé en bataille. 
###### 6
A sa vue, les peuples sont dans les transes, tous les visages perdent leur couleur. 
###### 7
Ils s'élancent comme des braves, tels des guerriers, ils escaladent les murailles. Chacun va droit sa route, sans s'écarter de sa voie. 
###### 8
Nul ne bouscule son voisin, chacun va son chemin; à travers les traits ils foncent sans rompre leurs rangs. 
###### 9
Ils se ruent sur la ville, s'élancent sur les murailles, escaladent les maisons, pénètrent par les fenêtres comme des voleurs. 
###### 10
Devant lui la terre frémit, les cieux tremblent! Le soleil et la lune s'assombrissent, les étoiles perdent leur éclat! 
###### 11
Yahvé fait entendre sa voix à la tête de ses troupes! Car ses bataillons sont sans nombre, car il est puissant, l'exécuteur de ses ordres, car il est grand, le jour de Yahvé, très redoutable - et qui peut l'affronter ? 
###### 12
" Mais encore à présent - oracle de Yahvé - revenez à moi de tout votre cœur, dans le jeûne, les pleurs et les cris de deuil. " 
###### 13
Déchirez votre cœur, et non vos vêtements, revenez à Yahvé, votre Dieu, car il est tendresse et pitié, lent à la colère, riche en grâce, et il a regret du mal. 
###### 14
Qui sait ? S'il revenait ? S'il regrettait ? S'il laissait après lui une bénédiction, oblation et libation pour Yahvé, votre Dieu ? 
###### 15
Sonnez du cor à Sion! Prescrivez un jeûne, publiez une solennité, 
###### 16
réunissez le peuple, convoquez la communauté, rassemblez les vieillards, réunissez les petits enfants, ceux qu'on allaite au sein! Que le jeune époux quitte sa chambre et l'épousée son alcôve! 
###### 17
Qu'entre l'autel et le portique pleurent les prêtres, serviteurs de Yahvé! Qu'ils disent : " Pitié, Yahvé, pour ton peuple! Ne livre pas ton héritage à l'opprobre, au persiflage des nations! Pourquoi dirait-on parmi les peuples : Où est leur Dieu ? " 
###### 18
Or Yahvé s'émut de jalousie pour son pays, il épargna son peuple. 
###### 19
Yahvé répondit et dit à son peuple : " Voici que je vous envoie le blé, le vin, l'huile fraîche. Vous en aurez à satiété. Et jamais plus je ne ferai de vous l'opprobre des nations. 
###### 20
Celui qui vient du Nord, je l'éloignerai de chez vous, je le repousserai vers une terre aride et désolée, son avant-garde vers la mer orientale, son arrière-garde vers la mer occidentale. Il en montera une puanteur, il en montera une infection! " Car il a fait grand! 
###### 21
Terre, ne crains plus, jubile et sois dans l'allégresse, car Yahvé a fait grand! 
###### 22
Ne craignez plus, bêtes des champs! les pacages des landes ont reverdi, les arbres portent leurs fruits, la vigne et le figuier donnent leurs richesses. 
###### 23
Fils de Sion, jubilez, réjouissez-vous en Yahvé votre Dieu! Car il vous a donné la pluie d'automne selon la justice, il a fait tomber pour vous l'ondée, celle d'automne et celle de printemps, comme jadis. 
###### 24
Les aires se rempliront de froment, les cuves regorgeront de vin et d'huile fraîche. 
###### 25
" Je vous revaudrai les années qu'ont dévorées la sauterelle et le yeleq, le hasîl et le gazam, ma grande armée que j'avais envoyée contre vous. " 
###### 26
Vous mangerez tout votre soûl, à satiété, et vous louerez le nom de Yahvé votre Dieu, qui aura accompli pour vous des merveilles. Mon peuple ne connaîtra plus la honte, jamais! 
###### 27
" Et vous saurez que je suis au milieu d'Israël, moi, que je suis Yahvé, votre Dieu, et sans égal! Mon peuple ne connaîtra plus la honte, jamais! " 
