---
aliases : 
- Joël 1
- Joël 1
- Jl 1
- Joel 1
tags : 
- Bible/Jl/1
- français
cssclass : français
---

# Joël 1

###### 1
Parole de Yahvé, qui fut adressée à Joèl, fils de Petuel. 
###### 2
Écoutez ceci, les anciens, prêtez l'oreille, tous les habitants du pays! Est-il de votre temps survenu rien de tel, ou du temps de vos pères ? 
###### 3
Racontez-le à vos fils, et vos fils à leurs fils, et leurs fils à la génération qui suivra! 
###### 4
Ce qu'a laissé le gazam, la sauterelle l'a dévoré! Ce qu'a laissé la sauterelle, le yeleq l'a dévoré! Ce qu'a laissé le yeleq, le hasîl l'a dévoré! 
###### 5
Réveillez-vous, ivrognes, et pleurez! Tous les buveurs de vin, lamentez-vous sur le vin nouveau : il vous est retiré de la bouche! 
###### 6
Car un peuple est monté contre mon pays, puissant et innombrable; ses dents sont dents de lion, il a des crocs de lionne. 
###### 7
Il a fait de ma vigne un désert, réduit en miettes mon figuier; il les a tout pelés, abattus, leurs rameaux sont devenus blancs! 
###### 8
Gémis, comme sur le fiancé de sa jeunesse la vierge revêtue du sac! 
###### 9
Oblation et libation ont disparu de la maison de Yahvé. Ils sont en deuil, les prêtres serviteurs de Yahvé. 
###### 10
La campagne est ravagée, la terre est en deuil. Car les blés sont ravagés, le vin fait défaut, l'huile fraîche tarit. 
###### 11
Soyez consternés, laboureurs, lamentez-vous, vignerons, sur le froment et sur l'orge, car elle est perdue la moisson des champs. 
###### 12
La vigne est étiolée et le figuier flétri; grenadiers, palmiers et pommiers, tous les arbres des champs ont séché. Oui, la gaieté s'est tarie parmi les humains. 
###### 13
Prêtres, revêtez-vous du sac! Poussez des cris de deuil! Lamentez-vous, serviteurs de l'autel! Venez, passez la nuit vêtus du sac, serviteurs de mon Dieu! Car la maison de votre Dieu est privée d'oblation et de libation. 
###### 14
Prescrivez un jeûne, publiez une solennité, réunissez, anciens, tous les habitants du pays à la maison de Yahvé votre Dieu. Criez vers Yahvé : 
###### 15
Ah! Quel jour! Car il est proche, le jour de Yahvé, il arrive comme une dévastation venant de Shaddaï. 
###### 16
Les aliments n'ont-ils pas disparu sous nos yeux, la joie et l'allégresse de la maison de notre Dieu ? 
###### 17
Les grains se sont racornis sous leurs mottes; les granges sont dévastées, les greniers en ruines, car le blé fait défaut. 
###### 18
Comme le bétail gémit! Les troupeaux de bœufs errent affolés, car ils n'ont plus de pâtures. Même les troupeaux de brebis subissent le châtiment. 
###### 19
Yahvé, je crie vers toi! car le feu a dévoré les pacages des landes, la flamme a consumé tous les arbres des champs. 
###### 20
Même les bêtes des champs languissent après toi, car les cours d'eau sont à sec, le feu a dévoré les pacages des landes. 
