---
aliases : 
- Joël 3
- Joël 3
- Jl 3
- Joel 3
tags : 
- Bible/Jl/3
- français
cssclass : français
---

# Joël 3

###### 1
" Après cela je répandrai mon Esprit sur toute chair. Vos fils et vos filles prophétiseront, vos anciens auront des songes, vos jeunes gens, des visions. 
###### 2
Même sur les esclaves, hommes et femmes, en ces jours-là, je répandrai mon Esprit. 
###### 3
Je produirai des signes dans le ciel et sur la terre, sang, feu, colonnes de fumée! " 
###### 4
Le soleil se changera en ténèbres, la lune en sang, avant que ne vienne le jour de Yahvé, grand et redoutable! 
###### 5
Tous ceux qui invoqueront le nom de Yahvé seront sauvés, car sur le mont Sion il y aura des rescapés, comme l'a dit Yahvé, et à Jérusalem des survivants que Yahvé appelle. 
