---
aliases : 
- Joël 4
- Joël 4
- Jl 4
- Joel 4
tags : 
- Bible/Jl/4
- français
cssclass : français
---

# Joël 4

###### 1
" Car en ces jours-là, en ce temps-là, quand je rétablirai Juda et Jérusalem, 
###### 2
je rassemblerai toutes les nations, je les ferai descendre à la Vallée de Josaphat; là j'entrerai en jugement avec elles au sujet d'Israël, mon peuple et mon héritage. Car ils l'ont dispersé parmi les nations et ils ont partagé mon pays. 
###### 3
Ils ont tiré mon peuple au sort; ils ont troqué les garçons contre des prostituées, pour du vin ils ont vendu les filles, et ils ont bu! " 
###### 4
" Et vous aussi, Tyr et Sidon, que me voulez-vous ? Et vous tous, districts de Philistie ? Vous vengeriez-vous sur moi ? Mais si vous exerciez sur moi votre vengeance, bien vite je ferais retomber la vengeance sur vos têtes! 
###### 5
Vous qui avez pris mon argent et mon or, qui avez emporté dans vos temples mes trésors précieux, 
###### 6
vous qui avez vendu aux fils de Yavân les fils de Juda et de Jérusalem, pour les éloigner de leur territoire! 
###### 7
Eh bien! Je vais les appeler du lieu où vous les avez vendus, et je ferai retomber vos actes sur vos têtes! 
###### 8
Je vendrai vos fils et vos filles, je les livrerai aux fils de Juda; ils les vendront aux Sabéens, à une nation éloignée, car Yahvé a parlé! " 
###### 9
Publiez ceci parmi les nations : Préparez la guerre! Appelez les braves! Qu'ils s'avancent, qu'ils montent, tous les hommes de guerre! 
###### 10
De vos socs, forgez des épées, de vos serpes, des lances, que l'infirme dise : " Je suis un brave! " 
###### 11
Hâtez-vous et venez, toutes les nations d'alentour, et rassemblez-vous là! Yahvé, fais descendre tes braves. 
###### 12
" Que les nations s'ébranlent et qu'elles montent à la Vallée de Josaphat! Car là je siégerai pour juger toutes les nations à la ronde. 
###### 13
Lancez la faucille : la moisson est mûre; venez, foulez : le pressoir est comble; les cuves débordent, tant leur méchanceté est grande! " 
###### 14
Foules sur foules dans la Vallée de la Décision! Car il est proche le jour de Yahvé dans la Vallée de la Décision! 
###### 15
Le soleil et la lune s'assombrissent, les étoiles perdent leur éclat. 
###### 16
Yahvé rugit de Sion, de Jérusalem il fait entendre sa voix; les cieux et la terre tremblent! Mais Yahvé sera pour son peuple un refuge, une forteresse pour les enfants d'Israël! 
###### 17
" Vous saurez alors que je suis Yahvé, votre Dieu, qui habite à Sion, ma montagne sainte! Jérusalem sera un lieu saint, les étrangers n'y passeront plus! " 
###### 18
Ce jour-là, les montagnes dégoutteront de vin nouveau, les collines ruisselleront de lait, et dans tous les torrents de Juda les eaux ruisselleront. Une source jaillira de la maison de Yahvé et arrosera le ravin des Acacias. 
###### 19
L'Égypte deviendra une désolation, Édom une lande désolée, à cause des violences exercées contre les fils de Juda dont ils ont versé le sang innocent dans leur pays. 
###### 20
Mais Juda sera habité à jamais et Jérusalem d'âge en âge. 
###### 21
" Je vengerai leur sang, je n'accorderai pas l'impunité ", et Yahvé aura sa demeure à Sion. 
