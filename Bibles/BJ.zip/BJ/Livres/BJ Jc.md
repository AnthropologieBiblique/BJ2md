---
aliases : 
- Jacques
- Jacques
- Jc
- James
tags : 
- Bible/Jc
- français
cssclass : français
---

# Jacques

[[BJ Jc 1|Jacques 1]]
[[BJ Jc 2|Jacques 2]]
[[BJ Jc 3|Jacques 3]]
[[BJ Jc 4|Jacques 4]]
[[BJ Jc 5|Jacques 5]]
