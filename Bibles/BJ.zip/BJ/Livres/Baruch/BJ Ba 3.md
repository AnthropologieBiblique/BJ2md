---
aliases : 
- Baruch 3
- Baruch 3
- Ba 3
tags : 
- Bible/Ba/3
- français
cssclass : français
---

# Baruch 3

###### 1
Seigneur tout-puissant, Dieu d'Israël, c'est une âme angoissée, un esprit ébranlé, qui te crie
###### 2
Ecoute, Seigneur, aie pitié, car nous avons péché devant toi.
###### 3
Toi, tu trônes éternellement; nous autres, nous périssons pour toujours.
###### 4
Seigneur tout-puissant, Dieu d'Israël, écoute donc la supplication des morts d'Israël, des fils de ceux qui ont péché contre toi, qui n'ont pas écouté la voix du Seigneur leur Dieu de sorte que les malheurs se sont attachés à nous.
###### 5
Ne te souviens pas des fautes de nos pères, mais en cette heure souviens-toi de ta main et de ton Nom.
###### 6
Oui, tu es le Seigneur notre Dieu, et nous voulons te louer, Seigneur.
###### 7
Car tu as mis en nos cœurs ta crainte pour que nous invoquions ton Nom. Nous voulons te louer en notre exil, puisque nous avons écarté de notre cœur toute la méchanceté de nos pères qui ont péché devant toi.
###### 8
Nous voici, aujourd'hui encore, en cet exil où tu nous as dispersés pour être un opprobre, une malédiction, une condamnation, après toutes les fautes de nos pères, qui s'étaient éloignés du Seigneur notre Dieu.
###### 9
Ecoute, Israël, les préceptes de vie, tends l'oreille pour connaître la science.
###### 10
Pourquoi, Israël, pourquoi es-tu au pays de tes ennemis, vieillissant en terre étrangère,
###### 11
te souillant avec les morts, compté parmi ceux qui vont au shéol?
###### 12
C'est que tu abandonnas la Source de la Sagesse!
###### 13
Si tu avais marché dans la voie de Dieu, tu habiterais dans la paix pour toujours.
###### 14
Apprends où est la science, où est la force, où est l'intelligence, pour connaître aussi où est la longueur de jours et la vie, où est la lumière des yeux et la paix.
###### 15
Mais qui a découvert son lieu, qui a pénétré en ses trésors?
###### 16
Où sont-ils les chefs des nations et les dominateurs des bêtes de la terre,
###### 17
ceux qui se jouent des oiseaux du ciel, ceux qui accumulent l'argent et l'or sur quoi les hommes s'appuient, et dont les possessions n'ont pas de fin,
###### 18
ceux qui travaillent l'argent avec grand soin mais leurs œuvres ne laissent pas de traces?
###### 19
Ils ont disparu, descendus au shéol! D'autres à leur place se sont levés,
###### 20
de plus jeunes ont vu la lumière et ont habité sur la terre mais la voie de la connaissance ils ne l'ont pas connue,
###### 21
ils n'ont pas compris ses sentiers. Leurs fils non plus ne l'ont point saisie, ils sont restés loin de sa voie.
###### 22
On n'a rien su d'elle en Canaan, on ne l'a pas aperçue à Témân;
###### 23
les fils d'Agar en quête d'intelligence ici-bas, les marchands de Madiân et de Téma, les diseurs de paraboles et les chercheurs d'intelligence n'ont pas connu la voie de la sagesse, ne se sont pas rappelés ses sentiers.
###### 24
Qu'elle est grande, Israël, la demeure de Dieu, qu'il est étendu le lieu de son domaine,
###### 25
grand et sans borne, haut et immense!
###### 26
Là naquirent les géants, fameux dès l'origine, hauts de stature, experts à la guerre;
###### 27
de ceux-là Dieu ne fit pas choix, il ne leur montra pas la voie de la connaissance;
###### 28
ils périrent, car ils n'avaient pas la science, ils périrent par leur folie.
###### 29
Qui monta au ciel pour la saisir et la faire descendre des nuées?
###### 30
Qui passa la mer pour la découvrir et la rapporter au prix d'un or très pur?
###### 31
Nul ne connaît sa voie, nul ne comprend son sentier.
###### 32
Mais Celui qui sait tout la connaît, il l'a scrutée par son intelligence, lui qui pour l'éternité a disposé la terre et l'a emplie de bétail,
###### 33
lui qui envoie la lumière, et elle part, qui la rappelle, et elle obéit en tremblant;
###### 34
les étoiles brillent à leur poste, joyeuses
###### 35
les appelle-t-il, elles répondent : Nous voici! elles brillent avec joie pour leur Créateur.
###### 36
C'est lui qui est notre Dieu aucun autre ne lui est comparable.
###### 37
Il a creusé la voie entière de la connaissance et l'a montrée à Jacob, son serviteur, à Israël, son bien-aimé;
###### 38
puis elle est apparue sur terre et elle a vécu parmi les hommes.
