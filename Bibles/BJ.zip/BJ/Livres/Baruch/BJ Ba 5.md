---
aliases : 
- Baruch 5
- Baruch 5
- Ba 5
tags : 
- Bible/Ba/5
- français
cssclass : français
---

# Baruch 5

###### 1
Jérusalem quitte ta robe de tristesse et de misère, revêts pour toujours la beauté de la gloire de Dieu,
###### 2
prends la tunique de la justice de Dieu, mets sur ta tête le diadème de gloire de l'Eternel;
###### 3
car Dieu veut montrer ta splendeur partout sous le ciel,
###### 4
et ton nom sera de par Dieu pour toujours "Paix de la justice et gloire de la piété."
###### 5
Jérusalem, lève-toi, tiens-toi sur la hauteur, et regarde vers l'Orient vois tes enfants du couchant au levant rassemblés sur l'ordre du Saint, jubilants, car Dieu s'est souvenu.
###### 6
Car ils t'avaient quittée à pied, sous escorte d'ennemis, mais Dieu te les ramène portés glorieusement, comme un trône royal.
###### 7
Car Dieu a décidé que soient abaissées toute haute montagne et les collines éternelles, et comblées les vallées pour aplanir la terre, pour qu'Israël chemine en sécurité dans la gloire de Dieu.
###### 8
Et les forêts, et tous arbres de senteur feront de l'ombre pour Israël, sur l'ordre de Dieu;
###### 9
car Dieu guidera Israël dans la joie, à la lumière de sa gloire, avec la miséricorde et la justice qui viennent de lui.
