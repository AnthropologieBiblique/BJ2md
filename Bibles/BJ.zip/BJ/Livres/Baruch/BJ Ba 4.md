---
aliases : 
- Baruch 4
- Baruch 4
- Ba 4
tags : 
- Bible/Ba/4
- français
cssclass : français
---

# Baruch 4

###### 1
Elle est le Livre des préceptes de Dieu, la Loi qui subsiste éternellement quiconque la garde vivra, quiconque l'abandonne mourra.
###### 2
Reviens, Jacob, saisis-la, marche vers la splendeur, à sa lumière
###### 3
ne cède pas à autrui ta gloire, à un peuple étranger tes privilèges.
###### 4
Heureux sommes-nous, Israël ce qui plaît à Dieu nous fut révélé!
###### 5
Courage, mon peuple, mémorial d'Israël!
###### 6
Vous avez été vendus aux nations, mais non pour l'anéantissement. Ayant excité la colère de Dieu, vous avez été livrés à vos ennemis.
###### 7
Car vous aviez irrité votre Créateur en sacrifiant à des démons et non à Dieu.
###### 8
Vous aviez oublié le Dieu éternel, votre nourricier! Vous avez aussi attristé Jérusalem, votre nourricière;
###### 9
elle a vu fondre sur vous la colère venue de Dieu et elle a dit Ecoutez, voisines de Sion Dieu m'a envoyé grande tristesse.
###### 10
J'ai vu la captivité de mes fils et filles que l'Eternel leur amena.
###### 11
Je les avais nourris avec joie; avec pleurs et tristesse je les vis partir.
###### 12
Que nul ne se réjouisse sur moi, veuve et délaissée d'un grand nombre; je subis la solitude pour les péchés de mes enfants, car ils se sont détournés de la Loi de Dieu,
###### 13
ils n'ont point connu ses préceptes, ni marché par les voies de ses préceptes, ni suivi les sentiers de discipline selon sa justice.
###### 14
Qu'elles arrivent, les voisines de Sion! Rappelez-vous la captivité de mes fils et filles que l'Eternel leur amena!
###### 15
Car il amena sur eux une nation lointaine, une nation effrontée, à la langue barbare, sans respect pour le vieillard, sans pitié pour le petit enfant;
###### 16
on emmena les fils chéris de la veuve, on la laissa toute seule, privée de ses filles.
###### 17
Moi, comment pourrais-je vous aider?
###### 18
Celui qui vous amena ces malheurs, c'est lui qui vous arrachera aux mains de vos ennemis.
###### 19
Allez, mes enfants, allez votre chemin! Moi, je reste délaissée, solitaire;
###### 20
j'ai quitté la robe de paix et revêtu le sac de ma supplication; je veux crier vers l'Eternel tant que je vivrai.
###### 21
Courage, mes enfants, criez vers Dieu il vous arrachera à la violence et à la main de vos ennemis;
###### 22
car j'attends de l'Eternel votre salut, une joie m'est venue du Saint, pour la miséricorde qui bientôt vous arrivera de l'Eternel, votre Sauveur.
###### 23
Car avec tristesse et pleurs je vous ai vus partir, mais Dieu vous rendra à moi pour toujours dans la joie et la jubilation.
###### 24
Comme les voisines de Sion voient maintenant votre captivité, ainsi verront-elles bientôt votre salut de par Dieu, qui vous surviendra avec grande gloire et éclat de l'Eternel.
###### 25
Mes enfants, supportez la colère qui de Dieu vous est venue. Ton ennemi t'a persécuté, mais bientôt tu verras sa ruine et sur sa nuque tu poseras ton pied.
###### 26
Mes enfants choyés ont marché par de rudes chemins, enlevés, tel un troupeau razzié par l'ennemi.
###### 27
Courage, mes enfants, criez vers Dieu Celui qui vous amena cela se souviendra de vous.
###### 28
Comme votre pensée fut d'égarement loin de Dieu, revenus à lui, recherchez-le dix fois plus fort.
###### 29
Car Celui qui vous amena ces malheurs vous ramènera, en vous sauvant, la joie éternelle.
###### 30
Courage, Jérusalem il te consolera, Celui qui t'a donné un nom.
###### 31
Malheur à ceux qui t'ont maltraitée et se sont réjouis de ta chute!
###### 32
Malheur aux cités dont furent esclaves tes enfants, malheur à celle qui reçut tes fils!
###### 33
Car de même qu'elle se réjouit de ta chute et fut heureuse de ta ruine, ainsi sera-t-elle affligée pour sa propre dévastation.
###### 34
Je lui ôterai son allégresse de ville bien peuplée, son insolence se changera en tristesse,
###### 35
un feu lui surviendra de l'Eternel pour de longs jours, elle sera la demeure de démons pour longtemps.
###### 36
Jérusalem, regarde vers l'Orient, vois la joie qui te vient de Dieu.
###### 37
Voici : ils reviennent, les fils que tu vis partir, ils reviennent rassemblés du levant au couchant, sur l'ordre du Saint, jubilants de la gloire de Dieu.
