---
aliases : 
- Baruch 2
- Baruch 2
- Ba 2
tags : 
- Bible/Ba/2
- français
cssclass : français
---

# Baruch 2

###### 1
Aussi le Seigneur a-t-il accompli la parole qu'il avait prononcée contre nous, contre nos juges qui gouvernèrent Israël, contre nos rois et nos chefs, contre les gens d'Israël et de Juda;
###### 2
sous l'immensité du ciel ne se produisit jamais rien de semblable à ce qu'il fit à Jérusalem, selon ce qui était écrit dans la Loi de Moïse
###### 3
nous en arrivâmes à manger chacun la chair de son fils, chacun la chair de sa fille.
###### 4
De plus, il les a mis au pouvoir de tous les royaumes qui nous entourent, pour être un opprobre et une exécration parmi tous les peuples d'alentour où le Seigneur les dispersa.
###### 5
Ils furent assujettis au lieu d'être maîtres, parce que nous avions offensé le Seigneur notre Dieu, en n'écoutant point sa voix.
###### 6
Au Seigneur notre Dieu la justice, mais pour nous et pour nos pères la honte au visage, comme il en est aujourd'hui.
###### 7
Tous ces malheurs que le Seigneur avait énoncés contre nous sont venus sur nous.
###### 8
Nous n'avons pas supplié la face du Seigneur, chacun de nous se détournant des pensées de son cœur mauvais
###### 9
alors le Seigneur a veillé sur ces malheurs et les a amenés sur nous; car le Seigneur est juste en toutes les œuvres qu'il nous a commandées,
###### 10
et nous n'avons pas écouté sa voix en marchant selon les ordres que le Seigneur avait mis devant nous.
###### 11
Et maintenant, Seigneur, Dieu d'Israël, toi qui tiras ton peuple du pays d'Egypte à main forte, par signes et miracles, par grande puissance et bras étendu, te faisant de la sorte un nom comme il en est aujourd'hui,
###### 12
nous avons péché, nous avons été impies, nous avons été injustes, Seigneur notre Dieu, pour tous tes préceptes.
###### 13
Que ta colère se détourne de nous, puisque nous ne sommes plus qu'un petit reste parmi les nations où tu nous dispersas.
###### 14
Ecoute, Seigneur, notre prière et notre supplication délivre-nous à cause de toi-même, et fais-nous trouver grâce devant ceux qui nous ont déportés,
###### 15
afin que la terre entière sache que tu es le Seigneur, notre Dieu, puisqu'Israël et sa race portent ton Nom.
###### 16
Seigneur, regarde de ta demeure sainte, et pense à nous, tends l'oreille et écoute,
###### 17
ouvre les yeux, Seigneur, et vois; ce ne sont pas les morts dans le shéol, ceux dont le souffle fut enlevé des entrailles, qui rendent gloire et justice au Seigneur;
###### 18
mais l'âme comblée d'affliction, celui qui chemine courbé et sans force, les yeux défaillants et l'âme affamée, voilà ce qui te rend gloire et justice, Seigneur!
###### 19
Nous ne nous appuyons pas sur les mérites de nos pères et de nos rois pour déposer notre supplication devant ta face, Seigneur notre Dieu.
###### 20
Car tu as envoyé sur nous ta colère et ta fureur, comme tu l'avais proclamé par le ministère de tes serviteurs les prophètes, en ces termes
###### 21
"Ainsi parle le Seigneur : Inclinez votre nuque et servez le roi de Babylone; alors, vous resterez au pays que j'ai donné à vos pères.
###### 22
Mais si vous n'écoutez pas l'invitation du Seigneur à servir le roi de Babylone,
###### 23
je ferai cesser, aux villes de Juda et à Jérusalem, le chant de joie et le chant d'allégresse, le chant du fiancé et le chant de la fiancée, et tout le pays deviendra une désolation, sans habitants."
###### 24
Mais nous n'avons pas écouté ton invitation à servir le roi de Babylone, alors tu as accompli les paroles que tu avais prononcées par le ministère de tes serviteurs les prophètes que les os de nos rois et les os de nos pères seraient arrachés de leur lieu.
###### 25
Voici qu'en effet ils furent jetés dehors à la chaleur du jour et au froid de la nuit. Et l'on mourut au milieu de terribles misères, par la famine, l'épée et la peste.
###### 26
Et tu fis de cette maison, qui porte ton Nom, ce qu'elle est aujourd'hui, à cause de la méchanceté de la maison d'Israël et de la maison de Juda.
###### 27
Pourtant, tu as agi envers nous, Seigneur notre Dieu, selon toute ton indulgence et ton immense tendresse,
###### 28
comme tu l'avais déclaré par le ministère de ton serviteur Moïse, le jour où tu lui commandas d'écrire ta Loi en présence des Israélites, en ces termes
###### 29
"Si vous n'écoutez pas ma voix, cette immense et innombrable multitude elle-même sera réduite à un petit nombre parmi les nations où je les disperserai,
###### 30
car je sais qu'ils ne m'écouteront point; c'est un peuple à la nuque raide. Mais dans le pays de leur exil, ils rentreront en eux-mêmes
###### 31
et connaîtront que je suis le Seigneur leur Dieu. Je leur donnerai un cœur et des oreilles qui entendent.
###### 32
Ils me loueront au pays de leur exil, ils se souviendront de mon nom;
###### 33
ils n'auront plus la nuque raide et se détourneront de leurs mauvaises actions, se rappelant le destin de leurs pères qui ont péché devant le Seigneur.
###### 34
Alors je les ramènerai au pays que j'ai promis par serment à leurs pères Abraham, Isaac et Jacob, et ils y seront maîtres. Je les multiplierai et ils ne seront plus diminués.
###### 35
Pour eux, j'établirai une alliance éternelle; je serai leur Dieu et ils seront mon peuple. Et je ne repousserai plus mon peuple Israël du pays que je leur ai donné."
