---
aliases : 
- Baruch 1
- Baruch 1
- Ba 1
tags : 
- Bible/Ba/1
- français
cssclass : français
---

# Baruch 1

###### 1
Voici les paroles du livre qu'écrivit à Babylone Baruch, fils de Nérias, fils de Maasias, fils de Sédécias, fils d'Asadias, fils d'Helcias,
###### 2
la cinquième année, le septième jour du mois, à l'époque où les Chaldéens s'étaient emparés de Jérusalem et l'avaient incendiée.
###### 3
Or Baruch lut les paroles de ce livre devant Jékonias, fils de Joiaqim, roi de Juda, et devant tout le peuple venu pour cette lecture,
###### 4
devant les dignitaires et les fils de roi, devant les anciens, bref devant le peuple entier, petits et grands, devant tous ceux qui habitaient à Babylone, aux bords de la rivière Soud.
###### 5
On pleurait, on jeûnait et on priait en présence du Seigneur;
###### 6
on collecta aussi de l'argent, selon les possibilités de chacun,
###### 7
et on l'envoya à Jérusalem au prêtre Joaqim, fils d'Helcias, fils de Salom, ainsi qu'aux autres prêtres et à tout le peuple qui se trouvait avec lui à Jérusalem.
###### 8
C'était déjà Baruch qui avait récupéré, le dixième jour de Sivân, les ustensiles de la maison du Seigneur, enlevés au Temple, pour les rapporter au pays de Juda, ustensiles d'argent qu'avait fait fabriquer Sédécias, fils de Josias, roi de Juda,
###### 9
après que Nabuchodonosor, roi de Babylone, eut déporté de Jérusalem et mené à Babylone Jékonias, avec les princes, les serruriers, les notables et le commun peuple.
###### 10
On écrivit : Voici, nous vous envoyons de l'argent; avec cet argent, achetez holocaustes, oblations pour le péché et encens; préparez des offrandes et portez-les sur l'autel du Seigneur notre Dieu.
###### 11
Priez pour la vie de Nabuchodonosor, roi de Babylone, et pour la vie de Balthazar son fils, que leurs jours soient sur terre comme les jours du ciel;
###### 12
que le Seigneur nous donne force et illumine nos yeux, pour que nous vivions à l'ombre de Nabuchodonosor, roi de Babylone, et à l'ombre de Balthazar son fils, les servions longtemps et trouvions grâce en leur présence.
###### 13
Priez aussi pour nous le Seigneur notre Dieu, car nous l'avons offensé et jusqu'aujourd'hui la fureur et la colère du Seigneur ne se sont pas détournées de nous.
###### 14
Lisez enfin ce livre que nous vous adressons pour que vous en fassiez la lecture publique, dans la maison du Seigneur, au jour de la Fête et aux jours qui conviennent.
###### 15
Vous direz Au Seigneur notre Dieu la justice, mais pour nous, la honte au visage, comme il en est aujourd'hui, pour l'homme de Juda et les habitants de Jérusalem,
###### 16
pour nos rois et nos princes, pour nos prêtres et nos prophètes, pour nos pères,
###### 17
parce que nous avons péché devant le Seigneur,
###### 18
nous lui avons désobéi et n'avons point écouté la voix du Seigneur notre Dieu, pour marcher selon les ordres que le Seigneur avait mis devant nous.
###### 19
Dès le jour où le Seigneur tira nos pères du pays d'Egypte jusqu'aujourd'hui, nous avons été indociles au Seigneur notre Dieu et nous nous sommes rebellés en n'écoutant pas sa voix.
###### 20
Alors se sont attachés à nous les malheurs et la malédiction que le Seigneur dicta à son serviteur Moïse, le jour où il tira nos pères d'Egypte pour nous donner une terre qui ruisselle de lait et de miel, comme aujourd'hui encore.
###### 21
Nous n'avons pas écouté la voix du Seigneur notre Dieu, selon toutes les paroles des prophètes qu'il nous envoya;
###### 22
nous sommes allés, chacun suivant l'inclination de son cœur mauvais, servir d'autres dieux, faire ce qui déplaît au Seigneur notre Dieu.
