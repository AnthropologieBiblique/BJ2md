---
aliases : 
- Éphésiens 6
- Éphésiens 6
- Ep 6
- Ephesians 6
tags : 
- Bible/Ep/6
- français
cssclass : français
---

# Éphésiens 6

###### 1
Enfants, obéissez à vos parents, dans le Seigneur : cela est juste. 
###### 2
Honore ton père et ta mère, tel est le premier commandement auquel soit attachée une promesse : 
###### 3
pour que tu t'en trouves bien et jouisses d'une longue vie sur la terre. 
###### 4
Et vous, parents, n'exaspérez pas vos enfants, mais usez, en les éduquant, de corrections et de semonces qui s'inspirent du Seigneur. 
###### 5
Esclaves, obéissez à vos maîtres d'ici-bas avec crainte et tremblement, en simplicité de cœur, comme au Christ ; 
###### 6
non d'une obéissance tout extérieure qui cherche à plaire aux hommes, mais comme des esclaves du Christ, qui font avec âme la volonté de Dieu. 
###### 7
Que votre service empressé s'adresse au Seigneur et non aux hommes, 
###### 8
dans l'assurance que chacun sera payé par le Seigneur selon ce qu'il aura fait de bien, qu'il soit esclave ou qu'il soit libre. 
###### 9
Et vous, maîtres, agissez de même à leur égard ; laissez de côté les menaces, et dites-vous bien que, pour eux comme pour vous, le Maître est dans les cieux, et qu'il ne fait point acception des personnes. 
###### 10
En définitive, rendez-vous puissants dans le Seigneur et dans la vigueur de sa force. 
###### 11
Revêtez l'armure de Dieu, pour pouvoir résister aux manœuvres du diable. 
###### 12
Car ce n'est pas contre des adversaires de sang et de chair que nous avons à lutter, mais contre les Principautés, contre les Puissances, contre les Régisseurs de ce monde de ténèbres, contre les esprits du mal qui habitent les espaces célestes. 
###### 13
C'est pour cela qu'il vous faut endosser l'armure de Dieu, afin qu'au jour mauvais vous puissiez résister et, après avoir tout mis en œuvre, rester fermes. 
###### 14
Tenez-vous donc debout, avec la Vérité pour ceinture, la Justice pour cuirasse, 
###### 15
et pour chaussures le Zèle à propager l'Évangile de la paix ; 
###### 16
ayez toujours en main le bouclier de la Foi, grâce auquel vous pourrez éteindre tous les traits enflammés du Mauvais ; 
###### 17
enfin recevez le casque du Salut et le glaive de l'Esprit, c'est-à-dire la Parole de Dieu. 
###### 18
Vivez dans la prière et les supplications ; priez en tout temps, dans l'Esprit ; apportez-y une vigilance inlassable et intercédez pour tous les saints. 
###### 19
Priez aussi pour moi, afin qu'il me soit donné d'ouvrir la bouche pour parler et d'annoncer hardiment le mystère de l'Évangile, 
###### 20
dont je suis l'ambassadeur dans mes chaînes ; obtenez-moi la hardiesse d'en parler comme je le dois. 
###### 21
Je désire que vous sachiez, vous aussi, où j'en suis et ce que je deviens ; vous serez informés de tout par Tychique, ce frère bien-aimé qui m'est un fidèle assistant dans le Seigneur. 
###### 22
Je vous l'envoie tout exprès pour vous donner de nos nouvelles et réconforter vos cœurs. 
###### 23
Que Dieu le Père et le Seigneur Jésus Christ accordent paix aux frères, ainsi que charité et foi. 
###### 24
La grâce soit avec tous ceux qui aiment notre Seigneur Jésus Christ, dans la vie incorruptible ! 
