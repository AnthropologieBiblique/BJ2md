---
aliases : 
- Éphésiens 2
- Éphésiens 2
- Ep 2
- Ephesians 2
tags : 
- Bible/Ep/2
- français
cssclass : français
---

# Éphésiens 2

###### 1
Et vous qui étiez morts par suite des fautes et des péchés 
###### 2
dans lesquels vous avez vécu jadis, selon le cours de ce monde, selon le Prince de l'empire de l'air, cet Esprit qui poursuit son œuvre en ceux qui résistent... 
###### 3
Nous tous d'ailleurs, nous fûmes jadis de ceux-là, vivant selon nos convoitises charnelles, servant les caprices de la chair et des pensées coupables, si bien que nous étions par nature voués à la colère tout comme les autres... 
###### 4
Mais Dieu, qui est riche en miséricorde, à cause du grand amour dont Il nous a aimés, 
###### 5
alors que nous étions morts par suite de nos fautes, nous a fait revivre avec le Christ - c'est par grâce que vous êtes sauvés ! - 
###### 6
avec lui Il nous a ressuscités et fait asseoir aux cieux, dans le Christ Jésus. 
###### 7
Il a voulu par là démontrer dans les siècles à venir l'extraordinaire richesse de sa grâce, par sa bonté pour nous dans le Christ Jésus. 
###### 8
Car c'est bien par la grâce que vous êtes sauvés, moyennant la foi. Ce salut ne vient pas de vous, il est un don de Dieu ; 
###### 9
il ne vient pas des œuvres, car nul ne doit pouvoir se glorifier. 
###### 10
Nous sommes en effet son ouvrage, créés dans le Christ Jésus en vue des bonnes œuvres que Dieu a préparées d'avance pour que nous les pratiquions. 
###### 11
Rappelez-vous donc qu'autrefois, vous les païens - qui étiez tels dans la chair, vous qui étiez appelés " prépuce " par ceux qui s'appellent " circoncision ", . . . d'une opération pratiquée dans la chair ! - 
###### 12
rappelez-vous qu'en ce temps-là vous étiez sans Christ, exclus de la cité d'Israël, étrangers aux alliances de la Promesse, n'ayant ni espérance ni Dieu en ce monde ! 
###### 13
Or voici qu'à présent, dans le Christ Jésus, vous qui jadis étiez loin, vous êtes devenus proches, grâce au sang du Christ. 
###### 14
Car c'est lui qui est notre paix, lui qui des deux peuples n'en a fait qu'un, détruisant la barrière qui les séparait, supprimant en sa chair la haine, 
###### 15
cette Loi des préceptes avec ses ordonnances, pour créer en sa personne les deux en un seul Homme Nouveau, faire la paix, 
###### 16
et les réconcilier avec Dieu, tous deux en un seul Corps, par la Croix : en sa personne il a tué la Haine. 
###### 17
Alors il est venu proclamer la paix, paix pour vous qui étiez loin et paix pour ceux qui étaient proches : 
###### 18
par lui nous avons en effet, tous deux en un seul Esprit, libre accès auprès du Père. 
###### 19
Ainsi donc, vous n'êtes plus des étrangers ni des hôtes ; vous êtes concitoyens des saints, vous êtes de la maison de Dieu. 
###### 20
Car la construction que vous êtes a pour fondation les apôtres et prophètes, et pour pierre d'angle le Christ Jésus lui-même. 
###### 21
En lui toute construction s'ajuste et grandit en un temple saint, dans le Seigneur ; 
###### 22
en lui, vous aussi, vous êtes intégrés à la construction pour devenir une demeure de Dieu, dans l'Esprit. 
