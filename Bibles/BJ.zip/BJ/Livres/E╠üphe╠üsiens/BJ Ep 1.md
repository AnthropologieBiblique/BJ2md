---
aliases : 
- Éphésiens 1
- Éphésiens 1
- Ep 1
- Ephesians 1
tags : 
- Bible/Ep/1
- français
cssclass : français
---

# Éphésiens 1

###### 1
Paul, apôtre du Christ Jésus, par la volonté de Dieu, aux saints et fidèles dans le Christ Jésus. 
###### 2
A vous grâce et paix de par Dieu notre Père et le Seigneur Jésus Christ. 
###### 3
Béni soit le Dieu et Père de notre Seigneur Jésus Christ, qui nous a bénis par toutes sortes de bénédictions spirituelles, aux cieux, dans le Christ. 
###### 4
C'est ainsi qu'Il nous a élus en lui, dès avant la fondation du monde, pour être saints et immaculés en sa présence, dans l'amour, 
###### 5
déterminant d'avance que nous serions pour Lui des fils adoptifs par Jésus Christ. Tel fut le bon plaisir de sa volonté, 
###### 6
à la louange de gloire de sa grâce, dont Il nous a gratifiés dans le Bien-aimé. 
###### 7
En lui nous trouvons la rédemption, par son sang, la rémission des fautes, selon la richesse de sa grâce, 
###### 8
qu'Il nous a prodiguée, en toute sagesse et intelligence : 
###### 9
Il nous a fait connaître le mystère de sa volonté, ce dessein bienveillant qu'Il avait formé en lui par avance, 
###### 10
pour le réaliser quand les temps seraient accomplis : ramener toutes choses sous un seul Chef, le Christ, les êtres célestes comme les terrestres. 
###### 11
C'est en lui encore que nous avons été mis à part, désignés d'avance, selon le plan préétabli de Celui qui mène toutes choses au gré de sa volonté, 
###### 12
pour être, à la louange de sa gloire, ceux qui ont par avance espéré dans le Christ. 
###### 13
C'est en lui que vous aussi, après avoir entendu la Parole de vérité, l'Évangile de votre salut, et y avoir cru, vous avez été marqués d'un sceau par l'Esprit de la Promesse, cet Esprit Saint 
###### 14
qui constitue les arrhes de notre héritage, et prépare la rédemption du Peuple que Dieu s'est acquis, pour la louange de sa gloire. 
###### 15
C'est pourquoi moi-même, ayant appris votre foi dans le Seigneur Jésus et votre charité à l'égard de tous les saints, 
###### 16
je ne cesse de rendre grâces à votre sujet et de faire mémoire de vous dans mes prières. 
###### 17
Daigne le Dieu de notre Seigneur Jésus Christ, le Père de la gloire, vous donner un esprit de sagesse et de révélation, qui vous le fasse vraiment connaître ! 
###### 18
Puisse-t-il illuminer les yeux de votre cœur pour vous faire voir quelle espérance vous ouvre son appel, quels trésors de gloire renferme son héritage parmi les saints, 
###### 19
et quelle extraordinaire grandeur sa puissance revêt pour nous, les croyants, selon la vigueur de sa force, 
###### 20
qu'il a déployée en la personne du Christ, le ressuscitant d'entre les morts et le faisant siéger à sa droite, dans les cieux, 
###### 21
bien au-dessus de toute Principauté, Puissance, Vertu, Seigneurie, et de tout autre nom qui se pourra nommer, non seulement dans ce siècle-ci, mais encore dans le siècle à venir. 
###### 22
Il a tout mis sous ses pieds, et l'a constitué, au sommet de tout, Tête pour l'Église, 
###### 23
laquelle est son Corps, la Plénitude de Celui qui est rempli, tout en tout. 
