---
aliases : 
- Éphésiens 5
- Éphésiens 5
- Ep 5
- Ephesians 5
tags : 
- Bible/Ep/5
- français
cssclass : français
---

# Éphésiens 5

###### 1
Oui, cherchez à imiter Dieu, comme des enfants bien-aimés, 
###### 2
et suivez la voie de l'amour, à l'exemple du Christ qui vous a aimés et s'est livré pour nous, s'offrant à Dieu en sacrifice d'agréable odeur. 
###### 3
Quant à la fornication, à l'impureté sous toutes ses formes, ou encore à la cupidité, que leurs noms ne soient même pas prononcés parmi vous : c'est ce qui sied à des saints. 
###### 4
De même pour les grossièretés, les inepties, les facéties : tout cela ne convient guère ; faites entendre plutôt des actions de grâces. 
###### 5
Car, sachez-le bien, ni le fornicateur, ni le débauché, ni le cupide - qui est un idolâtre - n'ont droit à l'héritage dans le Royaume du Christ et de Dieu. 
###### 6
Que nul ne vous abuse par de vaines raisons : ce sont bien de tels désordres qui attirent la colère de Dieu sur ceux qui lui résistent. 
###### 7
N'ayez donc rien de commun avec eux. 
###### 8
Jadis vous étiez ténèbres, mais à présent vous êtes lumière dans le Seigneur ; conduisez-vous en enfants de lumière ; 
###### 9
car le fruit de la lumière consiste en toute bonté, justice et vérité. 
###### 10
Discernez ce qui plaît au Seigneur, 
###### 11
et ne prenez aucune part aux œuvres stériles des ténèbres, dénoncez-les plutôt. 
###### 12
Certes, ce que ces gens-là font en cachette, on a honte même de le dire ; 
###### 13
mais quand tout cela est dénoncé, c'est dans la lumière qu'on le voit apparaître ; 
###### 14
tout ce qui apparaît, en effet, est lumière. C'est pourquoi l'on dit : Éveille-toi, toi qui dors, lève-toi d'entre les morts, et sur toi luira le Christ. 
###### 15
Ainsi prenez bien garde à votre conduite ; qu'elle soit celle non d'insensés mais de sages, 
###### 16
qui tirent bon parti de la période présente ; car nos temps sont mauvais ; 
###### 17
ne vous montrez donc pas inconsidérés, mais sachez voir quelle est la volonté du Seigneur. 
###### 18
Ne vous enivrez pas de vin : on n'y trouve que libertinage ; mais cherchez dans l'Esprit votre plénitude. 
###### 19
Récitez entre vous des psaumes, des hymnes et des cantiques inspirés ; chantez et célébrez le Seigneur de tout votre cœur. 
###### 20
En tout temps et à tout propos, rendez grâces à Dieu le Père, au nom de notre Seigneur Jésus Christ. 
###### 21
Soyez soumis les uns aux autres dans la crainte du Christ. 
###### 22
Que les femmes le soient à leurs maris comme au Seigneur : 
###### 23
en effet, le mari est chef de sa femme, comme le Christ est chef de l'Église, lui le sauveur du Corps ; 
###### 24
or l'Église se soumet au Christ ; les femmes doivent donc, et de la même manière, se soumettre en tout à leur maris. 
###### 25
Maris, aimez vos femmes comme le Christ a aimé l'Église : il s'est livré pour elle, 
###### 26
afin de la sanctifier en la purifiant par le bain d'eau qu'une parole accompagne ; 
###### 27
car il voulait se la présenter à lui-même toute resplendissante, sans tache ni ride ni rien de tel, mais sainte et immaculée. 
###### 28
De la même façon les maris doivent aimer leurs femmes comme leurs propres corps. Aimer sa femme c'est s'aimer soi-même. 
###### 29
Car nul n'a jamais haï sa propre chair ; on la nourrit au contraire et on en prend bien soin. C'est justement ce que le Christ fait pour l'Église : 
###### 30
ne sommes-nous pas les membres de son Corps ? 
###### 31
Voici donc que l'homme quittera son père et sa mère pour s'attacher à sa femme, et les deux ne feront qu'une seule chair : 
###### 32
ce mystère est de grande portée ; je veux dire qu'il s'applique au Christ et à l'Église. 
###### 33
Bref, en ce qui vous concerne, que chacun aime sa femme comme soi-même, et que la femme révère son mari. 
