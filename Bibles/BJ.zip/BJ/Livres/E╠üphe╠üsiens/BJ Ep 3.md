---
aliases : 
- Éphésiens 3
- Éphésiens 3
- Ep 3
- Ephesians 3
tags : 
- Bible/Ep/3
- français
cssclass : français
---

# Éphésiens 3

###### 1
C'est pourquoi moi, Paul, prisonnier du Christ à cause de vous, païens... 
###### 2
Car vous avez appris, je pense, comment Dieu m'a dispensé la grâce qu'il m'a confiée pour vous, 
###### 3
m'accordant par révélation la connaissance du Mystère, tel que je viens de l'exposer en peu de mots : 
###### 4
à me lire, vous pouvez vous rendre compte de l'intelligence que j'ai du Mystère du Christ. 
###### 5
Ce Mystère n'avait pas été communiqué aux hommes des temps passés comme il vient d'être révélé maintenant à ses saints apôtres et prophètes, dans l'Esprit : 
###### 6
les païens sont admis au même héritage, membres du même Corps, bénéficiaires de la même Promesse, dans le Christ Jésus, par le moyen de l'Évangile. 
###### 7
Et de cet Évangile je suis devenu ministre par le don de la grâce que Dieu m'a confiée en y déployant sa puissance : 
###### 8
à moi, le moindre de tous les saints, a été confiée cette grâce-là, d'annoncer aux païens l'insondable richesse du Christ 
###### 9
et de mettre en pleine lumière la dispensation du Mystère : il a été tenu caché depuis les siècles en Dieu, le Créateur de toutes choses, 
###### 10
pour que les Principautés et les Puissances célestes aient maintenant connaissance, par le moyen de l'Église, de la sagesse infinie en ressources déployée par Dieu 
###### 11
en ce dessein éternel qu'il a conçu dans le Christ Jésus notre Seigneur, 
###### 12
et qui nous donne d'oser nous approcher en toute confiance par le chemin de la foi au Christ. 
###### 13
Ainsi, je vous en prie, ne vous laissez pas abattre par les épreuves que j'endure pour vous ; elles sont votre gloire ! 
###### 14
C'est pourquoi je fléchis les genoux en présence du Père 
###### 15
de qui toute paternité, au ciel et sur la terre, tire son nom. 
###### 16
Qu'Il daigne, selon la richesse de sa gloire, vous armer de puissance par son Esprit pour que se fortifie en vous l'homme intérieur, 
###### 17
que le Christ habite en vos cœurs par la foi, et que vous soyez enracinés, fondés dans l'amour. 
###### 18
Ainsi vous recevrez la force de comprendre, avec tous les saints, ce qu'est la Largeur, la Longueur, la Hauteur et la Profondeur, 
###### 19
vous connaîtrez l'amour du Christ qui surpasse toute connaissance, et vous entrerez par votre plénitude dans toute la Plénitude de Dieu. 
###### 20
A Celui dont la puissance agissant en nous est capable de faire bien au-delà, infiniment au-delà de tout ce que nous pouvons demander ou concevoir, 
###### 21
à Lui la gloire, dans l'Église et le Christ Jésus, pour tous les âges et tous les siècles ! Amen. 
