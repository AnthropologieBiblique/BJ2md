---
aliases : 
- Abdias
- Abdias
- Ab
- Obadiah
tags : 
- Bible/Ab
- français
cssclass : français
---

# Abdias

[[BJ Ab 1|Abdias 1]]
