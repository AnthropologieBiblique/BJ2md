---
aliases : 
- Galates
- Galates
- Ga
- Galatians
tags : 
- Bible/Ga
- français
cssclass : français
---

# Galates

[[BJ Ga 1|Galates 1]]
[[BJ Ga 2|Galates 2]]
[[BJ Ga 3|Galates 3]]
[[BJ Ga 4|Galates 4]]
[[BJ Ga 5|Galates 5]]
[[BJ Ga 6|Galates 6]]
