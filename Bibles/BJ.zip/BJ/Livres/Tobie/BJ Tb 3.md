---
aliases : 
- Tobie 3
- Tobie 3
- Tb 3
- Tobit 3
tags : 
- Bible/Tb/3
- français
cssclass : français
---

# Tobie 3

###### 1
L'âme désolée, je soupirai, je pleurai, et je commençai cette prière de lamentation
###### 2
Tu es juste, Seigneur, et toutes tes œuvres sont justes. Toutes tes voies sont grâce et vérité, et tu es le Juge du monde.
###### 3
Et maintenant, toi, Seigneur, souviens-toi de moi, regarde-moi. Ne me punis pas pour mes péchés, ni pour mes ignorances, ni pour celles de mes pères. Car nous avons péché devant toi
###### 4
et violé tes commandements; et tu nous as livrés au pillage, à la captivité et à la mort, à la fable, à la risée et au blâme de tous les peuples où tu nous as dispersés.
###### 5
Et maintenant, tous tes décrets sont vrais, quand tu me traites selon mes fautes et celles de mes pères. Car nous n'avons pas obéi à tes ordres, ni marché en vérité devant toi.
###### 6
Et maintenant, traite-moi comme il te plaira, daigne me retirer la vie je veux être délivré de la terre et redevenir terre. Car la mort vaut mieux pour moi que la vie. J'ai subi des outrages sans raison, et j'ai une immense douleur! Seigneur, j'attends que ta décision me délivre de cette épreuve. Laisse-moi partir au séjour éternel, ne détourne pas ta face de moi, Seigneur. Car mieux vaut mourir que passer ma vie en face d'un mal inexorable, et je ne veux plus m'entendre outrager.
###### 7
Le même jour, il advint que Sarra, fille de Ragouèl, habitant d'Ecbatane en Médie, entendit aussi les insultes d'une servante de son père.
###### 8
Il faut savoir qu'elle avait été donnée sept fois en mariage, et qu'Asmodée, le pire des démons, avait tué ses maris l'un après l'autre, avant qu'ils se soient unis à elle comme de bons époux. Et la servante de dire : "Oui, c'est toi qui tues tes maris! En voilà déjà sept à qui tu as été donnée, et tu n'as pas eu de chance une seule fois!
###### 9
Si tes maris sont morts, ce n'est pas une raison pour nous châtier! Va donc les rejoindre, qu'on ne voie jamais de toi ni garçon ni fille!"
###### 10
Ce jour-là, elle eut du chagrin, elle sanglota, elle monta dans la chambre de son père, avec le dessein de se pendre. Puis, à la réflexion, elle pensa : "Et si l'on blâmait mon père? On lui dira : Tu n'avais qu'une fille chérie, et, de malheur, elle s'est pendue! Je ne veux pas affliger la vieillesse de mon père jusqu'au séjour des morts. Je ferais mieux de ne pas me pendre, et de supplier le Seigneur de me faire mourir, afin que je n'entende plus d'insultes pendant ma vie."
###### 11
A l'instant, elle étendit les bras du côté de la fenêtre, elle pria ainsi Tu es béni, Dieu de miséricorde! Que ton Nom soit béni dans les siècles, et que toutes tes œuvres te bénissent dans l'éternité!
###### 12
Et maintenant, je lève mon visage et je tourne les yeux vers toi.
###### 13
Que ta parole me délivre de la terre, je ne veux plus m'entendre outrager!
###### 14
Tu le sais, toi, Seigneur, je suis restée pure, aucun homme ne m'a touchée,
###### 15
je n'ai pas déshonoré mon nom, ni celui de mon père, sur ma terre d'exil. Je suis la fille unique de mon père, il n'a pas d'autre enfant pour héritier, il n'a pas de frère auprès de lui, il ne lui reste aucun parent, à qui je doive me réserver. J'ai perdu déjà sept maris, pourquoi devrai-je vivre encore? S'il te déplaît de me faire mourir, regarde-moi avec pitié, je ne veux plus m'entendre outrager!
###### 16
Cette fois-ci, leur prière, à l'un et à l'autre, fut agréée devant la Gloire de Dieu,
###### 17
et Raphaèl fut envoyé pour les guérir tous les deux. Il devait enlever les taches blanches des yeux de Tobit, pour qu'il voie de ses yeux la lumière de Dieu; et il devait donner Sarra, fille de Ragouèl, en épouse à Tobie, fils de Tobit, et la dégager d'Asmodée, le pire des démons. Car c'est à Tobie qu'elle revenait de droit, avant tous les autres prétendants. A ce moment-là, Tobit rentrait de la cour dans la maison; et Sarra, fille de Ragouèl, de son côté, était en train de descendre de la chambre.
