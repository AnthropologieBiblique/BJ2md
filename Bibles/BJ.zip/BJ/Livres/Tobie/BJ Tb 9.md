---
aliases : 
- Tobie 9
- Tobie 9
- Tb 9
- Tobit 9
tags : 
- Bible/Tb/9
- français
cssclass : français
---

# Tobie 9

###### 1
Alors Tobie s'adressa à Raphaèl
###### 2
"Frère Azarias, dit-il, emmène quatre serviteurs et deux chameaux, et pars pour Rhagès.
###### 3
Tu iras chez Gabaèl, tu lui donneras le reçu, et tu t'occuperas de l'argent; enfin tu l'inviteras à venir à mes noces avec toi.
###### 4
Tu sais que mon père doit compter les jours, et que je ne puis en perdre un seul sans le contrarier.
###### 5
Tu vois bien à quoi Ragouèl s'est engagé : je suis tenu par son serment." Raphaèl partit donc pour Rhagès de Médie, avec les quatre serviteurs et les deux chameaux. Ils descendirent chez Gabaèl, à qui il présenta le reçu. Il lui fit part du mariage de Tobie, fils de Tobit, et de son invitation aux noces. Gabaèl se mit à lui compter les sacs avec leurs sceaux intacts, et ils les chargèrent sur les chameaux.
###### 6
Ils partirent ensemble de bonne heure pour la noce, et ils arrivèrent chez Ragouèl, où ils trouvèrent Tobie en train de dîner. Il se leva et le salua, Gabaèl pleura, et le bénit avec ces paroles : "Excellent fils d'un père parfait, juste et bienfaisant! Que le Seigneur te donne la bénédiction du Ciel, à toi, et à ta femme, au père et à la mère de ta femme! Béni soit Dieu de m'avoir fait voir le portrait vivant de mon cousin Tobit!"
