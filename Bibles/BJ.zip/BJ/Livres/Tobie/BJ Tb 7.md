---
aliases : 
- Tobie 7
- Tobie 7
- Tb 7
- Tobit 7
tags : 
- Bible/Tb/7
- français
cssclass : français
---

# Tobie 7

###### 1
A l'entrée d'Ecbatane, Tobie dit : "Frère Azarias, mène-moi tout droit chez notre frère Ragouèl." Il le conduisit à la maison de Ragouèl, qu'ils trouvèrent assis à la porte de la cour. Ils le saluèrent les premiers, et il répondit : Je vous salue bien, frères, vous êtes les bienvenus!" Et il les fit entrer dans sa maison.
###### 2
Il dit à sa femme Edna : "Que ce jeune homme ressemble donc à mon frère Tobit!"
###### 3
Edna leur demanda d'où ils étaient, et ils lui dirent : "Nous sommes des fils de Nephtali déportés à Ninive" 
###### 4
"Connaissez-vous notre frère Tobit" "Oui" "Comment va-t-il" 
###### 5
"Il est toujours en vie, et il se porte bien." Et Tobie ajouta : "C'est mon père."
###### 6
D'un bond, Ragouèl fut debout, il l'embrassa et il pleura.
###### 7
Puis il parla et lui dit : "Béni sois-tu, mon enfant! Tu es le fils d'un père excellent. Quel malheur qu'un homme si juste et si bienfaisant soit devenu aveugle!" Il tomba au cou de son frère Tobie, et il pleura.
###### 8
Et sa femme pleura sur lui, et puis leur fille Sarra aussi.
###### 9
Et il tua un mouton du troupeau, et on leur fit une réception chaleureuse. On se lava, on se baigna, on se mit à table. Alors Tobie dit à Raphaèl : "Frère Azarias, si tu demandais à Ragouèl de me donner ma sœur Sarra?"
###### 10
Ragouèl surprit ces paroles, et dit au jeune homme : "Mange et bois, ne gâte pas ta soirée, parce que personne n'a le droit de prendre ma fille Sarra, si ce n'est toi, mon frère. Aussi bien ne suis-je pas libre, moi non plus, de la donner à un autre, puisque tu es son plus proche parent. Maintenant, mon petit, je vais te parler franchement.
###### 11
J'ai tenté sept fois de lui trouver un mari parmi nos frères, et tous sont morts, le premier soir, quand ils entraient dans sa chambre. Pour le moment, mon enfant, mange et bois, le Seigneur vous accordera sa grâce et sa paix." Et Tobie de déclarer : "Je ne veux pas entendre parler de boire et de manger, tant que tu n'as pas pris de décision vis-à-vis de moi." Ragouèl répondit : "Soit! Puisque, aux termes de la Loi de Moïse, elle t'est donnée, c'est le Ciel qui décrète qu'on te la donne. Je te confie donc ta sœur. Désormais tu es son frère, et elle est ta sœur. Elle t'est donnée à partir d'aujourd'hui pour toujours. Le Seigneur du Ciel vous sera favorable ce soir, mon enfant, et vous accordera sa grâce et sa paix."
###### 12
Ragouèl fit venir sa fille Sarra, il lui prit la main, et la remit à Tobie avec ces paroles : "Je te la confie, c'est la loi et la décision écrite dans le livre de Moïse qui te l'attribuent pour femme. Prends-la, emmène-la chez ton père, en bonne conscience. Que le Dieu du Ciel vous donne de faire en paix un bon voyage!"
###### 13
Puis il s'adressa à la mère, et lui dit d'aller chercher une feuille pour écrire. Il rédigea le contrat de mariage, comme quoi il donnait à Tobie sa fille pour épouse, en application de l'article de la Loi de Moïse.
###### 14
Après quoi, on se mit à manger et à boire.
###### 15
Ragouèl appela sa femme Edna et lui dit : "Ma sœur, prépare la seconde chambre, où tu la conduiras."
###### 16
Elle alla faire le lit de la chambre comme il lui avait dit, et elle y mena sa fille. Elle pleura sur elle, puis elle essuya ses larmes et dit
###### 17
"Aie confiance, ma fille! Que le Seigneur du Ciel change ton chagrin en joie! Aie confiance, ma fille!" Et elle sortit.
