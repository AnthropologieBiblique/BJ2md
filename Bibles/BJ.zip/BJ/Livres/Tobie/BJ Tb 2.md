---
aliases : 
- Tobie 2
- Tobie 2
- Tb 2
- Tobit 2
tags : 
- Bible/Tb/2
- français
cssclass : français
---

# Tobie 2

###### 1
Sous le règne d'Asarhaddon, je revins donc chez moi, et ma femme Anna me fut rendue avec mon fils Tobie. A notre fête de la Pentecôte la fête des Semaines , il y eut un bon dîner. Je pris ma place au repas,
###### 2
on m'apporta la table et on m'apporta plusieurs plats. Alors je dis à mon fils Tobie : "Va chercher, mon enfant, parmi nos frères déportés à Ninive, un pauvre qui soit de cœur fidèle, et amène-le pour partager mon repas. J'attends que tu reviennes, mon enfant."
###### 3
Tobie sortit donc en quête d'un pauvre parmi nos frères, mais il revint et dit : "Père!" Je répondis : "Eh bien, mon enfant?" Il reprit : "Père, il y a quelqu'un de notre peuple qui vient d'être assassiné, il a été étranglé, puis jeté sur la place du marché, et il y est encore."
###### 4
Je ne fis qu'un bond, laissai mon repas intact, enlevai l'homme de la place, et le déposai dans une chambre, en attendant le coucher du soleil pour l'enterrer.
###### 5
Je rentrai me laver, et je mangeai mon pain dans le chagrin,
###### 6
avec le souvenir des paroles du prophète Amos sur Béthel Vos fêtes seront changées en deuil et tous vos cantiques en lamentations.
###### 7
Et je pleurai. Puis, quand le soleil fut couché, j'allai, je creusai une fosse et je l'ensevelis.
###### 8
Mes voisins disaient en riant : "Tiens! Il n'a plus peur." Il faut se rappeler que ma tête avait déjà été mise à prix pour ce motif-là. "La première fois, il s'est enfui; et le voilà qui se remet à enterrer les morts!"
###### 9
Ce soir-là, je pris un bain, et j'allai dans la cour, je m'étendis le long du mur de la cour. Comme il faisait chaud, j'avais le visage découvert,
###### 10
je ne savais pas qu'il y avait, au-dessus de moi, des moineaux dans le mur. De la fiente me tomba dans les yeux, toute chaude; elle provoqua des taches blanches que je dus aller faire soigner par les médecins. Plus ils m'appliquaient d'onguents, plus les taches m'aveuglaient, et finalement la cécité fut complète. Je restai quatre ans privé de la vue, tous mes frères en furent désolés; et Ahikar pourvut à mon entretien pendant deux années, avant son départ en Elymaïde.
###### 11
A ce moment-là, ma femme Anna prit du travail d'ouvrière, elle filait de la laine et recevait de la toile à tisser,
###### 12
elle livrait sur commande et on lui payait le prix. Or, le sept du mois de Dystros, elle termina une pièce et elle la livra aux clients. Ils lui donnèrent tout son dû, et de plus ils lui firent cadeau d'un chevreau pour un repas.
###### 13
En rentrant chez moi, le chevreau se mit à bêler, j'appelai ma femme et lui dis : "D'où sort ce cabri? Et s'il avait été volé? Rends-le donc à ses maîtres, nous n'avons pas le droit de manger le produit d'un vol."
###### 14
Elle me dit : "Mais c'est un cadeau qu'on m'a donné par-dessus le marché!" Je ne la crus pas, et je lui dis de le rendre à ses propriétaires j'en rougissais devant elle . Alors elle répliqua : "Où sont donc tes aumônes? Où sont donc tes bonnes œuvres? Tout le monde sait ce que cela t'a rapporté."
