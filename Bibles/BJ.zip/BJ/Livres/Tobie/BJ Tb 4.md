---
aliases : 
- Tobie 4
- Tobie 4
- Tb 4
- Tobit 4
tags : 
- Bible/Tb/4
- français
cssclass : français
---

# Tobie 4

###### 1
Ce jour-là, Tobit pensa à l'argent qu'il avait déposé chez Gabaèl, à Rhagès de Médie,
###### 2
et il se dit : "J'en suis venu à demander la mort, je ferais bien d'appeler mon fils Tobie, pour lui parler de cette somme, avant de mourir."
###### 3
Il fit venir son fils Tobie auprès de lui, et parla ainsi "Quand je mourrai, fais-moi un enterrement convenable. Honore ta mère, et ne la délaisse en aucun jour de ta vie. Fais ce qui lui plaît, et ne lui fournis aucun sujet de tristesse.
###### 4
Souviens-toi, mon enfant, de tant de dangers qu'elle a courus pour toi, quand tu étais dans son sein. Et quand elle mourra, enterre-la auprès de moi, dans la même tombe.
###### 5
Mon enfant, sois tous les jours fidèle au Seigneur. N'aie pas la volonté de pécher, ni de transgresser ses lois. Fais de bonnes œuvres tous les jours de ta vie, et ne suis pas les sentiers de l'injustice.
###### 6
Car, si tu agis dans la vérité, tu réussiras dans toutes tes actions, comme tous ceux qui pratiquent la justice.
###### 7
Prends sur tes biens pour faire l'aumône. Ne détourne jamais ton visage d'un pauvre, et Dieu ne détournera pas le sien de toi.
###### 8
Mesure ton aumône à ton abondance : si tu as beaucoup, donne davantage; si tu as peu, donne moins, mais n'hésite pas à faire l'aumône.
###### 9
C'est te constituer un beau trésor pour le jour du besoin.
###### 10
Car l'aumône délivre de la mort, et elle empêche d'aller dans les ténèbres.
###### 11
L'aumône est une offrande de valeur, pour tous ceux qui la font en présence du Très-Haut.
###### 12
Garde-toi, mon enfant, de toute inconduite. Choisis une femme du sang de tes pères. Ne prends pas une femme étrangère à la tribu de ton père, parce que nous sommes les fils des prophètes. Souviens-toi de Noé, d'Abraham, d'Isaac et de Jacob, nos pères dès le commencement. Ils ont tous prix une femme dans leur parenté, et ils ont été bénis dans leurs enfants, et leur race aura la terre en héritage.
###### 13
Toi aussi, mon enfant, préfère tes frères, n'aie pas le cœur de mépriser tes frères, les fils et les filles de ton peuple, et prends ta femme parmi eux. Parce que l'orgueil entraîne la ruine, et beaucoup d'inquiétude; l'oisiveté amène la pauvreté et la pénurie, car la mère de la famine, c'est l'oisiveté.
###### 14
Ne fais pas attendre au lendemain le salaire de ceux qui travaillent pour toi, mais paie-le tout de suite. Si tu sers Dieu, tu seras récompensé. Sois vigilant, mon fils, dans toutes tes œuvres, et bien élevé dans toute ta conduite.
###### 15
Ne fais à personne ce que tu n'aimerais pas subir. Ne bois pas de vin jusqu'à l'ivresse, et n'aie pas la débauche pour compagne de ta route.
###### 16
Donne de ton pain à ceux qui ont faim, et de tes habits à ceux qui sont nus. De tout ce que tu as en abondance, prends pour faire l'aumône; et quand tu fais l'aumône, n'aie pas de regrets dans les yeux.
###### 17
Sois prodigue de pain et de vin sur le tombeau des justes, mais non pour le pécheur.
###### 18
Prends l'avis de toute personne sage, et ne méprise pas un conseil profitable.
###### 19
En toute circonstance, bénis le Seigneur Dieu, demande-lui de diriger tes voies, et de faire aboutir tes sentiers et tes projets. Car la sagesse n'est pas le propre de toute nation, c'est le Seigneur qui leur donne de vouloir le bien. A son gré, il élève, ou il abaisse jusqu'au fond du séjour des morts. Et maintenant, mon enfant, rappelle-toi ces commandements, et ne les laisse pas s'effacer de ton cœur.
###### 20
Maintenant, mon enfant, je t'informe que j'ai déposé dix talents d'argent chez Gabaèl, fils de Gabri, à Rhagès de Médie.
###### 21
N'aie pas peur, mon enfant, si nous sommes devenus pauvres. Tu as une grande richesse, si tu crains Dieu, si tu évites toute espèce de péché, et si tu fais ce qui plaît au Seigneur ton Dieu."
