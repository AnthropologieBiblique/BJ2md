---
aliases : 
- Tobie 8
- Tobie 8
- Tb 8
- Tobit 8
tags : 
- Bible/Tb/8
- français
cssclass : français
---

# Tobie 8

###### 1
Quand on eut fini de boire et de manger, on parla d'aller se coucher, et l'on conduisit le jeune homme depuis la salle du repas jusque dans la chambre.
###### 2
Tobie se souvint des conseils de Raphaèl, il prit son sac, il en tira le cœur et le foie du poisson, et il en mit sur les braises de l'encens.
###### 3
L'odeur du poisson incommoda le démon, qui s'enfuit par les airs jusqu'en Egypte. Raphaèl l'y poursuivit, l'entrava et le garrotta sur-le-champ.
###### 4
Cependant les parents étaient sortis en refermant la porte. Tobie se leva du lit, et dit à Sarra : "Debout, ma sœur! Il faut prier tous deux, et recourir à notre Seigneur, pour obtenir sa grâce et sa protection."
###### 5
Elle se leva et ils se mirent à prier pour obtenir d'être protégés, et il commença ainsi Tu es béni, Dieu de nos pères, et ton Nom est béni dans tous les siècles des siècles! Que te bénissent les cieux, et toutes tes créatures dans tous les siècles!
###### 6
C'est toi qui as créé Adam, c'est toi qui as créé Eve sa femme, pour être son secours et son appui, et la race humaine est née de ces deux-là. C'est toi qui as dit Il ne faut pas que l'homme reste seul, faisons-lui une aide semblable à lui.
###### 7
Et maintenant, ce n'est pas le plaisir que je cherche en prenant ma sœur, mais je le fais d'un cœur sincère. Daigne avoir pitié d'elle et de moi et nous mener ensemble à la vieillesse!
###### 8
Et ils dirent de concert : "Amen, amen!"
###### 9
Et ils se couchèrent pour la nuit. Or Ragouèl se leva, il appela les serviteurs, et ils vinrent l'aider à creuser une tombe.
###### 10
Il avait pensé : "Pourvu qu'il ne meure pas! Nous serions couverts de ridicule et de honte."
###### 11
Une fois la fosse achevée, Ragouèl revint à la maison, il appela sa femme
###### 12
et lui dit : "Si tu envoyais une servante dans la chambre voir si Tobie est en vie? Parce que, s'il est mort, on l'enterrerait sans que personne en sache rien."
###### 13
On avertit la servante, on alluma la lampe, on ouvrit la porte, et la servante entra. Elle les trouva dormant tous deux d'un profond sommeil;
###### 14
elle ressortit, et leur dit tout bas : "Il n'est pas mort, tout va bien."
###### 15
Ragouèl bénit le Dieu du Ciel par ces paroles Tu es béni, mon Dieu, par toute bénédiction pure! Qu'on te bénisse dans tous les siècles!
###### 16
Tu es béni de m'avoir réjoui, ce que je redoutais n'est pas arrivé, mais tu nous as traités avec ton immense bienveillance.
###### 17
Tu es béni d'avoir eu pitié de ce fils unique et de cette fille unique. Donne-leur, Maître, ta grâce et ta protection, fais-les poursuivre leur vie, dans la joie et dans la grâce!
###### 18
Et il fit combler la tombe par les serviteurs, avant le petit jour.
###### 19
Il fit faire par sa femme une fournée de pains, il alla au troupeau, prit deux bœufs et quatre moutons, il les recommanda à la cuisine, et l'on commença les préparatifs.
###### 20
Il fit venir Tobie et lui déclara : "Pendant quatorze jours, il n'est pas question que tu bouges d'ici. Tu resteras là où tu es, à manger et à boire, chez moi. Tu rendras la joie à ma fille après tous ses chagrins.
###### 21
Après, emporte d'ici la moitié de tout ce que j'ai, et retourne sans encombre auprès de ton père. Quand nous serons morts, ma femme et moi, vous aurez l'autre moitié. Aie confiance, mon garçon! Je suis ton père, et Edna est ta mère. Nous sommes tes parents, comme ceux de ta sœur, désormais. Aie confiance, mon enfant!"
