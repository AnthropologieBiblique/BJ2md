---
aliases : 
- Tobie 12
- Tobie 12
- Tb 12
- Tobit 12
tags : 
- Bible/Tb/12
- français
cssclass : français
---

# Tobie 12

###### 1
A la fin des noces, Tobit appela son fils Tobie, et lui dit "Mon enfant, pense à régler ce qui est dû à ton compagnon, tu dépasseras le prix convenu."
###### 2
Il demanda : "Père, combien vais-je lui donner pour ses services? Même en lui laissant la moitié des biens qu'il a rapportés avec moi, je n'y perds pas.
###### 3
Il me ramène sain et sauf, il a soigné ma femme, il rapporte avec moi l'argent, et enfin il t'a guéri! Combien lui donner encore pour cela?"
###### 4
Tobit lui dit : "Il a bien mérité la moitié de ce qu'il a rapporté."
###### 5
Tobie fit donc venir son compagnon, et lui dit : "Prends la moitié de ce que tu as ramené, pour prix de tes services, et va en paix."
###### 6
Alors Raphaèl les prit tous les deux à l'écart, et il leur dit : "Bénissez Dieu, célébrez-le devant tous les vivants, pour le bien qu'il vous a fait. Bénissez et chantez son Nom. Faites connaître à tous les hommes les actions de Dieu comme elles le méritent, et ne vous lassez pas de le remercier.
###### 7
Il convient de garder le secret du roi, tandis qu'il convient de révéler et de publier les œuvres de Dieu. Remerciez-le dignement. Faites ce qui est bien, et le malheur ne vous atteindra pas.
###### 8
Mieux vaut la prière avec le jeûne, et l'aumône avec la justice, que la richesse avec l'iniquité. Mieux vaut pratiquer l'aumône, que thésauriser de l'or.
###### 9
L'aumône sauve de la mort et elle purifie de tout péché. Ceux qui font l'aumône sont rassasiés de jours;
###### 10
ceux qui font le péché et le mal se font du tort à eux-mêmes.
###### 11
Je vais vous dire toute la vérité, sans rien vous cacher : je vous ai déjà enseigné qu'il convient de garder le secret du roi, tandis qu'il convient de révéler dignement les œuvres de Dieu.
###### 12
Vous saurez donc que, lorsque vous étiez en prière, toi et Sarra, c'était moi qui présentais vos suppliques devant la Gloire du Seigneur et qui les lisais; et de même lorsque tu enterrais les morts.
###### 13
Quand tu n'as pas hésité à te lever, et à quitter la table, pour aller ensevelir un mort, j'ai été envoyé pour éprouver ta foi,
###### 14
et Dieu m'envoya en même temps pour te guérir, ainsi que ta belle-fille Sarra.
###### 15
Je suis Raphaèl, un des sept Anges qui se tiennent toujours prêts à pénétrer auprès de la Gloire du Seigneur."
###### 16
Ils furent remplis d'effroi tous les deux; ils se prosternèrent, et ils eurent grand-peur.
###### 17
Mais il leur dit : "Ne craignez point, la paix soit avec vous. Bénissez Dieu à jamais.
###### 18
Pour moi, quand j'étais avec vous, ce n'est pas à moi que vous deviez ma présence, mais à la volonté de Dieu : c'est lui qu'il faut bénir au long des jours, lui qu'il faut chanter.
###### 19
Vous avez cru me voir manger, ce n'était qu'une apparence.
###### 20
Alors, bénissez le Seigneur sur la terre, et rendez grâce à Dieu. Je vais remonter à Celui qui m'a envoyé. Ecrivez tout ce qui est arrivé." .
###### 21
Et il s'éleva. Quand ils se redressèrent, il n'était plus visible. 
###### 22
Ils louèrent Dieu par des hymnes; ils le remercièrent d'avoir opéré de telles merveilles : un ange de Dieu ne leur était-il pas apparu!
