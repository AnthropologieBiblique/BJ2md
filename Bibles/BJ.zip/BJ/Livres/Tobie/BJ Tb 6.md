---
aliases : 
- Tobie 6
- Tobie 6
- Tb 6
- Tobit 6
tags : 
- Bible/Tb/6
- français
cssclass : français
---

# Tobie 6

###### 1
L'enfant partit avec l'ange, et le chien suivit derrière. Ils marchèrent tous les deux, et quand vint le premier soir, ils campèrent le long du Tigre.
###### 2
L'enfant descendit au fleuve se laver les pieds, quand un gros poisson sauta de l'eau, et faillit lui avaler le pied. Le garçon cria,
###### 3
et l'ange lui dit : "Attrape le poisson, et ne lâche pas!" Le garçon vint à bout du poisson, et le tira sur la rive.
###### 4
L'ange lui dit : "Ouvre-le, enlève le fiel, le cœur et le foie; mets-les à part, et jette les entrailles, parce que le fiel, le cœur et le foie font des remèdes utiles."
###### 5
Le jeune homme ouvrit le poisson, préleva le fiel, le cœur et le foie. Il fit frire un peu de poisson pour son repas, et il en garda pour le saler. Ils marchèrent ensuite tous deux ensemble jusqu'auprès de la Médie.
###### 6
Alors le garçon posa à l'ange cette question : "Frère Azarias, quel remède y a-t-il donc dans le cœur, le foie et le fiel de poisson?"
###### 7
Il répondit : "On brûle le cœur et le foie de poisson, et leur fumée s'emploie dans le cas d'un homme, ou d'une femme, que tourmente un démon ou un esprit malin : toute espèce de malaise disparaît définitivement sans laisser aucune trace.
###### 8
Quant au fiel, il sert d'onguent pour les yeux, quand on a des taches blanches sur l'œil : il n'y a plus qu'à souffler sur les taches pour les guérir."
###### 9
Ils pénétrèrent en Médie, ils étaient déjà rendus près d'Ecbatane,
###### 10
quand Raphaèl dit au jeune homme : "Frère Tobie!" Il répondit "Eh bien?" L'ange reprit : "Ce soir nous devons loger chez Ragouèl, c'est un parent à toi. Il a une fille du nom de Sarra,
###### 11
mais, à part Sarra, il n'a ni garçon ni fille. Or c'est toi son plus proche parent, elle te revient par priorité, et tu peux prétendre à l'héritage de son père. C'est une enfant sérieuse, courageuse, très gentille, et son père l'aime bien.
###### 12
Tu as le droit de la prendre. Ecoute-moi, frère, je parlerai de la jeune fille à son père, dès ce soir, pour te la retenir comme fiancée; et quand nous reviendrons de Rhagès, nous ferons le mariage. Je certifie que Ragouèl n'a absolument pas le droit de te la refuser, ou de la fiancer à un autre. Ce serait encourir la mort, d'après les termes du livre de Moïse, du moment qu'il saurait que la parenté te donne avant tout autre le droit de prendre sa fille. Alors, écoute-moi, frère. Dès ce soir, nous parlons de la jeune fille, et nous faisons la demande en mariage. A notre retour de Rhagès, nous la prendrons, pour l'emmener avec nous chez toi."
###### 13
Tobie répondit à Raphaèl : "Frère Azarias, je me suis laissé dire qu'elle a déjà été donnée sept fois en mariage, et que, chaque fois, son mari est mort dans la chambre des noces. Il mourait le soir où il entrait dans sa chambre, et j'ai entendu des gens dire que c'était un démon qui les tuait,
###### 14
si bien que j'ai un peu peur. Elle, il ne lui fait rien, parce qu'il l'aime; mais dès que quelqu'un veut s'en approcher, il le tue. Je suis le seul fils de mon père, et je ne tiens pas à mourir, je ne veux pas que mon père et ma mère s'affligent toute leur vie sur moi jusqu'au tombeau : ils n'ont pas d'autre fils pour les enterrer."
###### 15
Il lui dit : "Oublieras-tu les avis de ton père? Il t'a pourtant recommandé de prendre une femme de la maison de ton père. Alors, écoute-moi, frère. Ne tiens pas compte de ce démon, et prends-la. Je te garantis que, dès ce soir, elle te sera donnée pour femme.
###### 16
Seulement quand tu seras entré dans la chambre, prends le foie et le cœur du poisson, mets-en un peu sur les braises de l'encens. L'odeur se répandra,
###### 17
le démon la respirera, il s'enfuira, et il n'y a pas de danger qu'on le reprenne autour de la jeune fille. Puis, au moment de vous unir, levez-vous d'abord tous les deux pour prier. Demandez au Seigneur du Ciel de vous accorder sa grâce et sa protection. N'aie pas peur, elle t'a été destinée dès l'origine, 
###### 18
c'est à toi de la sauver. Elle te suivra, et je gage qu'elle te donnera des enfants qui te seront comme des frères. N'hésite pas." 
###### 19
Et quand Tobie entendit parler Raphaèl, qu'il sut que Sarra était sa sœur, parente de la famille de son père, il l'aima, au point de ne plus pouvoir en détacher son cœur.
