---
aliases : 
- Tobie 5
- Tobie 5
- Tb 5
- Tobit 5
tags : 
- Bible/Tb/5
- français
cssclass : français
---

# Tobie 5

###### 1
Alors Tobie répondit à son père Tobit : "Je ferai, père, tout ce que tu m'as commandé.
###### 2
Seulement, comment faire pour lui reprendre ce dépôt? Lui ne me connaît pas, et moi, je ne le connais pas non plus. Quel signe de reconnaissance vais-je lui donner, pour qu'il me croie et qu'il me remette l'argent? De plus, je ne sais pas les routes à prendre pour ce voyage en Médie."
###### 3
Alors Tobit répondit à son fils Tobie : "Nous avons échangé nos signatures sur un billet, et je l'ai coupé en deux pour que nous en ayons chacun la moitié. J'ai pris l'une, et j'ai mis l'autre avec l'argent. Dire que cela fait vingt ans que j'ai mis cet argent en dépôt! Maintenant, mon enfant, cherche-toi quelqu'un de sérieux pour compagnon de voyage, il sera à nos frais jusqu'à ton retour; et puis va toucher cet argent chez Gabaèl."
###### 4
Tobie sortit, en quête d'un bon guide capable de venir avec lui en Médie. Dehors, il trouva Raphaèl, l'ange, debout face à lui, sans se douter que c'était un ange de Dieu.
###### 5
Il lui dit : "D'où es-tu, mon ami?" L'ange répondit : "Je suis l'un des Israélites tes frères, je suis venu chercher du travail par là." Tobie lui dit : "Sais-tu la route pour aller en Médie?"
###### 6
L'autre répondit : "Bien sûr! J'y ai été plusieurs fois, je connais tous les chemins par cœur. Je suis allé fréquemment en Médie, j'ai été reçu chez Gabaèl, l'un de nos frères qui habites à Rhagès de Médie. Il faut bien deux jours de marche normale, d'Ecbatane à Rhagès; Rhagès est situé dans la montagne, et Ecbatane est au milieu de la plaine."
###### 7
Tobie lui dit : "Attends-moi, mon ami, que j'aille prévenir mon père : j'ai besoin que tu viennes avec moi, je te paierai tes journées."
###### 8
L'autre répondit : "Bien, j'attends. Seulement ne sois pas long."
###### 9
Tobie alla prévenir son père qu'il avait trouvé quelqu'un de leurs frères israélites. Et le père dit : "Présente-le moi, que je m'informe de sa famille et de sa tribu. Il faut voir si l'on peut compter sur lui pour t'accompagner, mon enfant." Tobie sortit donc l'appeler : "Mon ami, dit-il, mon père te demande."
###### 10
L'ange entra dans la maison. Tobit salua le premier, et l'autre lui répondit par des souhaits de bonheur. Tobit reprit : "Puis-je encore avoir du bonheur? Je suis un aveugle, je ne vois plus l'éclat du ciel, je suis plongé dans l'obscurité, comme les morts qui ne contemplent plus la lumière. Je suis un enterré vivant, j'entends la voix des gens sans les voir." L'ange lui dit : "Aie confiance, Dieu ne tardera pas à te guérir. Aie confiance!" Tobit lui dit : "Mon fils Tobie désire aller en Médie. Veux-tu te joindre à lui comme guide? Frère, je te paierai." Il répondit : "Je veux bien l'accompagner, je sais tous les chemins, je suis souvent allé en Médie, j'en ai traversé toutes les plaines et les montagnes, et j'en connais toutes les pistes."
###### 11
Tobit dit : "Frère, de quelle famille et de quelle tribu es-tu? Veux-tu me l'indiquer, frère" 
###### 12
"Que peut te faire ma tribu" "Je veux savoir pour de bon de qui tu es fils et quel est ton nom" 
###### 13
"Je suis Azarias, fils d'Ananias le grand, l'un de tes frères" 
###### 14
"Sois le bienvenu, salut, frère! Ne te froisse pas si j'ai désiré connaître ta vraie famille : il se trouve que tu es mon parent, de belle et bonne lignée. Je connais Ananias et Nathân, les deux fils de Séméias le grand. Ils venaient avec moi à Jérusalem, nous y avons adoré ensemble, et ils n'ont pas quitté la bonne route. Tes frères sont des hommes de bien, tu es de bonne souche : sois le bienvenu!"
###### 15
Il poursuivit : "Je t'engage pour une drachme par jour, avec ton entretien, comme pour mon fils. Voyage donc avec mon fils,
###### 16
et je dépasserai le prix convenu." L'ange répondit : "Je ferai le voyage avec lui. Ne crains rien. Notre départ se passera bien, et notre retour aussi, parce que la route est sûre."
###### 17
Tobit lui dit : "Sois béni, frère!" Puis il s'adressa à son fils : "Mon enfant, dit-il, prépare ce qu'il te faut pour le voyage, et pars avec ton frère. Que le Dieu qui est dans les cieux vous protège là-bas, et qu'il vous ramène sains et saufs auprès de moi! Que son ange vous accompagne de sa protection, mon enfant!" Tobie sortit pour se mettre en route, et il embrassa son père et sa mère. Tobit lui dit : "Bon voyage!"
###### 18
Sa mère pleura, et elle dit à Tobit : "Pourquoi as-tu décidé le départ de mon enfant? N'est-ce pas lui le bâton de notre main, lui qui va et vient devant nous?
###### 19
J'espère que l'argent ne passe pas avant tout, mais qu'il ne compte pas à côté de notre enfant.
###### 20
Le mode de vie que Dieu nous avait donné nous suffisait bien."
###### 21
Il lui dit : "Ne te fais pas des idées! Notre enfant ira bien en partant, il ira encore bien en rentrant à la maison. Le jour où il te reviendra, tes yeux verront qu'il va toujours très bien. Ne te fais pas des idées, n'aie pas d'inquiétude pour eux, ma sœur.
###### 22
Un bon ange l'accompagnera, il fera bon voyage, et il reviendra en bien bonne santé!"
###### 23
Et elle cessa de pleurer.
