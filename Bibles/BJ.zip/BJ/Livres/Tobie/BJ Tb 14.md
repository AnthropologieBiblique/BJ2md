---
aliases : 
- Tobie 14
- Tobie 14
- Tb 14
- Tobit 14
tags : 
- Bible/Tb/14
- français
cssclass : français
---

# Tobie 14

###### 1
Fin des hymnes de Tobit. Tobit mourut en paix à l'âge de 112 ans, et il fut enterré à Ninive avec honneur.
###### 2
Il avait 62 ans quand il devint aveugle; et, depuis sa guérison, il vécut dans l'abondance, il pratiqua l'aumône, et il continua toujours à bénir Dieu et à célébrer sa grandeur.
###### 3
Sur le point de mourir, il fit venir son fils Tobie, et lui donna ses instructions : "Mon fils, emmène tes enfants,
###### 4
cours en Médie, parce que je crois à la parole de Dieu que Nahum a dite sur Ninive. Tout s'accomplira, tout se réalisera, de ce que les prophètes d'Israël, que Dieu a envoyés, ont annoncé contre l'Assyrie et contre Ninive; rien ne sera retranché de leurs paroles. Tout arrivera en son temps. On sera plus à l'abri en Médie qu'en Assyrie et qu'en Babylonie. Parce que je sais et je crois, moi, que tout ce que Dieu a dit s'accomplira, cela sera, et il ne tombera pas un mot des prophéties. Nos frères qui habitent le pays d'Israël seront tous recensés et déportés loin de leur belle patrie. Tout le sol d'Israël sera un désert. Et Samarie et Jérusalem seront un désert. Et la Maison de Dieu sera, pour un temps, désolée et brûlée.
###### 5
Puis de nouveau, Dieu en aura pitié, et il les ramènera au pays d'Israël. Ils rebâtiront sa Maison, moins belle que la première, en attendant que les temps soient révolus. Mais alors, tous revenus de leur captivité, ils rebâtiront Jérusalem dans sa magnificence, et en elle la Maison de Dieu sera rebâtie, comme l'ont annoncé les prophètes d'Israël.
###### 6
Et tous les peuples de la terre entière se convertiront, et ils craindront Dieu en vérité. Tous, ils répudieront leurs faux dieux, qui les ont fait s'égarer dans l'erreur.
###### 7
Et ils béniront le Dieu des siècles dans la justice. Tous les Israélites, épargnés en ces jours-là, se souviendront de Dieu avec sincérité. Ils viendront se rassembler à Jérusalem, et désormais ils habiteront la terre d'Abraham en sécurité, et elle sera leur propriété. Et ceux-là se réjouiront, qui aiment Dieu en vérité. Et ceux-là disparaîtront de la terre, qui accomplissent le péché et l'injustice.
###### 8
Et maintenant, mes enfants, je vous en fais un devoir, servez Dieu en vérité, et faites ce qui lui plaît. Imposez à vos enfants l'obligation de faire la justice et l'aumône, de se souvenir de Dieu, de bénir son Nom en tout temps, en vérité, et de toutes leurs forces.
###### 9
Alors, toi, mon fils, quitte Ninive, ne reste pas ici.
###### 10
Dès que tu auras enterré ta mère auprès de moi, pars le jour même, quel qu'il soit, et ne demeure plus dans ce pays, où je vois triompher sans vergogne la perfidie et l'iniquité. Regarde, mon enfant, tout ce qu'a fait Nadab à son père nourricier, Ahikar. Ne fut-il pas réduit à descendre vivant sous la terre? Mais Dieu a fait payer son infamie au criminel, à la face de sa victime, parce que Ahikar revint à la lumière, tandis que Nadab entra dans les ténèbres éternelles, en châtiment de son dessein contre la vie d'Ahikar. A cause de ses bonnes œuvres, Ahikar échappa au filet mortel que lui avait tendu Nadab, et Nadab y tomba pour sa perte.
###### 11
Ainsi, mes enfants, voyez où mène l'aumône, et où conduit l'iniquité, c'est-à-dire à la mort. Mais le souffle me manque." Ils l'étendirent sur le lit, il mourut, et il fut enterré avec honneur.
###### 12
Quand sa mère mourut, Tobie l'enterra auprès de son père. Puis il partit pour la Médie, avec sa femme et ses enfants. Il habita Ecbatane, chez Ragouèl son beau-père.
###### 13
Il entoura la vieillesse de ses beaux-parents de respect et d'attention, puis il les enterra à Ecbatane de Médie. Tobie héritait du patrimoine de Ragouèl, comme de celui de son père Tobit.
###### 14
Il vécut honoré jusqu'à l'âge de 117 ans.
###### 15
Il fut témoin de la ruine de Ninive avant de mourir. Il vit les Ninivites prisonniers et déportés en Médie par Cyaxare, roi de Médie. Il bénit Dieu de tout ce qu'il infligea aux Ninivites et aux Assyriens. Avant sa mort, il put se réjouir du sort de Ninive, et bénir le Seigneur Dieu dans les siècles des siècles. Amen.
