---
aliases : 
- Tobie 11
- Tobie 11
- Tb 11
- Tobit 11
tags : 
- Bible/Tb/11
- français
cssclass : français
---

# Tobie 11

###### 1
Ils approchaient de Kasérîn, en face de Ninive.
###### 2
Raphaèl dit : "Tu sais dans quel état nous avons laissé ton père,
###### 3
prenons de l'avance sur ta femme, pour aller préparer la maison, pendant qu'elle arrive avec les autres."
###### 4
Ils marchèrent tous deux ensemble il lui avait bien recommandé d'emporter le fiel , et le chien les suivait.
###### 5
Anna était assise, à surveiller la route par où viendrait son fils.
###### 6
Elle pressentit que c'était lui, et elle dit au père : "Voici ton fils qui arrive avec son compagnon!"
###### 7
Raphaèl dit à Tobie, avant qu'il eût rejoint son père : "Je te garantis que les yeux de ton père vont s'ouvrir.
###### 8
Tu lui appliqueras sur l'œil le fiel de poisson : la drogue mordra, et lui tirera des yeux une petite peau blanche. Et ton père cessera d'être aveugle et verra la lumière."
###### 9
La mère courut se jeter au cou de son fils : "Maintenant, disait-elle, je puis mourir, je t'ai revu!" Et elle pleura.
###### 10
Tobit se leva, il trébuchait, mais il réussit à franchir la porte de la cour. Tobie se dirigea à sa rencontre
###### 11
il portait dans sa main le fiel de poisson . Il lui souffla dans les yeux, et lui dit, en le tenant bien : "Aie confiance, père!" Puis il appliqua la drogue, et la laissa quelque temps,
###### 12
et enfin, de chaque main, il lui ôta une petite peau du coin des yeux.
###### 13
Alors son père tomba à son cou
###### 14
et il pleura. Il s'écria : "Je te vois, mon fils, lumière de mes yeux!" Et il dit Béni soit Dieu Béni son grand Nom! Bénis tous ses saints anges! Béni son grand Nom dans tous les siècles!
###### 15
Parce qu'il m'avait frappé, et qu'il a eu pitié de moi, et que je vois mon fils Tobie! Tobie entra dans la maison, de joie il bénissait Dieu à haute voix. Puis il mit son père au courant : son voyage a bien marché, il rapporte l'argent; il a épousé Sarra, fille de Ragouèl; elle le suit de peu, elle n'est pas loin des portes de Ninive.
###### 16
Tobit partit à la rencontre de sa belle-fille, vers les portes de Ninive, en louant Dieu dans sa joie. Quand les gens de Ninive le virent marcher en se passant de guide, et avancer avec sa vigueur d'autrefois, ils furent émerveillés.
###### 17
Tobit proclama devant eux que Dieu avait eu pitié de lui, et lui avait ouvert les yeux. Enfin Tobit approcha de Sarra, l'épouse de son fils Tobie, et il la bénit en ces termes "Sois la bienvenue, ma fille! Béni soit ton Dieu de t'avoir fait venir chez nous, ma fille! Béni soit ton père, béni soit mon fils Tobie, et bénie sois-tu, ma fille! Sois la bienvenue chez toi, dans la joie et la bénédiction! Entre, ma fille." 
###### 18
Ce jour-là fut une fête pour tous les Juifs de Ninive,
###### 19
et ses cousins Ahikar et Nadab vinrent partager la joie de Tobit.
