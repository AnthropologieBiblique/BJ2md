---
aliases : 
- Tobie 10
- Tobie 10
- Tb 10
- Tobit 10
tags : 
- Bible/Tb/10
- français
cssclass : français
---

# Tobie 10

###### 1
Cependant, de jour en jour, Tobit comptait les journées que demandait le voyage, à l'aller et au retour. Le nombre fut atteint, sans que le fils eût paru.
###### 2
Alors il pensa : "Pourvu qu'il ne soit pas retenu là-bas! Pourvu que Gabaèl ne soit pas mort! Il n'y a peut-être eu personne pour lui donner l'argent!"
###### 3
Et il commença à être contrarié.
###### 4
Sa femme Anna disait : "Mon enfant est mort! Il n'est plus au nombre des vivants!" Et elle se mettait à pleurer et à se lamenter sur son fils. Elle disait
###### 5
"Quel malheur! Mon enfant, je t'ai laissé partir, toi, la lumière de mes yeux!"
###### 6
Et Tobit répondait : "Du calme, ma sœur! Ne te fais pas des idées! Il va bien! Ils auront eu là-bas un contretemps. Son compagnon est quelqu'un de sérieux, et l'un de nos frères. Ne te désole pas, ma sœur. Il va arriver d'un moment à l'autre."
###### 7
Mais elle répliquait : "Laisse-moi, n'essaie pas de me tromper. Mon enfant est mort." Et, tous les jours, elle sortait soudain, pour surveiller la route par où son fils était parti. Elle ne croyait plus personne. Quand le soleil était couché, elle rentrait, pour pleurer et gémir à longueur de nuits sans pouvoir dormir. A la fin des quatorze jours de noces, que Ragouèl avait juré de faire en l'honneur de sa fille, Tobie vint lui dire : "Laisse-moi partir, parce que mon père et ma mère ne doivent plus penser me revoir. Aussi, je t'en prie, père, laisse-moi rentrer chez mon père, je t'ai expliqué dans quel état je l'ai laissé."
###### 8
Ragouèl dit à Tobie : "Reste, mon fils, reste avec moi. J'enverrai des messagers à ton père Tobit donner de tes nouvelles."
###### 9
Tobie insista : "Non, je te demande la liberté de retourner chez mon père."
###### 10
sur-le-champ, Ragouèl lui remit son épouse Sarra. Il donnait à Tobie la moitié de ses biens, en serviteurs et servantes, en bœufs et brebis, ânes et chameaux, et en habits, argent et ustensiles.
###### 11
Il les laissait ainsi partir contents. Pour Tobie, il eut ces paroles d'adieu : "Bonne santé, mon enfant, et bon voyage! Que le Seigneur du Ciel soit favorable, à toi et à ta femme Sarra! J'espère bien voir vos enfants avant de mourir."
###### 12
A sa fille Sarra, il dit : "Va chez ton beau-père, puisque désormais ils sont tes parents, comme ceux qui t'ont donné la vie. Va en paix, ma fille. Je compte n'entendre dire que du bien de toi, tant que je vivrai." Il leur fit ses adieux, et il leur donna congé. 
###### 13
A son tour, Edna dit à Tobie : "Fils et frère très cher, qu'il plaise au Seigneur de te ramener! Je souhaite vivre assez pour voir vos enfants, à toi et à ma fille Sarra, avant de mourir. En présence du Seigneur je confie ma fille à ta garde. Ne lui fais jamais de la peine durant ta vie. Va en paix, mon fils. Désormais je suis ta mère, et Sarra est ta sœur. Puissions-nous tous vivre heureux pareillement, tous les jours de notre vie!" Et elle les embrassa tous les deux, et elle les laissa partir bien contents.
###### 14
Tobie partit satisfait de chez Ragouèl. Tout joyeux, il bénissait le Seigneur du Ciel et de la Terre et Roi de l'univers, de l'heureux succès de son voyage. Il bénit ainsi Ragouèl et sa femme Edna : "Puissé-je avoir le bonheur de vous honorer tous les jours de ma vie!"
