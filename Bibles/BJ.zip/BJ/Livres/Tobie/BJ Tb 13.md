---
aliases : 
- Tobie 13
- Tobie 13
- Tb 13
- Tobit 13
tags : 
- Bible/Tb/13
- français
cssclass : français
---

# Tobie 13

###### 1
Et il dit Béni soit Dieu qui vit à jamais, car son règne dure dans tous les siècles!
###### 2
Car tour à tour il châtie et il pardonne, il fait descendre aux profondeurs des enfers et il retire de la grande Perdition personne n'échappe à sa main.
###### 3
Célébrez-le en face des nations, vous, enfants d'Israël! Car s'il vous a dispersés parmi elles,
###### 4
c'est là qu'il vous a montré sa grandeur. Exaltez-le en face de tous les vivants, c'est lui notre Seigneur et c'est lui notre Dieu et c'est lui notre Père et il est Dieu dans tous les siècles!
###### 5
S'il vous châtie pour vos iniquités, il aura pitié de vous tous, il vous rassemblera de toutes les nations où vous aurez été dispersés.
###### 6
Si vous revenez à lui, du fond du cœur et de toute votre âme, pour agir dans la vérité devant lui, alors il reviendra vers vous, et ne vous cachera plus sa face. Regardez donc comme il vous a traités, rendez-lui grâce à haute voix. Bénissez le Seigneur de justice, et exaltez le Roi des siècles.
###### 7
Pour moi, je le célèbre sur ma terre d'exil, je fais connaître sa force et sa grandeur au peuple des pécheurs. Pécheurs, revenez à lui, pratiquez la justice devant lui; peut-être vous sera-t-il favorable et vous fera-t-il miséricorde!
###### 8
Pour moi, j'exalte Dieu et mon âme se réjouit dans le Roi du Ciel. Que sa grandeur soit sur toutes les lèvres, et qu'on le célèbre à Jérusalem!
###### 9
Jérusalem, cité sainte, Dieu te frappa pour les œuvres de tes mains et il aura encore pitié des fils des justes.
###### 10
Remercie dignement le Seigneur et bénis le Roi des siècles, pour qu'en toi son Temple soit rebâti dans la joie et qu'en toi il réjouisse tous les exilés, et qu'en toi il aime tous les malheureux, pour toutes les générations à venir.
###### 11
Une vive lumière illuminera toutes les contrées de la terre; des peuples nombreux viendront de loin, de toutes les extrémités de la terre, séjourner près du saint Nom du Seigneur Dieu, les mains portant des présents au Roi du Ciel. En toi des générations de générations manifesteront leur allégresse, et le nom de l'Elue durera dans les générations à venir.
###### 12
Maudit soit qui t'insultera, maudit soit qui te détruira, qui renversera tes murs, qui abattra tes tours, qui brûlera tes maisons! Et béni éternellement qui te bâtira!
###### 13
Alors tu exulteras et tu te réjouiras sur les fils des justes, car ils seront tous rassemblés et ils béniront le Seigneur des siècles.
###### 14
Bienheureux ceux qui t'aiment! heureux ceux qui se réjouiront de ta paix! heureux ceux qui se seront lamentés sur tous tes châtiments! Car ils vont se réjouir en toi, et ils verront tout ton bonheur à l'avenir.
###### 15
Mon âme bénit le Seigneur, le grand Roi,
###### 16
parce que Jérusalem sera rebâtie, et sa Maison pour tous les siècles! Quel bonheur, s'il reste quelqu'un de ma race, pour voir ta gloire et louer le Roi du Ciel! Les portes de Jérusalem seront bâties de saphir et d'émeraude, et tous tes murs de pierre précieuse; les tours de Jérusalem seront bâties en or, et leurs remparts en or pur.
###### 17
Les rues de Jérusalem seront pavées de rubis et de pierres d'Ophir; les portes de Jérusalem retentiront de cantiques d'allégresse; 
###### 18
et toutes ses maisons diront Alleluia! Béni soit le Dieu d'Israël! En toi l'on bénira le saint Nom, dans les siècles des siècles!
