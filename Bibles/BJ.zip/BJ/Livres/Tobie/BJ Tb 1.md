---
aliases : 
- Tobie 1
- Tobie 1
- Tb 1
- Tobit 1
tags : 
- Bible/Tb/1
- français
cssclass : français
---

# Tobie 1

###### 1
Histoire de Tobit, fils de Tobiel, fils de Ananiel, fils d'Adouel, fils de Gabaèl, de la lignée d'Asiel, de la tribu de Nephtali.
###### 2
Aux jours de Salmanasar, roi d'Assyrie, il fut déporté de Tibé, qui se trouve au sud de Kédès-Nephtali, en Haute-Galilée, au-dessus de Hasor, à l'ouest, au soleil couchant, et au nord de Shephat.
###### 3
Moi, Tobit, j'ai marché sur des chemins de vérité et dans les bonnes œuvres tous les jours de ma vie. J'ai fait beaucoup d'aumônes à mes frères et à mes compatriotes déportés avec moi à Ninive, au pays d'Assyrie.
###### 4
Dans ma jeunesse, quand j'étais encore dans mon pays, la terre d'Israël, toute la tribu de Nephtali mon ancêtre se détacha de la maison de David et de Jérusalem. C'était pourtant la ville choisie parmi toutes les tribus d'Israël pour leurs sacrifices; c'était là que le Temple où Dieu réside avait été bâti et dédié pour toutes les générations à venir.
###### 5
Tous mes frères, et la maison de Nephtali, eux, sacrifiaient au veau qu'avait fait Jéroboam, roi d'Israël, à Dan, sur tous les monts de Galilée.
###### 6
Bien des fois, j'étais absolument seul à venir en pèlerinage à Jérusalem, pour satisfaire à la loi qui oblige tout Israël à perpétuité. Je courais à Jérusalem, avec les prémices des fruits et des animaux, la dîme du bétail, et la première tonte des brebis.
###### 7
Je les donnais aux prêtres, fils d'Aaron, pour l'autel. Aux lévites, alors en fonction à Jérusalem, je donnais la dîme du vin et du blé, des olives, des grenades et des autres fruits. Je prélevais en espèces la seconde dîme, six ans de suite, et j'allais la dépenser à Jérusalem chaque année.
###### 8
Je donnais la troisième aux orphelins, aux veuves et aux étrangers qui vivent avec les Israélites; je la leur apportais en présent tous les trois ans. Nous la mangions, fidèles à la fois aux prescriptions de la Loi mosaïque et aux recommandations de Debbora, mère de Ananiel, notre père; parce que mon père était mort, en me laissant orphelin.
###### 9
A l'âge d'homme, je pris une femme de notre parenté, qui s'appelait Anna; elle me donna un fils que je nommai Tobie.
###### 10
Lors de la déportation en Assyrie, quand je fus emmené, je vins à Ninive. Tous mes frères, et ceux de ma race, mangeaient les mets des païens;
###### 11
pour moi, je me gardai de manger les mets des païens.
###### 12
Comme j'avais été fidèle à mon Dieu de tout mon cœur,
###### 13
le Très-Haut me donna la faveur de Salmanasar, dont je devins l'homme d'affaires.
###### 14
Je voyageais en Médie, où je passai des marchés pour lui, jusqu'à sa mort; et je déposai chez Gabaèl, frère de Gabri, à Rhagès de Médie, des sacs d'argent pour dix talents.
###### 15
A la mort de Salmanasar, Sennachérib, son fils, lui succéda; les routes de Médie se fermèrent, et je ne pus continuer à m'y rendre.
###### 16
Aux jours de Salmanasar, j'avais fait souvent l'aumône à mes frères de race,
###### 17
je donnais mon pain aux affamés, et des habits à ceux qui étaient nus; et j'enterrais, quand j'en voyais, les cadavres de mes compatriotes, jetés par-dessus les remparts de Ninive.
###### 18
J'enterrai de même ceux que tua Sennachérib. Quand il revint en fuyard de Judée, après le châtiment du Roi du Ciel sur le blasphémateur, Sennachérib, dans sa colère, tua un grand nombre d'Israélites. Alors, je dérobais leurs corps pour les ensevelir; Sennachérib les cherchait et ne les trouvait plus.
###### 19
Un Ninivite vint informer le roi que j'étais le fossoyeur clandestin. Quand je sus le roi renseigné sur mon compte, que je me vis recherché pour être mis à mort, j'eus peur, et je pris la fuite.
###### 20
Tous mes biens furent saisis; tout fut confisqué pour le trésor; rien ne me resta, que ma femme Anna, et que mon fils Tobie.
###### 21
Moins de 40 jours après, le roi fut assassiné par ses deux fils, qui s'enfuirent dans les monts Ararat. Asarhaddon, son fils, lui succéda. Ahikar, fils de mon frère Anaèl, fut chargé des comptes du royaume, et il avait la direction générale des affaires.
###### 22
Alors Ahikar intercéda pour moi, et je pus redescendre à Ninive. C'est que Ahikar, sous Sennachérib, roi d'Assyrie, avait été grand échanson, garde du sceau, administrateur et maître des comptes; et Asarhaddon l'avait maintenu en fonctions. Il était de ma parenté, c'était mon neveu.
