---
aliases : 
- Proverbes 24
- Proverbes 24
- Pr 24
- Proverbs 24
tags : 
- Bible/Pr/24
- français
cssclass : français
---

# Proverbes 24

###### 1
Ne porte pas envie aux méchants, ne souhaite pas leur compagnie, 
###### 2
car leur cœur ne songe qu'à la violence, leurs lèvres n'expriment que malheur. 
###### 3
C'est par la sagesse qu'on bâtit une maison, par l'intelligence qu'on l'affermit; 
###### 4
par le savoir, on emplit ses greniers de tous les biens précieux et désirables. 
###### 5
Un homme sage est plein de force, l'homme de science affermit sa vigueur; 
###### 6
car c'est par des calculs que tu feras la guerre, et le succès tient au grand nombre des conseillers. 
###### 7
Pour le fou, la sagesse est une forteresse inaccessible : à la porte de la ville, il n'ouvre pas la bouche. 
###### 8
Qui songe à mal faire, on l'appelle un maître en astuce. 
###### 9
La folie ne rêve que péché, le railleur est honni des hommes. 
###### 10
Si tu te laisses abattre au jour mauvais, ta vigueur est peu de chose. 
###### 11
Délivre ceux qu'on envoie à la mort, ceux qu'on traîne au supplice, puisses-tu les sauver! 
###### 12
Diras-tu : " Voilà! nous ne savions pas " ? Celui qui pèse les cœurs ne comprend-il pas ? Alors qu'il sait, lui qui a façonné ton âme; c'est lui qui rendra à l'homme selon son œuvre. 
###### 13
Mange du miel, mon fils, car c'est bon, un rayon de miel est doux à ton palais. 
###### 14
Ainsi sera, sache-le, la sagesse pour ton âme. Si tu la trouves, il y aura un avenir et ton espérance ne sera pas anéantie. 
###### 15
Ne t'embusque pas, méchant, près de la demeure du juste, ne dévaste pas son habitation. 
###### 16
Car le juste tombe sept fois et se relève, mais les méchants trébuchent dans l'adversité. 
###### 17
Si ton ennemi tombe, ne te réjouis pas, que ton cœur n'exulte pas de ce qu'il trébuche, 
###### 18
de peur que, voyant cela, Yahvé ne soit mécontent et qu'il ne détourne de lui sa colère. 
###### 19
Ne t'échauffe pas au sujet des méchants, ne jalouse pas les impies. 
###### 20
Car pour le méchant, il n'est pas d'avenir : la lampe des impies s'éteint. 
###### 21
Crains Yahvé, mon fils, et le roi; ne te lie pas avec les novateurs : 
###### 22
car tout soudain surgira leur malheur, et la ruine de l'un et de l'autre, qui la connaît ? 
###### 23
Ceci est encore des Sages : Avoir égard aux personnes dans les jugements n'est pas bien. 
###### 24
Quiconque dit au méchant : " Tu es juste ", les peuples le maudissent, les nations le honnissent; 
###### 25
mais ceux qui punissent s'en trouvent bien, sur eux viendra une heureuse bénédiction. 
###### 26
Il met un baiser sur les lèvres, celui qui répond franchement. 
###### 27
Organise au-dehors ta besogne et prépare-la aux champs; ensuite, tu bâtiras ta maison. 
###### 28
Ne témoigne pas à la légère contre ton prochain, ne trompe pas par tes lèvres. 
###### 29
Ne dis pas : " Comme il m'a fait, je lui ferai! à chacun je rendrai selon son œuvre! " 
###### 30
Près du champ du paresseux j'ai passé, près de la vigne de l'homme court de sens. 
###### 31
Or voici : tout était monté en orties, le chardon en couvrait la surface, le mur de pierres était écroulé. 
###### 32
Ayant vu, je réfléchis, ayant regardé, je tirai cette leçon : 
###### 33
" Un peu dormir, un peu s'assoupir, un peu croiser les bras en s'allongeant, 
###### 34
et, tel un rôdeur, viendra l'indigence et la disette, comme un mendiant! " 
