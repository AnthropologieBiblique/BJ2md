---
aliases : 
- Proverbes 2
- Proverbes 2
- Pr 2
- Proverbs 2
tags : 
- Bible/Pr/2
- français
cssclass : français
---

# Proverbes 2

###### 1
Mon fils, si tu accueilles mes paroles, si tu conserves à part toi mes préceptes, 
###### 2
rendant tes oreilles attentives à la sagesse, inclinant ton cœur vers l'intelligence, 
###### 3
oui, si tu fais appel à l'entendement, si tu réclames l'intelligence, 
###### 4
si tu la recherches comme l'argent, si tu la creuses comme un chercheur de trésor, 
###### 5
alors tu comprendras la crainte de Yahvé, tu trouveras la connaissance de Dieu. 
###### 6
Car c'est Yahvé qui donne la sagesse, de sa bouche sortent le savoir et l'intelligence. 
###### 7
Il réserve aux hommes droits son conseil, il est le bouclier de ceux qui pratiquent l'honnêteté; 
###### 8
il monte la garde aux chemins de l'équité, il veille sur la voie de ses fidèles. 
###### 9
Alors tu comprendras justice, équité et droiture, toutes les pistes du bonheur. 
###### 10
Quand la sagesse entrera dans ton cœur, que le savoir fera les délices de ton âme, 
###### 11
la prudence veillera sur toi, l'intelligence te gardera 
###### 12
pour t'éloigner de la voie mauvaise, de l'homme aux propos pervers, 
###### 13
de ceux qui délaissent les droits sentiers et vont courir par des voies ténébreuses; 
###### 14
ils trouvent leur joie à faire le mal, ils se complaisent dans la perversité; 
###### 15
leurs sentiers sont tortueux, leurs pistes sont obliques. 
###### 16
Pour te garder aussi de la femme étrangère, de l'inconnue aux paroles enjôleuses; 
###### 17
elle a abandonné l'ami de sa jeunesse, elle a oublié l'alliance de son Dieu; 
###### 18
sa maison penche vers la mort, ses pistes conduisent vers les ombres. 
###### 19
De ceux qui vont à elle, pas un ne revient, ils ne rejoignent plus les sentiers de la vie. 
###### 20
Ainsi chemineras-tu dans la voie des gens de bien, garderas-tu le sentier des justes. 
###### 21
Car les hommes droits habiteront le pays, les gens honnêtes y demeureront, 
###### 22
mais les méchants seront retranchés du pays, les traîtres en seront arrachés. 
