---
aliases : 
- Proverbes 27
- Proverbes 27
- Pr 27
- Proverbs 27
tags : 
- Bible/Pr/27
- français
cssclass : français
---

# Proverbes 27

###### 1
Ne te félicite pas du lendemain, car tu ignores ce qu'aujourd'hui enfantera. 
###### 2
Qu'autrui fasse ton éloge, mais non ta propre bouche, un étranger, mais non tes lèvres! 
###### 3
Lourde est la pierre, pesant le sable, mais plus lourd qu'eux, le dépit du fou. 
###### 4
Cruelle est la fureur, impétueuse la colère, mais contre la jalousie, qui tiendra ? 
###### 5
Mieux vaut réprimande ouverte qu'amour dissimulé. 
###### 6
Fidèles sont les coups d'un ami, mensongers les baisers d'un ennemi. 
###### 7
Gorge rassasiée méprise le miel, gorge affamée trouve douce toute amertume. 
###### 8
Comme l'oiseau qui erre loin de son nid, ainsi l'homme qui erre loin de son pays. 
###### 9
L'huile et le parfum mettent le cœur en joie, et la douceur de l'amitié, plus que la complaisance en soi-même. 
###### 10
N'abandonne pas ton ami ni l'ami de ton père; à la maison de ton frère, ne va pas au jour de ton affliction. Mieux vaut un voisin proche qu'un frère éloigné. 
###### 11
Deviens sage, mon fils, et réjouis mon cœur, que je puisse répondre à qui m'outrage. 
###### 12
L'homme avisé voit le malheur et se cache, les niais passent outre, à leurs dépens. 
###### 13
Prends-lui son vêtement, car il a cautionné un étranger, à cause d'inconnus, prends-lui un gage. 
###### 14
Si quelqu'un bénit son prochain à haute voix dès l'aube, cela lui est compté pour une malédiction. 
###### 15
Gargouille qui ne cesse de couler un jour de pluie et femme querelleuse sont pareilles! 
###### 16
Qui veut la saisir, saisit le vent et sa droite rencontre de l'huile. 
###### 17
Le fer s'aiguise par le fer, l'homme s'affine en face de son prochain. 
###### 18
Le gardien du figuier mange de son fruit, qui veille sur son maître sera honoré. 
###### 19
Comme l'eau donne le reflet du visage, ainsi le cœur de l'homme pour l'homme. 
###### 20
Insatiables sont le Shéol et la Perdition, ainsi les yeux de l'homme sont-ils insatiables. 
###### 21
Il y a la fournaise pour l'argent, le fourneau pour l'or : l'homme vaut ce que vaut sa réputation. 
###### 22
Quand tu pilerais le fou au mortier parmi les grains, avec un pilon , sa folie ne se séparerait pas de lui. 
###### 23
Connais bien l'état de ton bétail, à ton troupeau donne tes soins; 
###### 24
car la richesse n'est pas éternelle, et une couronne ne se transmet pas d'âge en âge. 
###### 25
Une fois l'herbe enlevée, le regain apparu, ramassé le foin des montagnes, 
###### 26
aie des agneaux pour te vêtir, des boucs pour acheter un champ, 
###### 27
le lait des chèvres en abondance pour te sustenter, pour nourrir ta maison et faire vivre tes servantes. 
