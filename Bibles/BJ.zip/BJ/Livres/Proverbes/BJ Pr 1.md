---
aliases : 
- Proverbes 1
- Proverbes 1
- Pr 1
- Proverbs 1
tags : 
- Bible/Pr/1
- français
cssclass : français
---

# Proverbes 1

###### 1
Proverbes de Salomon, fils de David, roi d'Israël : 
###### 2
pour connaître sagesse et discipline, pour pénétrer les discours profonds, 
###### 3
pour acquérir une discipline avisée - justice, équité, droiture - 
###### 4
pour procurer aux simples le savoir-faire, au jeune homme le savoir et la réflexion, 
###### 5
Que le sage écoute, il augmentera son acquis, et l'homme entendu acquerra l'art de diriger. 
###### 6
pour pénétrer proverbes et sentences obscures, les dits des sages et leurs énigmes. 
###### 7
La crainte de Yahvé, principe de savoir : les fous dédaignent sagesse et discipline. 
###### 8
Écoute, mon fils, l'instruction de ton père, ne méprise pas l'enseignement de ta mère : 
###### 9
c'est une couronne de grâce pour ta tête, des colliers pour ton cou. 
###### 10
Mon fils, si des pécheurs veulent te séduire, n'y va pas! 
###### 11
S'ils disent : " Viens avec nous, embusquons-nous pour répandre le sang, sans raison, prenons l'affût contre l'innocent; 
###### 12
comme le shéol, avalons-les tout vifs, tout entiers, tels ceux qui descendent dans la fosse! 
###### 13
Nous trouverons mainte chose précieuse, nous emplirons de butin nos maisons; 
###### 14
avec nous tu tireras ta part au sort, nous ferons tous bourse commune! " 
###### 15
Mon fils, ne les suis pas dans leur voie, éloigne tes pas de leur sentier, 
###### 16
car leurs pieds courent au mal ils ont hâte de répandre le sang; 
###### 17
car c'est en vain qu'on étend le filet sous les yeux de tout volatile. 
###### 18
C'est pour répandre leur propre sang qu'ils s'embusquent, contre eux-mêmes, ils sont à l'affût! 
###### 19
Tels sont les sentiers de tout homme avide de rapine : elle ôte la vie à ceux qu'elle habite. 
###### 20
La Sagesse crie par les rues, sur les places elle élève la voix; 
###### 21
à l'angle des carrefours, elle appelle, près des portes, dans la ville, elle prononce son discours : 
###### 22
" Jusques à quand, ô niais, aimerez-vous la niaiserie ? et les railleurs se plairont-ils à la raillerie ? et les sots haïront-ils le savoir ? 
###### 23
Convertissez-vous à mon exhortation, pour vous je vais épancher mon cœur et vous faire connaître mes paroles. 
###### 24
Puisque j'ai appelé et que vous avez refusé, puisque j'ai étendu la main sans que nul y prenne garde, 
###### 25
puisque vous avez négligé tous mes conseils et que vous n'avez pas voulu de mon exhortation, 
###### 26
à mon tour, je me rirai de votre détresse, je me moquerai quand viendra sur vous l'épouvante, 
###### 27
quand l'épouvante viendra sur vous comme l'orage, quand votre détresse arrivera comme un tourbillon, quand l'épreuve et l'angoisse fondront sur vous. 
###### 28
Alors ils m'appelleront, mais je ne répondrai pas; ils me chercheront et ne me trouveront pas. 
###### 29
Ils ont détesté le savoir, ils n'ont pas choisi la crainte de Yahvé, 
###### 30
ils n'ont pas voulu de mon conseil, ils ont méprisé toutes mes exhortations : 
###### 31
ils mangeront donc du fruit de leurs errements, ils se rassasieront de leurs propres conseils! 
###### 32
Car l'égarement des niais les tue, l'insouciance des sots les mène à leur perte; 
###### 33
mais qui m'écoute demeure en sécurité, il sera tranquille, sans craindre le malheur. " 
