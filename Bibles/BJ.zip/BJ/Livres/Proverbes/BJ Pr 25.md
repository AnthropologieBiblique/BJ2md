---
aliases : 
- Proverbes 25
- Proverbes 25
- Pr 25
- Proverbs 25
tags : 
- Bible/Pr/25
- français
cssclass : français
---

# Proverbes 25

###### 1
Voici encore des proverbes de Salomon, que transcrivirent les gens d'Ézéchias, roi de Juda. 
###### 2
C'est la gloire de Dieu de celer une chose, c'est la gloire des rois de la scruter. 
###### 3
Les cieux, par leur hauteur, la terre, par sa profondeur, et le cœur des rois sont insondables. 
###### 4
Ote de l'argent les scories, il en sortira totalement purifié; 
###### 5
ôte le méchant de la présence du roi, et sur la justice s'affermira son trône. 
###### 6
En face du roi, ne prends pas de grands airs, ne te mets pas à la place des grands; 
###### 7
car mieux vaut qu'on te dise : " Monte ici! " que d'être abaissé en présence du prince. Ce que tes yeux ont vu, 
###### 8
ne le produis pas trop vite au procès, car que feras-tu à la fin si ton prochain te confond ? 
###### 9
Avec ton prochain, vide ta querelle, mais sans révéler le secret d'autrui, 
###### 10
de crainte que celui qui entend ne te bafoue et que ta diffamation soit sans retour. 
###### 11
Des pommes d'or avec des ciselures d'argent, telle est une parole dite à propos. 
###### 12
Un anneau d'or, un joyau d'or fin, telle une sage réprimande à l'oreille attentive. 
###### 13
La fraîcheur de la neige au jour de la moisson, tel est un messager fidèle : il réconforte l'âme de son maître. 
###### 14
Nuages et vent, mais point de pluie! tel est l'homme qui promet royalement, mais ne tient pas. 
###### 15
Par la patience un juge se laisse fléchir, la langue douce broie les os. 
###### 16
As-tu trouvé du miel ? manges-en à ta faim; garde-toi de t'en gorger, tu le vomirais. 
###### 17
Dans la maison du prochain, fais-toi rare, de crainte que, fatigué de toi, il ne te prenne en grippe. 
###### 18
Une massue, une épée, une flèche aiguè : tel est l'homme qui porte un faux témoignage contre son prochain. 
###### 19
Dent gâtée, pied boiteux : le traître en qui l'on se confie au jour du malheur, 
###### 20
autant ôter son manteau par un temps glacial. C'est mettre du vinaigre sur du nitre que de chanter des chansons à un cœur affligé. 
###### 21
Si ton ennemi a faim, donne-lui à manger, s'il a soif, donne-lui à boire, 
###### 22
c'est amasser des charbons sur sa tête et Yahvé te le revaudra. 
###### 23
L'aquilon engendre la pluie, la langue dissimulatrice un visage irrité. 
###### 24
Mieux vaut habiter à l'angle d'un toit que faire maison commune avec une femme querelleuse. 
###### 25
De l'eau fraîche pour une gorge altérée : telle est une bonne nouvelle venant d'un pays lointain. 
###### 26
Fontaine piétinée, source souillée : tel est un juste tremblant devant un méchant. 
###### 27
Il n'est pas bon de manger trop de miel, ni de rechercher gloire sur gloire. 
###### 28
Ville ouverte, sans remparts : tel est l'homme qui ne se possède pas. 
