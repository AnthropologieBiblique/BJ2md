---
aliases : 
- Proverbes 17
- Proverbes 17
- Pr 17
- Proverbs 17
tags : 
- Bible/Pr/17
- français
cssclass : français
---

# Proverbes 17

###### 1
Mieux vaut une bouchée de pain sec et la tranquillité qu'une maison pleine de sacrifices de discorde. 
###### 2
Un serviteur avisé l'emporte sur le fils indigne, avec les frères il aura sa part d'héritage. 
###### 3
La fournaise pour l'argent, le fourneau pour l'or, pour éprouver les cœurs : Yahvé. 
###### 4
Le méchant est attentif aux lèvres pernicieuses, le menteur prête l'oreille à la langue perverse. 
###### 5
Qui nargue le pauvre outrage son Créateur, qui rit d'un malheureux ne restera pas impuni. 
###### 6
Couronne des vieillards : les enfants de leurs enfants; fierté des enfants : leur père. 
###### 7
Une langue distinguée ne sied pas à l'insensé, moins encore, au prince, une langue menteuse. 
###### 8
Un présent est un talisman pour qui en dispose : de quelque côté qu'il se tourne, il réussit. 
###### 9
Qui jette le voile sur une offense cultive l'amitié, qui répète la chose divise les intimes. 
###### 10
Un reproche fait plus d'impression sur l'homme intelligent que cent coups sur le sot. 
###### 11
Le méchant ne cherche que rébellion, mais un messager cruel sera envoyé contre lui. 
###### 12
Plutôt rencontrer une ourse privée de ses petits qu'un insensé en son délire. 
###### 13
Qui rend le mal pour le bien, le malheur ne s'éloignera pas de sa maison. 
###### 14
C'est libérer les eaux qu'entamer une querelle; avant que n'éclate le procès, désiste-toi. 
###### 15
Acquitter le coupable et condamner le juste : deux choses également en horreur à Yahvé. 
###### 16
A quoi bon de l'argent dans la main d'un sot ? A acheter la sagesse ? Il n'y a pas le cœur! 
###### 17
Un ami aime en tout temps, un frère est engendré en vue de l'adversité. 
###### 18
Est court de sens qui tope dans la main et pour son prochain se porte garant. 
###### 19
C'est aimer l'offense qu'aimer la chicane, qui se montre orgueilleux cultive la ruine. 
###### 20
Qui a le cœur tortueux ne trouve pas le bonheur, qui a la langue perverse tombe dans le malheur. 
###### 21
Qui engendre un sot, c'est pour son chagrin; il n'a guère de joie, le père de l'insensé! 
###### 22
Cœur joyeux améliore la santé, esprit déprimé dessèche les os. 
###### 23
Le méchant accepte un présent sous le manteau, pour faire une entorse au droit. 
###### 24
L'homme intelligent a devant lui la sagesse, mais les regards du sot se portent au bout du monde. 
###### 25
Chagrin pour son père qu'un fils insensé, et amertume pour celle qui l'a enfanté. 
###### 26
Il n'est pas bon de mettre le juste à l'amende; frapper les nobles est contraire au droit. 
###### 27
Qui retient ses paroles connaît le savoir, un esprit froid est un homme d'intelligence. 
###### 28
Même le fou, s'il se tait, passe pour sage, pour intelligent, celui qui clôt ses lèvres. 
