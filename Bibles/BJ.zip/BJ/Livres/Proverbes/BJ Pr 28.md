---
aliases : 
- Proverbes 28
- Proverbes 28
- Pr 28
- Proverbs 28
tags : 
- Bible/Pr/28
- français
cssclass : français
---

# Proverbes 28

###### 1
Le méchant s'enfuit quand nul ne le poursuit, d'un lionceau les justes ont l'assurance. 
###### 2
Quand un pays se révolte, nombreux sont les princes, avec l'homme intelligent et instruit, c'est la stabilité. 
###### 3
Un homme méchant qui opprime des faibles, c'est une pluie dévastatrice et plus de pain. 
###### 4
Ceux qui délaissent la loi font l'éloge du méchant, ceux qui observent la loi s'irritent contre eux. 
###### 5
Les méchants ne comprennent pas le droit, ceux qui cherchent Yahvé comprennent tout. 
###### 6
Mieux vaut le pauvre qui se conduit honnêtement que l'homme aux voies tortueuses, fût-il riche. 
###### 7
Qui garde la loi est un fils intelligent, qui hante les débauchés est la honte de son père. 
###### 8
Qui accroît son bien par usure et par intérêt, c'est pour qui en gratifiera les pauvres qu'il l'amasse. 
###### 9
Qui se bouche les oreilles pour ne pas entendre la loi, sa prière même est une abomination. 
###### 10
Qui fourvoie les gens droits dans le mauvais chemin, en sa propre fosse tombera. Les hommes honnêtes posséderont le bonheur. 
###### 11
Le riche est sage à ses propres yeux, mais un pauvre intelligent le démasque. 
###### 12
Quand les justes exultent, c'est une grande fierté, quand se lèvent les méchants, on se dérobe. 
###### 13
Qui masque ses forfaits point ne réussira; qui les avoue et y renonce obtiendra merci. 
###### 14
Heureux l'homme toujours en alarme; qui s'endurcit le cœur tombera dans le malheur. 
###### 15
Un lion rugissant, un ours qui bondit, tel est le chef méchant sur un peuple faible. 
###### 16
Un prince sans intelligence est riche en extorsions, qui hait la cupidité prolongera ses jours. 
###### 17
Un homme coupable de meurtre fuira jusqu'à la tombe : Qu'on ne l'arrête pas! 
###### 18
Qui se conduit honnêtement sera sauf; qui, tortueux, suit deux voies, tombera dans l'une d'elles. 
###### 19
Qui cultive sa terre sera rassasié de pain, qui poursuit des chimères sera rassasié d'indigence. 
###### 20
L'homme loyal sera comblé de bénédictions, qui se hâte de faire fortune ne restera pas impuni. 
###### 21
C'est mal de faire acception de personnes, mais pour une bouchée de pain, l'homme commet un forfait. 
###### 22
Il court après la fortune, l'homme au regard cupide, ignorant que c'est la disette qui lui adviendra. 
###### 23
Qui reprend autrui trouvera faveur à la fin, plus que le flatteur. 
###### 24
Qui dérobe à son père et à sa mère en disant : " Point d'offense! " du brigand est l'associé. 
###### 25
L'homme envieux engage la querelle, qui se confie en Yahvé prospérera. 
###### 26
Qui se fie à son propre sens est un sot, qui chemine avec sagesse sera sauf. 
###### 27
Pour qui donne aux pauvres, pas de disette, mais pour qui ferme les yeux, abondante malédiction. 
###### 28
Quand se lèvent les méchants, chacun se cache; qu'ils viennent à périr, les justes se multiplient. 
