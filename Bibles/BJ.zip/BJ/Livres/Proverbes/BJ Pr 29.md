---
aliases : 
- Proverbes 29
- Proverbes 29
- Pr 29
- Proverbs 29
tags : 
- Bible/Pr/29
- français
cssclass : français
---

# Proverbes 29

###### 1
Celui qui, sous les reproches, raidit la nuque sera brisé soudain et sans remède. 
###### 2
Quand les justes se multiplient, le peuple est en liesse; quand les méchants dominent, le peuple gémit. 
###### 3
Qui aime la sagesse réjouit son père, qui hante les prostituées dissipe son bien. 
###### 4
Par l'équité, un roi fait prospérer le pays, mais l'exacteur le mène à la ruine. 
###### 5
L'homme qui flatte son prochain tend un filet sous ses pas. 
###### 6
Dans l'offense du méchant il y a un piège, mais le juste exulte et se réjouit. 
###### 7
Le juste connaît la cause des faibles, le méchant n'a pas l'intelligence de la connaître. 
###### 8
Les railleurs mettent la cité en effervescence, mais les sages apaisent la colère. 
###### 9
Un sage est-il en procès avec un sot, qu'il se fâche ou plaisante, il n'aura pas de repos. 
###### 10
Les hommes sanguinaires haïssent l'homme honnête, mais les hommes droits recherchent sa personne. 
###### 11
Le sot donne livre cours à tous ses emportements, mais le sage, en les réprimant, les calme. 
###### 12
Quand un chef accueille des rapports mensongers, tous ses serviteurs sont mauvais. 
###### 13
Le pauvre et l'oppresseur se rencontrent : tous deux reçoivent de Yahvé la lumière. 
###### 14
Le roi qui juge les faibles avec équité voit son trône affermi pour toujours. 
###### 15
Baguette et réprimande procurent la sagesse, le jeune homme laissé à lui-même est la honte de sa mère. 
###### 16
Quand se multiplient les méchants, le forfait se multiplie, mais les justes seront témoins de leur chute. 
###### 17
Corrige ton fils, il te laissera en repos et fera les délices de ton âme. 
###### 18
Faute de vision, le peuple vit sans frein; heureux qui observe la loi. 
###### 19
On ne corrige pas un esclave avec des mots : même s'il comprend, il n'obéit pas. 
###### 20
Tu vois un homme prompt au discours ? il y a plus à espérer d'un sot. 
###### 21
Si dès l'enfance on gâte son esclave, il deviendra finalement ingrat. 
###### 22
L'homme coléreux engage la querelle, l'homme emporté multiplie les offenses. 
###### 23
L'orgueil de l'homme l'humiliera, qui est humble d'esprit obtiendra de l'honneur. 
###### 24
C'est partager avec le voleur et se haïr soi-même, que d'entendre l'adjuration sans dénoncer. 
###### 25
Trembler devant les hommes est un piège, qui se confie en Yahvé est en sûreté. 
###### 26
Beaucoup recherchent la faveur du chef, mais de Yahvé vient le droit de chacun. 
###### 27
Abomination pour les justes : l'homme inique; abomination pour le méchant : celui dont la voie est droite. 
