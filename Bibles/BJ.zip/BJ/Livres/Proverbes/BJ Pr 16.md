---
aliases : 
- Proverbes 16
- Proverbes 16
- Pr 16
- Proverbs 16
tags : 
- Bible/Pr/16
- français
cssclass : français
---

# Proverbes 16

###### 1
A l'homme les projets du cœur, de Yahvé vient la réponse. 
###### 2
Toutes les voies de l'homme sont pures à ses yeux, mais Yahvé pèse les esprits. 
###### 3
Recommande à Yahvé tes œuvres, et tes projets se réaliseront. 
###### 4
Yahvé fit toute chose en vue d'une fin, et même le méchant pour le jour du malheur. 
###### 5
Abomination pour Yahvé : tout cœur altier; à coup sûr, il ne restera pas impuni. 
###### 6
Par la piété et la fidélité on expie la faute, par la crainte de Yahvé on s'écarte du mal. 
###### 7
Que Yahvé se plaise à la conduite d'un homme, il lui réconcilie même ses ennemis. 
###### 8
Mieux vaut peu avec la justice que d'abondants revenus sans le bon droit. 
###### 9
Le cœur de l'homme délibère sur sa voie, mais c'est Yahvé qui affermit ses pas. 
###### 10
L'oracle est sur les lèvres du roi, dans un jugement, sa bouche est sans défaillance. 
###### 11
La balance et les plateaux justes sont à Yahvé, tous les poids du sac sont son œuvre. 
###### 12
Abomination pour les rois : commettre le mal, car sur la justice le trône est établi. 
###### 13
Les lèvres justes gagnent la faveur du roi, il aime qui parle avec droiture. 
###### 14
La fureur du roi est messagère de mort, mais l'homme sage l'apaise. 
###### 15
Dans la lumière du visage royal est la vie; telle une pluie printanière est sa bienveillance. 
###### 16
Combien il vaut mieux acquérir la sagesse que l'or! L'acquisition de l'intelligence est préférable à l'argent. 
###### 17
Le chemin des gens droits, c'est d'éviter le mal; il garde sa vie, celui qui veille sur ses démarches. 
###### 18
L'arrogance précède la ruine et l'esprit altier la chute. 
###### 19
Mieux vaut être humble avec les pauvres qu'avec les superbes partager le butin. 
###### 20
Qui est attentif à la parole trouve le bonheur, qui se fie en Yahvé est bienheureux. 
###### 21
Un cœur sage est proclamé intelligent, la douceur des lèvres augmente le savoir. 
###### 22
Le bon sens est source de vie pour qui le possède, la folie des fous est leur châtiment. 
###### 23
Le cœur du sage rend sa bouche avisée et ses lèvres riches de savoir. 
###### 24
Les paroles aimables sont un rayon de miel : doux au palais, salutaire au corps. 
###### 25
Tel chemin paraît droit à quelqu'un, mais en fin de compte, c'est le chemin de la mort. 
###### 26
L'appétit du travailleur travaille pour lui, car sa bouche le presse. 
###### 27
L'homme de rien produit le malheur, c'est comme un feu brûlant sur ses lèvres. 
###### 28
L'homme fourbe sème la querelle, le diffamateur divise les intimes. 
###### 29
L'homme violent séduit son prochain et le mène dans une voie qui n'est pas bonne. 
###### 30
Qui ferme les yeux pour méditer des fourberies, qui pince les lèvres, a commis le mal. 
###### 31
C'est une couronne d'honneur que des cheveux blancs, sur les chemins de la justice on la trouve. 
###### 32
Mieux vaut un homme lent à la colère qu'un héros, un homme maître de soi qu'un preneur de villes. 
###### 33
Dans le pli du vêtement on jette le sort, de Yahvé dépend le jugement. 
