---
aliases : 
- Proverbes 15
- Proverbes 15
- Pr 15
- Proverbs 15
tags : 
- Bible/Pr/15
- français
cssclass : français
---

# Proverbes 15

###### 1
Une aimable réponse apaise la fureur, une parole blessante fait monter la colère. 
###### 2
La langue des sages rend le savoir agréable, la bouche des sots éructe la folie. 
###### 3
En tout lieu sont les yeux de Yahvé, ils observent méchants et bons. 
###### 4
Langue apaisante est un arbre de vie, langue perverse brise le cœur. 
###### 5
Le fou méprise la correction paternelle, qui observe la réprimande est avisé. 
###### 6
Biens abondants dans la maison du juste, mais les revenus du méchant sont source d'inquiétude. 
###### 7
Les lèvres des sages répandent le savoir, mais non le cœur des sots. 
###### 8
Le sacrifice des méchants est une abomination pour Yahvé, mais la prière des hommes droits fait ses délices. 
###### 9
Abomination pour Yahvé : la mauvaise conduite; mais il chérit qui poursuit la justice. 
###### 10
Sévère correction pour qui s'écarte du sentier; qui hait la réprimande mourra. 
###### 11
Shéol et Perdition sont devant Yahvé : combien plus le cœur des enfants des hommes! 
###### 12
Le railleur n'aime pas qu'on le reprenne, avec les sages il ne va guère. 
###### 13
Cœur joyeux fait bon visage, cœur chagrin a l'esprit abattu. 
###### 14
Cœur intelligent recherche le savoir, la bouche des sots se repaît de folie. 
###### 15
Pour le pauvre tous les jours sont mauvais, pour le cœur joyeux, c'est un banquet perpétuel. 
###### 16
Mieux vaut peu avec la crainte de Yahvé qu'un riche trésor avec l'inquiétude. 
###### 17
Mieux vaut une portion de légumes avec l'affection qu'un bœuf gras avec la haine. 
###### 18
L'homme emporté engage la querelle, l'homme lent à la colère apaise la dispute. 
###### 19
Le chemin du paresseux est comme une haie d'épines, le sentier des hommes droits est une grand-route. 
###### 20
Le fils sage réjouit son père, l'homme sot méprise sa mère. 
###### 21
La folie fait la joie de l'homme privé de sens, l'homme intelligent va droit son chemin. 
###### 22
Faute de réflexion les projets échouent, grâce à de nombreux conseillers, ils prennent corps. 
###### 23
Joie pour l'homme qu'une réplique de sa bouche, que c'est bon, une réponse opportune! 
###### 24
A l'homme de bon sens, le sentier de la vie, qui mène en haut, afin d'éviter le shéol, en bas. 
###### 25
Yahvé renverse la maison des superbes, mais il relève la borne de la veuve. 
###### 26
Abomination pour Yahvé : les mauvais desseins; mais les paroles bienveillantes sont pures. 
###### 27
Qui est avide de rapines trouble sa maison, qui hait les présents vivra. 
###### 28
Le cœur du juste médite pour répondre, la bouche des méchants éructe la méchanceté. 
###### 29
Yahvé s'éloigne des méchants, mais il entend la prière des justes. 
###### 30
Un regard bienveillant réjouit le cœur, une bonne nouvelle ranime les forces. 
###### 31
L'oreille attentive à la réprimande salutaire a sa demeure parmi les sages. 
###### 32
Qui rejette la correction se méprise lui-même, qui écoute la réprimande acquiert du sens. 
###### 33
La crainte de Yahvé est discipline de sagesse, avant la gloire, il y a l'humilité. 
