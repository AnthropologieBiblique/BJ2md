---
aliases : 
- Proverbes 18
- Proverbes 18
- Pr 18
- Proverbs 18
tags : 
- Bible/Pr/18
- français
cssclass : français
---

# Proverbes 18

###### 1
Qui vit à l'écart suit son bon plaisir, contre tout conseil il s'emporte. 
###### 2
Le sot ne prend pas plaisir à être intelligent, mais à étaler son sentiment. 
###### 3
Quand vient la méchanceté, vient aussi l'affront, avec le mépris, l'opprobre. 
###### 4
Des eaux profondes, voilà les paroles de l'homme : un torrent débordant, une source de sagesse. 
###### 5
Il n'est pas bon de favoriser le méchant, pour débouter le juste dans un jugement. 
###### 6
Les lèvres du sot vont au procès et sa bouche appelle les coups. 
###### 7
La bouche du sot est sa ruine et ses lèvres un piège pour sa vie. 
###### 8
Les dires du calomniateur sont de friands morceaux qui descendent jusqu'au fond des entrailles. 
###### 9
Quiconque est paresseux à l'ouvrage, celui-là est frère du destructeur. 
###### 10
Une tour forte : le nom de Yahvé! le juste y accourt et il est hors d'atteinte. 
###### 11
La fortune du riche, voilà sa place forte : c'est une haute muraille, pense-t-il. 
###### 12
Avant la ruine, le cœur humain s'élève, avant la gloire, il y a l'humilité. 
###### 13
Qui riposte avant d'écouter, c'est pour lui folie et confusion. 
###### 14
L'esprit de l'homme peut endurer la maladie, mais l'esprit abattu, qui le relèvera ? 
###### 15
Cœur intelligent acquiert la science, l'oreille des sages recherche le savoir. 
###### 16
Le don que fait un homme lui ouvre la voie et le met en présence des grands. 
###### 17
On donne raison au premier qui plaide, que survienne un adversaire, il le démasque. 
###### 18
Le sort met fin aux querelles et décide entre les puissants. 
###### 19
Un frère offensé est pire qu'une ville fortifiée et les querelles sont comme les verrous d'un donjon. 
###### 20
Du fruit de sa bouche l'homme rassasie son estomac, du produit de ses lèvres il se rassasie. 
###### 21
Mort et vie sont au pouvoir de la langue, ceux qui la chérissent mangeront de son fruit. 
###### 22
Trouver une femme, c'est trouver le bonheur, c'est obtenir une faveur de Yahvé. 
###### 23
Le pauvre parle en suppliant, le riche répond durement. 
###### 24
Il y a des amis qui mènent à la ruine, il y en a qui sont plus chers qu'un frère. 
