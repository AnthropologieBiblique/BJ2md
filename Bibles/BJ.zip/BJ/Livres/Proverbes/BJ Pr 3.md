---
aliases : 
- Proverbes 3
- Proverbes 3
- Pr 3
- Proverbs 3
tags : 
- Bible/Pr/3
- français
cssclass : français
---

# Proverbes 3

###### 1
Mon fils, n'oublie pas mon enseignement, et que ton cœur garde mes préceptes, 
###### 2
car ils augmenteront la durée de tes jours, tes années de vie et ton bien-être. 
###### 3
Que piété et fidélité ne te quittent! Fixe-les à ton cou, inscris-les sur la tablette de ton cœur. 
###### 4
Tu trouveras ainsi faveur et réussite aux regards de Dieu et des hommes. 
###### 5
Repose-toi sur Yahvé de tout ton cœur, ne t'appuie pas sur ton propre entendement; 
###### 6
en toutes tes démarches, reconnais-le et il aplanira tes sentiers. 
###### 7
Ne te figure pas être sage, crains Yahvé et te détourne du mal : 
###### 8
cela sera salutaire à ton corps et rafraîchissant pour tes os. 
###### 9
Honore Yahvé de tes biens et des prémices de tout ton revenu; 
###### 10
alors tes greniers regorgeront de blé et tes cuves déborderont de vin nouveau. 
###### 11
Ne méprise pas, mon fils, la correction de Yahvé, et ne prends pas mal sa réprimande, 
###### 12
car Yahvé reprend celui qu'il aime, comme un père le fils qu'il chérit. 
###### 13
Heureux l'homme qui a trouvé la sagesse, l'homme qui acquiert l'intelligence! 
###### 14
Car mieux vaut la gagner que gagner de l'argent, son revenu vaut mieux que de l'or. 
###### 15
Elle est précieuse plus que les perles, rien de ce que tu désires ne l'égale. 
###### 16
Dans sa droite : longueur des jours! Dans sa gauche : richesse et honneur! 
###### 17
Ses chemins sont chemins de délices, tous ses sentiers, de bonheur! 
###### 18
C'est un arbre de vie pour qui la saisit, et qui la tient devient heureux. 
###### 19
Yahvé, par la sagesse, a fondé la terre, il a établi les cieux par l'intelligence. 
###### 20
Par sa science furent creusés les abîmes, et les nues distillent la rosée. 
###### 21
Mon fils, sans les quitter des yeux, observe le conseil et la prudence; 
###### 22
ils seront vie pour ton âme et grâce pour ton cou. 
###### 23
Tu iras ton chemin en sécurité, ton pied n'achoppera pas. 
###### 24
Si tu te couches, tu seras sans frayeur, une fois couché, ton sommeil sera doux. 
###### 25
Ne redoute ni terreur soudaine ni attaque qui vienne des méchants, 
###### 26
car Yahvé sera ton assurance, il préservera tes pas du piège. 
###### 27
Ne refuse pas un bienfait à qui y a droit quand il est en ton pouvoir de le faire. 
###### 28
Ne dis pas à ton prochain : " Va-t'en! repasse! demain je te donnerai! " quand la chose est en ton pouvoir. 
###### 29
Ne machine pas le mal contre ton prochain, alors qu'il demeure en confiance avec toi. 
###### 30
Ne te querelle pas sans motif avec un homme, s'il ne t'a fait aucun mal. 
###### 31
N'envie pas l'homme violent, ne choisis jamais ses chemins, 
###### 32
car les pervers sont l'abomination de Yahvé, lui qui fait des hommes droits ses familiers. 
###### 33
Malédiction de Yahvé sur la maison du méchant! mais il bénit la demeure des justes. 
###### 34
Il raille les railleurs, mais aux pauvres il donne sa faveur. 
###### 35
La gloire est la part des sages, mais les sots héritent le mépris. 
