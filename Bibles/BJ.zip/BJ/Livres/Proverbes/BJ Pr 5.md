---
aliases : 
- Proverbes 5
- Proverbes 5
- Pr 5
- Proverbs 5
tags : 
- Bible/Pr/5
- français
cssclass : français
---

# Proverbes 5

###### 1
Mon fils, sois attentif à ma sagesse, prête l'oreille à mon intelligence, 
###### 2
pour suivre la prudence et que tes lèvres gardent le savoir. Ne prête pas attention à la femme perverse, 
###### 3
car les lèvres de l'étrangère distillent le miel et plus onctueux que l'huile est son palais; 
###### 4
mais à la fin elle est amère comme l'absinthe, aiguisée comme une épée à deux tranchants. 
###### 5
Ses pieds descendent à la mort, ses démarches gagnent le shéol; 
###### 6
loin de prendre les sentiers de la vie, sa marche est incertaine et elle ne le sait pas. 
###### 7
Et maintenant, fils, écoutez-moi, ne vous écartez pas des paroles de ma bouche : 
###### 8
loin d'elle, passe ton chemin, n'approche pas de l'entrée de sa maison, 
###### 9
de peur qu'elle ne livre ton honneur à autrui, tes années à un homme impitoyable, 
###### 10
que ton bien n'engraisse des étrangers, que le fruit de ton labeur n'aille à des inconnus, 
###### 11
et que sur ta fin, ton corps et ta chair consumés, tu ne rugisses 
###### 12
et ne t'écries : " Hélas, j'ai haï la discipline, mon cœur a dédaigné la remontrance; 
###### 13
je n'ai pas écouté la voix de mes maîtres, je n'ai pas prêté l'oreille à ceux qui m'instruisaient! 
###### 14
Peu s'en faut que je sois au comble du malheur, au milieu de l'assemblée et de la communauté! " 
###### 15
Bois l'eau de ta propre citerne, l'eau jaillissante de ton puits! 
###### 16
Tes fontaines s'écouleraient au dehors, tes ruisseaux sur les places publiques : 
###### 17
Qu'ils restent pour toi seul, et non pour des étrangers avec toi! 
###### 18
Bénie soit ta source! Trouve la joie dans la femme de ta jeunesse : 
###### 19
biche aimable, gracieuse gazelle! En tout temps que ses seins t'enivrent, sois toujours épris de son amour! 
###### 20
Pourquoi, mon fils, te laisser égarer par une étrangère et embrasser le sein d'une inconnue ? 
###### 21
Car les yeux de Yahvé observent les chemins de l'homme et surveillent tous ses sentiers. 
###### 22
Le méchant est pris à ses propres méfaits, dans les liens de son péché il est capturé. 
###### 23
Il mourra faute de discipline, par l'excès de sa folie il s'égarera. 
