---
aliases : 
- Proverbes 20
- Proverbes 20
- Pr 20
- Proverbs 20
tags : 
- Bible/Pr/20
- français
cssclass : français
---

# Proverbes 20

###### 1
Raillerie dans le vin! Insolence dans la boisson! Qui s'y égare n'est pas sage. 
###### 2
Tel le rugissement du lion, la colère du roi! Qui l'excite pèche contre lui-même. 
###### 3
C'est un honneur pour l'homme d'éviter les procès, mais quiconque est fou se déchaîne. 
###### 4
A l'automne, le paresseux ne laboure pas, à la moisson il cherche, et rien! 
###### 5
C'est une eau profonde que le conseil au cœur de l'homme, l'homme intelligent n'a qu'à puiser. 
###### 6
Beaucoup de gens se proclament hommes de bien, mais un homme fidèle, qui le trouvera ? 
###### 7
Le juste qui se conduit honnêtement, heureux ses enfants après lui! 
###### 8
Un roi siégeant au tribunal dissipe tout mal par son regard. 
###### 9
Qui peut dire : " J'ai purifié mon cœur, de mon péché je suis net " ? 
###### 10
Poids et poids, mesure et mesure : deux choses en horreur à Yahvé. 
###### 11
Même par ses actes un jeune homme se fait connaître, si son action est pure et si elle est droite. 
###### 12
L'oreille qui entend, l'œil qui voit, l'un et l'autre, Yahvé les a faits. 
###### 13
N'aime pas à somnoler, tu deviendrais pauvre; tiens les yeux ouverts, tu auras ton content de pain! 
###### 14
" Mauvais! Mauvais! " dit l'acheteur, mais en partant il se félicite. 
###### 15
Il y a l'or et toutes sortes de perles, mais la chose la plus précieuse ce sont les lèvres instruites. 
###### 16
Prends-lui son vêtement, car il a cautionné un étranger, au profit d'inconnus, prends-lui un gage! 
###### 17
Doux est à l'homme le pain de la fraude, mais ensuite la bouche est remplie de gravier. 
###### 18
Dans le conseil s'affermissent les projets : par de sages calculs conduis la guerre. 
###### 19
Il révèle les secrets, le colporteur de médisance; avec qui a toujours la bouche ouverte, ne te lie pas! 
###### 20
Qui maudit son père et sa mère verra s'éteindre sa lampe au cœur des ténèbres. 
###### 21
Le bien vite acquis au début ne sera pas béni à la fin. 
###### 22
Ne dis point : " Je rendrai le mal! " fie-toi à Yahvé qui te sauvera. 
###### 23
Abomination pour Yahvé : poids et poids; une balance fausse, ce n'est pas bien. 
###### 24
Yahvé dirige les pas de l'homme : comment l'homme comprendrait-il son chemin ? 
###### 25
C'est un piège pour l'homme de crier : " Ceci est sacré! " et, après les vœux, de réfléchir. 
###### 26
Un roi sage vanne les méchants et fait passer sur eux la roue. 
###### 27
La lampe de Yahvé, c'est l'esprit de l'homme qui pénètre jusqu'au tréfonds de son être. 
###### 28
Piété et fidélité montent la garde près du roi; sur la piété est fondé son trône. 
###### 29
La fierté des jeunes gens, c'est leur vigueur, la parure des vieillards, c'est leur tête chenue. 
###### 30
Les blessures sanglantes sont un remède à la méchanceté, les coups vont jusqu'au fond de l'être. 
