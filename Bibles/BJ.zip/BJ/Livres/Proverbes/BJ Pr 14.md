---
aliases : 
- Proverbes 14
- Proverbes 14
- Pr 14
- Proverbs 14
tags : 
- Bible/Pr/14
- français
cssclass : français
---

# Proverbes 14

###### 1
La Sagesse bâtit sa maison, de sa main, la Folie la renverse. 
###### 2
Qui marche dans sa droiture craint Yahvé, qui dévie de ses chemins le méprise. 
###### 3
Dans la bouche du fou il y a un surgeon d'orgueil, les lèvres des sages les gardent. 
###### 4
Point de bœufs, mangeoire vide; taureau vigoureux, revenus abondants. 
###### 5
Le témoin véridique ne ment pas, mais le faux témoin exhale le mensonge. 
###### 6
Le railleur poursuit la sagesse, mais en vain, à l'homme intelligent le savoir est chose aisée. 
###### 7
Écarte-toi du sot, tu ignorerais les lèvres savantes. 
###### 8
Pour l'homme avisé, la sagesse est de surveiller sa conduite, mais la folie des sots n'est que tromperie. 
###### 9
Les fous raillent le sacrifice pour le péché, mais parmi les hommes droits se trouve la faveur. 
###### 10
Le cœur connaît son propre chagrin et nul étranger ne partage sa joie. 
###### 11
La maison des méchants sera détruite, la tente des hommes droits prospérera. 
###### 12
Tel chemin paraît droit à quelqu'un, mais en fin de compte c'est le chemin de la mort. 
###### 13
Dans le rire même, le cœur trouve la peine, et la joie s'achève en chagrin. 
###### 14
Le cœur dévoyé se rassasie de ses démarches, et l'homme de bien de ses œuvres. 
###### 15
Le niais croit tout ce qu'on dit, l'homme avisé surveille ses pas. 
###### 16
Le sage craint le mal et se détourne, le sot est insolent et sûr de lui. 
###### 17
L'homme prompt à la colère fait des sottises, l'homme malintentionné est odieux. 
###### 18
La part des niais, c'est la folie, les gens avisés se font du savoir une couronne. 
###### 19
Devant les bons, les méchants se prosternent, et aux portes des justes, les impies. 
###### 20
Même à son voisin, le pauvre est odieux, mais nombreux sont ceux qui aiment le riche. 
###### 21
Il pèche, celui qui méprise son prochain; heureux qui a pitié des pauvres. 
###### 22
N'est-ce pas s'égarer que machiner le mal ? Miséricorde et fidélité pour qui s'applique au bien. 
###### 23
Tout labeur donne du profit, le bavardage ne produit que disette. 
###### 24
Couronne des sages : leur richesse; la folie des sots est folie. 
###### 25
Un témoin véridique sauve des vies, qui profère des mensonges est un imposteur. 
###### 26
Dans la crainte de Yahvé, puissante sécurité; pour ses enfants il est un refuge. 
###### 27
La crainte de Yahvé est source de vie pour éviter les pièges de la mort. 
###### 28
Peuple nombreux, gloire du roi; baisse de population, ruine du prince. 
###### 29
L'homme lent à la colère est plein d'intelligence, qui a l'humeur prompte exalte la folie. 
###### 30
Vie du corps : un cœur paisible; mais l'envie est carie des os. 
###### 31
Opprimer le faible, c'est outrager son Créateur; c'est l'honorer que d'être bon pour les malheureux. 
###### 32
Par sa propre malice le méchant est terrassé, le juste trouve un refuge dans son intégrité. 
###### 33
En un cœur intelligent demeure la sagesse; on ne la reconnaît pas au cœur des sots. 
###### 34
La justice grandit une nation, le péché est la honte des peuples. 
###### 35
La faveur du roi va au serviteur intelligent et sa colère à celui qui fait honte. 
