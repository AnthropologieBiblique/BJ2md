---
aliases : 
- Proverbes 22
- Proverbes 22
- Pr 22
- Proverbs 22
tags : 
- Bible/Pr/22
- français
cssclass : français
---

# Proverbes 22

###### 1
Le renom l'emporte sur de grandes richesses, la faveur, sur l'or et l'argent. 
###### 2
Riche et pauvre se rencontrent, Yahvé les a faits tous les deux. 
###### 3
L'homme avisé voit le malheur et se cache, les niais passent outre, à leurs dépens. 
###### 4
Le fruit de l'humilité, c'est la crainte de Yahvé, la richesse, l'honneur et la vie. 
###### 5
Épines et pièges sur le chemin du pervers, qui tient à la vie s'en éloigne. 
###### 6
Instruis le jeune homme selon ses dispositions, devenu vieux, il ne s'en détournera pas. 
###### 7
Le riche domine les pauvres, du créancier l'emprunteur est esclave. 
###### 8
Qui sème l'injustice récolte le malheur et le bâton de sa colère disparaîtra. 
###### 9
L'homme bienveillant sera béni, car il donne de son pain au pauvre. 
###### 10
Chasse le railleur et la querelle cessera, procès et mépris s'apaiseront. 
###### 11
Celui qui aime les cœurs purs, qui a la grâce sur les lèvres, a le roi pour ami. 
###### 12
Les yeux de Yahvé protègent le savoir, mais il confond les discours du traître. 
###### 13
Le paresseux dit : " Il y a un lion dehors! dans la rue je vais être tué! " 
###### 14
Fosse profonde, la bouche des étrangères : celui que Yahvé réprouve y tombe. 
###### 15
La folie est ancrée au cœur du jeune homme, le fouet de l'instruction l'en délivre. 
###### 16
Opprimer un pauvre, c'est l'enrichir, donner au riche, c'est l'appauvrir. 
###### 17
Prête l'oreille, entends les paroles des sages, à mon savoir, applique ton cœur, 
###### 18
car il y aura plaisir à les garder au-dedans de toi, à les avoir toutes assurées sur tes lèvres. 
###### 19
Pour qu'en Yahvé soit ta confiance, je veux t'instruire aujourd'hui, toi aussi. 
###### 20
N'ai-je pas écrit pour toi trente chapitres de conseils et de science, 
###### 21
pour te faire connaître la certitude des paroles vraies et que tu rapportes des paroles sûres à qui t'enverra ? 
###### 22
Ne dépouille pas le faible, car il est faible, et n'opprime pas à la porte le pauvre, 
###### 23
car Yahvé épouse leur querelle et ravit à leurs ravisseurs la vie. 
###### 24
Ne te lie pas avec un homme emporté, ne va pas avec un homme irascible, 
###### 25
de peur que tu n'apprennes ses manières et n'y trouves un piège pour ta vie. 
###### 26
Ne sois pas de ceux qui topent dans la main, qui se portent garants pour dettes; 
###### 27
si tu n'as pas de quoi t'acquitter, on prendra ton lit de dessous toi. 
###### 28
Ne déplace pas la borne antique que posèrent tes pères. 
###### 29
Vois-tu un homme preste à sa besogne ? au service des rois il se tiendra. il ne se tiendra pas au service des gens obscurs. 
