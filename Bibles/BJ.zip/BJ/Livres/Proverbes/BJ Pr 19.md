---
aliases : 
- Proverbes 19
- Proverbes 19
- Pr 19
- Proverbs 19
tags : 
- Bible/Pr/19
- français
cssclass : français
---

# Proverbes 19

###### 1
Mieux vaut le pauvre qui se conduit honnêtement que l'homme aux lèvres tortueuses et qui n'est qu'un sot. 
###### 2
Où manque le savoir, le zèle n'est pas bon, qui presse le pas se fourvoie. 
###### 3
La folie de l'homme pervertit sa conduite et c'est contre Yahvé que son cœur s'emporte. 
###### 4
La richesse multiplie les amis, mais de son ami le pauvre est privé. 
###### 5
Le faux témoin ne restera pas impuni, qui profère des mensonges n'échappera point. 
###### 6
Beaucoup flattent en face l'homme généreux, tout le monde est ami de celui qui donne. 
###### 7
Tous les frères du pauvre le haïssent, à plus forte raison, ses amis s'éloignent-ils de lui. Il se met en quête de paroles, mais point! 
###### 8
Qui acquiert du sens se chérit lui-même, qui garde l'intelligence trouve le bonheur. 
###### 9
Le faux témoin ne restera pas impuni, qui profère des mensonges périra. 
###### 10
Il ne sied pas au sot de vivre dans le luxe, moins encore à l'esclave de dominer les princes. 
###### 11
Le bon sens rend l'homme lent à la colère, sa fierté, c'est de passer sur une offense. 
###### 12
Comme le rugissement du lion, la fureur du roi, mais comme la rosée sur l'herbe, sa faveur. 
###### 13
C'est une calamité pour son père qu'un fils insensé, une gargouille qui ne cesse de couler que les querelles d'une femme. 
###### 14
Une maison et du bien sont l'héritage paternel, mais c'est Yahvé qui donne une femme de sens. 
###### 15
La paresse fait choir dans la torpeur, l'âme nonchalante aura faim. 
###### 16
A garder le commandement on se garde soi-même, mais qui méprise ses voies mourra. 
###### 17
Qui fait la charité au pauvre prête à Yahvé qui paiera le bienfait de retour. 
###### 18
Tant qu'il y a de l'espoir, châtie ton fils, mais ne t'emporte pas jusqu'à le faire mourir. 
###### 19
L'homme violent s'expose à l'amende; si tu l'épargnes, tu augmentes son mal. 
###### 20
Entends le conseil, accepte la discipline pour être sage à la fin. 
###### 21
Nombreux sont les projets au cœur de l'homme, mais le dessein de Yahvé, lui, reste ferme. 
###### 22
Ce qu'on souhaite, chez l'homme, c'est la miséricorde; on aime mieux un pauvre qu'un menteur. 
###### 23
La crainte de Yahvé mène à la vie, on a vivre et couvert sans craindre le malheur. 
###### 24
Le paresseux plonge la main dans le plat, mais ne peut même pas la ramener à sa bouche. 
###### 25
Frappe le railleur, et le niais deviendra avisé; reprends un homme intelligent, il comprendra le savoir. 
###### 26
Qui maltraite son père et chasse sa mère est un fils indigne et infâme. 
###### 27
Cesse, mon fils, d'écouter l'instruction pour t'écarter des paroles de science! 
###### 28
Un témoin indigne se moque du droit; la bouche des méchants avale l'iniquité. 
###### 29
Les châtiments sont faits pour les railleurs, les coups pour l'échine des sots. 
