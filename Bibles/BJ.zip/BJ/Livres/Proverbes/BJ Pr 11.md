---
aliases : 
- Proverbes 11
- Proverbes 11
- Pr 11
- Proverbs 11
tags : 
- Bible/Pr/11
- français
cssclass : français
---

# Proverbes 11

###### 1
La balance fausse est une abomination pour Yahvé, mais le poids juste a sa faveur. 
###### 2
Vienne l'insolence, viendra le mépris, mais chez les humbles se trouve la sagesse. 
###### 3
Leur honnêteté conduit les hommes droits, leur perversité mène les traîtres à la ruine. 
###### 4
Au jour de la fureur, la richesse sera inutile, mais la justice délivre de la mort. 
###### 5
La justice de l'homme honnête rend droit son chemin, le méchant succombe dans sa méchanceté. 
###### 6
Leur justice sauve les hommes droits, dans leur convoitise les traîtres sont pris. 
###### 7
L'espérance du méchant périt à sa mort, l'espoir mis dans les richesses est anéanti. 
###### 8
Le juste échappe à l'angoisse, le méchant y vient à sa place. 
###### 9
Par sa bouche l'impie ruine son prochain, par le savoir les justes se tirent d'affaire. 
###### 10
Au bonheur des justes, la cité exulte, à la perte des méchants, c'est un cri de joie. 
###### 11
Par la bénédiction des hommes droits s'élève une ville, par la bouche des méchants, elle est démolie. 
###### 12
Qui méprise son prochain est privé de sens; l'homme intelligent se tait. 
###### 13
C'est un colporteur de médisance, celui qui révèle les secrets, c'est un esprit sûr, celui qui cache l'affaire. 
###### 14
Faute de direction un peuple succombe, le succès tient au grand nombre de conseillers. 
###### 15
Celui qui cautionne l'étranger se fait du tort, qui répugne à toper est en sécurité. 
###### 16
Une femme gracieuse acquiert de l'honneur, les violents acquièrent la richesse. 
###### 17
L'homme miséricordieux fait du bien à soi-même, mais un homme intraitable afflige sa propre chair. 
###### 18
Le méchant accomplit un travail décevant, à qui sème la justice, la récompense est assurée. 
###### 19
Qui établit la justice va à la vie, qui poursuit le mal, à la mort. 
###### 20
Abomination pour Yahvé : les cœurs tortueux; il aime ceux dont la conduite est honnête. 
###### 21
A coup sûr, le méchant ne restera pas impuni, mais la race des justes sera sauve. 
###### 22
Un anneau d'or au groin d'un pourceau : une femme belle mais dépourvue de sens. 
###### 23
Le souhait des justes, ce n'est que le bien, l'espoir des méchants, c'est la colère. 
###### 24
Tel est prodigue et sa richesse s'accroît, tel amasse sans mesure et ne fait que s'appauvrir. 
###### 25
L'âme qui bénit prospérera, et qui abreuve sera abreuvé. 
###### 26
Le peuple maudit l'accapareur de blé, bénédiction sur la tête de celui qui le vend. 
###### 27
Qui vise le bien obtient la faveur, qui poursuit le mal, celui-ci l'atteindra. 
###### 28
Qui se fie en la richesse tombera, mais les justes pousseront comme le feuillage. 
###### 29
Qui laisse sa maison en désordre hérite le vent, et le fou devient esclave du sage. 
###### 30
Le fruit du juste est un arbre de vie; le sage captive les âmes. 
###### 31
Si le juste ici-bas reçoit son salaire, combien plus le méchant et le pécheur. 
