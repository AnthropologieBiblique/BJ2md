---
aliases : 
- Proverbes 4
- Proverbes 4
- Pr 4
- Proverbs 4
tags : 
- Bible/Pr/4
- français
cssclass : français
---

# Proverbes 4

###### 1
Écoutez, mes fils, l'instruction d'un père, soyez attentifs à connaître l'intelligence. 
###### 2
Car c'est une bonne doctrine que je vous livre : n'abandonnez pas mon enseignement. 
###### 3
Je fus un fils pour mon père, tendre et unique aux yeux de ma mère. 
###### 4
Or il m'enseignait en ces termes : " Que ton cœur retienne mes paroles, observe mes préceptes et tu vivras; 
###### 5
acquiers la sagesse, acquiers l'intelligence, ne l'oublie pas et ne t'écarte pas des paroles de ma bouche. 
###### 6
Ne l'abandonne pas, elle te gardera, aime-la, elle veillera sur toi. 
###### 7
Commencement de la sagesse : acquiers la sagesse; au prix de tout ce que tu possèdes, acquiers l'intelligence! 
###### 8
Étreins-la et elle t'élèvera, elle fera ta gloire si tu l'embrasses; 
###### 9
sur ta tête elle posera un diadème de grâce, elle t'offrira une couronne d'honneur. " 
###### 10
Écoute, mon fils, accueille mes paroles, et les années de ta vie se multiplieront. 
###### 11
Dans la voie de la sagesse je t'ai enseigné, je t'ai fait cheminer sur la piste de la droiture. 
###### 12
Dans ta marche tes pas seront sans contrainte, si tu cours, tu ne trébucheras pas. 
###### 13
Saisis la discipline, ne la lâche pas, garde-la, c'est ta vie. 
###### 14
Ne suis pas le sentier des méchants, ne t'avance pas sur le chemin des mauvais. 
###### 15
Évite-le, n'y passe pas, détourne-toi, passe outre. 
###### 16
Car ils ne s'endorment pas qu'ils n'aient fait le mal, le sommeil leur manque s'ils n'ont fait trébucher quelqu'un; 
###### 17
car ils mangent un pain de méchanceté et boivent le vin des violents. 
###### 18
La route des justes est comme la lumière de l'aube, dont l'éclat grandit jusqu'au plein jour; 
###### 19
le chemin des méchants est comme l'obscurité : ils ne savent sur quoi ils trébuchent. 
###### 20
Mon fils, sois attentif à mes paroles, à mes discours prête l'oreille! 
###### 21
qu'ils n'échappent pas à tes regards, au fond du cœur garde-les! 
###### 22
Car pour qui les trouve ils sont vie et santé pour toute chair. 
###### 23
Plus que sur toute chose, veille sur ton cœur, c'est de lui que jaillit la vie. 
###### 24
Écarte loin de toi la bouche perverse, et les lèvres trompeuses, éloigne-les. 
###### 25
Que tes yeux regardent en face, que tes regards se dirigent droit devant toi. 
###### 26
Aplanis la piste sous tes pas et que tous tes chemins soient bien affermis. 
###### 27
Ne dévie ni à droite ni à gauche, écarte ton pied du mal. 
