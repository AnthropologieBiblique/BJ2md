---
aliases : 
- Proverbes 23
- Proverbes 23
- Pr 23
- Proverbs 23
tags : 
- Bible/Pr/23
- français
cssclass : français
---

# Proverbes 23

###### 1
Si tu t'assieds à la table d'un grand, prends bien garde à ce qui est devant toi; 
###### 2
mets un couteau sur ta gorge si tu es gourmand. 
###### 3
Ne convoite pas ses mets, car c'est une nourriture décevante. 
###### 4
Ne te fatigue pas à acquérir la richesse, cesse d'y appliquer ton intelligence. 
###### 5
Lèves-tu les yeux vers elle, elle n'est plus là, car elle sait se faire des ailes comme l'aigle qui vole vers le ciel. 
###### 6
Ne mange pas le pain de l'homme aux regards envieux, ne convoite pas ses mets. 
###### 7
Car le calcul qu'il fait en lui-même, c'est lui : " Mange et bois! " te dit-il, mais son cœur n'est pas avec toi. 
###### 8
La bouchée à peine avalée, tu la vomiras et tu en seras pour tes paroles flatteuses. 
###### 9
Aux oreilles du sot ne parle pas, il mépriserait la finesse de tes propos. 
###### 10
Ne déplace pas la borne antique, dans le champ des orphelins n'entre pas, 
###### 11
car leur vengeur est puissant, c'est lui qui épousera, contre toi, leur querelle. 
###### 12
Applique ton cœur à la discipline, tes oreilles aux paroles de science. 
###### 13
Ne ménage pas à l'enfant la correction, si tu le frappes de la baguette, il n'en mourra pas! 
###### 14
Si tu le frappes de la baguette, c'est son âme que tu délivreras du shéol. 
###### 15
Mon fils, si ton cœur est sage, mon cœur, à moi, se réjouira, 
###### 16
et mes reins exulteront quand tes lèvres exprimeront des choses justes. 
###### 17
Que ton cœur n'envie pas les pécheurs, mais dans la crainte de Yahvé qu'il reste tout le jour, 
###### 18
car il existe un avenir et ton espérance ne sera pas anéantie. 
###### 19
Écoute, mon fils, deviens sage, et dirige ton cœur dans le chemin. 
###### 20
Ne sois pas de ceux qui s'enivrent de vin, ni de ceux qui se gavent de viande, 
###### 21
car buveur et glouton s'appauvrissent, et la torpeur fait porter des haillons. 
###### 22
Écoute ton père qui t'a engendré, ne méprise pas ta mère devenue vieille. 
###### 23
Acquiers la vérité, ne la vends pas : sagesse, discipline et intelligence. 
###### 24
Il est au comble de l'allégresse, le père du juste; celui qui a donné le jour au sage s'en réjouit. 
###### 25
Ton père et ta mère seront dans la joie, et dans l'allégresse, celle qui t'a enfanté. 
###### 26
Mon fils, prête-moi attention, que tes yeux se complaisent dans ma voie : 
###### 27
c'est une fosse profonde que la prostituée, un puits étroit que l'étrangère. 
###### 28
Elle aussi, comme un brigand, est en embuscade, parmi les hommes elle multiplie les traîtres. 
###### 29
Pour qui les " Malheur " ? pour qui les " Hélas " ? pour qui les querelles ? pour qui les plaintes ? pour qui les coups à tort et à travers ? pour qui les yeux troubles ? 
###### 30
Pour ceux qui s'attardent au vin, qui vont en quête de boissons mêlées. 
###### 31
Ne regarde pas le vin, comme il est vermeil! comme il brille dans la coupe! comme il coule tout droit! 
###### 32
Il finit par mordre comme un serpent, par piquer comme une vipère. 
###### 33
Tes yeux verront d'étranges choses, ton cœur s'exprimera de travers. 
###### 34
Tu seras comme un homme couché en haute mer, ou couché à la pointe d'un mât, 
###### 35
" On m'a battu, je n'ai point de mal! On m'a rossé, je n'ai rien senti! Quand m'éveillerai-je ?... J'en demanderai encore! " 
