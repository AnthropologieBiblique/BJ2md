---
aliases : 
- Proverbes 7
- Proverbes 7
- Pr 7
- Proverbs 7
tags : 
- Bible/Pr/7
- français
cssclass : français
---

# Proverbes 7

###### 1
Mon fils, garde mes paroles, conserve chez toi mes préceptes. 
###### 2
Garde mes préceptes et tu vivras, que mon enseignement soit comme la pupille de tes yeux. 
###### 3
Fixe-les à tes doigts, inscris-les sur la tablette de ton cœur. 
###### 4
Dis à la sagesse : " Tu es ma sœur! " donne le nom de parente à l'intelligence, 
###### 5
pour te garder de la femme étrangère, de l'inconnue aux paroles doucereuses. 
###### 6
Comme j'étais à la fenêtre de ma demeure, j'ai regardé par le treillis 
###### 7
et j'ai vu, parmi de jeunes niais, j'ai remarqué parmi des enfants un garçon privé de sens. 
###### 8
Passant par la venelle, près du coin où elle est, il gagne le chemin de sa maison, 
###### 9
à la brune, au tomber du jour au cœur de la nuit et de l'ombre. 
###### 10
Et voici qu'une femme vient à sa rencontre, vêtue comme une prostituée, la fausseté au cœur. 
###### 11
Elle est hardie et insolente; ses pieds ne peuvent tenir à la maison. 
###### 12
Tantôt dans la rue, tantôt sur les places, à tous les coins elle se tient aux aguets. 
###### 13
Elle le saisit et l'embrasse et d'un air effronté lui dit : 
###### 14
" J'avais à offrir un sacrifice de communion, j'ai accompli mes vœux aujourd'hui, 
###### 15
voilà pourquoi je suis sortie à ta rencontre pour te chercher, et je t'ai trouvé. 
###### 16
J'ai recouvert mon divan de couvertures, de tissus brodés, d'étoffe d'Égypte, 
###### 17
j'ai aspergé ma couche de myrrhe, d'aloès et de cinnamome. 
###### 18
Viens! Enivrons-nous d'amour jusqu'au matin! Jouissons dans la volupté! 
###### 19
Car il n'y a point de mari à la maison : il est parti pour un lointain voyage, 
###### 20
il a emporté le sac aux écus, à la pleine lune il reviendra chez lui. 
###### 21
A force de persuasion elle le séduit, par le charme doucereux de ses lèvres elle l'entraîne. 
###### 22
Aussitôt il la suit, tel un bœuf qui va à l'abattoir, tel un fou marchant au supplice des entraves, 
###### 23
jusqu'à ce qu'un trait lui perce le foie, tel l'oiseau qui se précipite dans le filet sans savoir qu'il y va de sa vie. 
###### 24
A présent, fils, écoutez-moi, prêtez attention aux paroles de ma bouche : 
###### 25
Que ton cœur ne dévie pas vers ses chemins, ne t'égare pas dans ses sentiers, 
###### 26
car nombreux sont ceux qu'elle a frappés à mort et les plus robustes furent tous ses victimes. 
###### 27
Sa demeure est le chemin du shéol, la pente vers le parvis des morts. 
