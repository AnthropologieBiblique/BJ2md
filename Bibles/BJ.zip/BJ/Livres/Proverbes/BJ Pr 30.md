---
aliases : 
- Proverbes 30
- Proverbes 30
- Pr 30
- Proverbs 30
tags : 
- Bible/Pr/30
- français
cssclass : français
---

# Proverbes 30

###### 1
Paroles d'Agur, fils de Yaqé, de Massa. Oracle de cet homme pour Itéel, pour Itéel et pour Ukal. 
###### 2
Oui, je suis le plus stupide des hommes, sans aucune intelligence humaine, 
###### 3
je n'ai pas appris la sagesse et j'ignore la science des saints. 
###### 4
Qui est monté au ciel et puis en est descendu ? qui dans ses poings a recueilli le vent ? qui dans son manteau a serré les eaux ? qui a affermi toutes les extrémités de la terre ? Quel est son nom ? quel est le nom de son fils, si tu le sais ? 
###### 5
Toute parole de Dieu est éprouvée, il est un bouclier pour qui s'abrite en lui. 
###### 6
A ses discours, n'ajoute rien, de crainte qu'il ne te reprenne et ne te tienne pour un menteur. 
###### 7
J'implore de toi deux choses, ne les refuse pas avant que je meure : 
###### 8
éloigne de moi fausseté et paroles mensongères, ne me donne ni pauvreté ni richesse, laisse-moi goûter ma part de pain, 
###### 9
de crainte que, comblé, je ne me détourne et ne dise : " Qui est Yahvé ? " ou encore, qu'indigent, je ne vole et ne profane le nom de mon Dieu. 
###### 10
Ne dénigre pas un esclave près de son maître, de crainte qu'il ne te maudisse et que tu n'en portes la peine. 
###### 11
Engeance qui maudit son père et ne bénit pas sa mère, 
###### 12
engeance pure à ses propres yeux, mais dont la souillure n'est pas effacée, 
###### 13
engeance aux regards altiers et aux paupières hautaines, 
###### 14
engeance dont les dents sont des épées, les mâchoires, des couteaux, pour dévorer les pauvres et les retrancher du pays, et les malheureux, d'entre les hommes. 
###### 15
La sangsue a deux filles : " Apporte! Apporte! " Il y a trois choses insatiables et quatre qui jamais ne disent : " Assez! " : 
###### 16
le shéol, le sein stérile, la terre que l'eau ne peut rassasier, le feu qui jamais ne dit : " Assez! " 
###### 17
L'œil qui nargue un père et méprise l'obéissance due à une mère, les corbeaux du torrent le crèveront, les aigles le dévoreront. 
###### 18
Il est trois choses qui me dépassent et quatre que je ne connais pas : 
###### 19
le chemin de l'aigle dans les cieux, le chemin du serpent sur le rocher, le chemin du vaisseau en haute mer, le chemin de l'homme chez la jeune femme. 
###### 20
Telle est la conduite de la femme adultère : elle mange, puis s'essuie la bouche en disant : " Je n'ai rien fait de mal! " 
###### 21
Sous trois choses tremble la terre et il en est quatre qu'elle ne peut porter : 
###### 22
un esclave qui devient roi, une brute gorgée de nourriture, 
###### 23
une fille odieuse qui vient à se marier, une servante qui hérite de sa maîtresse. 
###### 24
Il est quatre êtres minuscules sur la terre, mais sages entre les sages : 
###### 25
les fourmis, peuple chétif, mais qui, en été, assure sa provende; 
###### 26
les damans, peuple sans vigueur, mais qui gîtent dans les rochers; 
###### 27
chez les sauterelles, point de roi! mais elles marchent toutes en bon ordre; 
###### 28
le lézard que l'on capture à la main, mais qui hante les palais du roi. 
###### 29
Trois choses ont une belle allure et quatre une belle démarche : 
###### 30
le lion, le plus brave des animaux, qui ne recule devant rien; 
###### 31
le coq bien râblé, ou le bouc, et le roi, quand il harangue le peuple. 
###### 32
Si tu fus assez sot pour t'emporter et si tu as réfléchi, mets la main sur ta bouche! 
###### 33
Car en pressant le lait, on obtient le beurre, en pressant le nez, on obtient le sang, en pressant la colère, on obtient la querelle. 
