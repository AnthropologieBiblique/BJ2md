---
aliases : 
- Proverbes 21
- Proverbes 21
- Pr 21
- Proverbs 21
tags : 
- Bible/Pr/21
- français
cssclass : français
---

# Proverbes 21

###### 1
Comme l'eau courante, le cœur du roi est aux mains de Yahvé qui l'incline partout à son gré. 
###### 2
Toutes les voies de l'homme sont droites à ses yeux, mais Yahvé pèse les cœurs. 
###### 3
Pratiquer la justice et le droit vaut, pour Yahvé, mieux que le sacrifice. 
###### 4
Regards altiers, cœur dilaté, flambeau des méchants, ce n'est que péché. 
###### 5
Les projets de l'homme diligent ne sont que profit; pour qui se presse, rien que la disette! 
###### 6
Amasser des trésors par une langue menteuse : vanité fugitive de qui cherche la mort. 
###### 7
La violence des méchants les emporte, car ils refusent de pratiquer le droit. 
###### 8
Tortueuse est la voie de l'homme criminel, mais de l'innocent l'action est droite. 
###### 9
Mieux vaut habiter à l'angle d'un toit que faire maison commune avec une femme querelleuse. 
###### 10
L'âme du méchant souhaite le mal, à ses yeux le prochain ne trouve pas grâce. 
###### 11
Quand on châtie le railleur, le niais s'assagit; quand on instruit le sage, il accueille le savoir. 
###### 12
Le Juste considère la maison du méchant : il précipite les méchants dans le malheur. 
###### 13
Qui ferme l'oreille à l'appel du faible criera, lui aussi, sans qu'on lui réponde. 
###### 14
Un don secret apaise la colère, un présent sous le manteau, la fureur violente. 
###### 15
C'est une joie pour le juste de pratiquer le droit, mais c'est l'épouvante pour les malfaisants. 
###### 16
Qui s'égare loin du chemin de la prudence dans l'assemblée des ombres reposera. 
###### 17
Restera indigent qui aime le plaisir, point ne s'enrichira qui aime vin et bonne chère. 
###### 18
Le méchant est la rançon du juste; à la place des hommes droits : le traître. 
###### 19
Mieux vaut habiter en un pays désert qu'avec une femme querelleuse et chagrine. 
###### 20
Il y a un trésor précieux et de l'huile dans la demeure du sage, mais le sot les engloutit. 
###### 21
Qui poursuit la justice et la miséricorde trouvera vie, justice et honneur. 
###### 22
Le sage escalade la ville des guerriers, il abat le rempart dans lequel elle se confiait. 
###### 23
A garder sa bouche et sa langue, on se garde soi-même de l'angoisse. 
###### 24
Insolent, hautain, son nom est " railleur "! il agit dans l'excès de son insolence. 
###### 25
Le désir du paresseux cause sa mort, car ses mains refusent le travail. 
###### 26
Tout le jour l'impie est en proie au désir, le juste donne sans jamais refuser. 
###### 27
Le sacrifice des méchants est une abomination, surtout s'ils l'offrent avec malice. 
###### 28
Le faux témoin périra, mais qui sait écouter parlera à jamais. 
###### 29
Le méchant se donne un air assuré, l'homme droit affermit sa propre conduite. 
###### 30
Il n'y a ni sagesse, ni intelligence, ni conseil devant Yahvé. 
###### 31
On équipe le cheval pour le jour du combat, mais c'est à Yahvé qu'appartient la victoire. 
