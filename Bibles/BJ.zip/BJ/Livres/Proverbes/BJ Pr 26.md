---
aliases : 
- Proverbes 26
- Proverbes 26
- Pr 26
- Proverbs 26
tags : 
- Bible/Pr/26
- français
cssclass : français
---

# Proverbes 26

###### 1
Pas plus que la neige à l'été ou la pluie à la moisson, les honneurs ne conviennent au sot. 
###### 2
Le passereau s'échappe, l'hirondelle s'envole, ainsi la malédiction gratuite n'atteint pas son but. 
###### 3
Le fouet pour le cheval, la bride pour l'âne, pour l'échine des sots, le bâton. 
###### 4
Ne réponds pas à l'insensé selon sa folie, de peur de lui devenir semblable, toi aussi. 
###### 5
Réponds à l'insensé selon sa folie, de peur qu'il ne soit sage à ses propres yeux. 
###### 6
Il se mutile, il s'abreuve de violence, celui qui envoie un message par l'entremise d'un sot. 
###### 7
Mal assurées, les jambes du boiteux; ainsi un proverbe dans la bouche des sots. 
###### 8
C'est attacher la pierre à la fronde que de rendre honneur à un sot. 
###### 9
Une ronce pousse dans la main d'un ivrogne comme un proverbe dans la bouche d'un sot. 
###### 10
Un archer blessant tout le monde : tel est celui qui embauche le sot et l'ivrogne qui passent. 
###### 11
Comme le chien revient à son vomissement, le sot retourne à sa folie. 
###### 12
Tu vois un homme sage à ses propres yeux ? Il y a plus à espérer d'un insensé. 
###### 13
Le paresseux dit : " Un fauve sur le chemin! un lion par les rues! " 
###### 14
La porte tourne sur ses gonds, et sur son lit le paresseux. 
###### 15
Le paresseux plonge la main dans le plat : la ramener à sa bouche le fatigue! 
###### 16
Le paresseux est plus sage à ses propres yeux que sept personnes répondant avec tact. 
###### 17
Il prend par les oreilles un chien qui passe, celui qui s'immisce dans une querelle étrangère. 
###### 18
Un homme pris de folie qui lance des traits enflammés, des flèches et la mort : 
###### 19
tel est l'homme qui ment à son compagnon, puis dit : " N'était-ce pas pour plaisanter ? " 
###### 20
Faute de bois, le feu s'éteint, faute de calomniateur, la querelle s'apaise. 
###### 21
Du charbon sur les braises, du bois sur le feu, tel est l'homme querelleur pour attiser les disputes. 
###### 22
Les dires du calomniateur sont de friands morceaux qui descendent jusqu'au fond des entrailles. 
###### 23
De l'argent non purifié appliqué sur de l'argile : tels sont lèvres brûlantes et cœur mauvais. 
###### 24
Celui qui hait donne le change par ses propos, mais en son sein gît la tromperie; 
###### 25
s'il prend un ton cauteleux, ne t'y fie pas, car en son cœur il y a sept abominations. 
###### 26
La haine peut s'envelopper de ruse, elle révélera sa méchanceté dans l'assemblée. 
###### 27
Qui creuse une fosse y tombe, qui roule une roche, elle revient sur lui. 
###### 28
La langue menteuse hait ses victimes, la bouche enjôleuse provoque la chute. 
