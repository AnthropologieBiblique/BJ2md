---
aliases : 
- Proverbes 31
- Proverbes 31
- Pr 31
- Proverbs 31
tags : 
- Bible/Pr/31
- français
cssclass : français
---

# Proverbes 31

###### 1
Paroles de Lemuel, roi de Massa, que sa mère lui apprit. 
###### 2
Quoi, mon fils! quoi, fils de mes entrailles! quoi, fils de mes vœux! 
###### 3
Ne livre pas ta vigueur aux femmes, ni tes voies à celles qui perdent les rois. 
###### 4
Il ne convient pas aux rois, Lemuel, il ne convient pas aux rois de boire du vin, ni aux princes d'aimer la boisson, 
###### 5
de crainte qu'en buvant ils n'oublient ce qui est décrété et qu'il ne faussent la cause de tous les pauvres. 
###### 6
Procure des boissons fortes à qui va mourir, du vin à qui est rempli d'amertume; 
###### 7
qu'il boive, qu'il oublie sa misère, qu'il ne se souvienne plus de son malheur! 
###### 8
Ouvre la bouche en faveur du muet, pour la cause de tous les abandonnés; 
###### 9
ouvre la bouche, juge avec justice, défends la cause du pauvre et du malheureux. 
###### 10
Une maîtresse femme, qui la trouvera ? Elle a bien plus de prix que les perles! 
###### 11
En elle se confie le cœur de son mari, il ne manque pas d'en tirer profit. 
###### 12
Elle fait son bonheur et non son malheur, tous les jours de sa vie. 
###### 13
Elle cherche laine et lin et travaille d'une main allègre. 
###### 14
Elle est pareille à des vaisseaux marchands : de loin, elle amène ses vivres. 
###### 15
Il fait encore nuit qu'elle se lève, distribuant à sa maisonnée la pitance, et des ordres à ses servantes. 
###### 16
A-t-elle en vue un champ, elle l'acquiert; du produit de ses mains, elle plante une vigne. 
###### 17
Elle ceint vigoureusement ses reins et déploie la force de ses bras. 
###### 18
Elle sait que ses affaires vont bien, de la nuit, sa lampe ne s'éteint. 
###### 19
Elle met la main à la quenouille, ses doigts prennent le fuseau. 
###### 20
Elle étend les mains vers le pauvre, elle tend les bras aux malheureux. 
###### 21
Elle ne redoute pas la neige pour sa maison, car toute sa maisonnée porte double vêtement. 
###### 22
Elle se fait des couvertures, de lin et de pourpre est son vêtement. . 
###### 23
Aux portes de la ville, son mari est connu, il siège parmi les anciens du pays. 
###### 24
Elle tisse des étoffes et les vend, au marchand elle livre une ceinture. 
###### 25
Force et dignité forment son vêtement, elle rit au jour à venir. 
###### 26
Avec sagesse elle ouvre la bouche, sur sa langue : une doctrine de piété. 
###### 27
De sa maisonnée, elle surveille le va-et-vient, elle ne mange pas le pain de l'oisiveté. 
###### 28
Ses fils se lèvent pour la proclamer bienheureuse, son mari, pour faire son éloge : 
###### 29
" Nombre de femmes ont accompli des exploits, mais toi, tu les surpasses toutes! " 
###### 30
Tromperie que la grâce! Vanité, la beauté! La femme qui craint Yahvé, voilà celle qu'il faut féliciter! 
###### 31
Accordez-lui une part du produit de ses mains, et qu'aux portes ses œuvres fassent son éloge! 
