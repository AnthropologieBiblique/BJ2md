---
aliases : 
- Proverbes 8
- Proverbes 8
- Pr 8
- Proverbs 8
tags : 
- Bible/Pr/8
- français
cssclass : français
---

# Proverbes 8

###### 1
La Sagesse n'appelle-t-elle pas ? l'Intelligence n'élève-t-elle pas la voix ? 
###### 2
Au sommet des hauteurs qui dominent la route, au croisement des chemins, elle se poste; 
###### 3
près des portes, à l'entrée de la cité, sur les voies d'accès, elle s'écrie : 
###### 4
" Humains! C'est vous que j'appelle, ma voix s'adresse aux enfants des hommes. 
###### 5
Simples! apprenez le savoir-faire, sots, devenez raisonnables. 
###### 6
Écoutez, j'ai à vous dire des choses importantes, j'ouvre mes lèvres pour dire des paroles droites. 
###### 7
C'est la vérité que mon palais proclame, car le mal est abominable à mes lèvres. 
###### 8
Toutes les paroles de ma bouche sont justes, en elles rien de faux ni de tortueux. 
###### 9
Toutes sont franches pour qui les comprend, droites pour qui a trouvé le savoir. 
###### 10
Prenez ma discipline et non de l'argent, le savoir plutôt que l'or pur. 
###### 11
Car la sagesse vaut mieux que les perles, et rien de ce que l'on désire ne l'égale. " 
###### 12
" Moi, la Sagesse, j'habite avec le savoir-faire, je possède la science de la réflexion. 
###### 13
La crainte de Yahvé est la haine du mal. Je hais l'orgueil et l'arrogance, la mauvaise conduite et la bouche torse. 
###### 14
A moi appartiennent le conseil et la prudence, je suis l'entendement, à moi la puissance! 
###### 15
Par moi règnent les rois et les nobles décrètent le droit; 
###### 16
par moi gouvernent les princes et les grands, les juges légitimes. 
###### 17
J'aime ceux qui m'aiment, qui me cherche avec empressement me trouve. 
###### 18
Chez moi sont la richesse et la gloire, les biens stables et la justice. 
###### 19
Mon fruit est meilleur que l'or, que l'or fin, mes produits meilleurs que le pur argent. 
###### 20
Je marche dans le chemin de la justice, dans le sentier du droit, 
###### 21
pour procurer des biens à ceux qui m'aiment, et remplir leurs trésors. 
###### 22
" Yahvé m'a créée, prémices de son œuvre, avant ses œuvres les plus anciennes. 
###### 23
Dès l'éternité je fus établie, dès le principe, avant l'origine de la terre. 
###### 24
Quand les abîmes n'étaient pas, je fus enfantée, quand n'étaient pas les sources aux eaux abondantes. 
###### 25
Avant que fussent implantées les montagnes, avant les collines, je fus enfantée; 
###### 26
avant qu'il eût fait la terre et la campagne et les premiers éléments du monde. 
###### 27
Quand il affermit les cieux, j'étais là, quand il traça un cercle à la surface de l'abîme, 
###### 28
quand il condensa les nuées d'en haut, quand se gonflèrent les sources de l'abîme, 
###### 29
quand il assigna son terme à la mer - et les eaux n'en franchiront pas le bord -, quand il traça les fondements de la terre, 
###### 30
j'étais à ses côtés comme le maître d'œuvre, je faisais ses délices, jour après jour, m'ébattant tout le temps en sa présence, 
###### 31
m'ébattant sur la surface de sa terre et trouvant mes délices parmi les enfants des hommes. 
###### 32
" Et maintenant, mes fils, écoutez-moi : Heureux ceux qui gardent mes voies! 
###### 33
Écoutez l'instruction et devenez sages, ne la méprisez pas. 
###### 34
Heureux l'homme qui m'écoute, qui veille jour après jour à mes portes pour en garder les montants! 
###### 35
Car qui me trouve trouve la vie, il obtient la faveur de Yahvé; 
###### 36
mais qui pèche contre moi blesse son âme, quiconque me hait chérit la mort. " 
