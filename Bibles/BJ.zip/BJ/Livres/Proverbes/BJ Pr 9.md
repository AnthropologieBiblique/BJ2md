---
aliases : 
- Proverbes 9
- Proverbes 9
- Pr 9
- Proverbs 9
tags : 
- Bible/Pr/9
- français
cssclass : français
---

# Proverbes 9

###### 1
La Sagesse a bâti sa maison, elle a taillé ses sept colonnes, 
###### 2
elle a abattu ses bêtes, préparé son vin, elle a aussi dressé sa table. 
###### 3
Elle a dépêché ses servantes et proclamé sur les buttes, en haut de la cité : 
###### 4
" Qui est simple ? Qu'il passe par ici! " A l'homme insensé elle dit : 
###### 5
" Venez, mangez de mon pain, buvez du vin que j'ai préparé! 
###### 6
Quittez la niaiserie et vous vivrez, marchez droit dans la voie de l'intelligence. " 
###### 7
Qui corrige un railleur s'attire le mépris, qui reprend un méchant le déshonneur. 
###### 8
Ne reprends pas le railleur, il te haïrait, reprends le sage, il t'aimera. 
###### 9
Donne au sage : il deviendra plus sage encore; instruis le juste, il accroîtra son acquis. 
###### 10
Principe de la sagesse : la crainte de Yahvé! la science des saints, voilà l'intelligence. 
###### 11
Car par moi tes jours se multiplient et pour toi s'accroissent les années de vie. 
###### 12
Si tu es sage, tu l'es pour toi-même, si tu es railleur, toi seul en porteras la peine. 
###### 13
Dame Folie est impulsive, niaise et ne connaissant rien! 
###### 14
Elle s'assied à la porte de sa maison, sur un trône, en haut de la cité, 
###### 15
pour appeler les passants, ceux qui vont droit leur chemin. 
###### 16
" Qui est simple ? Qu'il fasse un détour par ici! " A l'homme insensé elle dit : 
###### 17
" Les eaux dérobées sont douces, et savoureux le pain du mystère! " 
###### 18
Or il ignore qu'il y a là des Ombres et que ses invités sont aux vallées du shéol. 
