---
aliases : 
- Proverbes 13
- Proverbes 13
- Pr 13
- Proverbs 13
tags : 
- Bible/Pr/13
- français
cssclass : français
---

# Proverbes 13

###### 1
Le fils sage écoute la discipline de son père, le railleur n'entend pas le reproche. 
###### 2
Par le fruit de sa bouche l'homme se nourrit de ce qui est bon, mais l'âme des traîtres se repaît de violence. 
###### 3
Qui veille sur sa bouche garde sa vie, qui ouvre grand ses lèvres se perd. 
###### 4
Le paresseux attend, mais rien pour sa faim; la faim des diligents est apaisée. 
###### 5
Le juste hait la parole mensongère, mais le méchant déshonore et diffame. 
###### 6
La justice garde celui dont la voie est honnête, le péché cause la ruine du méchant. 
###### 7
Tel joue au riche qui n'a rien, tel fait le pauvre qui a de grands biens. 
###### 8
Rançon d'une vie d'homme : sa richesse; mais le pauvre n'entend pas le reproche. 
###### 9
La lumière des justes est joyeuse, la lampe des méchants s'éteint. 
###### 10
Insolence n'engendre que chicane; chez qui accepte les conseils se trouve la sagesse. 
###### 11
Fortune hâtive va diminuant, qui amasse peu à peu s'enrichit. 
###### 12
Espoir différé rend le cœur malade; c'est un arbre de vie que le désir satisfait. 
###### 13
Qui méprise la parole se perdra, qui respecte le commandement sera sauf. 
###### 14
L'enseignement du sage est source de vie pour éviter les pièges de la mort. 
###### 15
Un grand bon sens procure la faveur, la voie des traîtres est dure. 
###### 16
Tout homme avisé agit à bon escient, le sot étale sa folie. 
###### 17
Messager malfaisant tombe dans le malheur, messager fidèle apporte la guérison. 
###### 18
Misère et mépris à qui abandonne la discipline, honneur à qui observe la réprimande. 
###### 19
Désir satisfait, douceur pour l'âme. Abomination pour les sots : se détourner du mal. 
###### 20
Qui chemine avec les sages devient sage, qui hante les sots devient mauvais. 
###### 21
Aux trousses du pécheur, le malheur; le bonheur récompense les justes. 
###### 22
Aux enfants de ses enfants l'homme de bien laisse un héritage, au juste est réservée la fortune des pécheurs. 
###### 23
Riche en nourriture, la culture des pauvres; il en est qui périssent faute d'équité. 
###### 24
Qui épargne la baguette hait son fils, qui l'aime prodigue la correction. 
###### 25
Le juste mange et se rassasie, le ventre des méchants crie famine. 
