---
aliases : 
- Proverbes 12
- Proverbes 12
- Pr 12
- Proverbs 12
tags : 
- Bible/Pr/12
- français
cssclass : français
---

# Proverbes 12

###### 1
Qui aime la discipline aime le savoir, qui hait la réprimande est stupide. 
###### 2
L'homme de bien attire la faveur de Yahvé, mais l'homme malintentionné, celui-ci le condamne. 
###### 3
On ne s'affermit pas par la méchanceté, mais rien n'ébranle la racine des justes. 
###### 4
Une maîtresse femme est la couronne de son mari, mais une femme indigne est comme une carie dans ses os. 
###### 5
Les desseins du juste sont équité, les machinations du méchant, tromperie. 
###### 6
Les paroles des méchants sont des pièges de sang, mais la bouche des hommes droits les délivre. 
###### 7
Jetés bas, les méchants ne sont plus, la maison des justes subsiste. 
###### 8
On fait l'éloge d'un homme selon son bon sens, le cœur tortueux est en butte aux affronts. 
###### 9
Mieux vaut un homme du commun qui a un serviteur qu'un homme qui se glorifie et manque de pain. 
###### 10
Le juste connaît les besoins de ses bêtes, mais les entrailles du méchant sont cruelles. 
###### 11
Qui cultive sa terre sera rassasié de pain, qui poursuit des chimères est dépourvu de sens. 
###### 12
L'impie se plaît au filet des méchants, mais la racine des justes rapporte. 
###### 13
Dans le forfait des lèvres, il y a un piège funeste, mais le juste se tire de la détresse. 
###### 14
Par le fruit de sa bouche l'homme se rassasie de ce qui est bon, on reçoit la récompense de ses œuvres. 
###### 15
Le chemin du fou est droit à ses propres yeux, mais le sage écoute le conseil. 
###### 16
Le fou manifeste son dépit sur l'heure, mais l'homme habile dissimule le mépris. 
###### 17
Celui qui révèle la vérité proclame la justice, le faux témoin n'est que tromperie. 
###### 18
Tel qui parle étourdiment blesse comme une épée, la langue des sages guérit. 
###### 19
La lèvre sincère est affermie pour jamais, mais pour un instant la langue trompeuse. 
###### 20
Au cœur de qui médite le mal : la fraude; aux conseillers pacifiques : la joie. 
###### 21
Au juste n'échoit nul mécompte, mais les méchants sont comblés de malheur. 
###### 22
Abomination pour Yahvé : des lèvres menteuses; il aime ceux qui pratiquent la vérité. 
###### 23
L'homme avisé cèle son savoir, le cœur des sots publie sa folie. 
###### 24
A la main diligente le commandement, la main nonchalante aura la corvée. 
###### 25
Une peine au cœur de l'homme le déprime, mais une bonne parole le réjouit. 
###### 26
Un juste montre la voie à son compagnon, la voie des méchants les égare. 
###### 27
L'indolence ne rôtit pas son gibier, mais la diligence est une précieuse ressource de l'homme. 
###### 28
Sur le sentier de la justice : la vie; le chemin des pervers mène à la mort. 
