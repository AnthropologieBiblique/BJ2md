---
aliases : 
- Proverbes 6
- Proverbes 6
- Pr 6
- Proverbs 6
tags : 
- Bible/Pr/6
- français
cssclass : français
---

# Proverbes 6

###### 1
Mon fils, si tu t'es porté garant envers ton prochain, si tu as topé dans la main en faveur d'un étranger, 
###### 2
si tu t'es lié par les paroles de ta bouche, si tu es pris aux paroles de ta bouche, 
###### 3
fais donc ceci, mon fils, pour te tirer d'affaire, puisque tu es tombé aux mains de ton prochain : Va, prosterne-toi, importune ton prochain, 
###### 4
n'accorde ni sommeil à tes yeux ni repos à tes paupières, 
###### 5
dégage-toi, comme du filet la gazelle, ou comme l'oiseau de la main de l'oiseleur. 
###### 6
Va voir la fourmi, paresseux! observe ses mœurs et deviens sage : 
###### 7
elle qui n'a ni magistrat, ni surveillant ni chef, 
###### 8
durant l'été elle assure sa provende, et amasse, au temps de la moisson, sa nourriture. 
###### 9
Jusques à quand, paresseux, resteras-tu couché ? Quand te lèveras-tu de ton sommeil ? 
###### 10
Un peu dormir, un peu s'assoupir, un peu croiser les bras en s'allongeant, 
###### 11
et, tel un rôdeur, viendra l'indigence, et la disette comme un mendiant. 
###### 12
Un vaurien, un homme inique, il va, la bouche torse, 
###### 13
clignant de l'œil, traînant les pieds, faisant signe des doigts. 
###### 14
La fourberie au cœur, méditant le mal en toute saison, il suscite des querelles. 
###### 15
Aussi, soudain viendra sa ruine, à l'instant il sera brisé, sans remède. 
###### 16
Il y a six choses que hait Yahvé, sept qui lui sont en abomination : 
###### 17
des yeux hautains, une langue menteuse, des mains qui répandent le sang innocent, 
###### 18
un cœur qui médite des projets coupables, des pieds empressés à courir au mal, 
###### 19
un faux témoin qui profère des mensonges, le semeur de querelles entre frères. 
###### 20
Garde, mon fils, le précepte de ton père, ne rejette pas l'enseignement de ta mère. 
###### 21
Fixe-les constamment dans ton cœur, noue-les à ton cou. 
###### 22
Dans tes démarches ils te guideront, dans ton repos ils te garderont, à ton réveil ils s'entretiendront avec toi. 
###### 23
Car le précepte est une lampe, l'enseignement une lumière; les exhortations de la discipline sont le chemin de la vie, 
###### 24
pour te préserver de la femme mauvaise, de la langue doucereuse d'une étrangère. 
###### 25
Ne convoite pas dans ton cœur sa beauté, ne te laisse pas prendre à ses œillades, 
###### 26
car à la prostituée suffit un quignon de pain, mais la femme mariée en veut à une vie précieuse. 
###### 27
Peut-on porter du feu dans son sein sans enflammer ses vêtements ? 
###### 28
Peut-on marcher sur des charbons ardents sans se brûler les pieds ? 
###### 29
Ainsi celui qui court après la femme de son prochain : qui s'y essaie ne s'en tirera pas indemne. 
###### 30
On ne méprise pas le voleur qui vole pour s'emplir l'estomac quand il a faim; 
###### 31
pourtant, s'il est pris, il rendra au septuple, il donnera toutes les ressources de sa maison. 
###### 32
Mais l'adultère est privé de sens, qui veut sa propre perte agit ainsi! 
###### 33
Il récolte coups et mépris, jamais ne s'effacera son opprobre. 
###### 34
Car la jalousie excite la rage du mari, au jour de la vengeance il sera sans pitié, 
###### 35
il n'aura égard à aucune compensation, il ne consentira à rien, même si tu multiplies les présents. 
