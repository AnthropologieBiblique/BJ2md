---
aliases : 
- Proverbes 10
- Proverbes 10
- Pr 10
- Proverbs 10
tags : 
- Bible/Pr/10
- français
cssclass : français
---

# Proverbes 10

###### 1
Proverbes de Salomon. Le fils sage réjouit son père, le fils sot chagrine sa mère. 
###### 2
Trésors mal acquis ne profitent pas, mais la justice délivre de la mort. 
###### 3
Yahvé ne laisse pas le juste affamé, mais il réprime la convoitise des méchants. 
###### 4
Main nonchalante appauvrit, la main des diligents enrichit. 
###### 5
Amasser en été est d'un homme avisé, dormir à la moisson est d'un homme indigne. 
###### 6
Bénédictions sur la tête du juste, mais la bouche des impies recouvre la violence. 
###### 7
La mémoire du juste est en bénédiction, le nom des méchants tombe en pourriture. 
###### 8
L'homme au cœur sage accepte les ordres, l'homme aux lèvres folles court à sa perte. 
###### 9
Qui va honnêtement va en sécurité, qui suit une voie tortueuse est démasqué. 
###### 10
Qui cligne de l'œil donne du tourment, qui réprimande en face procure l'apaisement. 
###### 11
Source de vie : la bouche du juste, mais la bouche des impies recouvre la violence. 
###### 12
La haine allume des querelles, l'amour couvre toutes les offenses. 
###### 13
Sur les lèvres de l'homme intelligent se trouve la sagesse, sur le dos de l'insensé, le bâton. 
###### 14
Les sages thésaurisent le savoir, mais la bouche du fou est un danger menaçant. 
###### 15
La fortune du riche, voilà sa place forte; le mal des faibles, c'est leur indigence. 
###### 16
Le salaire du juste procure la vie, le revenu du méchant, le péché. 
###### 17
Il marche vers la vie, celui qui garde la discipline; qui délaisse la réprimande se fourvoie. 
###### 18
Les lèvres du menteur couvrent la haine; qui profère une calomnie est un sot. 
###### 19
Abondance de paroles ne va pas sans offense; qui retient ses lèvres est avisé. 
###### 20
La langue du juste est pur argent, le cœur des méchants est de peu de prix. 
###### 21
Les lèvres du juste repaissent une multitude, mais les fous meurent faute de sens. 
###### 22
C'est la bénédiction de Yahvé qui enrichit, sans que l'effort y ajoute rien. 
###### 23
C'est un jeu pour le sot de s'adonner au crime, et pour l'homme intelligent de cultiver la sagesse. 
###### 24
Ce que redoute le méchant lui échoit, ce que souhaite le juste lui est donné. 
###### 25
Quand la tourmente a passé, plus de méchant! mais à jamais, le juste est établi. 
###### 26
Vinaigre aux dents, fumée aux yeux, tel est le paresseux pour qui l'envoie. 
###### 27
La crainte de Yahvé prolonge les jours, les années du méchant seront abrégées. 
###### 28
L'espoir des justes est joie, l'espérance des méchants périra. 
###### 29
La voie de Yahvé est un rempart pour l'homme honnête, pour les malfaisants, une ruine. 
###### 30
Jamais le juste ne sera ébranlé, mais les méchants n'habiteront pas le pays. 
###### 31
La bouche du juste exprime la sagesse, la langue perverse sera coupée. 
###### 32
Les lèvres du juste connaissent la bienveillance, la bouche des méchants la perversité. 
